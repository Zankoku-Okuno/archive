NAME = "grept"
VERSION = "0.3.3b"
AUTHOR = "Zankoku Okuno"
#FIXME for 0.4b, I should implement file/dir pruning and command-line pattern defs

from functools import reduce
import re

# === Clone perl's chomp ===
def chomp(input_str):
    assert 0 <= input_str.count('\n') <= 1
    if input_str and input_str[-1] == "\n":
        return input_str[:-1]
    else:
        return input_str


# === Define a simplified find interface ===

import os
from os import path

def find(root_path, file_pattern, recursive=False):
    if recursive:
        return reduce(lambda acc,i: acc + i, #SPIFFY
               [[path.join(node[0], file) for file in node[2] if file_pattern.match(file)]
                for node in os.walk(root_path)],
               [])
    else:
        return [path.join(root_path, file) for file in os.listdir(root_path)
                if not path.isdir(file) and file_pattern.match(file)]

# === Define a simplified grep interface ===

import fileinput
from struct import LineDetection, FileDetection

def grep(files, *tags):
    out = set()
    for filepath in files:
        results = _grep_one(filepath, *tags)
        if results:
            out.add(results)
    return out
def _grep_one(filepath, *tags):
    file = None
    accumulator = FileDetection(filepath, *tags)
    try:
        file, lineno = open(filepath), 0
        for line in file.readlines():
            lineno += 1
            for tag in tags:
                if tag.search(line):
                    accumulator.add(LineDetection(tag, lineno, chomp(line)))
    except IOError: #TODO report skipped files
        accumulator = None
    except UnicodeDecodeError: #TODO other encodings: prolly research needed
        accumulator = None
    finally:
        if file: file.close()
        return accumulator


def load_configuration_file(options):
    from parser import ConfigParser
    config = ConfigParser()
    if options.config is not None:
        config.parse_file(options.config)
    else:
        if path.exists('./.greptrc'): #WARN this ought to take account of comline-passed directory
            config.parse_file('./.greptrc')
        elif path.exists(path.expanduser('~/.greptrc')):
            config.parse_file(path.expanduser('~/.greptrc'))
        elif path.exists('/.greptrc'):
            config.parse_file('/.greptrc')
    return config

#REFAC settle on having things return a set or a list, but not one of either
def detect_default_veiws(veiw, config):
    if re.match(r"all\Z", veiw, re.IGNORECASE):
        return config['pattern']
    if re.match(r"\d+\+\Z", veiw):
        weight = int(re.match(r"(\d+)\+\Z", veiw).groups()[0])
        return [name for name in config['pattern'] if config.get('weight', name) >= weight]
    if re.match(r"\d+-\Z", veiw):
        weight = int(re.match(r"(\d+)-\Z", veiw).groups()[0])
        return [name for name in config['pattern'] if config.get('weight', name) <= weight]
    if re.match(r"\d+-\d+\Z", veiw):
        match = re.match(r"(\d+)-(\d+)\Z", veiw)
        low, high = int(match.groups()[0]), int(match.groups()[1])
        return [name for name in config['pattern'] if low <= config.get('weight', name) <= high]
    return None
def get_active_tag_names(options, config): #refac by splitting into view and tag_names functions
    veiw = config.get('profile', 'default.veiw') if options.veiw is None else options.veiw
    active_tag_names = detect_default_veiws(veiw, config)
    if active_tag_names is None:
        try:
            active_tag_names = config.get('veiw', veiw)
        except KeyError as ke:
            if veiw in config['pattern']:
                active_tag_names = {veiw}
            else:
                raise GreptError("Veiw '{0}' is not defined.".format(veiw))
    if options.tag:
        tag_flags = ','.join(options.tag).split(',')
        if options.veiw:
            tag_flags += active_tag_names
        active_tag_names = tag_flags #OPTZ by not building active_tag_names in the first place
        #TODO allow command-line definition of basic tags
    return active_tag_names

def get_active_tags(active_tag_names, config):
    from struct import Tag
    try:
        return {Tag(name, config.get('pattern', name), config.get('weight', name)) for name in active_tag_names}
    except KeyError as ke:
        raise GreptError("Tag {0} is not defined.".format(ke))

# === Error handling ===
class GreptError(Exception):
    pass

#TODO make a plugin version, not just the stand-alone