from main import *

def _attr_err(obj, attr):
    return AttributeError(
        "'{0}' object has no attribute '{1}'".format(
            obj.__class__.__name__, attr) )

class DottedIndex:
    def __init__(self, data=None):
        if data is None:
            data = dict()
        self.items = data

    def __setitem__(self, key, value):
        if not isinstance(key, str):
            raise KeyError(key)
        self.items.__setitem__(key, value)
    def __getitem__(self, key):
        if not isinstance(key, str):
            raise KeyError(key)
        possible = {_trim(key, i): self.items[i]
                     for i in self.items if _filter(key, i) }
        if not possible:
            raise KeyError(key)
        elif '' in possible:
            return possible['']
        else:
            return DottedIndex(possible)
    def __len__(self):
        return len(self.items)
    def __str__(self):
        return str(self.items)

#MAYBE find a way to make these only accesible by Dottedindex (staticmethod with double-underscore?)
def _filter(key, item):
    key_seq, item_seq = key.split('.'), item.split('.')
    if len(key_seq) > len(item_seq):
        return False
    for i in range(len(key_seq)):
        if key_seq[i] != item_seq[i]:
            return False
    else:
        return True
def _trim(key, item):
    assert _filter(key, item), "_trim(): {0} does not start with {1}".format(item, key)
    return '.'.join(item.split('.')[len(key.split('.')):])

class Configuration:
    index_class = DottedIndex
    def __init__(self):
        self.headings = dict()
        self.default = None
    def __getitem__(self, key):
        if key in self.headings:
            return self.headings[key]
        elif self.default:
            return self.default[key]
        else:
            self.headings[key] = self.index_class()
            assert key in self.headings
            return self[key]
    
    def __contains__(self, key):
        return key in self.headings or self.default and key in self.default

print("correct code:")

d = DottedIndex()
d['hi.bob'] = 3
d['bye'] = True
c = Configuration()
print(c['nope'])

#FIXME or at least write an essay on this
#TODO also write an essay on the __mro__-based proxied I tried
class BadIndex(DottedIndex):
    def __init__(self, data=dict()):
        self.items = data
class BadConfig(Configuration):
    index_class = BadIndex

print("incorrect code:")
d2 = BadIndex()
d2['hi.bob'] = 3
d2['bye'] = True
c2 = BadConfig()
print(c2['nope'])





