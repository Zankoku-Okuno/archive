#! /usr/bin/python3

import sys, os, re
from os import path
from main import *

from struct import Tag
from parser import comline
from printer import Printer

def determine_recurse(options, config):
    if options.r or options.R:
        if options.r and options.R:
            raise GreptError("Ambiguous command-line options '-rR'.")
        else:
            return options.r
    else:
        return config.get('profile', 'default.recurse')

if __name__ == '__main__':
    
# === Options and Configuration === #
    p = Printer()
    #MAYBE figure out how to catch any exceptions this might raise
    options = comline.parse_args(sys.argv[1:])
    
    print(options) #DEBUG
    
    #load up the configuration file
    try:
        config = load_configuration_file(options)
    except GreptError as ge:
        p.abort(ge)
    
    #prime the printer with color if desired
    if not options.no_color:
        p.color = config.get('profile', 'color')
    
# === Setup Find Arguments === #
    #find what sorts of files to search
    try:
        _recurse = determine_recurse(options, config)
        if not path.exists(options.dir):
            raise GreptError("Path '{0}' does not exist.".format(options.dir))
    except GreptError as ge:
        p.abort(ge)
        
    extensions = [ ext.strip() for ext in
                  (','.join(options.ext) if options.ext
                   else config.get('profile', 'default.extensions')
                  ).split(',') ]
    if "*" in extensions:
        _pattern = re.compile(r".+\Z") #HAX should allow the find command to deal with having a None pattern
    else:
        _pattern = re.compile(r"[^.].*\.(?:{0})\Z".format('|'.join(extensions)), re.IGNORECASE)
    
    #get some basic info for find
    
    #TODO prune out directories and ignore files
    #TODO auto-prune hidden files/directories
    
# === Setup Grep Arguments === #
    #find out what veiw/tags are being searched for
    try:
        tags = get_active_tags(get_active_tag_names(options, config), config) #REFAC maybe
    except GreptError as ge:
        p.abort(ge)
        
# === Search and Destroy, err, Display === #
    if config.get('profile', 'welcome'):
        p.print_greeting(config.get('profile', 'name'))
    
    #MAYBE print out the option set
    
    #find all the files in the system
    from time import clock
    t_i = clock()
    filenames = find(options.dir, _pattern, _recurse)
    detections = grep(filenames, *tags)
    t_f = clock()
    
    if config.get('profile', 'timeit'):
        p.print_statistics(len(filenames), t_f - t_i)
    p.print_all_detections(detections)
    
    summary = config.get('profile', 'summary') if options.s is None else options.s
    #REFAC into a print_summary() method
    if summary >= 1:
        p.print_summary1(tags, detections)
    
    #MAYBE maintain a little (or growing) history file so that the user can see how far their code has come
    #if so, I'll need grept --clear-history