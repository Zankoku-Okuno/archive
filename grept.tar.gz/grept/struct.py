from functools import reduce
#   ================
# -- Configurations --
#   ================ 

#TODO a configuration that can support defaults

class Configuration:
    def __init__(self):
        self.headings = dict()
        #WARN allow for possible headings, moving error-checking away from the parser
    def __getitem__(self, key):
        if key in self.headings:
            return self.headings[key]
        else:
            self.headings[key] = DottedIndex()
            assert key in self.headings
            return self[key]
    def __contains__(self, key):
        return key in self.headings or self.default and key in self.default
    
    def __str__(self):
        return '\n'.join({"[{0}] {1}".format(i, self.headings[i]) for i in self.headings})

class DottedIndex:
    def __init__(self, data=None): #HAX why does this not work if data=dict()? @below
        if data is None:
            data = dict()
        self.items = data
#d = DottedIndex()
#d['hi.bob'] = 3
#d['bye'] = True
#c = Configuration()
#print(c['nope'])
    
    def __setitem__(self, key, value):
        if not isinstance(key, str):
            raise KeyError(key)
        self.items.__setitem__(key, value)
    def __getitem__(self, key):
        if not isinstance(key, str):
            raise KeyError(key)
        possible = {_trim(key, i): self.items[i]
                     for i in self.items if _filter(key, i) }
        if not possible:
            raise KeyError(key)
        elif '' in possible:
            return possible['']
        else:
            return DottedIndex(possible)
    def __len__(self):
        return len(self.items)
    def __str__(self):
        return str(self.items)
    def __iter__(self):
        return self.items.__iter__()

#MAYBE find a way to make these only accesible by Dottedindex (staticmethod with double-underscore?)
def _filter(key, item):
    key_seq, item_seq = key.split('.'), item.split('.')
    if len(key_seq) > len(item_seq):
        return False
    for i in range(len(key_seq)):
        if key_seq[i] != item_seq[i]:
            return False
    else:
        return True
def _trim(key, item):
    assert _filter(key, item), "_trim(): {0} does not start with {1}".format(item, key)
    return '.'.join(item.split('.')[len(key.split('.')):])

#   ==============
# -- grep Results --
#   ==============

from main import chomp

class LineDetection:
    def __init__(self, tag, lineno, linedata):
        self.tag, self.lineno, self.line = tag, lineno, linedata
class TagDetection:
    def __init__(self, weight, tag_name, *line_detections):
        self.name = tag_name
        self.weight = weight
        self.lines = set(line_detections)
    def add(self, line_detection):
        self.lines.add(line_detection)
    def __iter__(self):
        return self.lines.__iter__()
    def __len__(self):
        return len(self.lines)
class FileDetection:
    def __init__(self, file, *tags):
        self.file = file
        self._all = {tag: TagDetection(tag.weight, tag.name) for tag in tags}
    def add(self, line_detection):
        self._all[line_detection.tag].add(line_detection)
    def __len__(self):
        return reduce(lambda acc, key: acc + len(self._all[key]), self._all, 0)
    def __iter__(self):
        return self.__next__()
    def __next__(self):
        for tag_detect in self._all.values():
            yield tag_detect
    def __getitem__(self, index):
        return self._all[index]

#   ======
# -- Misc --
#   ======

class Tag:
    def __init__(self, name, pattern, weight):
        self.name, self.regex, self.weight = name, pattern, weight
    def search(self, input):
        return self.regex.search(input)
    def match(self, input):
        return self.regex.match(input)
    def sub(self, replacement, input):
        return self.regex.sub(replacement, input)


