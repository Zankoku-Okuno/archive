import sys
from main import *

import colorama
colorama.init()

BRIGHT = colorama.Style.BRIGHT
DIM = colorama.Style.DIM

BLUE = colorama.Fore.BLUE
YELLOW = colorama.Fore.YELLOW
RED = colorama.Fore.RED

def _enclose(string, code, reset=''):
    return "{0}{1}{2}".format(code, string, reset)
def _colorize(string, code, reset=colorama.Fore.RESET):
    return _enclose(string, code, reset)
def _stylize(string, code, reset=colorama.Style.NORMAL):
    return _enclose(string, code, reset)


_NO_RESULTS = "No results were found."

class Printer:
    stream = sys.stdout
    def __init__(self, colorize=False):
        self.color = colorize
    
    def colorize(self, string, code=colorama.Fore.RESET):
        return _colorize(string, code) if self.color else string
    def stylize(self, string, code=colorama.Style.NORMAL):
        return _stylize(string, code) if self.color else string
    
    def println(self, *inputs):
        print(*inputs, sep='', end='\n', file=self.stream)
    def print(self, *inputs):
        print(*inputs, sep='', end='', file=self.stream)
    
    def print_greeting(self, name):
        self.println(self.stylize("{0}, bonsoir.".format(name), BRIGHT))
        self.println("  > This is {0} {1}.".format(NAME, VERSION))
        self.println("      by {0}".format(AUTHOR))
    
    def print_statistics(self, num_files, dt):
        self.println("Searched {0} files in {1} milliseconds.".format(num_files, int(1000*dt)))
    
    def print_all_detections(self, detection):
        #MAYBE make sorting different, right now the policy is ure alphabetical on pathname
        if not detection:
            self.println(self.stylize(_NO_RESULTS, BRIGHT))
        for file in sorted(detection, key=lambda x: x.file):
            self.print_file_detection(file)
    
    def print_file_detection(self, detection):
        self.println(self.colorize(self.stylize(detection.file, BRIGHT), RED))
        for tag in sorted(detection, key=lambda x: x.weight, reverse=True):
            self.print_tag_detection(tag)
    
    def print_tag_detection(self, detection):
        for line in sorted(detection, key=lambda x: x.lineno):
            self.print_line_detection(line)
    
    def print_line_detection(self, detection):
        self.println(self.format_line(detection.tag, detection.line, detection.lineno))
    
    def format_line(self, tag, line, lineno):
        #MAYBE allow custom color schemes
        #build the strings
        lineno = "  >{0}{1}| ".format(_add_spaces(lineno), lineno)
        line = line.strip()
        #make sure the output fits on a std-len line (80)
        window = 80 - len(lineno) #TODO allow for differing window sizes in options
        #FIXME consider a tag more than ~45 chars in with a lot of chars after it: the tag gets pushed ahead of the window. We must find the word, then put the window around IT
        if len(line) > window:
            start, end = tag.search(line).span()
            if start > window//2:
                line = line[min(end-window//2, -window):]
            if len(line) > window:
                line = line[:window-3]+'...'
        return self.stylize(lineno, DIM) + tag.sub(self.colorize(r"\1", BLUE), line)
    
    def print_summary1(self, searched_tags, detection): #OPTZ
        self.println()
        self.println(self.colorize(self.stylize("Summary:", BRIGHT), BLUE))
        longest_tag_length = max({len(tag.name) for tag in searched_tags})
        total_found = reduce(lambda acc, i: acc+len(i), detection, 0)
        for tag in sorted(searched_tags, key=lambda x: x.weight, reverse=True):
            self.print(' '*4, tag.name, ': ', ' '*(longest_tag_length-len(tag.name)))
            self.println(reduce(lambda acc, file: acc+len(file[tag]), detection, 0))
            #MAYBE print percentages and left-align numbers
        self.println(self.stylize(" Total: {0}".format(total_found), BRIGHT))
        #MAYBE color this
    
    def abort(self, ex):
        self.println(self.colorize(self.stylize("Aborting.", BRIGHT), YELLOW))
        self.println(self.colorize(ex, YELLOW))
        exit(-1)

def _add_spaces(lineno, maxlen=4):
    #TODO maxlen calculate maxlen once per file
    return ' '*(maxlen-len(str(lineno)))
