===========
== About ==
===========

grept is a command-line utility written in Python3k. It searches for tags (i.e.
TODO, FIXME, &c) in source code files and nicely organizes and displays the
results.

The program is meant to be highly configurable, it may be instructed to
include/exclude particular types of files and/or directories while searching for
any number of user-defined regular expressions.

===================
== Prerequisites ==
===================

grept requires a Python3 Interpreter, of which many are freely available.

TODO make sure that the she-bang can actually find the interpreter

===================
== Configuration ==
===================

A sample configuration file comes with the program (.greptrc). Until I write a
tutorial, just use that as a template, referring to the source code for anythong
you aren't sure about.

TODO a configuration tutorial

=======================
== Copyright Notices ==
=======================

Copyright 2012 Okuno Zankoku
All rights reserved.

Released under the GNU GPLv3

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.


This program makes use of Jonathan Hartley's colorama library, which is relased
under the New BSD Liscence. A copy of this liscence should be included in this
distribution.


