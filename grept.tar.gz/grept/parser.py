from main import *

#   ==============
# -- Command Line --
#   ==============
import argparse

__desc = "Search through directories/projects to find tags in source code."

comline = argparse.ArgumentParser(description=__desc)
#DOC an epilogue that explains all sorts of shit about configuration

# Positionals
comline.add_argument("veiw", nargs='?',
                     help="name a predefined set of tags or a single tag for which to search")
comline.add_argument("dir", nargs='?', default='.',
                     help="specify a search directory relative to the current one")

# Flags
comline.add_argument("-v", "--version", action='version',
                     version="{0} {1} -- {2}".format(NAME, VERSION, AUTHOR))

comline.add_argument("-r", action='store_true',
                     help="[default] search through directories recursively")
comline.add_argument("-R", action='store_true',
                     help="only search in this directory")
comline.add_argument("--no-color", action='store_true',
                     help="only search in this directory")

# Parameters
comline.add_argument("-c", "--config",
                    help="specify a configuration file")
comline.add_argument("-e", "--ext", action='append',
                     help="specify the extensions of files to search")
comline.add_argument("-s", action='count',
                     help="print a summary of the results")
#MAYBE -s, -ss, -sss... for print a summary of a given detail
comline.add_argument("-t", "--tag", action='append',
                     help="specify tags by name for which to search")
#TEST specify extensions to search/ignore
#TODO path/file pruning (-p for directories and -i for files), accepts glob
#TODO specify custom patterns with the advanced syntax MAYBE also a modified basic syntax
#TODO extra help that shows what veiw&pattern names are available



#    ================
# --  Parser Helpers --
#    ================

import re
from struct import DottedIndex, Configuration

_NONE = 0
_PROFILE = 1
_ADVANCED = 2
_BASIC = 3
_LEVEL = 4

def _burn_microcode(obj):
    return {
        _NONE: lambda key, value: None, #MAYBE raise an error
        _PROFILE: obj._profile_callback,
        _BASIC: obj._basic_callback,
        _ADVANCED: obj._advanced_callback,
        _LEVEL: obj._veiw_callback
    }

def _parse_line(line):
    #OPTZ compile these elsewhere
    if line and line[-1] == '\n':
        line = line[:-1]
    attempt = re.match(r"\s*(?:[#;].*)?\Z", line)
    if attempt:
        return None, None
    attempt = re.match(r"\s*\[(\w+)\]\s*\Z", line)
    if attempt:
        return _parse_header(attempt.groups()[0]), None
    attempt = re.match(r"\s*([.\w_-]+)\s*[:=]\s*(\S.*)\Z", line)
    if attempt:
        return _parse_feild(attempt.groups()[0]), attempt.groups()[1].strip()
    raise ConfigParseError("unknown line:\n\t{0}".format(line))

__STATE_MAP = {
    'profile': _PROFILE,
    'advanced': _ADVANCED,
    'basic': _BASIC,
    'veiw': _LEVEL 
}
__VALID_HEADER = re.compile(r"(?:{0})\Z".format('|'.join(__STATE_MAP.keys())), re.IGNORECASE)
def _parse_header(name):
    if not __VALID_HEADER.match(name):
        raise ConfigParseError("invalid header '{0}'".format(name))
    return __STATE_MAP[name]
    
def _parse_feild(name):
    if re.match(r"\w[\w_-]*(?:\.\w[\w_-]*)*\Z", name):
        return name
    else:
        raise ConfigParseError("invalid feild '{0}'".format(name))

def _parse_flags(flags):
    settings = [0,0,0,0]
    def deal_with_flags(input, char, cChar, index):
        def set_flag(c, v):
            if input == c:
                if settings[index]:
                    raise ConfigParseError("invalid flags '{0}'".format(flags))
                settings[index] = v
                return True
        return set_flag(char, 1) or set_flag(cChar, -1)
    for char in flags:
        deal_with_flags(char, 'a', 'A', 0) or \
        deal_with_flags(char, 'b', 'B', 1) or \
        deal_with_flags(char, 'c', 'C', 2) or \
        deal_with_flags(char, 'i', 'I', 3)
    out = 0
    if settings[0] == 1:
        out |= re.ASCII #TESTME
    if settings[3] == 1:
        out |= re.IGNORECASE
    return out, settings[2] != -1, settings[3] == 1

def _parse_uint(val):
    try:
        out = int(val)
        if out < 0:
            raise ValueError()
    except ValueError:
        raise ConfigParseError("Cannot parse '{0}' as a non-negative integer.".format(val))
    return out

def _parse_bool(val):
    if re.match(r"(?:1|y(?:es)?|t(?:rue)?)\Z", val, re.IGNORECASE):
        return True
    if re.match(r"(?:0|no?|f(?:alse)?)\Z", val, re.IGNORECASE):
        return False
    raise ConfigParseError("Cannot parse '{0}' as a boolean.".format(val))

def _parse_delimited_list(delimited):
    #WARN have some validation (like, values only have [\w._-] allowed)
    return [item.strip() for item in delimited.split(',')]
    #TODO allow level inheritance (like 'clean = basic,delete')

class ConfigParseError(GreptError):
    pass


#   ====================
# -- Configuration File --
#   ====================

class ConfigParser: #REFAC make this parser more general, like the comline parser
    def __init__(self):
        self.options = Configuration()
        self.defaults = Configuration()
        self.__state = _NONE
        self.__microcode = _burn_microcode(self)
        self._set_defaults()
    
    def get(self, header, *keys):
        try:
            return self.options[header]['.'.join(keys)]
        except KeyError:
            return self.defaults[header]['.'.join(keys)]
    def mov(self, value, header, *keys):
        self.options[header]['.'.join(keys)] = value
    
    def __getitem__(self, header):
        """Returns the keys defined under the passed header"""
        out = set()
        for key in self.defaults[header]:
            out.add(key)
        for key in self.options[header]:
            out.add(key)
        return out
    
    def parse_file(self, path):
        file = None
        try:
            file = open(path)
            lineno = 0
            for line in file:
                lineno += 1
                try:
                    self.parse_line(chomp(line))
                except ConfigParseError as ex:
                    raise ConfigParseError(
                        """Invalid syntax in configuration file, line {0}:
    {1}""".format(lineno, ex)
                        )
        except IOError:
            raise GreptError("""Cannot open file '{0}'.""".format(path))
        finally:
            if file: file.close()
    
    def parse_line(self, line):
        key, value= _parse_line(line)
        if key is None:         #found blank/comment line
            pass
        elif value is None:     #found a header
            self.__state = key
        else:                   #found a key/value pair
            self.__microcode[self.__state](key, value)
    
    def _profile_callback(self, key, value):
        #WARN validate keys
        if key in {'color', 'timeit', 'welcome', 'default.recurse'}:
            value = _parse_bool(value)
        if key in {'summary'}:
            value = _parse_uint(value)
        self.options['profile'][key] = value
    def _basic_callback(self, key, value):
        try:
            weight = int(value)
            if weight < 0: raise ValueError()
            self.options['weight'][key] = weight
            self.defaults['pattern'][key] = re.compile(r"\b({0})\b".format(key), re.IGNORECASE)
        except ValueError:
            raise ConfigParseError("weight '{0}' must be a non-negative integer".format(value))
    def _advanced_callback(self, key, value): #TEST
        match = re.match(r"/(.+)/([AaCcIi]*)(\d*)\Z", value)
        if not match:
            raise ConfigParseError("invalid pattern definition: '{0}'.".format(value))
        flags, word_break, comment_only = _parse_flags(match.groups()[1])
        #TODO comment-only, force word
        try:
            filtered = r"\b({0})\b".format(
                re.sub(r"(?<!\\)\\\d+", "",
                       re.sub(r"(?<!\\)\((?!\?)", "(?:",
                              match.groups()[0]))
                )
            self.options['pattern'][key] = re.compile(filtered, flags)
        except re.error as ex:
            raise ConfigParseError("Failed to compile /{0}/ because of {1}.".format(match.groups()[0], ex))
        if match.groups()[2]:
            self.options['weight'][key] = int(match.groups()[2])
        else:
            self.defaults['weight'][key] = -1
    def _veiw_callback(self, key, value):
        self.options['veiw'][key] = _parse_delimited_list(value)
        #MAYBE check that the values actually exist, though not necessarily right here
    
    def _set_defaults(self):
        self.defaults['profile']['name'] = "Mesdames, messieurs"
        self.defaults['profile']['welcome'] = True
        self.defaults['profile']['default.extensions'] = "*"
        self.defaults['profile']['default.recurse'] = True
        self.defaults['profile']['default.veiw'] = 'all'
        self.defaults['profile']['color'] = True
        self.defaults['profile']['timeit'] = True
        self.defaults['profile']['summary'] = 0
        #MAYBE specify a default.directory here, along with changes to the comline parser
        #WARN need a default for everything




