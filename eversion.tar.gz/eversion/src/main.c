#include "crypto.h"
#include "espace.h"
#include "hardware.h"
#include "loader.h"
#include "machine.h"
#include "opcodes.h"
#include "thread.h"
#include "uarch.h"

#include <stdio.h>

int main(int argc, char** argv) {
	printf("%d\n", 1 >> 1);
	return 0;
}


/*

data structures:
	code plane
	register set
	thread tree
	i/o streams
processes:
	something to read in a binary file and find PH, l, n, N
	execution cycle
	fetch-decode-execute
	thread management
plugin hooks:
	cryptographic functions




 == module structure ==

loader (machine startup) -> espace thread
machine (cycling, scarce resources) -> espace hardware thread crypto
espace (indexing into the code plane)
thread (thread tree+management) -> uarch
uarch (register sets, fde-loop) -> hardware opcodes
hardware (n-vectors, stacks, registers, dequeues, i/o sockets)
opcodes (semantics for each instruction)
crypto/
	white
	...

*/