#include "hardware.h"

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

static const unsigned int bits_per_word = 8*sizeof(unsigned int);

bit peek_stack(stack* this) {
	assert(this->depth > 0);
	unsigned int block =  this->depth / bits_per_word,
	             elem  =  this->depth % bits_per_word;
	return (this->data[block] >> elem) & 1;
}
bit pop_stack(stack* this) {
	bit out = peek_stack(this);
	--this->depth;
	return out;
}
void push_stack(stack* this, bit value) {
	assert(value == 0 | value == 1);
	//find insert location
	++this->depth;
	unsigned int block =  this->depth / bits_per_word,
	             elem  =  this->depth % bits_per_word;
    //make sure we have space
	if (block == this->block_capacity) {
		void* new_data = realloc(this, (this->block_capacity *= 2) * sizeof(unsigned int));
		assert(new_data);
		if (new_data) this->data = new_data;
		else {
			sprintf(stderr, "FATAL ERROR: out of memory\n");
			abort();
		}
	}
	//perform insert
	if (value)
		 this->data[block] |=  1 << elem;
	else this->data[block] &= ~1 << elem;
}

//void push_stack(stack self, bit value);