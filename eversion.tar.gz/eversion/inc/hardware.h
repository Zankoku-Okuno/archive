#ifndef __HARDWARE_H__
#define __HARDWARE_H__

extern unsigned int dimention;
extern unsigned int extent;

typedef unsigned int bit;
typedef unsigned int index;
typedef unsigned int reg4;
typedef unsigned int reg13;

typedef struct {
	unsigned int data[13];
} vector;

typedef struct {
	unsigned int depth;
	unsigned int block_capacity;
	unsigned int* data;
} stack;

typedef struct {
	unsigned int depth;
	vector* data;
} vec_stack;

typedef struct {
	reg4 data[13];
} cir_queue;

typedef struct {
	unsigned int active;
	unsigned int value;
} iobuffer;


bit peek_stack(stack*);
bit pop_stack(stack* this);
void push_stack(stack*, bit);

#endif