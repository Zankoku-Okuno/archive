#ifndef __UARCH_H__
#define __UARCH_H__

#include <assert.h>

typedef struct {
	stack general[13];

	vector iv;
	vector ix;
	vec_stack fp;
	vector jp;

	unsigned int tc;
	reg13 cc;
	cir_queue hc;
}* Register;

inline
bit peek_R(Register r, index which) {
	assert(which < dimention);
	return peek_stack(&r->general[which]);
}
inline
bit pop_R(Register r, index which) {
	assert(which < dimention);
	return pop_stack(&r->general[which]);
}
inline
void push_R(Register r, index which, bit value) {
	assert(which < dimention);
	push_stack(&r->general[which], value);
}

#endif