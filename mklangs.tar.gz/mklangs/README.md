MkLangs
=======

Create empty projects in a variety of languages.

This repo is really just here to collect scripts that set up programming projects according to _my_ preferences.
Well, since it's a public repo, I may as well just give a couple of instructions and release it.

It's set up to use git/github through ssh. It also has my names &c hardcoded.

Configure
---------

Change the variables in the `.mkLangConfig` file.

_Do not forget this step!_ I don't want emails about projects I have nothing to do with, and you don't want to alienate your users by looking like an idiot.

If you want, you can also modify other facets of the setup:

  * Hello world programs.
  * How and what to put in version control.
  * Anything you friggin' want: shell is Turing-complete.

Install
-------

Probably you have a folder (or a handful of them) where you store all your projects. Put your configuration file in there.
Then, put all the `mk*.sh` scripts somewhere on your path.

Use
---

Go into your projects folder and execute one of the `mk*.sh` scripts. Follow directions.

Contribute
----------

If there's a language you like, but isn't included here, add an empty project template. I'm sure to pull it in.

If you're up for more of a challenge, you could always try to make the scripts more applicable.
Generalization could be done by supporting more repo locations, more VCSs, selectable empty projects, blah blah.

If wider applicability is added, then at all costs, avoid worse-is-better as the system grows.
This should probably mean porting to a real language, using a real configuration file, and so on.
