_generic_prefix = "[autofind] {}: {}\n > "
_error_prefix = _generic_prefix.format("ERROR", '{}')
_warn_prefix = _generic_prefix.format("WARNING", '{}')

class AutofindError(Exception):
    def __init__(self, file, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.file = file
    def __str__(self):
        return _error_prefix.format(self.file) + self.diagnose()

_conflict = """File '{}' is both included and excluded by name in '{}'.
\tincluded in: '{}'
\texcluded in: '{}'"""
class ExplicitConflictError(AutofindError):
    def __init__(self, input_file, product, conflict_file, include_line=None, exclude_line=None, *args, **kwargs):
        super().__init__(input_file, *args, **kwargs)
        self.product = product
        self.conflict_file = conflict_file
        if include_line is None or exclude_line is None:
            self.include_line, self.exclude_line = None, None
        else:
            self.include_line, self.exclude_line = include_line, exclude_line
    def diagnose(self):
        return _conflict.format(self.product, self.conflict_file,
                                self.include_line, self.exclude_line)

_syntax = """{}
\t'{}'"""
class SyntaxError(AutofindError):
    def __init__(self, file, line, *args, **kwargs):
        super().__init__(file, *args, **kwargs)
        self.line = line
    def diagnose(self):
        return _syntax.format(self.syntax_expectation, self.line)

class MacroSpellingError(SyntaxError):
    @property
    def syntax_expectation(self):
        return "Format of AF_DETECT macro is 'AF_MACRO(<variable>):\\n'."

class UserSubdirsError(SyntaxError):
    @property
    def syntax_expectation(self):
        return "'SUBDIRS' variable not allowed in autofind files: it should be automatically populated."

class NegationError(SyntaxError):
    @property
    def syntax_expectation(self):
        return "Expected named file list or detector statement after '!'."

#TODO error for if the user is trying to set SUBDIRS
#TODO error for if the user gets the syntax wrong for an AF_DETECT
#TODO error for if the user gets the syntax wrong in a line of the detect body
#TODO error for if the user gets the syntax wrong on the AF_CONGIG_FILES macro
#TODO error for if the user starts autofind in a directory with no autofind file