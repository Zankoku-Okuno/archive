#! /usr/bin/python3

from .common import *
from .utils import list_subdirs_rec, is_direct_child, ls_multiple_dirs
from .parsers import ac, af


def is_autofound(dir):
    "Whether the directory contains an autofind file."
    return path.exists(path.join(dir, af_file))

def has_af_update(dir):
    """Whether the directory's autofind file has been modified since the
    automake file was last regenerated."""
    if not path.exists(path.join(dir, am_file)):
        return True
    af = os.stat(path.join(dir, af_file)).st_mtime
    am = os.stat(path.join(dir, am_file)).st_mtime
    return af - am >= 0

def has_subdir_update(dir, structure):
    return True #STUB


def _main():
    found = list_subdirs_rec(os.getcwd(), is_autofound)
    ac.update_ac(found)
    for dir in found:
        if has_af_update(dir) or has_subdir_update(dir, found):
            try:
                with af.Generator(dir, found) as generate:
                    generate()
            except AutofindError as err:
                force_out_of_date = path.join(dir, am_file)
                if path.exists(force_out_of_date):
                    os.remove(force_out_of_date)
                print(err, file=sys.stderr)

if __name__ == '__main__':
    _main()



