
from ..common import *
from ..utils import ls_multiple_dirs, list_subdirs_rec, normjoin


class _Accumulator:
    "Helps aggregate all of the digested information from a AF_DETECT macro."
    def __init__(self, product):
        self.product = product
        self.input_line = None
        self.auto_files, self.explicit_files = dict(), dict()
        self.auto_exclude, self.explicit_exclude = dict(), dict()
    
    def _base_imm_op_(self, files, location):
        if isinstance(files, str):
            location[files] = self.input_line
        else:
            for file in files:
                location[file] = self.input_line
        return self
    def __iadd__ (self, files):
        "Adds the given file(s) to the list of explicitly included files."
        return self._base_imm_op_(files, self.explicit_files)
    def __isub__(self, files):
        "Adds the given file(s) to the list of explicitly excluded files."
        return self._base_imm_op_(files, self.explicit_exclude)
    def __imul__ (self, files):
        "Adds the given file(s) to the list of automatically included files."
        return self._base_imm_op_(files, self.auto_files)
    def __itruediv__(self, files):
        "Adds the given file(s) to the list of automatically excluded files."
        return self._base_imm_op_(files, self.auto_exclude)
    
    def compile(self):
        "Returns the set of all specified/detected source files."
        for conflict in self.explicit_files.keys() & self.explicit_exclude.keys():#TEST
            raise ExplicitConflictError(self.dir, self.product, conflict,
                                        self.explicit_files[conflict],
                                        self.explicit_exclude[conflict])
        excluded = self.auto_exclude.keys() | self.explicit_exclude.keys()
        found = self.auto_files.keys() - excluded | self.explicit_files.keys()
        return found

class _Printer:
    "Provides output formatting for a single product source detection."
    def __str__(self):
        files = self.compile()
        if not files: #TESTME
            #TODO make this a proper warning once I have a warning framework
            print("[autofind] WARNING: No files detected for variable '{}'.".format(self.name))
        else:
            return self.product + " = " + ' '.join(files)

af_detection_start = re.compile(r"\s*AF_DETECT\s*\(\s*([A-Za-z_]+)\s*\)\s*:\s*$", re.IGNORECASE)
af_director = re.compile(r"\t|    |\s*(?:#|$)")

af_in_with = re.compile(r"IN\s+(.*)\s+WITH\s+(.*)$", re.IGNORECASE)
af_at_with = re.compile(r"AT\s+(.*)\s+WITH\s+(.*)$", re.IGNORECASE)
af_exclude = re.compile(r'!\s*(.*)$')
af_empty = re.compile(r'\s*(?:#|AF_DETECT|$)')

class AF_DETECT(_Accumulator, _Printer):
    @staticmethod
    def is_new_detector(line, file):
        "Whether the passed line is the first line of an AF_DETECT macro."
        if line.startswith("AF_DETECT"):
            syntax_check = af_detection_start.match(line)
            if not syntax_check:
                raise MacroSpellingError(file, chomp(line))
            return syntax_check
        else:
            return False
    @staticmethod
    def is_finished(line):
        """Whether the line is not a member of a (presumably) preceeding
        AF_DETECT macro body."""
        return not af_director.match(line)
    
    def __init__(self, macro_line, dir):
        product = af_detection_start.match(macro_line).groups()[0]
        super().__init__(product)
        self.dir = dir
    
    def __lshift__(self, line):
        """Interface for user to send data into the detector."""
        self._current_line = chomp(line)
        if '#' in line: line = line[:line.index('#')] #TEST
        self._parse(line.strip())
    
    def _parse(self, line, exclude=False):
        """Handle one line of AF_DETECT body."""
        if af_exclude.match(line):
            excluded = af_exclude.match(line).groups()[0].strip()
            if af_empty.match(excluded) or af_exclude.match(excluded):
                raise NegationError(path.join(self.dir, af_file), self._current_line) #TESTME
            self._parse(excluded, True)
        else:
            if af_in_with.match(line):
                autodetect, matcher = True, af_in_with
                dirs_in = lambda scope: list_subdirs_rec(normjoin(self.dir, scope))
            elif af_at_with.match(line):
                autodetect, matcher = True, af_at_with
                dirs_in = lambda scope: {normjoin(self.dir, scope)}
            else:
                autodetect = False
                #TODO allow space-delimited lists on one line
                #TODO allow backslash-escapes of space
                #TODO allow quoting
            self.input_line = line
            if autodetect:
                scope, pattern = matcher.match(line).groups()[0:2]
                found = ls_multiple_dirs(pattern, dirs_in(scope), self.dir)
                if not exclude: self *= found
                else: self /= found
            else:
                if not exclude: self += line
                else: self -= line
            self.input_line = None




