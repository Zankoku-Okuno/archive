import os, sys, shutil
from os import path
import glob, re
from functools import reduce, partial

#perhaps, I should createa a callable class (at least one argument: a root dir)
#this framework will perform a directory traversal
#   it performs a pre-action
#   it applies a filter to the list of subdirectories
#   if iterates into that filtered set
#   it performs a post-action
#this would replace list_subdirs_rec

def normjoin(*args):
    """Acts as path.join, but also normalizes the result."""
    return path.normpath(path.join(*args))

def ls_subdirs(dir=None):
    """Returns a collection of subdirectories contained directly in the passed
    directory.
    
    dir: defaults to '.'
    return: the paths all have dir prepended onto them."""
    if dir is None: dir = "./"
    return set(filter(path.isdir,
                      map(partial(normjoin, dir),
                          os.listdir(dir))))

def list_subdirs_rec(base, pred=lambda x: True):
    found, tip, grow = set(), {base}, set()
    while True:
        for dir in tip:
            if pred(dir):
                found.add(dir)
                grow |= ls_subdirs(dir)
        if not grow:
            break
        tip, grow = grow, set()
    return found

def is_direct_child(child, dir):
    """Test if child is contained in dir directly."""
    dir = path.abspath(path.normpath(dir)).split('/')
    child = path.abspath(path.normpath(child)).split('/')
    return len(child) == len(dir) + 1 and child[:-1] == dir


def ls_multiple_dirs(pattern, dirs, basepath=None):
    """Matches the pattern in all the passed dirs.
    
    pattern: a glob pattern to filter the children of each directory
    basepath: if set, the results are given relative to this path"""
    def ls_glob(dir, pattern):
        return glob.glob(path.join(dir, pattern))
    if basepath is None: #TEST
        ls_base = lambda dir, pattern: set(ls_glob(dir, pattern))
    else:
        ls_base = lambda dir, pattern: {path.relpath(x, basepath)
                                   for x in ls_glob(dir, pattern)}
    ls = lambda acc, x: acc | ls_base(x, pattern)
    return reduce(ls, dirs, set())
    