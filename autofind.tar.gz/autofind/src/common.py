# Useful Modules

import os, sys, shutil
from os import path
import re, glob
from functools import reduce, partial

from .errors import *

# Constants

af_file = "Makefile.af"
am_file = "Makefile.am"

# Utility functions

def chomp(self):
    """Removes one linefeed from the end of a string, provided there is one to
    remove. Recognizes LF, CR, and CR+LF."""
    if self.endswith('\r\n'):
        return self[:-2]
    elif any(map(self.endswith, '\n\r')):
        return self[:-1]