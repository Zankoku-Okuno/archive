import unittest

import os, shutil
from os import path

from src.autofind import _main as autofind

class TestConfigureUpdate(unittest.TestCase):
    def setUp(self):
        shutil.copy("../input_files/successful.af", "./bin/Makefile.af")
    def tearDown(self):
        os.remove("./bin/Makefile.af")
        os.remove("./configure.ac")
    def test_nonexistant(self):
        shutil.copy("../input_files/nonexistant.ac", "./configure.ac")
        autofind()
        self.assert_ac_updated()
        self.assert_bak_successful("../input_files/nonexistant.ac")
    def test_existant(self):
        shutil.copy("../input_files/existing.ac", "./configure.ac")
        autofind()
        self.assert_ac_updated()
        self.assert_bak_successful("../input_files/existing.ac")
    def test_af_macro(self):
        shutil.copy("../input_files/af_macro.ac", "./configure.ac")
        autofind()
        self.assert_ac_updated()
        self.assert_bak_successful("../input_files/af_macro.ac")
    def test_double(self):
        shutil.copy("../input_files/double.ac", "./configure.ac")
        autofind()
        self.assert_ac_updated(True)
        self.assert_bak_successful("../input_files/double.ac")

    def assert_ac_updated(self, double=False):
        cmp1 = ["AC_PREREQ([2.68])\n",
                "AC_INIT([FULL-PACKAGE-NAME], [VERSION], [BUG-REPORT-ADDRESS])\n",
                "AM_INIT_AUTOMAKE\n",
                "AC_CONFIG_SRCDIR([inc/hello.h])\n",
                "AC_CONFIG_HEADERS([config.h])\n",
                "AC_PROG_CC\n"]
        cmpaction = "AC_CONFIG_FILES([./Makefile bin/Makefile]) #"
        cmpdouble = "AC_CONFIG_FILES([README])\n"
        cmp2 = ["AC_OUTPUT\n"]
        with open("./configure.ac") as file:
            for cmp in cmp1:
                self.assertEqual(cmp, file.readline())
            self.assertTrue(file.readline().startswith(cmpaction))
            if double:
                self.assertEqual(cmpdouble, file.readline())
            for cmp in cmp2:
                self.assertEqual(cmp, file.readline())
    def assert_bak_successful(self, input):
        with open(input) as cmp:
            with open("./configure.ac.bak") as bak:
                for line in cmp.readlines():
                    self.assertEqual(line, bak.readline())
                self.assertEqual('', bak.readline())

class TestSuccessfulMakefile(unittest.TestCase):
    def setUp(self):
        shutil.copy("../input_files/successful.af", "./bin/Makefile.af")
        shutil.copy("../input_files/af_macro.ac", "./configure.ac")
        autofind()
    def tearDown(self):
        os.remove("./configure.ac")
        os.remove("./configure.ac.bak")
        os.remove("./Makefile.am")
        os.remove("./bin/Makefile.af")
        os.remove("./bin/Makefile.am")
    def test_passthrough(self):
        with open("./bin/Makefile.am") as file:
            cmp = ["#Passthrough test\n",
                   "MY_VAR = 3\n",
                   "rule: dependency\n",
                   "\techo 'Goodbyte, cruel world!'\n"]
            i, check = 0, False
            for line in file.readlines():
                if line == "#Passthrough test\n": check = True
                if check:
                    self.assertEqual(cmp[i], line)
                    i+=1
                if i >= len(cmp): break
            else: assert False
    def test_subdirs_variable(self):
        with open("./Makefile.am") as file:
            for line in file.readlines():
                if line.startswith("SUBDIRS"):
                    self.assertEqual(line, "SUBDIRS = bin\n")
                    break
            else:
                self.assertTrue(False)
        with open("./bin/Makefile.am") as file:
            for line in file.readlines():
                self.assertFalse(line.startswith("SUBDIRS"))
    #src
    #   extraneous_file.c           X
    #   hello.c                     <-
    #   module1
    #       include_me.c            <-
    #   module2
    #       do_not_include_me.c     X
    #       extra_file.c            <-
    #   notme.h                     X
    #inc
    #   hello.h                     <-
    #   notme.c                     X
    #   subinc
    #       notme.h                 X
    def test_found_files(self):
        with open("./bin/Makefile.am") as file:
            for line in file.readlines():
                if line.startswith("hello_SOURCES = "):
                    found = line[16:].split()
                    cmp = {'../inc/hello.h',
                           '../src/hello.c',
                           '../src/module1/include_me.c',
                           '../src/module2/extra_file.c'}
                    self.assertSetEqual(cmp, set(found))
                    break
            else:
                self.assertTrue(False)

from src.errors import *
from src.parsers import af

class TestFileDetectionErrors(unittest.TestCase):
    def setUp(self):
        shutil.copy("../input_files/af_macro.ac", "./configure.ac")
    def tearDown(self):
        if path.exists("./configure.ac"): os.remove("./configure.ac")
        if path.exists("./configure.ac.bak"): os.remove("./configure.ac.bak")
        if path.exists("./Makefile.am"): os.remove("./Makefile.am")
        if path.exists("./bin/Makefile.af"): os.remove("./bin/Makefile.af")
        if path.exists("./bin/Makefile.am"): os.remove("./bin/Makefile.am")
    def test_explicit_conflict(self):
        shutil.copy("../input_files/explicit_conflict.af", "./bin/Makefile.af")
        with self.assertRaises(ExplicitConflictError) as err:
            with af.Generator("./bin", {'.', './bin'}) as generate:
                generate()
        self.assertTrue("included in: '../src/extraneous_file.c'" in str(err.exception))
        self.assertTrue("excluded in: '../src/extraneous_file.c'" in str(err.exception))
    #def test_explicit_conflict(self):
    #    shutil.copy("../input_files/explicit_conflict.af", "./bin/Makefile.af")
    #    autofind()
    #    self.assertFalse(path.exists("./bin/Makefile.am")) #FIXME should actually test that the file is out-of-date

class TestSyntaxErrors(unittest.TestCase):
    def test_negate_empty(self):
        shutil.copy("../input_files/syntax1.af", "./bin/Makefile.af")
        with self.assertRaises(NegationError) as err:
            with af.Generator("./bin", {'.', './bin'}) as generate:
                generate()
        self.assertTrue("'\t!'" in str(err.exception))
    def test_double_negate(self):
        shutil.copy("../input_files/syntax2.af", "./bin/Makefile.af")
        with self.assertRaises(NegationError) as err:
            with af.Generator("./bin", {'.', './bin'}) as generate:
                generate()
        self.assertTrue("'\t!!../src/extraneous_file.c'" in str(err.exception))
    def test_double_negate(self):
        shutil.copy("../input_files/syntax3.af", "./bin/Makefile.af")
        with self.assertRaises(MacroSpellingError) as err:
            with af.Generator("./bin", {'.', './bin'}) as generate:
                generate()
        self.assertTrue("'AF_DETECT():'" in str(err.exception))




