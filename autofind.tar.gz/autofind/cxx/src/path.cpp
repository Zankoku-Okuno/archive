#include <string>
#include <iostream>
#include <vector>

using namespace std;
#include "path.hpp"

using namespace shutil;

#define pass (void)0
#define elif else if
#define forever while(true)
#define loop forever
#define until(cond) if (cond) break; else pass


Path::Path(string s) :
	nodes(),
	absolute(s[0] == '/')
{
	unsigned int i, j;
	for (i = j = absolute ? 1 : 0; j <= s.length(); ++j) {
		if (s[j] == '/' || j == s.length()) {
			if (i == j) pass;
			elif (i+1 == j && s[i] == '.') pass;
			elif (i+2 == j && s[i] == '.' && s[i+1] == '.' && nodes.size() > 0)
				nodes.pop_back();
			else
				nodes.emplace_back(s.substr(i, j-i));
			i = j+1;
		}
	}
}

ostream& shutil::operator <<(ostream& out, const Path& self) {
	bool leading_slash = self.absolute;
	for (auto s : self.nodes) {
		if (leading_slash) out << '/';
		else leading_slash = true;
		out << s;
	}
	return out;
}