#include <string>
#include <iostream>
#include <vector>
#include "path.hpp"

using namespace std;
using namespace shutil;

int main(int argc, char** argv) {
	cout << Path(argv[1]) << endl;
	return 0;
}