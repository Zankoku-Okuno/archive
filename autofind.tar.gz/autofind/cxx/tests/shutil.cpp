#include "UnitTest++.h"


#include <string>
#include <iostream>
#include <vector>

#include "path.hpp"
using namespace std;
using namespace shutil;

int main(int argc, char** argv) {
	UnitTest::RunAllTests();
	cout << Path("hi////../../there.py") << endl;
	return 0;
}