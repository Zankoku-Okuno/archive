#ifndef __PATH_HPP__
#define __PATH_HPP__
namespace shutil {

class Path {
public:
	friend std::ostream& operator <<(std::ostream&, const Path&);
	Path(std::string);
private:
	std::vector<std::string> nodes;
	bool absolute;
};
std::ostream& operator <<(std::ostream&, const Path&);

}
#endif