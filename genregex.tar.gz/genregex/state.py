"""States provide a way to organize and conduct Agents. Since states are
actually stateless (ironic, though predictable), they do not themselves store
agents, but are able to dispense outgoing agents based on 'incoming' agents:
those agents which the state has been told are apparently now at the state.

States are able to modify agents as the pass through. More technically, since an
agent is a container independent of all other agents, a state must be able to
make a copy of each incoming agent for all applicable outgoing transitions and
to perform a change on each of those outgoing agents.

The important method of a state is the update() method, which takes three
parameters. The first is a set of agents which are assumed to be currently in
the state. The second is the input symbol which is matched against transitions'
acceptance condition. The third is a transition table, assumed to contain the
state, to which the update method ought to delegate the task of determining
valid transitions. Finally, the method should return a set of agents. These
agents must be independent objects, both independent from each other and from
all the input agents.

The size() method should also be provided so that the number of states in a
machine can be counted. """

class BasicState: #RENAME NFAState
    """A state with a very simple update. An epsilon-nondeterministic finite
    automaton would be built entirely out of these states."""
    def update(self, agents, symbol, table): #REFAC ensure these arguments are ina good order
        new_states = {agent: table.get(self, symbol, agent) for agent in agents}
        new_agents = set()
        for agent in agents:
            for state in new_states[agent]:
                new_agents.add((state, agent.copy().glomb(symbol)))
        return new_agents
    
    def size(self):
        return 1

class CapturingState:
    pass #TODO




