# == Compiler ==

def compile(input):
    from stovokor.sed import Reader
    if input[:2] == '[^':
        inclusion = False
        input = input[2:-1]
    else:
        inclusion = True
        input = input[1:-1]
    parser = ClassParser()
    reader = Reader(tokenizer, parser)
    reader.feed(input)
    reader.eof()
    return parser.compile(inclusion)

# == Tokenizer Setup ==

from stovokor.local import DisjointAlphabet
from stovokor.quantum import Keyword
from stovokor.quantum import Delimiter
from stovokor.matcher import Driver

from . import textex_main_parser
_alphabet = DisjointAlphabet()
_keywords = {Keyword(delim.not_end) for delim in textex_main_parser._delimiters}
_range_char = '-'

tokenizer = Driver(_alphabet, _keywords, set(), set())

# == Parser ==

class ClassParser:
    def __init__(self):
        self.buffer = None
        self.range = False
        self.output = CharClass()
    def append(self, token):
        if len(token) == 2:
            token = token[1]
        if self.range:
            self.output.add(self.buffer, token)
            self.buffer = None
            self.range = False
        elif token == _range_char:
            self.range = True
        elif self.buffer is not None:
            self.output.add(self.buffer)
            self.buffer = token
        else:
            self.buffer = token
    def eof(self):
        if self.buffer is not None:
            self.output.add(self.buffer)
            self.buffer = None
        if self.range:
            self.output.add(_range_char)
            self.range = False
    def compile(self, inclusion=True):
        self.eof()
        return self.output.compile(inclusion)

# == Support ==

from ..rxconst import epsilon
class CharClass:
    def __init__(self):
        self.points = set()
        self.ranges = set()
    def add(self, code1, code2=None):
        if code2 is None:
            self.points.add(ord(code1))
        else:
            if code1 == code2:
                self.add(code1)
            if code2 < code1:
                code1, code2 = code2, code1
            self.ranges.add((ord(code1), ord(code2)))
    def compile(self, char_class=True):
        basic = lambda agent, symbol: symbol is not epsilon and \
                (ord(symbol) in self.points or \
                 exists(lambda r: r[0] <= ord(symbol) <= r[1], self.ranges))
        return basic if char_class else lambda agent, symbol: not basic(agent, symbol)

def exists(func, iterable):
    for item in iterable:
        if func(item):
            return True
    else:
        return False
