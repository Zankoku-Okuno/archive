from arboreum.tree import isleaf

from ..graph import Graph
from ..state import BasicState

from ..rxconst import epsilon_transition
from .textex import *

def compile(tree):
    out = Graph()
    last_i, last_f = set(), {BasicState()}
    out.initial_states |= last_f
    #last_i is what transisions connect to in a feedback scenario (genreally second-last created state)
    #last_f is where new transitions should start (generally last created state)
    for child in tree:
        if not isleaf(child):
            subgraph = compile(child)
            out.merge(subgraph)
            out.add_all(last_f, epsilon_transition, subgraph.initial_states)
            last_i, last_f = subgraph.initial_states, subgraph.final_states
        elif child is alternator:
            out.final_states |= last_f
            last_i, last_f = set(), {BasicState()}
            out.initial_states |= last_f
        elif child is option_mark:
            if not last_i:
                raise Exception() #TODO more specific
            last_f |= last_i
        elif child is kleene_star:
            if not last_i:
                raise Exception() #TODO more specific
            out.add_all(last_f, epsilon_transition, last_i)
            new = {BasicState()}
            out.add_all(last_i, epsilon_transition, new)
            last_i, last_f = set(), new
        elif child is kleene_plus:
            if not last_i:
                raise Exception() #TODO more specific
            out.add_all(last_f, epsilon_transition, last_i)
            last_i = set()
        else:
            new = {BasicState()}
            out.add_all(last_f, child, new)
            last_i, last_f = last_f, new
    out.final_states |= last_f
    return out




