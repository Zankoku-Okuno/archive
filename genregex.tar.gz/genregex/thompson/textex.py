
# ==============
# == Compiler ==
# ==============

def compile(input):
    input = _preprocess(input)
    parse_tree = _parse(input)
    if parse_tree._is_open:
        raise Exception() #TODO more specific
    return _compile(parse_tree)

def _preprocess(input): #REFAC this is used in the waterworks, too
    import re
    match = re.search(r'\\u([\dA-Fa-f]+);', input)
    while match:
        replace = match.groups()[0]
        input = re.sub(r'\\u{0};'.format(replace), chr(int(replace, 16)), input)
        match = re.search(r'\\u([\dA-Fa-f]+);', input)
    return input

def _parse(input):
    from . import textex_main_parser as mparse
    from stovokor.sed import AnnotatingReader
    parse = mparse.MainParser()
    tokenizer = AnnotatingReader(mparse.tokenizer, parse)
    tokenizer.feed(input)
    tokenizer.eof()
    return parse.tree

def _compile(tree):
    from . import construct
    return construct.compile(tree)

# ================
# == Background ==
# ================
from ..rxconst import _RXConst

kleene_star = _RXConst('kleene star')
kleene_plus = _RXConst('kleene plus')
alternator = _RXConst('alternator')
expr = _RXConst('expr')
end = _RXConst('end expr')
special = _RXConst('special')
capture = _RXConst('capture')
char_class = _RXConst('class')
anti_class = _RXConst('anticlass')
end_class = _RXConst('end class')

#TODO more features
option_mark = _RXConst('optional')

