from .textex import *
from stovokor.local import DisjointAlphabet
from stovokor.quantum import Keyword
from stovokor.quantum import Delimiter
from stovokor.matcher import Driver

# == Tokenizer Setup ==

_KEYWORD_LOOKUP = {
    '\\': special,
    '(': expr,
    ')': end,
    '|': alternator,
    '*': kleene_star,
    '+': kleene_plus,
    '?': option_mark
}

_DELIMITER_LOOKUP = {
    '[': char_class,
    '[^': anti_class
}

_alphabet = DisjointAlphabet()
_keywords = ({Keyword(kw) for kw in _KEYWORD_LOOKUP.keys()} | 
            {Keyword('\\'+kw[0]) for kw in _KEYWORD_LOOKUP.keys()} |
            {Keyword('\\'+delim[0]) for delim in _DELIMITER_LOOKUP.keys()}
            )
_delimiters = {
    Delimiter('charclass', '[', ']', '\\'),
    Delimiter('anticlass', '[^', ']', '\\')
}

tokenizer = Driver(_alphabet, _keywords, set(), _delimiters)

# == Parser ==

class MainParser:
    def __init__(self):
        from arboreum.tree import TreeBuilder
        self.tree = TreeBuilder()
    
    def append(self, token):
        string, type, name = token[0], token[1][0], token[1][1]
        if type == 'keyword':
            if len(string) == 2 and string[0] == '\\':
                self.tree.append(lambda agent, symbol : symbol == string[1])
            else:
                kw = _KEYWORD_LOOKUP[string]
                if kw is expr: self.tree.open()
                elif kw is end: self.tree.close()
                else: self.tree.append(kw)
        elif type == 'delimited':
            from . import textex_class_parser as cparse
            self.tree.append(cparse.compile(string))
        else:
            self.tree.append(lambda agent, symbol: symbol == string)
    
    def eof(self):
        self.tree.close()
    


