"""Provides some constants which are used throughout the system, though
generally not explicitly by the user.

In all actuallity, it only provides epsilon and epsilon_transition as constants.
More importantly, it supplies the _RXConst class, which is useful in the
construction of new constants (e.g. kleene star) which might be included in a
regex engine descvription stream but would need to be disambiguated from content
elements of that stream.

epsilon is the only zero-length symbol. epsilon_transition is a transition
function independent of agent which is active only when th einput is epsilon."""

class _RXConst:
	def __init__(self, name):
		self.name = name
	def __repr__(self):
		return self.name

epsilon = _RXConst('epsilon')
epsilon_transition = lambda agent, symbol: symbol == epsilon