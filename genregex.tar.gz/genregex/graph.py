"""Provides a way to manage networks of states without any execution logic."""

from .rxconst import epsilon

class Table:
    """Provides the logic to create and query a state network.
    
    The functionality focused on here is the determination of active transitions
    and accumulation of actively connected states. If a transition to a state q
    from state p is active for a given agent on a given input symbol, then that
    agent, if it is currently on p, should migrate (move/spawn) to state q when
    that input symbol is consumed."""
    def __init__(self):
        self._table = dict()
        #from state to dict(from lambda to set of states)
    def add(self, from_state, accept_lambda, to_state):
        """Creates a connection from from_state to to_state, active only when
        accept_lambda returns true on an input symbol.
        
        The acceptance lambda takes two parameters (agent, symbol) and returns a
        boolean."""
        if from_state not in self._table:
            self._table[from_state] = dict()
        if accept_lambda not in self._table[from_state]:
            self._table[from_state][accept_lambda] = set()
        self._table[from_state][accept_lambda].add(to_state)
    def add_all(self, from_states, accept_lambda, to_states):
        """Connects n states to n states with transitions, just as in add()."""
        for from_state in from_states:
            for to_state in to_states:
                self.add(from_state, accept_lambda, to_state)
    def get(self, from_state, on_symbol, agent):
        """Returns the states to which the from_state are connected by active
        transitions, given an input symbol and transitioning agent."""
        out = set()
        if from_state in self._table:
            for accept in self._table[from_state]:
                if accept(agent, on_symbol):
                    out |= self._table[from_state][accept]
        return out
    def merge(self, other):
        self._table.update(other._table)
    
    def size(self):
        return len(self._table) #HAX ought to to count all the states (or maybe transitions) properly

class Graph(Table):
    """Adds the concept of initial and final states to a table.
    
    Note that there are both multiple final states and multiple initial states.
    Frankly, I'm not sure why the asymmetry of one initial-many final remained
    in NFAs, but I've gotten rid of it here for efficiency reasons."""
    def __init__(self):
        super().__init__()
        self.initial_states = set()
        self.final_states = set()
    




