class Agent:
    """The basic element of state in an automaton.
    
    An agent exists only at one point in a table, but stores a history of
    modifications made to it along its path. Agents are identical only iff their
    properties (match location and backreferences) are identical."""
    def __init__(self, start_location=0, end_location=None):
        if end_location is None:
            end_location = start_location
        self.bounds = Bounds(start_location, end_location)
        self.groups = Groups()
    def copy(self):
        "Performs a deep copy on all of the agent's data."
        out = Agent()
        out.bounds = self.bounds.copy()
        out.groups = self.groups.copy()
        return out
    def glomb(self, symbol):
        "Notifies the agent that it has read a (possibly empty) symbol."
        self.bounds.glomb(symbol)
        return self
    def __eq__(self, other):
        return self.bounds == other.bounds and self.groups == other.groups
    def __hash__(self):
        return 3*hash(self.bounds) + 2*hash(self.groups)
    def __str__(self):
        return "<Agent: {0} {1}>".format(self.bounds, self.groups)
    def __repr__(self):
        return str(self)

class CompiledAgent:
    def __init__(self, agent, input):
        self.match = input[agent.bounds.begin : agent.bounds.end]
        self.groups = {key:
                [input[group.begin : group.end] for group in agent.groups[key]]
            for key in agent.groups}

class Bounds:
    """Manages match location for an agent.
    
    For efficiency, it does not hold the input sequence itself: two bounds
    objects are equal iff their match start and end are equal."""
    def __init__(self, begin, end):
        self.begin = begin
        self.end = end
    def copy(self):
        return Bounds(self.begin, self.end)
    def glomb(self, symbol):
        """Increase the length of the match, unless the input symbol was
        'epsilon', the zero-length symbol."""
        from .rxconst import epsilon
        if symbol is not epsilon:
            self.end += 1
    def __eq__(self, other):
        return isinstance(other, Bounds) and (
            self.begin == other.begin and self.end == other.end )
    def __hash__(self):
        return 2*self.begin + 3*self.end
    def __str__(self):
        return "<Bounds {0}-{1}>".format(self.begin, self.end)
    def __repr__(self):
        return str(self)

class Groups:
    """Manages record-keeping of backreferences for an agent. Because
    backreference-matchers can be re-entered, a group actually maintains a
    sorted list of backreferences for each backreferenced name.
    
    For efficiency, it does not hold the backreference sequence itself: two
    groups objects are equal iff the contain the same bounds objects."""
    def __init__(self):
        self._data = dict() #from group name to list of Bounds
    #DOC names are _flat_: b/r name scope is always global to the match
    def copy(self):
        copy = Groups()
        copy._data = {key: [bounds.copy() for bounds in self._data[key]] for key in self._data}
        return copy
    def glomb(self, symbol, group):
        """Increases the length of a particular backreference, provided the
        input symbol was not 'epsilon', the zero-length symbol.
        
        Only increases the length of the last backreference, since all previous
        backreferences are assumed to have finished matching."""
        if group not in self:
            raise KeyError(group)
        self._data[group][-1].glomb(symbol)
    def __contains__(self, group):
        return group in self._data
    def __getitem__(self, group):
        """Call to retrieve an already matched group.
        
        Since groups may have match multiple matches associated, a list of all
        matches is returned. If there is no match for the group, then the empty
        list is returned. MAYBE FIXME All groups will be returned, even if they
        are not done matching."""
        return self._data[group] if group in self else []
    def __setitem__(self, group, begin):
        """Call when a new group needs to be tracked.
        
        group = the name of the group to be tracked
        begin = the index where the group begins its match"""
        if group not in self:
            self._data[group] = []
        self._data[group].append(Bounds(begin, begin))
    def __eq__(self, other):
        if not isinstance(other, Groups):
            return False
        if len(self._data) != len(other._data):
            return False
        for key in self._data:
            if key not in other._data:
                return False
            if self._data[key] != other._data[key]:
                return False
        else:
            return True
    def __hash__(self):
        hashdict = 0
        for key in self._data:
            hashdict += hash(key)
            for item in self._data[key]:
                hashdict += hash(item)
            hashdict %= 2**20
        return 5*len(self._data) + hashdict
    
    def __str__(self):
        return "<Groups {0}>".format(self._data)
    def __repr__(self):
        return str(self)
