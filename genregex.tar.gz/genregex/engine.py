"""Provides the logic for state updates in an automaton.

An engine is able to spawn new agents, collect information on living and
accepted agents and to manage the flow of agents through the automaton. It
essentially provides the execution semantics of an epsilon-nondeterministic
finite automaton; however, because transitions may activate based on the
properties of an agent and agents may include arbitrary state information, the
expressive power is probably equivalent to a Turing machine. The non-masochistic
user will decide to use the engine's environment only for problems which are
either nearly or completely within the scope of an e-NFA.

DOC The algorithmic complexity is probably in O(n^k) on the number of transition
functions, since the number of agents is related to their spawn/die ratio, which
in turn is determined by the number and nature of transitions. I bet it hovers
near O(n) amortized, since the spawn/die ratio is likely to be <= 1.

The Automaton class is meant to provide a neat, all-in-one-place, simple
interface to 80% of the utility of the engine. It's the nice bodywork that
conceals the twin turbo-chargers."""

from .struct import Agent
from .graph import Graph
from .rxconst import epsilon

class Engine(Graph):
    def __init__(self, graph = None):
        if graph is None:
            super().__init__()
        else:
            self._table = graph._table
            self.initial_states = graph.initial_states
            self.final_states = graph.final_states
        self._agents = dict() #from state to set of agents
        self._input = []
    
    def get_agents(self, location=None):
        if location is None:
            return self._agents
        if location not in self._agents:
            return set()
        return self._agents[location]
    def add_agent(self, location, agent):
        self.add_agents(location, {agent})
    def add_agents(self, location, agents):
        if location not in self._agents:
            self._agents[location] = set()
        self._agents[location] |= agents
    
    def update(self, located_agents, symbol, compute_closure=True):
        out = dict()
        for state in located_agents:
            for child in state.update(located_agents[state], symbol, self):
                if child[0] not in out:
                    out[child[0]] = set()
                out[child[0]].add(child[1])
        if compute_closure:
            return self.epsilon_close(out)
        else:
            return out
    
    def epsilon_close(self, located_agents):
        """Computes the epsilon closure for a number of located agents."""
        out = located_agents
        found_states = self.update(out, epsilon, False) #basis
        while found_states:
            new_states = dict()
            for key in found_states:
                if key not in out: #malloc
                    out[key] = set()
                for agent in found_states[key]: 
                    if agent not in out[key]:
                        out[key].add(agent) #saturate
                        if key not in new_states: #malloc
                            new_states[key] = set() 
                        new_states[key].add(agent) #formulate next step
            found_states = self.update(new_states, epsilon, False) #iterate
        return out
    
    def extract(self, bounds):
        return self._input[bounds.begin : bounds.end]

from functools import reduce
class Automaton(Engine):
    """The Automaton provides the sort of high-level functionality necessary for
    the design goal: to match full and partial patterns given input one item at
    a time.
    
    In addition to the basic tools, (match, findall &c), some lower-level
    interfacing is also defined which allows for custom search strategies."""
    
    def spawn(self):
        """Creates a new agent for each initial state.
        
        The new agents will, from here out, automatically attempt to match the
        compiled pattern starting at the item of input next-to-be consumed."""
        q0e = self.epsilon_close({q0: {Agent(len(self._input))} for q0 in self.initial_states})
        for state in q0e:
            self.add_agents(state, q0e[state])
    
    def input(self, symbol):
        """Provides one input symbol, causing the Agents to move/die
        accordingly."""
        self._input.append(symbol)
        self._agents = self.update(self._agents, symbol)
    
    def flush(self):
        """Removes all agents from the engine, prepping it for a fresh match
        attempt."""
        self._agents = dict()
        self._input = []
    
    def alive(self):
        """Returns all those states in the engine which have not died.
        
        Technically, returns copies of all of those states, so the user may
        modify them as desired without affecting the operation of the engine."""
        return reduce(lambda acc,s: acc | s, self._agents.values(), set())
    
    def potential(self):
        """Returns all the living states which are not terminal: those which
        could, theoretically become terminal.
        
        Technically, returns copies of all of those states, so the user may
        modify them as desired without affecting the operation of the engine."""
        return reduce(lambda acc,s: acc | self._agents[s],
                      self._agents.keys() - self.final_states, set())
    
    def terminal(self):
        """Returns all the agents which have made it into a terminal state. The
        future liveness of these agents is dependent on any following input.
        
        Technically, returns copies of all of those states, so the user may
        modify them as desired without affecting the operation of the engine."""
        return reduce(lambda acc,s: acc | self._agents[s],
                      self._agents.keys() & self.final_states, set())
    
    
    