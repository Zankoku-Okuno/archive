import Murex.Frontend.Common
import Murex.Frontend.Lexer
import Murex.Frontend.Monad (startParser)
import Murex.Machine.Data

main = do
	input <- readFile "Test/lexer.txt"
	results <- runParserT testParser startParser "Test/lexer.txt" input
	case results of
		Right val -> do { exitSuccess }
		Left err -> do { putStrLn (show err); exitFailure }

testParser = do
	{------------------------------------------------------ Shebangs ------------------------------------------------------}
	tok shebang
	tok shebang
	{------------------------------------------------------ Keywords ------------------------------------------------------}
	tok name >>= \(x, loc) -> case x of { Keyword Let -> return (); _ -> fail "" }
	tok name >>= \(x, loc) -> case x of { Keyword Seq -> return (); _ -> fail "" }
	tok name >>= \(x, loc) -> case x of { Keyword Lambda -> return (); _ -> fail "" }
	tok name >>= \(x, loc) -> case x of { Keyword Lambda -> return (); _ -> fail "" }
	tok name >>= \(x, loc) -> case x of { Keyword Ellipsis -> return (); _ -> fail "" }
	tok name >>= \(x, loc) -> case x of { Keyword Ellipsis -> return (); _ -> fail "" }
	tok name >>= \(x, loc) -> case x of { Keyword Where -> return (); _ -> fail "" }
	tok name >>= \(x, loc) -> case x of { Keyword Where -> return (); _ -> fail "" }
	tok name >>= \(x, loc) -> case x of { Keyword MapsTo -> return (); _ -> fail "" }
	tok name >>= \(x, loc) -> case x of { Keyword MapsTo -> return (); _ -> fail "" }
	tok name >>= \(x, loc) -> case x of { Keyword Wildcard -> return (); _ -> fail "" }
	tok name >>= \(x, loc) -> case x of { Keyword Wildcard -> return (); _ -> fail "" }
	{------------------------------------------------------ Names ------------------------------------------------------}
	tok name >>= \(x, loc) -> case x of { Variable name | name == "x" -> return (); _ -> fail "" }
	tok name >>= \(x, loc) -> case x of { Variable name | name == "水" -> return (); _ -> fail "" }
	tok name >>= \(x, loc) -> case x of { Macro name | name == "macro" -> return (); _ -> fail "" }
	char '('
	tok name >>= \(x, loc) -> case x of { Macro name | name == "reader" -> return (); _ -> fail "" }
	char '"'
	unit >>= \(x, loc) -> case x of { Unit -> return (); _ -> fail "" }
	bool >>= \(x, loc) -> case x of { BoolTok p | p -> return (); _ -> fail "" }
	bool >>= \(x, loc) -> case x of { BoolTok p | not p -> return (); _ -> fail "" }
	{------------------------------------------------------ Integers ------------------------------------------------------}
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(0%1) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(1%1) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(1%1) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Neg && rmag p == Finite(1%1) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(1%1) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	{------------------------------------------------------ Rationals ------------------------------------------------------}
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(1%10) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(11%10) && isgn p == Pos && imag p == Finite(0%1)-> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Neg && rmag p == Finite(3%2) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(13333%10) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(13333%10) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(1%1000) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	{------------------------------------------------------ Complex Numbers ------------------------------------------------------}
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(0%1) && isgn p == Pos && imag p == Finite(1%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(1%1) && isgn p == Pos && imag p == Finite(1%1)-> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(1%1) && isgn p == Neg && imag p == Finite(1%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(0%1) && isgn p == Pos && imag p == Finite(1%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	{------------------------------------------------------ Other Bases ------------------------------------------------------}
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(10%1) && isgn p == Pos && imag p == Finite(0%1)-> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Neg && rmag p == Finite(1%1) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(10%1) && isgn p == Neg && imag p == Finite(11%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(255%1) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(255%1) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(493%1) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(493%64) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(13%1) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Pos && rmag p == Finite(13%4) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	{------------------------------------------------------ Unusual Numbers ------------------------------------------------------}
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Neg && rmag p == Finite(0%1) && isgn p == Pos && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Neg && rmag p == Finite(0%1) && isgn p == Pos && imag p == Finite(1%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	number >>= \(x, loc) -> case x of
		NumTok p | rsgn p == Neg && rmag p == Finite(0%1) && isgn p == Neg && imag p == Finite(0%1) -> return ()
		NumTok p -> do { liftIO $ putStrLn (show p); fail "" }
		_ -> fail ""
	{------------------------------------------------------ Characters ------------------------------------------------------}
	character >>= \(x, loc) -> case x of { CharTok c | c == 'a' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '\'' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '"' -> return (); _ -> fail "" }
	
	character >>= \(x, loc) -> case x of { CharTok c | c == '\a' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '\b' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '\27' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '\f' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '\n' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '\r' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '\t' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '\v' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '\'' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '"' -> return (); _ -> fail "" }

	character >>= \(x, loc) -> case x of { CharTok c | c == '\0' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '\4' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '\12' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '\18' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == 'λ' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '\716813' -> return (); _ -> fail "" }
	character >>= \(x, loc) -> case x of { CharTok c | c == '\1110029' -> return (); _ -> fail "" }
	{------------------------------------------------------ Strings ------------------------------------------------------}
	basicString >>= \(x, loc) -> case x of { StringTok str | str == "Goodbyte, cruel world!" -> return (); _ -> fail "" }
	basicString >>= \(x, loc) -> case x of { StringTok "two\n    lines" -> return (); _ -> fail "" }
	basicString >>= \(x, loc) -> case x of { StringTok "MAKE A HOLE!" -> return (); _ -> fail "" }
	do
		(s, _) <- openWovenString
		(n, _) <- basicString
		(e, _) <- closeWovenString
		case (s, n, e) of
			(LString "My age is ", StringTok "4", RString "") -> return ()
			(LString "My age is ", StringTok "4", RString str) -> do { liftIO $ putStrLn str; fail "" }
			(LString "My age is ", StringTok str, _) -> do { liftIO $ putStrLn str; fail "" }
			(LString str, _, _) -> do { liftIO $ putStrLn str; fail "" }
			_ -> fail ""
	{------------------------------------------------------ Punctuation ------------------------------------------------------}
	tok punctuation >>= \(x, loc) -> case x of { Keyword Namespace -> return (); _ -> fail "" }
	tok punctuation >>= \(x, loc) -> case x of { Keyword LParen -> return (); _ -> fail "" }
	tok punctuation >>= \(x, loc) -> case x of { Keyword RParen -> return (); _ -> fail "" }
	tok punctuation >>= \(x, loc) -> case x of { Keyword LBrack -> return (); _ -> fail "" }
	tok punctuation >>= \(x, loc) -> case x of { Keyword RBrack -> return (); _ -> fail "" }
	tok punctuation >>= \(x, loc) -> case x of { Keyword LBrace -> return (); _ -> fail "" }
	tok punctuation >>= \(x, loc) -> case x of { Keyword RBrace -> return (); _ -> fail "" }
	tok punctuation >>= \(x, loc) -> case x of { Keyword TypeAnn -> return (); _ -> fail "" }
	tok punctuation >>= \(x, loc) -> case x of { Keyword Eval -> return (); _ -> fail "" }
	char '0'
	tok punctuation >>= \(x, loc) -> case x of { Keyword QuoteExpr -> return (); _ -> fail "" }
	char '0'
	tok punctuation >>= \(x, loc) -> case x of { Keyword QuoteDector -> return (); _ -> fail "" }
	char '0'
	tok punctuation >>= \(x, loc) -> case x of { Keyword Splice -> return (); _ -> fail "" }
	char '0'
	tok punctuation >>= \(x, loc) -> case x of { Keyword Comma -> return (); _ -> fail "" }
	tok punctuation >>= \(x, loc) -> case x of { Keyword At -> return (); _ -> fail "" }
	{------------------------------------------------------ Indentation ------------------------------------------------------}
	do
		tok name
		i <- indent
		tok name
		d <- dedent
		tok name
		tok name
		case (i, d) of { (Keyword Indent, Keyword Dedent) -> return (); _ -> fail "" }
	do
		tok name
		i <- indent
		(Variable name, loc) <- tok name
		d <- dedent
		case (i, d) of { (Keyword Indent, Keyword Dedent) -> return (); _ -> fail "" }
	eof
