import Common

import Murex.Frontend.Lexer
import Murex.Frontend.Parser

main = putStrLn "Goodbyte, cruel world!"