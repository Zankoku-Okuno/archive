module Common (
      module Numeric
    , module Data.Function
    , module Data.Ratio
    , module Data.Char
    , module Data.List
    , module Data.Maybe
    , module System.IO
    , module System.Directory
    , module System.Exit
    , module Data.IORef

    , module Control.Monad
    , module Control.Monad.IO.Class
    , module Control.Monad.Trans

    , (<<)
    , putErrLn
    ) where

import Numeric
import Data.Function
import Data.Ratio
import Data.Char
import Data.List
import Data.Maybe
import System.IO
import System.Directory
import System.Exit
import Data.IORef

import Control.Monad
import Control.Monad.IO.Class
import Control.Monad.Trans

infixl 1 <<
x << y = do { out <- x; y; return out }

putErrLn = hPutStrLn stderr
