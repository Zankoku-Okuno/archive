module Murex.Machine.Data where

import Common

data Sign = Pos | Neg
    deriving (Eq, Show)
data Magnitude = Inf | Finite (Ratio Integer)
	deriving (Eq, Show)
data MurexNum = MurexNan
              | MurexNum { rsgn :: Sign
                         , rmag :: Magnitude
                         , isgn :: Sign
                         , imag :: Magnitude
                         }
    deriving (Eq, Show)