module Murex.Frontend.Common (
      module Common
    , module Text.Parsec
    , module Text.Parsec.Char

    , Identifier (..)
    , Literal (..)

    , skip, many2, between2
    ) where

import Common
import Text.Parsec
import Text.Parsec.Char
import Murex.Machine.Data (MurexNum)


data Identifier = Id [String] String (Maybe Int)

data Literal = UnitLit
             | BoolLit   Bool
             | NumLit    MurexNum
             | CharLit   Char
             | ListLit   [Literal]
             | StringLit String
             | TupleLit  [Literal]


skip :: (Monad m) => ParsecT s u m a -> ParsecT s u m ()
skip p = p >> return ()
many2 :: (Monad m) => ParsecT s u m a -> ParsecT s u m a -> ParsecT s u m [a]
many2 p1 p2 = do
    car <- p1
    cdr <- many p2
    return (car:cdr)
between2 :: (Monad m, Stream s m t) => ParsecT s u m a -> ParsecT s u m b -> ParsecT s u m b
between2 x = between x x
