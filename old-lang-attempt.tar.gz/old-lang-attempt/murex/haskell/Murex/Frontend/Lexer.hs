module Murex.Frontend.Lexer (
      Token(..)
    , Keyword(..)

    , keyword

    , tok
    , indent, dedent

    , shebang, comment
    , name
    , unit, bool, number, character, basicString
    , openWovenString, closeWovenString
    , punctuation
    ) where

{--- USAGE ---

Always wrap these lexing functions in `tok` to ensure correct backtracking and error reporting.
Exception: DO NOT wrap `indent` or `dedent`; these are meant to be used stand-alone.

WARNING: You must parse numbers before parsing names, as '-1' is a valid name!

 -------------}

import Murex.Frontend.Common
import Murex.Frontend.Utils
import Murex.Frontend.Monad (Parser, peekIndent, pushIndent, popIndent)
import Murex.Machine.Data (MurexNum(..), Sign(..), Magnitude(..))

type TokenPos = (Token, SourcePos)
data Token = Comment   String

           | Keyword   Keyword
           | Variable  String
           | Box       String
           | Macro     String

           | Unit
           | BoolTok   Bool
           | NumTok    MurexNum
           | CharTok   Char
           | StringTok String
           | LString   String
           | RString   String
    deriving (Eq)

data Keyword = LParen | RParen | LBrack | RBrack | LBrace | RBrace
             | Indent | Dedent
             | Comma
             | Eval | QuoteExpr | QuoteDector | Splice
             | Let | Lambda | Seq
             | At
             | Wildcard | Ellipsis
             | Where | MapsTo
             | TypeAnn
             | Namespace
    deriving (Eq)


keyword :: Keyword -> Parser ((), SourcePos)
keyword x = tok (dispatch >>= check)
    where
    dispatch = head [ f | (kws, f) <- table, x `elem` kws ]
    check res = if res == Keyword x then return () else fail ""
    table = [ ([ LParen, RParen
               , LBrack, RBrack
               , LBrace, RBrace
               , Comma
               , Eval, QuoteExpr, QuoteDector, Splice
               , TypeAnn, Namespace
               , At
               ], punctuation)
            , ([ Let, Lambda, Seq
               , Where, MapsTo
               , Wildcard, Ellipsis
               ], name)
            , ([Indent], indent)
            , ([Dedent], dedent)
            ]
--TODO variable name
--TODO macro name
--TODO literal lexer


separate :: Parser ()
separate = lookAhead (skip (oneOf ",:)]} \t\n\r") <|> eof)

tok :: Parser a -> Parser (a, SourcePos)
tok p = try (eat >> impl p)
    where
    eat = many (skipMany1 (oneOf " \t\n\r") <|> skip comment)
    impl p = do
        loc <- getPosition
        res <- p
        return (res, loc)


shebang :: Parser ()
shebang = string "#!" >> optional (char ' ') >> char '/' >> skipMany (noneOf "\n")

comment :: Parser Token
comment = liftM Comment (block <|> line)
    where
    line = try startLine >> many (noneOf "\n")
    block = between (try startBlock) endBlock $ do
        parts <- many $  (many1 $ noneOf "#}")
                     <|> (lookAhead (try $ string "#{") >> block)
                     <|> (string "#" << notFollowedBy (char '{'))
                     <|> (try $ string "}" << notFollowedBy (char '#'))
        return $ concat parts
    startLine = char '#' >> notFollowedBy (oneOf "!{")
    startBlock = string "#{"
    endBlock = string "}#"


name :: Parser Token
name = do
        val <- many2 (noneOf $ ill++firstIll) (noneOf ill)
        other <- lookAhead ( (oneOf "(\"" >> return Macro) <|> (char '{' >> return Box) <|> return Variable )
        return (classify val other)
    where
    ill = "()[]{}`,$@: \t\n\r#\"\\"
    firstIll = "0123456789\'"
    classify str other = case str of
        "let"              -> Keyword Let
        "seq"              -> Keyword Seq
        "λ"                -> Keyword Lambda
        "fn"               -> Keyword Lambda
        "|"                -> Keyword Where
        "where"            -> Keyword Where
        "→"                -> Keyword MapsTo
        "->"               -> Keyword MapsTo
        "…"                -> Keyword Ellipsis
        "..."              -> Keyword Ellipsis
        _ | nub str == "_" -> Keyword Wildcard
          | otherwise      -> other str


unit :: Parser TokenPos
unit = tok $ string "()" >> separate >> return Unit

bool :: Parser TokenPos
bool = tok $ do
    char '\\'
    val <- (char 't' >> return True) <|> (char 'f' >> return False)
    separate
    return (BoolTok val)

number :: Parser TokenPos
number = tok $ do
        (sign, base, parseDigits, parseExpMark) <- try $ do
            sign <- parseSign
            (base, parseDigits, parseExpMark) <- parsePreNum
            lookAhead parseDigits
            return (sign, base, parseDigits, parseExpMark)
        return . NumTok =<< impl sign base parseDigits parseExpMark
    where
    impl sign base parseDigits parseExpMark = do
            part1 <- parsePart
            (sign, real, iSign, imag) <- ( (                           oneOf "iι" >>             return (Pos,  0%1,   sign, part1) )
                                       <|> ( (char '+' >> parsePart << oneOf "iι") >>= \part2 -> return (sign, part1, Pos,  part2) )
                                       <|> ( (char '-' >> parsePart << oneOf "iι") >>= \part2 -> return (sign, part1, Neg,  part2) )
                                       <|>                                                       return (sign, part1, Pos,  0%1)   )
            power <- parseExp <|> return 0
            separate
            let exp = if power < 0 then (/ (base^(-power)%1)) else (* (base^power%1))
            return MurexNum { rsgn=sign, rmag=Finite(exp real), isgn=iSign, imag=Finite(exp imag) }
        where
        parsePart = do
            whole <- liftM (strToInteger base) parseDigits
            frac' <- (char '.' >> parseDigits) <|> return "0"
            let frac = strToInteger base frac' % (base ^ toInteger (length frac'))
            return (whole%1 + frac)
        parseExp = do 
            parseExpMark
            sign <- (string "-" >> return (-1)) <|> (optional (char '+') >> return 1)
            body <- liftM (strToInteger base) parseDigits
            return (sign * body)

character :: Parser TokenPos
character = tok $ do
    val <- between2 (char '\'') (char '"' <|> parseChar)
    separate
    return (CharTok val)

basicString :: Parser TokenPos
basicString = tok $ return . StringTok =<< (between2 (char '"') (many stringChar) << separate)

openWovenString :: Parser TokenPos
openWovenString = tok $ return . LString =<< between (char '"') (string "\\(") (many stringChar)

closeWovenString :: Parser TokenPos
closeWovenString = tok $ return . RString =<< (between (char ')') (char '"') (many stringChar) << separate)

stringChar = char '\n' <|> try parseGap <|> parseChar
    where parseGap = char '\\' >> many1 (oneOf " \t\n\r") >> char '\\' >> parseChar

punctuation :: Parser Token
punctuation = (try (string "::")                                     >> return (Keyword Namespace))
           <|> try (string "`@"  << notFollowedBy (oneOf " \t\n\r#") >> return (Keyword QuoteDector))
           <|>     (char '@'                                         >> return (Keyword At))
           <|>     ((oneOf "[{:" <|> openParen)                      >>= classify)
           <|>     (oneOf ")]}"  << separate                         >>= classify)
           <|>     (oneOf "$`"   << notFollowedBy (oneOf " \t\n\r#") >>= classify)
           <|> try (char ','     << separate                         >> return (Keyword Comma))
           <|>     (char ','                                         >> return (Keyword Splice))
    where
    classify = return . Keyword . fromJust . flip lookup table
    table =  [ ('(', LParen), (')', RParen),
               ('[', LBrack), (']', RBrack),
               ('{', LBrace), ('}', RBrace),
               ('$', Eval),   ('`', QuoteExpr),
               (':', TypeAnn)                ]
    openParen = char '(' << notFollowedBy (char ')')

indent :: Parser Token
indent = try $ do
    many1 $ try (skipMany (oneOf " \t") >> oneOf "\n\r")
    pushIndent =<< liftM length (many $ char ' ')
    return (Keyword Indent)

dedent :: Parser Token
dedent = try $ do
        skip (many1 nextline) <|> eof
        liftIO $ putStrLn "DEBUG"
        popIndent =<< liftM length (many $ char ' ')
        return (Keyword Dedent)
    where nextline = try $ skipMany (oneOf " \t") >> (oneOf "\n\r")
