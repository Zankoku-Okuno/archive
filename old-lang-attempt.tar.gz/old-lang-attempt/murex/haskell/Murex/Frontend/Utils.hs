module Murex.Frontend.Utils where

import Murex.Frontend.Common
import Murex.Frontend.Monad (Parser)
import Murex.Machine.Data


strToInteger :: Integer -> String -> Integer
strToInteger radix input = impl 0 input
  where impl acc "" = acc
        impl acc (x:xs) = impl (radix * acc + (toInteger . digitToInt) x) xs
strToMantissa :: Integer -> String -> Ratio Integer
strToMantissa radix str = strToInteger radix str % (radix ^ toInteger (length str))

parseSign :: Parser Sign
parseSign = (string "-" >> return Neg) <|> (optional (char '+') >> return Pos)
parsePreNum :: Parser (Integer, Parser String, Parser Char)
parsePreNum =  prefix "Xx" (16, many1 hexDigit, oneOf "Hh")
           <|> prefix "Oo" ( 8, many1 octDigit, oneOf "Hh")
           <|> prefix "Bb" ( 2, many1 binDigit, oneOf "Hh")
           <|> return      (10, many1 digit,    oneOf "Ee")
    where
    prefix p r = try $ char '0' >> oneOf p >> return r
    binDigit = oneOf "01"

parseChar :: Parser Char
parseChar = noneOf "\\\"\t\n\r" <|> try (char '\\' >> (
             special
         <|> ascii
         <|> uni4
         <|> try uni5
         <|> uni6 ))
    where
    special = do
            p <- oneOf (map fst table)
            return $ fromJust $ lookup p table
        where table = [ ('a','\a')
                      , ('b','\b')
                      , ('e','\27')
                      , ('f','\f')
                      , ('n','\n')
                      , ('r','\r')
                      , ('t','\t')
                      , ('v','\v')
                      , ('\'','\'')
                      , ('\"','\"')
                      , ('\\','\\')
                      ]
    ascii = decode                                        (count 2 hexDigit)
    uni4  = decode (char 'u' >>                            count 4 hexDigit)
    uni5  = decode (char 'U' >>               char '0' >> (count 5 hexDigit))
    uni6  = decode (char 'U' >> liftM2 (++) (string "10") (count 4 hexDigit))
    decode = liftM (chr . fromInteger . strToInteger 16)

