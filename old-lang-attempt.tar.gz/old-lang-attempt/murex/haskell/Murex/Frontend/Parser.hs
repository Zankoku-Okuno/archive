module Murex.Frontend.Parser where

import Murex.Frontend.Common
import Murex.Frontend.Monad (Parser)
import qualified Murex.Frontend.Lexer as Lex
import Murex.Frontend.Lexer (Token(Keyword), Keyword, keyword)

--TODO add locations for relevant nodes
type StatementPos = (Statement, SourcePos)
data Statement = Statement Expr
           | Definition (Maybe String) Identifier Expr
           --TODO types
           --TODO notation, using notation

type ExprPos = (Expr, SourcePos)
data Expr = LitExp        Literal
          | List          [ExprPos]
          | ListSplice    [ExprPos] [ExprPos]
          | Comprehension ExprPos [ComprehensionExpr]
          | WovenString   String ExprPos String
          --TODO records and boxes
          | Name          Identifier
          | ExprWildcard
          | ExprChain     [ExprPos]
          | Lambda        [Pattern] --at least one
          | Let           [StatementPos] [StatementPos]
          | Seq           [StatementPos]
          | Eval          ExprPos
          | QuoteExpr     ExprPos
          | QuoteDector   DectorPos
          | SpliceExpr    ExprPos
          | Macro         String [ExprPos]
          | Case          ExprPos [Pattern]
          | If            ExprPos ExprPos ExprPos
          | ExprType      ExprPos ExprPos

type DectorPos = (Dector, SourcePos)
data Dector = LitDector     Literal
            | DectorList    [DectorPos]
            | ListSegment   [DectorPos] [DectorPos]
            | StringSegment String String
            | Variable      String
            | As            String DectorPos
            | Wildcard
            | ExprCode      ExprPos
            | DectorCode    DectorPos
            | EvalDector    ExprPos
            | DectorType    DectorPos ExprPos

type Pattern = ([DectorPos], [Clause]) -- a Ptrn (1 or more Dstr) and at least one clause
type Clause  = ([ExprPos], ExprPos) -- bool exprs + expr
data ComprehensionExpr = Iterate DectorPos ExprPos
                       | Bind    DectorPos ExprPos
                       | Filter  ExprPos



expr :: Parser ExprPos
expr = do
    car@(_, loc) <- aexpr
    cdr <- many aexpr
    return (ExprChain (car:cdr), loc)

aexpr :: Parser ExprPos
aexpr =  ( Lex.unit        >>= \(Lex.Unit       , loc) -> return (LitExp   UnitLit    , loc) )
     <|> ( Lex.bool        >>= \(Lex.BoolTok   p, loc) -> return (LitExp $ BoolLit   p, loc) )
     <|> ( Lex.number      >>= \(Lex.NumTok    n, loc) -> return (LitExp $ NumLit    n, loc) )
     <|> ( Lex.character   >>= \(Lex.CharTok   c, loc) -> return (LitExp $ CharLit   c, loc) )
     <|> ( Lex.basicString >>= \(Lex.StringTok s, loc) -> return (LitExp $ StringLit s, loc) )
     <|> ( Lex.openWovenString >>= wovenString )
     <|> ( keyword Lex.LBrack >>= listy )
--record
--box
--name
     <|> ( keyword Lex.Wildcard >>= \((), loc) -> return (ExprWildcard, loc))
     <|> ( parens expr )
--fn
--let
--seq
--eval
--quote
--splice
--macro
--case
--if aexpr aexpr aexpr
     <?> "expression"
    where
    wovenString (Lex.LString start, loc) = do
        mid <- expr
        (Lex.RString end, _) <- Lex.closeWovenString
        return (WovenString start mid end, loc)
    listy :: ((), SourcePos) -> Parser ExprPos
    listy ((), loc) =  finished []
                   <|> concatEnd []
                   <|> ( expr >>= listy' )
        where
        listy' hd =  finished [hd]
                 <|> concatEnd [hd]
                 <|> ( do
                        keyword Lex.Where
                        exprs <- comprExpr `sepBy1` keyword Lex.Comma
                        keyword Lex.RBrack
                        return (Comprehension hd exprs, loc) )
                 <|> ( do
                        keyword Lex.Comma 
                        tl <- listElems
                        finished (hd:tl) <|> concatEnd (hd:tl) )
        finished hd = keyword Lex.RBrack >> return (List hd, loc)
        concatEnd leading = do
            keyword Lex.Ellipsis
            trailing <- listElems
            keyword Lex.RBrack
            return (ListSplice leading trailing, loc)
        listElems = expr `sepBy` keyword Lex.Comma
        comprExpr = bind <|> try iter <|> comprFilter
            where
            iter = fail "" --STUB
            comprFilter = liftM Filter expr 
            bind = fail "" --STUB
    record :: Parser () --STUB
    record = fail ""

dector :: Parser DectorPos
dector =  ( Lex.unit        >>= \(Lex.Unit       , loc) -> return (LitDector   UnitLit    , loc) )
      <|> ( Lex.bool        >>= \(Lex.BoolTok   p, loc) -> return (LitDector $ BoolLit   p, loc) )
      <|> ( Lex.number      >>= \(Lex.NumTok    n, loc) -> return (LitDector $ NumLit    n, loc) )
      <|> ( Lex.character   >>= \(Lex.CharTok   c, loc) -> return (LitDector $ CharLit   c, loc) )
      <|> ( Lex.basicString >>= stringy )
      --list
      --variable
      --as
      <|> ( keyword Lex.Wildcard >>= \((), loc) -> return (Wildcard, loc))
      --ExprCode
      --DectorCode
      --EvalDector
      --DectorType
    where
    stringy (Lex.StringTok start, loc) = do
        x <- optionMaybe (keyword Lex.Ellipsis)
        case x of
            Nothing -> return (LitDector $ StringLit start, loc)
            Just _ -> do
                (Lex.StringTok end, _) <- Lex.basicString
                return (StringSegment start end, loc)


parens :: Parser a -> Parser a
parens = between (keyword Lex.LParen) (keyword Lex.RParen)

brackets :: Parser a -> Parser a
brackets = between (keyword Lex.LBrack) (keyword Lex.RBrack)

block :: Parser a -> Parser a
block p =  between (keyword Lex.LBrace) (keyword Lex.RBrace) p
       <|> between (keyword Lex.Indent) (keyword Lex.Dedent) p