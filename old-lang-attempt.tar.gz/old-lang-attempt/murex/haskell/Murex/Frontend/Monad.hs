module Murex.Frontend.Monad where

import Murex.Frontend.Common

type Parser = ParsecT String ParserState IO

data ParserState = ParserState { indent :: [Int] }


startParser :: ParserState
startParser = ParserState { indent = [0] }


peekIndent :: Parser Int
peekIndent = return . head . indent =<< getState

pushIndent :: Int -> Parser ()
pushIndent n' = do
	s <- getState
	let n = head (indent s)
	when (n' <= n) (fail "")
	setState (s { indent = n':(indent s) })

popIndent :: Int -> Parser ()
popIndent n' = do
	s <- getState
	let n = head (indent s)
	    n'' = (head . tail) (indent s)
	when (n' >= n) (fail "")
	when (n' > n'') (fail "")
	setState (s { indent = tail (indent s) })