Nautilus
========

A Lisp dialect that takes to heart modern techniques of computational theory.

Goals
=====

 * Expressivity (room for growth)
 * Type-safety
 * Static scope
 * Concurrency-safe
 * Efficient runtime
 * Simple cost-model
 * Non-local control
 * Code transformation
 * Deterministic inlining
 * Deployment configuration
 * Good diagnostics
 * Concision

Status
======

I expect to explore quite a bit before I come up with formal specifications for Nautilus. This exploration will manifest itself as a simple language called Fossil, which will follow mostly traditional Scheme techniques. After experimenting with primitive concepts, implementation, and syntax in Fossil, I will proceed to implementing Nautilus, adding type inference, compilation.

Fossil
======

The major contribution of Fossil (other than teaching myself how to implement certain things) will be a cleaning of Lisp syntax and a run-time manifest type system. Perhaps these two will be easier to understand with an explanation of the plan:

Fix Lisp Syntax
---------------

It is not true that Lisp has no syntax. One, there is a decently complex tokenizer (not to mention reader-macros!) Two, special forms and macros impose ad-hoc syntactic requirements which are usually only checked at runtime. Three, the user (programmer) is required to explicitly notate the abstract syntax tree in its entirety, a menial and verbose task. Four, without syntax, there is no surface form: no possibility of communication, neither human-human, nor human-machine, nor even machine-machine. As Lisp may be understood by humans and machines, we have achieved reductio ad absurdum.

Now that I have that out of my system...

All functions take one argument and return one value. Any identifier may be registered as an infix, and syntactic sugar will collect arguments and handle precedence. As the arity of all functions are known, we can dispense with all parenthesis that are not required for disambiguation. The ability to define infixes allows code to be read in a more natural way than prefix notation.

This will require a change in the internal representation of Fossil/Nautilus, as lists are now too powerful to represent the program reliably (though they work very well when every function accepts varargs). The syntax of expressions is still very uniform however, so I foresee no special difficulties in manipulating Fossil/Nautilus.

With the loss of lists as the implementation of homoiconicity, lists receive a new syntax, which is the same as Haskell syntax, because that's simple enough.

Runtime Manifest Types
----------------------

Here, I mean manifest as opposed to latent. In the latently-typed Scheme, values have types, but variables (using the bad Scheme terminology) do not. Fossil, by contrast, gives types not just to values, but also to references (including assignables, which are normally thought of as variables, but also fluid variables, ports, and promise/future pairs).

Anything which is not a reference is single-assignment, so we need not worry about type confusion except when passing an argument to a function. When assignables (and presumably other references, but let's keep the discussion concrete) are first created, they are created with a value, and thus have are assigned an associated type equal to the initial value. Attempt to store a value of the wrong type in an assignable is an error at runtime.

Rather than go through the difficulty of implementing record types, Fossil will have only tuples as a way to create aggregates. Therefore structural, rather than nominal, typing will be used in Fossil, which is a fairly big break from other languages.

Nautilus
========

I will refrain from saying much about Nautilus for now, except that I intend it to have a powerful type system amenable to type inference (combining higher-kinded type, higher-ranked types, and modular overloading via a module system combining the ML module system and Haskell typeclasses). I further intend for Nautilus to be compiled to machine code.
