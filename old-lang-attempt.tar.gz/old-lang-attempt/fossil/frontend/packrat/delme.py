#! /usr/bin/python3
from functools import partial
from machine import *
import string
m = parseFromFile(CodeMachine, 'delme')
print( m.many1(partial(m.oneOf, string.digits), partial(m.oneOf, string.ascii_letters)) )
m.eof()


exit()
try:
	# print( m.eq('q') )
	# print( m.choice(partial(m.string, 'hl'), partial(m.string, 'ello')) )
	pass
except Exception as ex:
	print(ex)
