module Syntax (
      ParsedFossil(..)
    , TokenTree(..)
    , parseFossilFile
    ) where

import Common
import Data

 ------ Data Structures ------

type Parser = ParsecT String (Accum, ([String], [String], [String])) IO
data ParsedFossil = ParsedFossil { flags    :: [Flag]   , unflags :: [String]
                                 , infixes  :: [Infix]  , uninfixes :: [String]
                                 , prefixes :: [Prefix] , unprefixes :: [String]
                                 , provided :: [Provision]
                                 , tokTree  :: [TokenTree]
                                 }


data TokenTree = Ltrl Literal
               | Name String
               | Expr [TokenTree]
               | List [TokenTree]
               | StrS [TokenTree]
               | Lmbd Matcher SourcePos
               | Blok [TokenTree] [TokenTree]
               | Splc TokenTree
               | Quot TokenTree
               | Unqt TokenTree
               | Defn String TokenTree
               | Ptrn [TokenTree]
               | Dstr TokenTree
               | Wild
               | Dots
               | Node String TokenTree
    deriving (Eq, Show)
type Matcher = [Pattern] -- at least one pattern
type Pattern = (TokenTree, [Clause]) -- a Ptrn (1 or more Dstr) and at least one clause
type Clause  = ([TokenTree], TokenTree) -- predicates + expr

--{ pattern { { | predicate } |- expression } }


startState = (([],[],[],[]), ([],[],[]))
type Accum = ([Flag], [Prefix], [Infix], [Provision])
type Flag = String
type Prefix = String
data Infix = Infix { name :: String
                   , adjacent :: Bool
                   , leftAssociative :: Bool
                   , before :: Maybe String
                   , after :: Maybe String
                   }
    deriving (Eq, Show)
type Provision = (String, String)


 ------ Interface ------

parseFossilFile :: String -> IO ParsedFossil
parseFossilFile filename = do
    ensureExists filename
    result <- runParserT parseFossil startState filename =<< readFile filename
    case result of
        Right val -> return val
        Left err -> do
            putErrLn $ show err
            exitFailure

parseFossil :: Parser ParsedFossil
parseFossil = do
        dropSheBang >> skipSpace
        result <- many parseTop
        eof
        wrap $ map fromJust $ filter isJust result
    where
    dropSheBang = optional $ string "#!" >> many (noneOf "\n\r")
    wrap tokens = do
        ((f,p,i,v), (uf,up,ui)) <- getState
        return ParsedFossil { flags = nub f, unflags = nub uf
                            , prefixes = nub p, unprefixes = nub up
                            , infixes = nub i, uninfixes = nub ui
                            , provided = nub v
                            , tokTree = tokens
                            }


 ------ Syntax ------

parseTop :: Parser (Maybe TokenTree)
parseTop =  (return . Just =<< parseBlock) <|> parseDirective

parseBlock :: Parser TokenTree
parseBlock = parseParenExpr <|> parseDefinition <|> parseLet

parseDefinition :: Parser TokenTree
parseDefinition = try $ do
    name <- parseId
    (string "≡" <|> string "=" <|> try (string "\\def") <|> string "\\equiv") >> skipSpace
    expr <- parseExpr
    skipSpace
    return $ Defn name expr

parseExpr :: Parser TokenTree
parseExpr = try $  parseLet
               <|> parseAtom
               <|> parseParenExpr
               <|> parseList
               <|> parseLambda
               <|> parseMatch
               <|> parseQuote
               <|> parseQuoteDestructure
               <|> parseUnquote
               <|> parseDestructureUnquote
               <|> parseSplice

parseParenExpr :: Parser TokenTree
parseParenExpr = try $ do
    result <- encloseWith "(" ")" $ many1 parseExpr
    case result of
        [expr@(Expr _)] -> return expr
        _ -> return $ Expr result
parseBareExpr :: Parser TokenTree
parseBareExpr = try $ do
    result <- many1 parseExpr
    skipSpace
    case result of
        [expr@(Expr _)] -> return expr
        _ -> return $ Expr result

parseLet :: Parser TokenTree
parseLet = try $ do
        string "let" >> skipSpace
        defs <- encloseWith "{" "}" $ many (parseDefinition <|> parseParenExpr)
        string "in" >> skipSpace
        body <- encloseWith "{" "}" (many parseBlock) <|> (parseExpr >>= return . wrapExpr)
        return $ Blok defs body
    where
    wrapExpr expr@(Expr _) = [expr]
    wrapExpr expr = [Expr [expr]]

--TODO find a way to splice in here, and perhaps also quote/unquote
parseDestructure :: Parser TokenTree
parseDestructure = try (parenDstr <|> oneDstr)
    where
    oneDstr = liftM (Ptrn . (:[]) . Dstr) parseOneDestructure
    parenDstr = liftM Ptrn $ encloseWith "(" ")" $ many1 parseOneDestructure

parseOneDestructure :: Parser TokenTree
parseOneDestructure =  parseNode
                   <|> parseWildcard
                   <|> parseLiteral
                   <|> parseString
                   <|> parseName
                   <|> listTail
                   <|> parseList
                   <|> parseQuote
                   <|> parseQuoteDestructure
                   <|> parseDestructureUnquote
                   <|> parseSplice
    where
    parseList = encloseWith "[" "]" $ do
        leading <- parseOneDestructure `sepBy1` comma
        ellipsis <- optionMaybe parseDots
        result <- case ellipsis of
            Nothing -> return leading
            Just dots -> do
                trailing <- parseOneDestructure `sepBy1` comma
                return $ leading ++ [dots] ++ trailing
        return $ List result
    listTail = encloseWith "[" "]" $ do
        dots <- parseDots
        trailing <- parseOneDestructure `sepBy1` comma
        return $ List (dots:trailing)
    parseNode = try $ do
        name <- parseId
        dstr <- encloseWith "{" "}" parseOneDestructure
        return $ Node name dstr
    parseLiteral = try (parseNumber <|> parseChar <|> parseUnit <?> "literal value")
    parseString = tok "string" $ do
            leading <- liftM (map (Ltrl . ChrL)) $ parseBareString
            ellipsis <- optionMaybe parseBareDots
            result <- case ellipsis of
                Nothing -> return leading
                Just dots -> do
                    trailing <- liftM (map (Ltrl . ChrL)) $ parseBareString
                    return $ leading ++ [dots] ++ trailing
            return $ List $ result

parseDirective :: Parser (Maybe TokenTree)
parseDirective = try $ do
        string "#!" >> space
        (     parseInclude >>= addInclude << skipSpace)
          <|> (parseFlag >>= addFlag >> retNone)
          <|> (parseUnFlag >>= remFlag >> retNone)
          <|> (parsePrefix >>= addPrefix >> retNone)
          <|> (parseInfix >>= addInfix >> retNone)
          <|> (parseUnprefix >>= remPrefix >> retNone)
          <|> (parseUninfix >>= remInfix >> retNone)
          <|> (parseVersion >>= addVersion >> retNone)
    where
    parseInclude = wrap "include" $ parseBareString
    parseFlag = wrap "set" $ many1 (alphaNum <|> char '_') `sepBy1` (space >> char ',' >> space)
    parseUnFlag = wrap "unset" $ many1 (alphaNum <|> char '_') `sepBy1` (space >> char ',' >> space)
    parsePrefix = wrap "prefix" $ parseBareId
    parseUnprefix = wrap "remove prefix" $ parseBareId
    parseInfix = try $ do
        string "infix"
        assoc <- (char 'r' >> return False) <|> (char 'l' >> return True)
        name <- space1 >> parseBareId
        before <- optionMaybe $ try (space1 >> string "before" >> space1 >> parseBareId)
        after <- optionMaybe $ try (space1 >> string "after" >> space1 >> parseBareId)
        space << (skip newline <|> eof)
        return Infix { name = name
                     , adjacent = True -- STUB
                     , leftAssociative = assoc
                     , before = before
                     , after = after
                     }
    parseUninfix = wrap "remove infix" $ parseBareId
    parseVersion = wrap "version" $ do
        modName <- parseBareString
        space1
        verStr <- parseBareString
        return (modName, verStr)
    addInclude filename = do
        (flags', prefixes', infixes', provisions') <- liftIO $ getDirectivesFromFile filename
        ((f, p, i, v), u) <- getState
        mapM addInfix infixes'
        mapM addVersion provisions'
        setState ((f++flags', p++prefixes', i++infixes', v++provisions'), u)
        return $ Just $ Expr [Name "#include", List $ map (Ltrl . ChrL) filename]
    addFlag flag = do
        ((flags, x, y, v), z) <- getState
        setState ((flags++flag, x, y, v), z)
    remFlag flag = do
        (z, (flags, x, y)) <- getState
        setState (z, (flags++flag, x, y))
    addPrefix prefix = do
        ((x, prefixes, y, v), z) <- getState
        setState ((x, prefixes++[prefix], y, v), z)
    remPrefix prefix = do
        (z, (x, prefixes, y)) <- getState
        setState (z, (x, prefixes++[prefix], y))
    addInfix ifix = do
        ((x, y, infixes, v), z) <- getState
        let sameName = ((name ifix ==) . name) `filter` infixes
        let conflicts = (ifix /=) `filter` sameName
        when (conflicts /= []) (fail $ "Conflicting definition of infix `" ++ name ifix ++ "'.")
        setState ((x, y, infixes++[ifix], v), z)
    remInfix ifix = do
        (z, (x, y, infixes)) <- getState
        setState (z, (x, y, infixes++[ifix]))
    addVersion ver = do
        ((x, y, w, vers), z) <- getState
        when (fst ver `elem` map fst vers)
             (fail $ "Version already defined for `" ++ fst ver ++ "'.")
        setState ((x, y, w, ver:vers), z)
    wrap str p = try $ string str >> space1 >> p << space << newline
    space = skipMany (oneOf " \t")
    space1 = oneOf " \t" >> space
    retNone = skipSpace >> return Nothing


 ------ Lexer ------

parseAtom :: Parser TokenTree
parseAtom = parseLiteral <|> parseName

parseLiteral :: Parser TokenTree
parseLiteral = flip (<?>) "literal value" $ parseNumber <|> parseChar <|> parseString <|> parseUnit

parseUnit :: Parser TokenTree
parseUnit = tok "unit" $ string "()" >> return (Ltrl Unit)

parseNumber :: Parser TokenTree
parseNumber = tok "number" $ do
        sign <- (string "-" >> return False) <|> return True
        (base, digits, expMark) <- parseHex <|> parseOct <|> parseBin <|> return (10, digit, oneOf "Ee")
        (sign, whole, frac, iSign, iWhole, iFrac, power) <- impl sign base digits expMark
        return $ Ltrl $ NumL { positive = sign
                             , whole = whole
                             , fraction = frac
                             , imagPositive = iSign
                             , imagWhole = iWhole
                             , imagFraction = iFrac
                             , radix = base
                             , power = power
                             }
    where
    impl sign base digits expMark = try $ do
            (whole, frac) <- parsePart
            (sign, whole, frac, iSign, iWhole, iFrac) <- (
                    ( oneOf "iι" >> return (True, 0, 0%1, sign, whole, frac) )
                <|> ( try (char '+' >> parsePart << oneOf "iι")
                      >>= \(w,f) -> return (sign, whole, frac, True, w, f) )
                <|> ( try (char '-' >> parsePart << oneOf "iι")
                      >>= \(w,f) -> return (sign, whole, frac, False, w, f) )
                <|> return (sign, whole, frac, True, 0, 0%1)
                 )
            power <- (do 
                        expMark
                        sign <- (string "-" >> return (-1)) 
                            <|> (optional (char '+') >> return 1)
                        body <- liftM (strToInteger base) (many digits)
                        return (sign * body)
                     ) <|> return 0
            return (sign, whole, frac, iSign, iWhole, iFrac, power)
            where
            parsePart = do
                whole <- liftM (strToInteger base) (many1 digits)
                frac' <- (char '.' >> many1 digits) <|> return "0"
                let frac = strToInteger base frac' % (base ^ toInteger (length frac'))
                return (whole, frac)
    parseHex = try $ do
        char '0' >> oneOf "Xx"
        return (16, hexDigit, oneOf "Hh")
    parseOct = try $ do
        char '0' >> oneOf "Oo"
        return (8, octDigit, oneOf "Hh") -- TODO figure out the best notation for *8^
    parseBin = try $ do
        char '0' >> oneOf "Bb"
        return (2, oneOf "01", oneOf "Hh") -- TODO figure out the best notation for *2^

parseChar :: Parser TokenTree
parseChar = tok "character" $ between2 (char '\'') (wrap $ char '"' <|> oneChar)
    where wrap = (return . Ltrl . ChrL =<<)

parseBareString :: Parser String
parseBareString = between2 (char '"') $ many oneChar
parseString :: Parser TokenTree
parseString = tok "string" $ between2 (char '"') $ liftM StrS $ many $ literal <|> splice
    where
    literal = wrap $ many1 $ try (char '\n' <|> oneChar)
        where wrap = (return . List . (map (Ltrl . ChrL)) =<<)
    splice = try $ char '\\' >> parseParenExpr
    --WARNING this is copy-pasted from the real parseParenExpr
    parseParenExpr = try $ do
        char '(' >> skipSpace
        result <- many1 parseExpr
        char ')'
        case result of
            [expr@(Expr _)] -> return expr
            _ -> return $ Expr result

parseId :: Parser String
parseId = tok "identifier" parseBareId 
parseBareId :: Parser String
parseBareId = flip (<?>) "identifier" $ do
    car <-        noneOf ("()[]{}`,\"\\$ \t\n\r#"++"_'λ0123456789")
    cdr <- many $ noneOf  "()[]{}`,\"\\$ \t\n\r#"
    return (car:cdr)
parseName :: Parser TokenTree
parseName = return . Name =<< parseId

parseWildcard :: Parser TokenTree
parseWildcard = tok "wildcard" $ many1 (char '_') >> return Wild
parseDots :: Parser TokenTree
parseDots = tok "ellipsis" parseBareDots
parseBareDots = (string "…" <|> string "..." <|> string "\\ellipsis") >> return Dots

parseList :: Parser TokenTree
parseList = try $ do
    char '[' >> skipSpace
    result <- parseBareExpr `sepBy` comma
    char ']' >> skipSpace
    return $ List result

parseLambda :: Parser TokenTree
parseLambda = try $ do
    loc <- getPosition
    lambda
    args <- parseDestructure
    expr <- parseExpr
    let clause = ([], expr)
    return $ Lmbd [(args, [clause])] loc

parseMatch :: Parser TokenTree
parseMatch = try $ do
        loc <- getPosition
        lambda 
        char '{' >> skipSpace
        clauses <- parseMatcher
        char '}' >> skipSpace
        return $ Lmbd clauses loc
    where
    parseMatcher = do
        car@((Ptrn pat), _) <- parsePattern
        cdrQua <- optionMaybe (comma >> parseNPattern (length pat) `sepBy` comma)
        let cdr = case cdrQua of
                       Nothing -> []
                       Just x -> x
        return (car:cdr)
    parsePattern = do
        dstr <- parseDestructure
        clauses <- many1 parseClause
        return (dstr, clauses)
    parseNPattern n = do
        dstr@(Ptrn args) <- parseDestructure
        when (length args /= n) (fail "A single lambda must take the same number of arguments in all its patters.")
        clauses <- many1 parseClause
        return (dstr, clauses)
    parseClause = do
        guards <- many $ try (char '|' >> notFollowedBy (char '-') >> skipSpace >> parseExpr)
        expr <- tack >> parseExpr
        return (guards, expr)

parseSplice :: Parser TokenTree
parseSplice = return . Splc =<< prefixExpr "$"

parseQuote :: Parser TokenTree
parseQuote = return . Quot =<< prefixExpr "`"

parseUnquote :: Parser TokenTree
parseUnquote = return . Unqt =<< prefixExpr ","

parseQuoteDestructure :: Parser TokenTree
parseQuoteDestructure = try $ do
    result <- encloseWith "`{" "}" $ parseOneDestructure
    return $ Quot $ Dstr result
parseDestructureUnquote :: Parser TokenTree
parseDestructureUnquote = try $ do
    result <- encloseWith ",{" "}" parseOneDestructure
    return $ Unqt $ Dstr result


 ------ Parsing Helpers ------

comma :: Parser ()
comma = try (char ',' >> space >> skipSpace)

lambda :: Parser ()
lambda = (string "λ" <|> try (string "\\lambda") <|> string "\\") >> skipSpace

tack :: Parser ()
tack = (string "⊢" <|> try (string "|-") <|> string "\\infer") >> skipSpace

oneChar :: Parser Char
oneChar = noneOf "\\\"\t\n\r" <|> try (char '\\' >> (
           special
       <|> ascii
       <|> uni4
       <|> try uni5
       <|> uni6 ))
    where
    special = do
            p <- oneOf (map fst table)
            return $ fromJust $ lookup p table
        where table = [ ('a','\a')
                      , ('b','\b')
                      , ('f','\f')
                      , ('n','\n')
                      , ('r','\r')
                      , ('t','\t')
                      , ('\'','\'')
                      , ('\"','\"')
                      , ('\\','\\')
                      ]
    ascii = liftM (chr . fromInteger . strToInteger 16) (count 2 hexDigit)
    uni4 = liftM (chr . fromInteger . strToInteger 16) (oneOf "Uu" >> count 4 hexDigit)
    uni5 = liftM (chr . fromInteger . strToInteger 16) (oneOf "Xx" >> char '0' >> (count 5 hexDigit))
    uni6 = liftM (chr . (+ 0x100000) . fromInteger . strToInteger 16) (oneOf "Xx" >> string "10" >> (count 4 hexDigit))

skipSpace :: Parser ()
skipSpace = skipMany $ (space >> return ()) <|> try blockComment <|> lineComment
    where
    lineComment = try ( char '#' >> notFollowedBy (oneOf "!{") >> skipMany (noneOf "\n") )
    blockComment = do
        string "#{"
        many $  skip (noneOf "#}")
            <|> skip (lookAhead (string "#{") >> blockComment)
            <|> skip (char '#')
            <|> skip (try $ char '}' << notFollowedBy (char '#'))
        string "}#"
        return ()

noSuffix = notFollowedBy (noneOf ",)]{} \t\n\r")

skipSpace1 = noSuffix >> skipSpace

many2 p = do
    car <- p
    cdr <- many1 p
    return (car:cdr)

between2 x = between x x

encloseWith :: String -> String -> Parser a -> Parser a
encloseWith lead trail p = try $ do
    string lead >> skipSpace
    result <- p
    string trail >> skipSpace
    return result

tok str p = flip (<?>) str (try p << skipSpace1)

prefixExpr :: String -> Parser TokenTree
prefixExpr prefix = try ( string prefix >> parseExpr)
prefixDstr :: String -> Parser TokenTree
prefixDstr prefix = try ( string prefix >> parseOneDestructure)

skip :: Parser a -> Parser ()
skip = (>> return ())

 ------ Helpers ------

getDirectivesFromFile :: String -> IO Accum
getDirectivesFromFile filename = do
        ParsedFossil { flags = f
                     , unflags = uf
                     , infixes = i
                     , uninfixes = ui
                     , prefixes = p
                     , unprefixes = up
                     , provided = v
                     } <- parseFossilFile filename
        return (f \\ uf, p \\ up, subInfixes i ui, v)
        where
        subInfixes a b = (not . (flip elem b) . name) `filter` a

ensureExists :: String -> IO ()
ensureExists filename = do
    exists <- doesFileExist filename
    if exists then return () else do
        putErrLn ("Cannot find file: `" ++ filename ++ "'.")
        exitFailure

strToInteger :: Integer -> String -> Integer
strToInteger radix input = impl 0 input
  where impl acc "" = acc
        impl acc (x:xs) = impl (radix * acc + (toInteger . digitToInt) x) xs


 ------ Display ------
{-
instance Show TokenTree where
    show (Ltrl lit) = show lit
    show (Name name) = name
    show (Expr exprs) = "(" ++ foldl1 ((++) . (++" ")) (map show exprs) ++ ")"
    show (List []) = "[]"
    show (List exprs) = "[" ++ fold exprs ++ "]"
        where fold [x] = show x
              fold (Dots : xs) = show Dots ++ " " ++ fold xs
              fold [x, Dots] = show x ++ " " ++ show Dots
              fold (x : Dots : xs) = show x ++ " " ++ show Dots ++ " " ++ fold xs
              fold (x : xs) = show x ++ ", " ++ fold xs
    show (StrS xs) = concatMap show xs
    show (Lmbd patterns _) = "λ { " ++ foldl1 ((++) . (++"\n\t, ")) (map showPattern patterns) ++ " }"
        where
        showPattern (dstr, clauses) = show dstr ++ foldl1 (++) (concatMap showClause clauses)
        showClause = map showDispatcher
        showDispatcher (guards, expr) = concatMap showGuard guards ++ " ⊢ " ++ show expr
        showGuard = (" | "++) . show
    show (Blok defs [expr]) = "let { \n" ++ concatMap ((++"\n") . show) defs ++ "} in " ++ show expr ++ "\n"
    show (Blok defs body) = "let { \n" ++ concatMap ((++"\n") . show) defs ++ "}\nin {\n" ++ showBlock body ++ "\n}"
    show (Splc expr) = "$" ++ show expr
    show (Quot (Dstr dstr)) = "`{" ++ foldl1 ((++) . (++" ")) (map show dstr) ++ "}"
    show (Quot expr) = "`" ++ show expr
    show (Unqt (Dstr [dstr])) = "," ++ show dstr
    show (Unqt (Dstr dstr)) = ",{" ++ foldl1 ((++) . (++" ")) (map show dstr) ++ "}"
    show (Unqt expr) = "," ++ show expr
    show (Defn name val) = name ++ " ≡ " ++ show val
    show (Dstr dstrs) = foldl1 ((++) . (++" ")) (map show dstrs)
    show Wild = "_"
    show Dots = "…"
    show (Node name dstr) = name ++ " {" ++ show dstr ++ "}"

showBlock block = foldl1 ((++) . (++"\n")) (map wrapExprs block)
    where wrapExprs x@(Defn _ _) = show x
          wrapExprs x = "(" ++ show x ++ ")"

instance Show Infix where
    show x = "Infix" ++ (if leftAssociative x then "L " else "R ") ++ show (name x) ++ maybe "" ((" before "++) . show) (before x) ++ maybe "" ((" after "++) . show) (after x)
-}