module Data (
	  FossilNum(..), Sign(..)
	, Literal(..)
	) where

import Common

data Sign = Pos | Neg
    deriving (Eq, Show)
data FossilNum = FossilNan
               | FossilInf
               | FossilNegInf
               | FNum { rsgn :: Sign
                      , rmag :: Ratio Integer
                      , isgn :: Sign
                      , imag :: Ratio Integer
                      }
    deriving (Eq, Show)


data Literal = Unit
			 | BooL Bool
             | NumL FossilNum
             | ChrL Char
    deriving (Eq)


instance Show Literal where
    show Unit = "()"
    show (BooL p) = if p then "\\t" else "\\f"
    show (NumL n) = show n
    --FIXME use the Fossil syntax, not Haskell
    show (ChrL c) = show c
