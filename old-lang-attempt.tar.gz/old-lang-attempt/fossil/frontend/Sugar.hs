module Sugar (
      getFossilFromFile
    , SAST(..)
    , EAST(..)
    , DAST(..)
    ) where

import Common
import Data


 ------ Data Structures ------

 -- Scope AST
data SAST = SDefn String EAST
          | SExpr EAST
    deriving (Eq)

 -- Expression AST
data EAST = ELtrl Literal
          | EName String --FIXME to identitier
          | EList [EAST]
          | ELmbd [( [DAST], [( [EAST], EAST )] )] SourcePos
          | EAply EAST EAST
          | EBlok [SAST] [SAST] --FIXME give a scope name to it
          | EWild
          | ESplc EAST
          | EQotE EAST
          | EQotD DAST
          | EUqtE EAST
          | EUqtD DAST
          -- below here, there are sugared expressions
          | EName' String
          | Expr' [EAST]
    deriving (Eq)

 -- Destructure AST
data DAST = DLtrl Literal
          | DName String
          | DWild
          | DDots
          | DList [DAST]
          | DNode String DAST
          | DSplc EAST
          | DQotE EAST
          | DQotD DAST
    deriving (Eq)


 ------ Interface ------

getFossilFromFile :: FilePath -> IO [SAST]
getFossilFromFile filename = do 
    parsed <- parseFossilFile filename
    -- DELME the printing crap
    {-
    putStrLn $ (show $ flags parsed) ++ " - " ++ (show $ unflags parsed)
    putStrLn $ (show $ prefixes parsed) ++ " - " ++ (show $ unprefixes parsed)
    putStrLn $ (show $ infixes parsed) ++ " - " ++ (show $ uninfixes parsed)
    putStrLn $ show $ provided parsed
    putStrLn $ take 12 $ repeat '='
    -}
    when (ast parsed /= []) (putStr $ concatMap ((++"\n") . show) $ ast parsed)
    putStrLn $ take 12 $ repeat '='
    case map desugarScope (ast parsed) of
        [] -> putStrLn "Nothing to desugar." >> return []
        it -> mapM (putStrLn . show) it >> return it
    return [] --STUB

 ------ Desugar ------

desugarScope :: SAST -> SAST
desugarScope (SDefn name expr) = SDefn name (desugarExpr expr)
desugarScope (SExpr expr) = SExpr (desugarExpr expr)

desugarExpr :: EAST -> EAST
desugarExpr (Expr' exprs) = implicitParens exprs
desugarExpr (EList exprs) = EList (map desugarExpr exprs)
desugarExpr (ELmbd pats loc) = ELmbd (map desugarPattern pats) loc
    where
    desugarPattern (dectors, clauses) = (map desugarDector dectors , map desugarClause clauses)
    desugarClause (guards, expr) = (map desugarExpr guards, desugarExpr expr)
desugarExpr (EAply f x) = EAply (desugarExpr f) (desugarExpr x)
desugarExpr (EBlok defs body) = EBlok (map desugarScope defs) (map desugarScope body)
desugarExpr (ESplc x) = ESplc (desugarExpr x)
desugarExpr (EQotE x) = EQotE (desugarExpr x)
desugarExpr (EUqtE x) = EUqtE (desugarExpr x)
desugarExpr (EQotD x) = EQotD (desugarDector x)
desugarExpr (EUqtD x) = EUqtD (desugarDector x)
desugarExpr x = x



desugarDector = id


implicitParens = implicitApply . doInfixes . doPrefixes

doPrefixes = id
doInfixes = id
implicitApply :: [EAST] -> EAST
implicitApply it = foldl1 EAply $ map desugarExpr it


 ------------ Parser ------------

type Parser = ParsecT String (Accum, Unaccum, QuoteDepth) IO
data ParsedFossil = ParsedFossil { flags       :: [Flag]      , unflags :: [String]
                                 , prefixes    :: [Prefix]    , unprefixes :: [String]
                                 , infixes     :: [Infix]     , uninfixes :: [String]
                                 , infixGroups :: [InfixGroup]
                                 , suffixes    :: [Suffix]    , unsuffixes :: [String]
                                 , provided    :: [Provision]
                                 , ast         :: [SAST]
                                 }

parseFossilFile :: String -> IO ParsedFossil
parseFossilFile filename = do
    ensureExists filename
    result <- runParserT parseFossil startState filename =<< readFile filename
    case result of
        Right val -> return val
        Left err -> do
            putErrLn $ show err
            exitFailure

parseFossil :: Parser ParsedFossil
parseFossil = do
        dropSheBang >> skipSpace
        result <- many parseAtTop
        eof
        wrap $ map fromJust $ filter isJust result
    where
    dropSheBang = optional $ string "#!" >> many (noneOf "\n\r")
    wrap tokens = do
        ((f,p,i,g,s,v), (uf,up,ui,us), _) <- getState
        --TODO clean this up
        return ParsedFossil { flags = nub f, unflags = nub uf
                            , prefixes = nub p, unprefixes = nub up
                            , infixes = nub i, uninfixes = nub ui
                            , infixGroups = nub g
                            , suffixes = nub s, unsuffixes = nub us
                            , provided = nub v
                            , ast = tokens
                            }


 ------ State ------

startState = (([],[],[],[],[],[]), ([],[],[],[]), 0)
type QuoteDepth = Int
type Accum   = ([Flag],   [Prefix], [Infix], [InfixGroup], [Suffix], [Provision])
type Unaccum = ([String], [String], [String],              [String])
type Flag = String
type Prefix = String
type Suffix = String
data Infix = Infix { name :: String
                   , adjacent :: Bool
                   , leftAssociative :: Bool
                   , before :: Maybe String
                   , after :: Maybe String
                   }
    deriving (Eq, Show)
type InfixGroup = (String, [String])
type Provision = (String, String)

addFlag :: Flag -> Parser ()
addFlag x = do
    (( xs ,a,b,c,d,e),f,g) <- getState
    when (not $ x `elem` xs) $ setState (( x:xs ,a,b,c,d,e),f,g)
remFlag :: Flag -> Parser ()
remFlag x = do
    (a,( xs ,b,c,d),e) <- getState
    when (not $ x `elem` xs) $ setState (a,( x:xs ,b,c,d),e)
addPrefix :: Prefix -> Parser ()
addPrefix x = do
    ((a, xs ,b,c,d,e),f,g) <- getState
    --TODO check that the name is not already an infix or suffix
    when (not $ x `elem` xs) $ setState ((a, x:xs ,b,c,d,e),f,g)
remPrefix :: String -> Parser ()
remPrefix x = do
    (a,(b, xs ,c,d),e) <- getState
    when (not $ x `elem` xs) $ setState (a,(b, x:xs ,c,d),e)
addInfix :: Infix -> Parser ()
addInfix x = do
    ((a,b, xs ,c,d,e),f,g) <- getState
    let sameNames = ((name x ==) . name) `filter` xs
    let conflicts = (x /=) `filter` sameNames
    when (conflicts /= [])         (fail $ "Conflicting definition of infix `" ++ name x ++ "'.")
    when (name x `elem` b)         (fail $ "Definition of infix `" ++ name x ++ "' conflicts with an existing prefix.")
    when (name x `elem` map fst c) (fail $ "Definition of infix `" ++ name x ++ "' conflicts with an existing infix group.")
    when (name x `elem` d)         (fail $ "Definition of infix `" ++ name x ++ "' conflicts with an existing suffix.")
    when (not $ name x `elem` map name xs) $ setState ((a,b, x:xs ,c,d,e),f,g)
remInfix :: String -> Parser ()
remInfix x = do
    (a,(b,c, xs ,d),e) <- getState
    when (not $ x `elem` xs) $ setState (a,(b,c, x:xs ,d),e)
addInfixGroup :: InfixGroup -> Parser ()
addInfixGroup x = do
    ((a,b,c, xs ,d,e),f,g) <- getState
    --TODO check the group is not yet defined
    --TODO check that the name is not in infixes
    setState ((a,b,c, x:xs ,d,e),f,g)
addSuffix :: Suffix -> Parser ()
addSuffix x = do
    ((a,b,c,d, xs ,e),f,g) <- getState
    --TODO check that the name is not already an infix or prefix
    when (not $ x `elem` xs) $ setState ((a,b,c,d, x:xs ,e),f,g)
remSuffix :: String -> Parser ()
remSuffix x = do
    (a,(b,c,d, xs ),e) <- getState
    when (not $ x `elem` xs) $ setState (a,(b,c,d, x:xs),e)
addVersion :: Provision -> Parser ()
addVersion x = do
    ((a,b,c,d,e, xs),f,g) <- getState
    if fst x `elem` map fst xs
      then fail $ "Version is already set for `" ++ fst x ++ "'."
      else setState ((a,b,c,d,e, x:xs),f,g)


 ------ Syntax ------

parseAtTop =  (parseAtScope >>= return . Just)
          <|> (parseDirective >> return Nothing)

parseAtScope =  (parseDefinition)
            <|> (parseParenExpr >>= return . SExpr)
            <|> (parseLetBlock >>= return . SExpr)
            <|> (parseDoBlock >>= return . SExpr)
            --TODO splice, defer, destructuring definition, import

parseDefinition :: Parser SAST
parseDefinition = try $ do
    name <- parseName
    parseDef
    expr <- parseExpr
    return $ SDefn name expr


parseExpr :: Parser EAST
parseExpr =   parseParenExpr
         <|>  parseLetBlock
         <|>  parseDoBlock
         <|>  parseAbstraction
         <|>  parseLiteral
         <|> (parseName >>= return . EName')
         <|> (parseWildcard >> return EWild)
         <|>  parseList
         <|>  parseString
    where
    parseLiteral =  (parseUnit >> return (ELtrl Unit))
                <|> (parseBool >>= return . ELtrl . BooL)
                <|> (parseNumber >>= return . ELtrl . NumL)
                <|> (parseChar >>= return . ELtrl . ChrL)

parseNoParenExpr :: Parser EAST
parseNoParenExpr = try $ many1 parseExpr >>= return . Expr'
parseParenExpr :: Parser EAST
parseParenExpr = try $ parseParens parseNoParenExpr


parseDector :: Parser DAST
parseDector =  parseDectorNode
           <|> parseLiteral
           <|> (parseName >>= return . DName)
           <|> (parseWildcard >> return DWild)
           <|> parseDectorList
           <|> parseDectorString
    where
    parseLiteral =  (parseUnit >> return (DLtrl Unit))
                <|> (parseBool >>= return . DLtrl . BooL)
                <|> (parseNumber >>= return . DLtrl . NumL)
                <|> (parseChar >>= return . DLtrl . ChrL)
parseMultidector :: Parser [DAST]
parseMultidector = try $ parseDector `sepBy1` parseComma


parseLetBlock :: Parser EAST
parseLetBlock = try $ do
    parseLet
    defs <- parseBraces (many parseAtScope)
    parseIn
    body <- parseBraces (many parseAtScope) <|> liftM ((:[]) . SExpr) parseExpr
    return $ EBlok defs body
parseDoBlock :: Parser EAST
parseDoBlock = try $ parseDo >> parseBraces (many parseAtScope) >>= return . (EBlok [])

parseAbstraction :: Parser EAST
parseAbstraction = try $ do
        loc <- getPosition
        parseLambda
        result <- parseBraces $ dector `sepBy1` parseComma
        if (length (nub $ map (length . fst) result) /= 1)
          then fail "All patterns must accept the same number of arguments."
          else return $ ELmbd result loc
    where
    dector :: Parser ([DAST], [([EAST], EAST)])
    dector = do 
        pattern <- parseMultidector
        clauses <- many clause
        return (pattern, clauses)
    clause :: Parser ([EAST], EAST)
    clause = do
        guards <- many (parseWhere >> parseExpr)
        parseDispatch
        expr <- parseExpr
        return (guards, expr)


parseList :: Parser EAST
parseList = try $ parseBrackets (parseNoParenExpr `sepBy` parseComma) >>= return . EList

parseString :: Parser EAST
parseString = try $ do
        result <- between2 (char '"') $ many (literal <|> splice)
        leaveSpace
        case result of
            [] -> return $ EList []
            [x@(EList _)] -> return x
            xs -> return $ EAply (EName' "#concat") (EList (map callStrSplice xs))
    where
    literal = many1 (try $ char '\n' <|> oneChar) >>= return . EList . (map (ELtrl . ChrL))
    splice = try $ between (string "\\(" >> skipSpace) (string ")") parseNoParenExpr
    callStrSplice x@(EList _) = x
    callStrSplice x@(Expr' _) = EAply (EName' "#strSplice") x


parseDectorNode :: Parser DAST
parseDectorNode = try $ do
    name <- parseName
    body <- parseBraces parseDector
    return $ DNode name body

parseDectorList :: Parser DAST
parseDectorList = parseBrackets $ parseListTail <|> do
        leading <- parseDectorInList `sepBy1` parseComma
        dots <- maybe (return False) (const $ return True) =<< optionMaybe parseEllipsis
        if dots
          then do
                 trailing <- parseDectorInList `sepBy` parseComma
                 return $ DList (leading ++ [DDots] ++ trailing)
          else return $ DList leading
    where
    parseListTail = do
        parseEllipsis
        trailing <- parseDectorInList `sepBy` parseComma
        return $ DList (DDots:trailing)
    parseDectorInList = parseNodeInList <|> parseDector
    parseNodeInList = try $ do
        name <- parseName
        body <- parseBraces $ parseDectorInList `sepBy1` parseComma
        return $ DNode name (DList body)

parseDectorString :: Parser DAST
parseDectorString = do
    leading <- between2 (char '"') (many oneChar)
    dots <- maybe (return False) (const $ return True) =<< optionMaybe bareEllipsis
    result <- if dots
                then do
                       trailing <- between2 (char '"') (many oneChar)
                       return $ DList $ (map (DLtrl . ChrL) leading) ++ [DDots] ++ (map (DLtrl . ChrL) trailing)
                else return $ DList (map (DLtrl . ChrL) leading)
    leaveSpace
    return result


 ------ Lexer ------

parseName :: Parser String
parseName = bareName << leaveSpace
bareName :: Parser String
bareName = try $ do
        result <- many2 (noneOf (disallow ++ disallow1)) (noneOf disallow)
        if (nub result == "_")
          then fail ""
          else return result
    where disallow =  " \t\n\r()[]{}$\\`,:\"$#"
          disallow1 = disallow ++ "0123456789'"

parseUnit :: Parser ()
parseUnit = try $ string "()" >> leaveSpace

parseBool :: Parser Bool
parseBool = try $ char '\\' >> oneOf "tf" << leaveSpace >>= return . (== 't')

parseNumber :: Parser FossilNum
parseNumber = do
        rsgn <- liftM (maybe Neg (const Pos)) $ optionMaybe (string "-")
        (base, digits, expMark) <- parseHex <|> parseOct <|> parseBin <|> return (10, digit, oneOf "Ee")
        ((rsgn, whole, frac), (isgn, iWhole, iFrac), power) <- impl rsgn base digits expMark
        leaveSpace
        return $ mkFossilNum RIR { rsgn' = rsgn
                                 , rmag' = (whole % 1) + frac
                                 , isgn' = isgn
                                 , imag' = (iWhole % 1) + iFrac
                                 , radx' = base
                                 , expt' = power
                                 }
    where
    impl sign base digits expMark = try $ do
            part1 <- parsePart sign
            (part1, part2) <- (  ( oneOf "iι"                                    >>  return (zero, part1) )
                             <|> ( try (char '+' >> parsePart Pos << oneOf "iι") >>= return . ((,) part1) )
                             <|> ( try (char '-' >> parsePart Neg << oneOf "iι") >>= return . ((,) part1) )
                             <|>                                                     return (part1, zero) 
                              )
            power <- (do 
                        expMark
                        sign <- (char '-' >> return (-1)) <|> (optional (char '+') >> return 1)
                        body <- liftM (strToInteger base) (many digits)
                        return (sign * body)
                     ) <|> return 0
            return (part1, part2, power)
            where
            parsePart sign = do
                whole <- liftM (strToInteger base) (many1 digits)
                frac' <- (char '.' >> many1 digits) <|> return "0"
                let frac = strToInteger base frac' % (base ^ toInteger (length frac'))
                return (sign, whole, frac)
            zero = (Pos, 0, 0%1)
    parseHex = try $ do
        char '0' >> oneOf "Xx"
        return (16, hexDigit, oneOf "Hh")
    parseOct = try $ do
        char '0' >> oneOf "Oo"
        return (8, octDigit, oneOf "Hh") -- TODO figure out the best notation for *8^
    parseBin = try $ do
        char '0' >> oneOf "Bb"
        return (2, oneOf "01", oneOf "Hh") -- TODO figure out the best notation for *2^

parseChar :: Parser Char
parseChar = try $ between2 (char '\'') (char '"' <|> oneChar) << leaveSpace


parseWildcard :: Parser ()
parseWildcard = try $ many1 (char '_') >> leaveSpace

 ------ Directives ------

parseDirective :: Parser ()
parseDirective = try $ do
        string "#!" >> skipMany lineSpace
        do    flagDirective
          <|> prefixDirective
          <|> infixGroupDirective
          <|> infixDirective
          <|> suffixDirective
          <|> versionDirective

flagDirective = try $ do
    f <- (string "set" >> return addFlag) <|> (string "unset" >> return addFlag)
    skipMany1 lineSpace
    names <- directiveString `sepBy1` (char ',' >> skipMany1 lineSpace)
    mapM f names
    endDirective

prefixDirective = try $ do
    f <- (string "prefix" >> return addPrefix) <|> (string "remove prefix" >> return remPrefix)
    skipMany1 lineSpace
    name <- bareName
    f name
    endDirective

infixDirective = try $ do
    tight <- (string "tight infix" >> return True) <|> (string "infix" >> return False)
    assoc <- (char 'r' >> return False) <|> (char 'l' >> return True)
    skipMany1 lineSpace
    name <- bareName
    --TODO ordering: before, after, at, and operator groups
    --TODO ensure that ordering refers onyl to infixes and infix groups that have been defined
    let (before, after) = (Nothing, Nothing) --STUB
    --before <- optionMaybe $ try (space1 >> string "before" >> space1 >> parseBareId)
    --after <- optionMaybe $ try (space1 >> string "after" >> space1 >> parseBareId)
    addInfix Infix { name = name
                   , adjacent = tight
                   , leftAssociative = assoc
                   , before = before
                   , after = after
                   }
    endDirective

infixGroupDirective = try $ do
    string "infix group"
    skipMany1 lineSpace
    name <- bareName
    skipMany1 lineSpace
    char '='
    skipMany1 lineSpace
    elems <- bareName `sepBy1` (char ',' >> skipMany1 space)
    addInfixGroup (name, elems)
    endDirective

suffixDirective = try $ do
    f <- (string "suffix" >> return addSuffix) <|> (string "remove suffix" >> return remSuffix)
    skipMany1 lineSpace
    name <- bareName
    f name
    endDirective

versionDirective = try $ do
    string "version"
    skipMany1 lineSpace
    name <- directiveString
    skipMany1 lineSpace
    version <- directiveString
    addVersion (name, version)
    endDirective

directiveString :: Parser String
directiveString = try $ between2 (char '"') (many oneChar)

endDirective = skipMany lineSpace >> newline >> skipSpace


 ------ Lexer Helpers ------

oneChar :: Parser Char
oneChar = noneOf "\\\"\t\n\r" <|> try (char '\\' >> (
           special
       <|> ascii
       <|> uni4
       <|> try uni5
       <|> uni6 ))
    where
    special = do
            p <- oneOf (map fst table)
            return $ fromJust $ lookup p table
        where table = [ ('a','\a')
                      , ('b','\b')
                      , ('f','\f')
                      , ('n','\n')
                      , ('r','\r')
                      , ('t','\t')
                      , ('\'','\'')
                      , ('\"','\"')
                      , ('\\','\\')
                      ]
    ascii = liftM (chr . fromInteger . strToInteger 16) (count 2 hexDigit)
    uni4 = liftM (chr . fromInteger . strToInteger 16) (oneOf "Uu" >> count 4 hexDigit)
    uni5 = liftM (chr . fromInteger . strToInteger 16) (oneOf "Xx" >> char '0' >> (count 5 hexDigit))
    uni6 = liftM (chr . (+ 0x100000) . fromInteger . strToInteger 16) (oneOf "Xx" >> string "10" >> (count 4 hexDigit))


parseParens p = try $ between open close p
    where open = char '(' >> skipSpace
          close = char ')' >> leaveSpace
parseBrackets p = try $ between open close p
    where open = char '[' >> skipSpace
          close = char ']' >> leaveSpace
parseBraces p = try $ between open close p
    where open = char '{' >> skipSpace
          close = char '}' >> leaveSpace
parseDectorQuote p = try $ between open close p
    where open = string "`{" >> skipSpace
          close = char '}' >> leaveSpace
parseDectorUnquote p = try $ between open close p
    where open = string ",{" >> skipSpace
          close = char '}' >> leaveSpace

parseSplice p        = try $ char '$'                                          >> p
parseQuote p         = try $ char '`' >> notFollowedBy (char '{')              >> p
parseUnquote p       = try $ char ',' >> notFollowedBy (char '{')              >> p

parseComma           = skip $ try $ char ','                                         >> leaveSpace
parseColon           = skip $ try $ char ':' >> notFollowedBy (char ':')             >> leaveSpace
parseFourDots        = skip $ try $ string "::" >> notFollowedBy (char ':')          >> leaveSpace
parseLet             = skip $ try $ string "let"                                     >> leaveSpace
parseIn              = skip $ try $ string "in"                                      >> leaveSpace
parseDo              = skip $ try $ string "do"                                      >> leaveSpace
parseLambda          = skip $ try $ (string "λ" <|> string "lambda" <|> string "fn") >> leaveSpace
parseMu              = skip $ try $ (string "μ" <|> string "mu" <|> string "macro")  >> leaveSpace
parseDef             = skip $ try $ (string "≡" <|> string "=" <|> string "def")     >> leaveSpace
parseEllipsis        = skip $ try $ (string "…" <|> string "...")                    >> leaveSpace
parseWhere           = skip $ try $ char '|' >> notFollowedBy (char '-')             >> leaveSpace
parseDispatch        = skip $ try $ (string "⊢" <|> string "|-")                     >> leaveSpace
parseSubstitute      = skip $ try $ (string "↝" <|> string "~>")                     >> leaveSpace

bareEllipsis         = skip $ try $ (string "…" <|> string "...")


skipSpace :: Parser ()
skipSpace = skipMany $ (space >> return ()) <|> try blockComment <|> lineComment
    where
    lineComment = try ( char '#' >> notFollowedBy (oneOf "!{") >> skipMany (noneOf "\n\r") )
    blockComment = do
        string "#{"
        many $  skip (noneOf "#}")
            <|> skip (lookAhead (string "#{") >> blockComment)
            <|> skip (char '#')
            <|> skip (try $ char '}' << notFollowedBy (char '#'))
        string "}#"
        return ()
leaveSpace :: Parser ()
leaveSpace = lookAhead (oneOf " \t\n\r#,:)]}") >> skipSpace

lineSpace :: Parser Char
lineSpace = oneOf " \t"

 ------ x-parsec ------

skip = (>> return ())
expect str p = p <?> str
between2 x = between x x
many2 p q = do
    car <- p
    cdr <- many q
    return (car:cdr)
many2' p = many2 p p


 ------------ Display ------------

instance Show SAST where
    show (SDefn name val) = name ++ " ≡ " ++ show val
    show (SExpr expr@(EAply _ _)) = show expr
    show (SExpr expr@(EBlok _ _)) = show expr
    show (SExpr expr) = "(" ++ show expr ++ ")"

instance Show EAST where
    show (ELtrl lit) = show lit
    show (EName name) = name
    show (EList []) = "[]"
    show (EList exprs) = "[" ++ foldl1 ((++) . (++", ")) (map show exprs) ++ "]"
    show (ELmbd pats _) = "λ { " ++ foldl1 ((++) . (++"\n\t, ")) (map showPattern pats) ++ " }"
        where
        showPattern (dstrs, clauses) = foldl1 ((++) . (++", ")) (map show dstrs) ++ concatMap showClause clauses
        showClause (preds, expr)= concatMap showGuard preds ++ " ⊢ " ++ show expr
        showGuard = (" | "++) . show
    show (EAply f x) = "(" ++ show f ++ " " ++ show x ++ ")"
    show (EBlok [] body) = "do {\n" ++ concatMap ((++"\n") . show) body ++ "}"
    show (EBlok defs [expr]) = "let {\n" ++ concatMap ((++"\n") . show) defs ++ "}\nin " ++ show expr
    show (EBlok defs body) = "let {\n" ++ concatMap ((++"\n") . show) defs ++ "}\nin {\n" ++ concatMap ((++"\n") . show) body ++ "}"
    show EWild = "_"
    show (ESplc expr) = "$" ++ show expr
    show (EQotE expr) = "`" ++ show expr
    show (EQotD expr) = "`{" ++ show expr ++ "}"
    show (EUqtE expr) = "," ++ show expr
    show (EUqtD expr) = ",{" ++ show expr ++ "}"
    show (EName' n) = "EName' " ++ n
    show (Expr' es) = "Expr " ++ show es

instance Show DAST where
    show (DLtrl lit) = show lit
    show DWild = "_"
    show DDots = "…"
    show (DName name) = name
    show (DList []) = "[]"
    show (DList exprs) = "[" ++ fold exprs ++ "]"
        where fold [x] = show x
              fold (DDots : xs) = show DDots ++ " " ++ fold xs
              fold [x, DDots] = show x ++ " " ++ show DDots
              fold (x : DDots : xs) = show x ++ " " ++ show DDots ++ " " ++ fold xs
              fold (x : xs) = show x ++ ", " ++ fold xs
    show (DNode name dstr) = name ++ " {" ++ show dstr ++ "}"
    show (DSplc expr) = "$" ++ show expr
    show (DQotE expr) = "`" ++ show expr
    show (DQotD expr) = "`{" ++ show expr ++ "}"

 ------------ Misc Helpers ------------

ensureExists :: String -> IO ()
ensureExists filename = do
    exists <- doesFileExist filename
    if exists then return () else do
        putErrLn ("Cannot find file: `" ++ filename ++ "'.")
        exitFailure
    --FIXME also check that I have permissions

strToInteger :: Integer -> String -> Integer
strToInteger radix input = impl 0 input
  where impl acc "" = acc
        impl acc (x:xs) = impl (radix * acc + (toInteger . digitToInt) x) xs

data RawIntRep = RIR { rsgn' :: Sign
                     , rmag' :: Ratio Integer
                     , isgn' :: Sign
                     , imag' :: Ratio Integer
                     , radx' :: Integer
                     , expt' :: Integer
                     }

mkFossilNum :: RawIntRep -> FossilNum
mkFossilNum n = FNum { rsgn = rsgn' n
                     , rmag = (rmag' n) * mult
                     , isgn = rsgn' n
                     , imag = (imag' n) * mult
                     }
    where mult = (radx' n % 1) ^ (expt' n)

setMinus :: (Eq a) => [a] -> [a] -> [a]
setMinus a b = (not . (`elem` b)) `filter` a