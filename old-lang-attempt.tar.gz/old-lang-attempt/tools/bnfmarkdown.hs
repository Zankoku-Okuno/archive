import Prelude hiding (lex)
import Control.Monad
import System.IO
import System.Environment
import System.Exit
import Text.Parsec hiding (token)
import Text.Parsec.Char
import Text.Parsec.String


main = do
	args <- getArgs
	case args of
		["-css"] -> do { printCss; exitSuccess }
		[x] -> parseFile x
		_ -> do
			putErrLn "USAGE: bnfmarkdown ( -css | file )"
			exitFailure

parseFile x = do
	input <- readFile x
	case parse bnf x input of
		Left err -> do
			hPutStrLn stderr (show err)
			exitFailure
		Right val -> do
			putStrLn $ "<div class='bnf'>\n\n<table>" ++ val ++ "</table>\n\n</div>"
			exitSuccess

printCss = putStrLn ".bnf { font-style: normal; font-weight: normal; font-family: Palatino, serif; }\n\
					\.bnf .meta { font-weight: bold; font-size: 110%; }\n\                    
                    \.bnf .node { font-style: italic; }\n\
                    \.bnf .lex {  }\n\
                    \.bnf .lit { font-family: Helvetica, monospace; }\n\
                    \.bnf .spec { text-decoration: underline; }"


bnf :: Parser String
bnf = liftM concat (many $ blankline <|> line) << eof

linespace :: Parser String
linespace = many (oneOf " \t")

blankline :: Parser String
blankline =  (try (linespace >> char '\n' >> spaces) >> return "</table>\n\n<table>")
         <|> (char '#' >> many (noneOf "\n") >> (skip (char '\n') <|> eof) >> return "")

line :: Parser String
line = do
	linespace
	initial <- try (do 
			name <- many1 (noneOf " \n")
			linespace
			op <- (string "::=")
			return (node name++"</td><td style='text-align:right'>"++meta op)
		) <|> (do 
			linespace
			op <- string "|"
			return ("</td><td style='text-align:right'>"++meta op)
		)
	linespace
	body <- markup
	string "\n" <|> (eof >> return "")
	return $ "<tr><td style='text-align:right'>" ++ initial ++ "</td><td>" ++ body ++ "</td></tr>"

markup :: Parser String
markup = liftM (concatMap (++" ")) (many token)

token :: Parser String
token = (literal <|> lexeme <|> nonterminal <|> op <|> special) << linespace

literal :: Parser String
literal = try $ between2 (char '\'') (many1 $ noneOf "\' \n") >>= return . lit

lexeme :: Parser String
lexeme = try $ between2 (char '_') (many $ noneOf "_ \n") >>= return . lex

nonterminal :: Parser String
nonterminal = try $ between (char '<') (char '>') (many $ noneOf "> \n") >>= return . node

op :: Parser String
op = (try (string "(")
  <|> try (string ")")
  <|> try (string "[")
  <|> try (string "]")
  <|> try (string "{")
  <|> try (string "}")
  <|> try (string "|")
  <|> try (string "-")
  <|> try (string "''" >> return "ε")
   ) >>= return . meta

special :: Parser String
special = between (char '?' >> linespace) (try $ linespace << char '?') (many1 $ noneOf "?\n") >>= return . spec

lit x = "<span class='lit'>" ++ x ++ "</span>"
lex x = "<span class='lex'>" ++ x ++ "</span>"
node x = "<span class='node'>" ++ x ++ "</span>"
meta x = "<span class='meta'>" ++ x ++ "</span>"
spec x = "<span class='spec'>" ++ x ++ "</span>"


skip p = p >> return ()
between2 p = between p p
x << y = do { r <- x; y; return r }
putErrLn = hPutStrLn stderr