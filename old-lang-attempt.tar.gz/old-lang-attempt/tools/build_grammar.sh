echo '<html><head><meta charset="UTF-8"><style type="text/css">' > $2
tools/bnfmarkdown -css >> $2
echo '</style></head><body>' >> $2
tools/bnfmarkdown $1 >> $2
echo '</body></html>' >> $2