package okuno.shall.model

import System.currentTimeMillis
import scala.collection.mutable.ArrayBuffer

class Module(val subject: String) {
  val features = new ArrayBuffer[Feature]
  var runningTime = 0l
  
  protected def add(requirements: => Any) = {
    val start = currentTimeMillis()
    requirements
    val stop = currentTimeMillis()
    runningTime += stop-start
    this
  }
  def register(feature: Feature) = features += feature
  
}