package okuno.shall.model

import scala.collection.mutable.ArrayBuffer

class Suite {
  val modules = new ArrayBuffer[Module]
  
  def register(module: Module) = modules += module
}