package okuno.shall.model

case class TruthAssertion(val cmp: Boolean)
	extends Assertion("%s is not %s.") {
  
  def mustBeTrue {
    if (!cmp)
      throw new AssertionFailure(failMsg(cmp, true))
  }
  def mustBeFalse {
    if (cmp)
      throw new AssertionFailure(failMsg(cmp, false))
  }
}

case class EqualityAssertion[T](val cmp: T)
	extends Assertion("%s does not equal %s.", "%s equals %s.") {
  //def must = this //TODO find a way to make this work as "(2+2) must equal 4"
  
  def mustEqual(exp: T) {
    if (exp != cmp)
      throw new AssertionFailure(failMsg(cmp, exp))
  }
  def mustNotEqual(exp: T) {
    if (exp == cmp)
      throw new AssertionFailure(secondary(cmp, exp))
  }
}

case class SizeAssertion(val cmp: Seq[_])
	extends Assertion("Sequence of length %d does not have length %d.") {
  def mustHaveSize(exp: Int) {
    if(cmp.length != exp)
      throw new AssertionFailure(failMsg(cmp.length, exp))
  }
}
case class InclusionAssertion[T](val cmp: Seq[T])
	extends Assertion("%s does not contain element %s") {
  def mustInclude(exp: T) {
    if (!cmp.contains(exp))
      throw new AssertionFailure(failMsg(cmp, exp))
  }
}

//TODO mustHaveSize, mustBeIn

case class ExceptionAssertion(val expected: Exception)
	extends Assertion("%s was not thrown.", "Message '%s' is not '%s'.") {
  
  val className = ExceptionAssertion.getExceptionName(expected)
  
  def mustBeRaisedBy(block: => Any): Unit = {
    val msg = what_was_thrown(block)
    if (msg != null)
    	throw new AssertionFailure(msg)
  }
  
  private def what_was_thrown(block: => Any): String = {
    try {
      block
      primary(className)
    }
    catch {
      case caught: Exception => {
        if (ExceptionAssertion.getExceptionName(caught) != className)
          primary(className)
        else
          if (expected.getMessage == null || expected.getMessage == "" 
          		 || caught.getMessage == expected.getMessage)
    	    null
          else
            secondary(if (caught.getMessage == null) "" else caught.getMessage, expected.getMessage)
      }
    }
  }
}
object ExceptionAssertion {
  def getExceptionName(ex: Exception) = {
    val strVer: String = ex toString
    val fullName = if (strVer.contains(":"))
    			     strVer.substring(0, strVer.indexOf(":"))
    			   else strVer
    fullName.substring(fullName.lastIndexOf(".") + 1)
  }
}