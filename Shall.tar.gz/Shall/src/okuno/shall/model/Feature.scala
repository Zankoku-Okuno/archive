package okuno.shall.model


class Feature(val requirement: String) {
  
  var status: Status = untested()
  var output = ""
  
  def test(testCase: => Any) {
    try {
      testCase
      status = success()
    }
    catch {
      case af: AssertionFailure => {
        status = failure()
        output = af getMessage
      }
      case ex => {
        status = error()
        output = ex toString
      }
    }
    finally this
  }
  
}