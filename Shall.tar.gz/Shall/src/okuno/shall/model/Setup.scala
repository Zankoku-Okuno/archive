package okuno.shall.model

class Setup {

}