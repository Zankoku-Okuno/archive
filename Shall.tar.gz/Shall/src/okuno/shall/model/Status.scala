package okuno.shall.model

class Status

case class untested extends Status
case class success extends Status
case class failure extends Status
case class error extends Status