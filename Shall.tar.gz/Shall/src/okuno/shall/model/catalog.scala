package okuno.shall.model

import scala.collection.mutable.ArrayBuffer

object catalog {
  val suites = new ArrayBuffer[Suite]
  
  def register(suite: Suite) = suites += suite
  
  def foreach[U](block: Suite => U) = suites foreach block
  
}