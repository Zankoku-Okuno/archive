package okuno.shall.model


class Assertion(val primary: String, val secondary: String) {
  def this(msg: String) = this(msg, null)
  
  final def failMsg(cmp: Any) = primary(cmp)
  final def failMsg(exp: Any, cmp: Any) = primary(exp, cmp)
  
  def primary(cmp: Any): String = {
    primary.format(cmp toString)
  }
  def primary(exp: Any, cmp: Any): String = {
    primary.format(exp toString, cmp toString)
  }
  def secondary(cmp: Any): String = {
    secondary.format(cmp toString)
  }
  def secondary(exp: Any, cmp: Any): String = {
    secondary.format(exp toString, cmp toString)
  }
}

case class AssertionFailure(msg: String) extends Exception(msg) {
  def this() = this("")
}
