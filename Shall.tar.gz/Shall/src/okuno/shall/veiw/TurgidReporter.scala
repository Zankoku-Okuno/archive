package okuno.shall.veiw

object TurgidReporter extends BasicReporterHelper {
  override val verbosity = -1
  override def report() = summaryBlock
}