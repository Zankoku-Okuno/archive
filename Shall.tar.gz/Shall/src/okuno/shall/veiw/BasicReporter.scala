package okuno.shall.veiw

import okuno.shall.model._

class BasicReporter(override val verbosity: Int = 0) extends Reporter {
  
  val delegate = verbosity match {
    case 0 => EverydayReporter
    case v if v > 0 => VerboseReporter
    case v if v < 0 => TurgidReporter
  }
  
  def report(status: Status): String = delegate report status

  def report(feature: Feature): String = delegate report feature

  def report(module: Module): String = delegate report module

  def report(suite: Suite): String = delegate report suite

  def report(): String = delegate report

}

abstract class BasicReporterHelper extends Reporter {
  
  override def report(status: Status): String = {
    status match {
      case success() => "... okay."
      case untested() => " ???"
      case failure() => " FAILS: "
      case error() => ", but FATAL ERROR! "
    }
  }
  
  override def report(feature: Feature): String = {
    bullet(feature.status) + " " + feature.requirement +
    	report(feature.status) + feature.output
  }
  
  override def report(module: Module): String = {
    module.subject + " shall\n  " + 
    	(module.features map {report _} reduce {_+"\n  "+_})
  }
  
  override def report(suite: Suite): String = {
    suite.modules map {report _} reduce {_+"\n"+_}
  }
  
  override def report(): String = {
    val body = catalog.suites map{report _} reduce{_+"\n"+_}
    body + "\n" + summaryBlock 
  }
  
  
  protected def bullet(status: Status) = status match {
    case failure() => "!"
    case error() => "!"
    case untested() => "?"
    case success() => "*"
  }
  protected def summaryBlock() = {
    val errors = if (totalErrors > 0)
    			     formatCountNoun(totalErrors, "error")
    			 else ""
    val failures = if (totalFailures > 0)
    			     formatCountNoun(totalFailures, "failure")
    			   else ""
    val skipped = if (totalUntested > 0) totalUntested + " skipped" else ""
    val ofNote = List(errors, failures) filter {_ != ""}
    
    val summary = (if (ofNote.length > 0) ofNote reduce{_+", "+_}
    			   else "OK") +
    			  (if (skipped != "") ", " + skipped
    			   else "") + "."
    val profile = "Ran " + totalTests + " tests in " + formatTime(runningTime) + "."
    val sep = "-" * Math.max(profile length, summary.length + 4)
    Array(sep, profile, "  = " + summary, sep) reduce {_+"\n"+_}
  }
  def formatTime(millis: Long) = millis match {
    case time if time < 500 => time + " ms"
    case time if time > 60000 => {
      val min = time / 60000
      val sec = time / 1000 % 60
      min + " min " + sec + " s"
    }
    case time => time / 1000. + " s"
  }
  def formatCountNoun(count: Int, noun: String) = 
    count + " " + noun + (if(count != 1) "s" else "")
    
}