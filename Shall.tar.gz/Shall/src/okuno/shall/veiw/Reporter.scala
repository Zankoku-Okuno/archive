package okuno.shall.veiw
import okuno.shall.model._

trait Reporter {
  val verbosity: Int
  def report(status: Status): String
  def report(feature: Feature): String
  def report(module: Module): String
  def report(suite: Suite): String
  def report(): String
  
  def totalTests =
    catalog.suites map {
      _.modules map {
        _.features length
      } reduce {_+_}
    } reduce {_+_}
  
  def totalErrors =
    catalog.suites map {
      _.modules map {
        _.features filter{_.status == error()} length
      } reduce {_+_}
    } reduce {_+_}
  
  
  def totalFailures =
    catalog.suites map {
      _.modules map {
        _.features filter{_.status == failure()} length
      } reduce {_+_}
    } reduce {_+_}
  
  def totalUntested =
    catalog.suites map {
      _.modules map {
        _.features filter{_.status == untested()} length
      } reduce {_+_}
    } reduce {_+_}
  
  def runningTime = 
    catalog.suites map {
      _.modules map {
        _.runningTime
      } reduce {_+_}
    } reduce {_+_}
}