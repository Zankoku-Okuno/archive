package okuno.shall.veiw

import okuno.shall.model._

object EverydayReporter extends BasicReporterHelper {
  override val verbosity = 0
  override def report(): String = {
    (if (totalErrors + totalFailures + totalUntested > 0)
      catalog.suites map{report _} reduce{_+"\n"+_}
    else "") + "\n" + summaryBlock
  }
  
  override def report(suite: Suite): String = {
    suite.modules filter {
      _.features.filter {_.status != success()}.length > 0
    } map {report _} reduce {_+"\n"+_}
  }
  
  override def report(module: Module): String = {
    module.subject + " shall\n  " + 
    	(module.features filter {_.status != success()} map {report _} reduce {_+"\n  "+_})
  }
}