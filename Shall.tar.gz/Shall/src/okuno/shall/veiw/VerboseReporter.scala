package okuno.shall.veiw

import okuno.shall.model._

object VerboseReporter extends BasicReporterHelper {
  override val verbosity = 1
}