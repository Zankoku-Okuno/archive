package okuno.shall.dsl

import okuno.shall.model

class Feature(override val requirement: String, module: model.Module)
	extends model.Feature(requirement) {
  module register this
  
  final def like (testcase: => Any) = {
    test(testcase)
    this
  }
  final def skip {
    this.status = model.untested()
  }
  
  /* TODO
  override def like(testCase: => Any)
  					(implicit setup: () => Unit)
  					(implicit teardown: () => Unit) {
    setup()
    super.like(testCase)
    teardown()
  }
  */
}