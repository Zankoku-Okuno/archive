package okuno.shall.dsl

import okuno.shall.model
import okuno.shall.model.{
  TruthAssertion, EqualityAssertion,
  SizeAssertion, InclusionAssertion,
  ExceptionAssertion
}
import okuno.shall.model.catalog

class Suite extends model.Suite {
  
  private var module: Module = null
  
  implicit def string2feature(str: String) = new Feature(str, module)
  implicit def string2module(str: String) = { module = new Module(str, this); module }
  
  implicit def bool2tAssertion(bool: Boolean) = new TruthAssertion(bool)
  implicit def any2eqAssertion[T](block: => T) = new EqualityAssertion[T](block)
  implicit def seq2sizeAssertion(seq: Seq[_]) = new SizeAssertion(seq)
  implicit def any2inclusionAssertion[T](seq: Seq[T]) = new InclusionAssertion[T](seq)
  implicit def exception2exAssertion(exception: Exception) = new ExceptionAssertion(exception)
  
  implicit def array2sizeAssertion(seq: Array[_]) = new SizeAssertion(seq)
  implicit def array2inclusionAssertion[T](seq: Array[T]) = new InclusionAssertion[T](seq)
  
}