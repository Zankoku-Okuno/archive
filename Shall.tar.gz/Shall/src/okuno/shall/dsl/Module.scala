package okuno.shall.dsl

import okuno.shall.model

class Module(override val subject: String, specification: model.Suite)
	extends model.Module(subject) {
  specification register this
  
  final def shall(requirements: => Any) = {
    add(requirements)
  }
}