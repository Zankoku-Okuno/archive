package okuno

import okuno.shall.veiw._
package object shall {
  val libname = "UnitShall"
  val description = "A Scala unit test library with domain specific language."
  val version = "v0.9b"
  val authors = Array("Zankoku Okuno")
  
  type Feature = dsl.Feature
  type Module = dsl.Module
  type Suite = dsl.Suite
  
  val catalog = model.catalog
  
  def run(suites: Suite*) {
    suites foreach {
      catalog register _
    }
  }
  
  def report(verbosity: Int = 0) {
    print(new BasicReporter(verbosity).report())
  }
  def contemplate {
    //TODO, like koans
  }
  
}