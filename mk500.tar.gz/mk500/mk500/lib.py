from libzan import *
import re

import mk500
from mk500 import Division, Span, Line, priority

# ================ #
# == SuperBasic == #
# ================ #

@mk500.plugin
class SuperBasic:
    class Paragraph(Division):
        def parse(self, logical_lines):
            self.lines = logical_lines
    class Text(Span):
        def parse(self, text):
            self.text = text
    
    def block_passthrough(self, block):
        acc = ''
        for physical_line in block:
            done = True
            if physical_line.endswith('\\'):
                if not physical_line.endswith('\\\\'):
                    done = False
                physical_line = physical_line[:-1]
            acc += physical_line
            if done:
                yield acc + '\n'
                acc = ''
        if acc: yield acc

    @priority(Infinity)
    def is_block_paragraph(self, block):
        return True
    def block_paragraph(self, block):
        logical_lines = ['']
        for physical_line in block:
            if physical_line.endswith('\\'):
            #TODO allow the double-space at eol to trigger linebreak, for Gruber compatability
                logical_lines[-1] = smart_line_join(logical_lines[-1], physical_line[:-1])
                if not physical_line.endswith('\\\\'):
                    logical_lines.append('')
            else:
                logical_lines[-1] = smart_line_join(logical_lines[-1], physical_line)
        if not logical_lines[-1]:
            logical_lines = logical_lines[:-1]
        return SuperBasic.Paragraph(logical_lines)
    
    @priority(Infinity)
    def is_block_text(self, block):
        return True, 0, None
    def block_text(self, block):
        return SuperBasic.Text(reduce(lambda acc,x: smart_line_join(acc, x), block, ''))
    @priority(Infinity)
    def is_element_text(self, line):
        return True, 0, None
    def element_text(self, line):
        return SuperBasic.Text(line)

# ========== #
# == Core == #
# ========== #

@mk500.plugin
class Core:
    class Header(SuperBasic.Text):
        def parse(self, text): raise NotImplementedError() #STUB
        def build(self, level, text):
            self.level, self.text = level, text
    class Emphasis(Span):
        def parse(self, text):
            if text.startswith('**'):
                self.build('em', 2, text[2:-2])
            elif (text.startswith('*')):
                self.build('em', 1, text[1:-1])
            elif (text.startswith('_')):
                self.build('u', 1, text[1:-1])
            else: assert False
        def build(self, kind, level, text):
            self.kind, self.level, self.text = kind, level, text
    class Link(Span):
        def parse(self, text): raise NotImplementedError() #STUB
        def build(self, text, target, **attrs):
            self.text = text
            self.target = target
            self.attrs = attrs
    class List(Division):
        def parse(self, lines): pass #STUB
        def build(self, numbering, items):
            self.numbering = numbering
            self.items = items

# ============ #
# == Gruber == #
# ============ #
@mk500.plugin
class Gruber:
    emphasis_detector = re.compile(r'(([*_])\2?)(?![\s,.:;!?]).*?(?<![\s,.:;!?])\1(?!\w)', re.I)
    def is_element_emphasis(self, line):
        match = Gruber.emphasis_detector.search(line.text)
        if match: return (True,) + match.span()
    def element_emphasis(self, line):
        if line.text.startswith("__"):
            return Core.Emphasis('**'+line.text[2:-2]+'**')
        elif line.text.startswith("_"):
            return Core.Emphasis('*'+line.text[1:-1]+'*')
        else: return Core.Emphasis(line.text)

    link_detector = re.compile(r'''\[(?P<text>[^\]]+)\](?:\((?P<target>[^\)]+?)(?:\s+(?P<q>['"])(?P<title>[^\)]*?)(?P=q))?\)|\[(?P<id>[^\]]*)\])''')
    def is_element_link(self, line):
        m = Gruber.link_detector.search(line.text)
        return False if not m else (True,) + m.span()
    def element_link(self, line):
        match = Gruber.link_detector.match(line.text).groupdict()
        text, target, title, id = match['text'], match['target'], match['title'], match['id']
        if target:
            return Core.Link.factory(text, target, title=title)
        else:
            if not id: id = text
            id = id.lower() #HAX why I need lower here?

            def bind_link(state):
                _target, _attrs = state.link_defs[id]
                return Core.Link.factory(text, _target, **_attrs)
            return bind_link
    link_def_detector = re.compile(r'\s*\[([^\)]*?)\]:\s*(.*?)(?:\s+"(.*?)")?\s*$')
    def is_block_link_def(self, block):
        for i, line in enumerate(block):
            if Gruber.link_def_detector.match(line):
                break
        else: return False
        j = i+1
        while j < len(block):
            if not Gruber.link_def_detector.match(block[j]):
                break
            j += 1
        return True, i, j
    def block_link_def(self, block):
        if not hasattr(self.state, 'link_defs'):
            self.state.link_defs = dict()
        for line in block:
            id, target, title = Gruber.link_def_detector.match(line).groups()
            data = {'title': title} if title else dict()
            self.state.link_defs[id] = (target, data)

    bullet_detector = re.compile(r'(\s*)\*\s+')
    indent_detector = re.compile(r'(\s*)')
    def is_block_list(self, block):
        match, i = None, 0
        while i < len(block):
            match = Gruber.bullet_detector.match(block[i])
            if match: break
            i += 1
        else: return False
        j, indent = i+1, len(match.groups()[0])
        while j < len(block):
            match = Gruber.indent_detector.match(block[j])
            if not (match and len(match.groups()[0]) >= indent):
                break
            j += 1
        return True, i, j
    def block_list(self, block):
        #go until an unindent is found: all the acc lines are a Block
        def package(lines):
            if isinstance(lines, mk500.Block) or isinstance(lines, mk500.Line):
                return lines
            elif len(lines) == 1:
                return mk500.Line(lines[0], block.loc[0]+i-len(block))
            elif Gruber.bullet_detector.match(lines[1]):
                return [mk500.Line(lines[0], block.loc[0]+i-len(block)),
                        mk500.Block(block.loc[0]+i-len(block)+1, lines[1:])]
            else:
                return mk500.Block(block.loc[0]+i-len(block), lines)
        items = []
        indent = len(Gruber.bullet_detector.match(block[0]).groups()[0])
        trim = indent + 1
        for i, line in enumerate(block.lines):
            match = Gruber.bullet_detector.match(line)
            if match and len(match.groups()[0]) == indent:
                if items: items[-1] = package(items[-1])
                items.append([])
                line = line[trim:].lstrip()
            else:
                line = line[trim:]
            items[-1].append(line)
        if items: items[-1] = package(items[-1])
        return Core.List.factory(False, items)

# =============== #
# == My Syntax == #
# =============== #

@mk500.plugin
class Okuno:
    header_extraction = re.compile(r'\s*(={6}|===?|---?)\s*(.+?)\s*\1\s*$')
    def is_block_header(self, block):
        match = Okuno.header_extraction.match(block.lines[0])
        if match:
            return True, 0, 1
    def block_header(self, block):
        level, text = Okuno.header_extraction.match(block.lines[0]).groups()
        level = {'======': 2,
                 '===': 3, '==': 3,
                 '---': 4, '--': 4}[level]
        return Core.Header.factory(level, text)

# ========== #
# == HTML == #
# ========== #
    
@mk500.plugin
class HTML:
    # Constants
    open, close, void, comment = 'open', 'close', 'void', 'comment'
    
    html_attr = r'''[a-zA-Z][0-9a-zA-Z]*(?:\s*=\s*(?:'[^']*'|"[^"]*"|[^'"\s/>][^\s/>]*))?'''
    html_start_tag = r'''<[a-zA-Z][0-9a-zA-Z]*(?:\s+{})*\s*/?>'''.format(html_attr)
    html_close_tag = r'''</[a-zA-Z][0-9a-zA-Z]*\s*>'''
    html_comment = r'''<!--.*?-->'''
    html_tag = r'(?:{}|{}|{})'.format(html_start_tag, html_close_tag, html_comment)
    
    tag_detector = re.compile(r'\\?\\?{}'.format(html_tag))
    name_extractor = re.compile(r'<(/?[0-9a-zA-Z]+)')
    attr_extractor = re.compile(r'''([0-9a-zA-Z]+)(?:\s*=\s*('[^']*'|"[^"]*"|[^'"\s/>][^\s/>]*))?''')
    
    # All html elements in output should be generated through this class because
    # element names and attributes are validated in build, and...
    class HtmlElement(Span):
        def parse(self, text):
            assert HTML.tag_detector.match(text)
            if text.startswith('<!--'):
                self.text = text
                return self.build(HTML.comment, None)
            match = HTML.name_extractor.match(text)
            if match:i = match.end()
            # 1. Determine tag name and type
            name = match.groups()[0]
            if name.startswith('/'):
                name = name[1:]
                type = HTML.close
            elif text.endswith('/>'):
                type = HTML.void
            else:
                type = HTML.open
            # 2. Extract attributes
            attributes = dict()
            while True:
                match = HTML.attr_extractor.search(text, i)
                if match is None: break
                i = match.end()
                key, value = match.groups()
                if value.startswith('"') or value.startswith("'"):
                    value = value[1:-1]
                #TODO ensure the key doesn't already exist
                attributes[key] = escape_html_attribute(value) #REFAC move to printing
            # 3. Pass on to build, where everything is validated
            self.build(type, name, **attributes)
        def build(self, type, name, **attrs):
            #TODO lookup custom tags
            #TODO validate tag info (including that close tags have no attributes)
            self.type = type
            self.name = name
            self.attrs = {k:v for k, v in attrs.items() if v is not None}
    # Shortcuts
    OpenElement = partial(HtmlElement.factory, open)
    CloseElement = partial(HtmlElement.factory, close)
    VoidElement = partial(HtmlElement.factory, void)
    
    # ... printing also validates html structure.
    def print_HtmlElement_html(self, item):
        #TODO validate
        attrs = ''.join(' {}="{}"'.format(key, escape_html_attribute(value))
                         for key, value in item.attrs.items())
        if item.type == HTML.comment:
            return item.text
        elif item.type == HTML.open:
            return "<{}{}>".format(item.name, attrs)
        elif item.type == HTML.close:
            return "</{}{}>".format(item.name, attrs)
        elif item.type == HTML.void:
            return "<{}{}/>".format(item.name, attrs)
        else:
            raise Exception("TODO")
    
    def is_block_inline_html(self, block):
        fmatch = HTML.tag_detector.match(block[0].strip())
        if not fmatch or fmatch.end() != len(block[0].strip()): return False
        lmatch = HTML.tag_detector.match(block[-1].strip())
        if not lmatch or lmatch.end() != len(block[-1].strip()): return False
        return partial(SuperBasic.block_passthrough, self)
    def is_element_inline_html(self, line):
        m = HTML.tag_detector.search(line.text)
        return False if not m else (True, m.start(), m.end())
    def element_inline_html(self, line):
        return HTML.HtmlElement(line.text)
    
    
    def print_Paragraph_html(self, div):
        yield HTML.OpenElement('p')
        if div.lines: yield Line(div.lines[0])
        for line in div.lines[1:]:
            yield HTML.VoidElement('br')
            yield Line(line)
        yield HTML.CloseElement('p')
    def print_Text_html(self, span):
        return escape_html_text(span.text)

    def print_Header_html(self, span):
        tagname = 'h{}'.format(span.level)
        yield HTML.OpenElement(tagname)
        yield SuperBasic.Text(span.text)
        yield HTML.CloseElement(tagname)

    def print_Emphasis_html(self, span):
        if span.kind == 'em':
            kind = ['em', 'strong'][span.level-1]
        elif span.kind == 'u':
            kind = 'u'
        else: assert False
        yield HTML.OpenElement(kind)
        yield mk500.Line(span.text)
        yield HTML.CloseElement(kind)

    def print_Link_html(self, span):
        yield HTML.OpenElement('a', href=span.target, **span.attrs)
        yield SuperBasic.Text(span.text)
        yield HTML.CloseElement('a')

    def print_List_html(self, block):
        if block.numbering is False:
            yield HTML.OpenElement('ul')
            for item in block.items:
                yield HTML.OpenElement('li')
                yield item
                yield HTML.CloseElement('li')
            yield HTML.CloseElement('ul')
        else: raise NotImplementedError() #STUB


    def postfilter_pretty_indent(self, text):
        return text #STUB

# ========== #
# == Code == #
# ========== #

from pygments import highlight
from pygments.lexers import get_lexer_by_name, guess_lexer
from pygments.formatters import HtmlFormatter

@mk500.plugin
class Code:
    #TODO allow automatic generation of a css file (into the metadata?)

    open_block_detector = re.compile(r'(?:^|(?<=\s))([^\s]+)?(~~~+)(\s*{0}(?:\s+{0})*)?$'.format(HTML.html_attr), re.I)
    inline_detector = re.compile(r'([^\s~]+)?(~~~+)(.+?)\2', re.I)
    def is_block_code(self, block):
        match = Code.open_block_detector.match(block[0])
        return bool(match and re.match(r'\s*{}\s*$'.format(match.groups()[1]), block[-1]))
    def block_code(self, block):
        return Code.CodeDiv(block.lines)


    def is_element_code(self, line):
        match = Code.inline_detector.search(line.text)
        if match: return (True,) + match.span()
    def element_code(self, line):
        lang, _, text = Code.inline_detector.match(line.text).groups()
        return Code.CodeSpan.factory(lang, text)

    class CodeDiv(Division):
        def parse(self, lines):
            lang, _, attr_text = Code.open_block_detector.match(lines[0]).groups()
            lines = lines[1:-1]
            for i, line in enumerate(lines):
                if re.match(r'\s*~+\s*$', line):
                    lines[i] = ''
            attributes = dict()
            if attr_text:
                i = 0
                while True:
                    match = HTML.attr_extractor.search(attr_text, i)
                    if match is None: break
                    else: i = match.end()
                    key, value = match.groups()
                    if value.startswith('"') or value.startswith("'"):
                        value = value[1:-1]
                    #TODO ensure the key doesn't already exist
                    attributes[key] = value
            self.build(lang, '\n'.join(lines), **attributes)
        def build(self, lang, text, **attrs):
            #TODO validate attrs
            self.lang, self.text, self.attrs = lang, text, attrs
    class CodeSpan(Span):
        def parse(self, text): raise NotImplementedError() #STUB
        def build(self, lang, text):
            self.lang, self.text = lang, text

    def print_CodeDiv_html(self, div):
        yield HTML.OpenElement('div', **{'class': 'codeblock'})
        if 'title' in div.attrs:
            yield Core.Header.factory(6, div.attrs['title'])
        if 'line' in div.attrs:
            line = div.attrs['line']
        else: line = 1
        if div.lang is None:
            if 'code' in self.state.metadata:
                cssclass = self.state.metadata['code'].lower()
                lexer = get_lexer_by_name(cssclass)
            else:
                lexer = guess_lexer(div.text)
                cssclass = re.sub(r'\s', '_', lexer.name.lower())
        else:
            lexer = get_lexer_by_name(div.lang.lower())
            cssclass = div.lang
        cssclass = re.sub(r'\+', 'p', cssclass)
        formatter = HtmlFormatter(linenos=True, linenostart=line)
        #if 'pygments' not in self.state.metadata:
        #    self.state.metadata['pygments'] = formatter.get_style_defs()
        yield highlight(div.text, lexer, formatter)
        yield HTML.CloseElement('div')
    def print_CodeSpan_html(self, span):
        if span.lang is None:
            yield HTML.OpenElement('code')
            yield SuperBasic.Text(span.text)
        else:
            pass #STUB incorportate pygments
        yield HTML.CloseElement('code')


# =============== #
# == Utilities == #
# =============== #

def smart_line_join(a, b):
    """Handles adding appropriate whitespace (or lack thereof) when two
    physical lines are concatenated as logical lines. Also removes
    hyphenation (at most one character) from words broken across a line."""
    if not a: return b.strip()
    elif not b: return a.strip()
    elif a[-1] == '-': return a[:-1] + b.strip()
    elif a[-1] == '/': return a + b.strip()
    else: return a + ' ' + b.strip()


html_escapes = [
    (r'&(?!#x?[a-z0-9A-F]+;|[a-zA-Z]+;)', '&#38;'),
    ('<', '&#60;'),
    ('>', '&#62;'),
    ('"', '&#34;'),
    ("'", '&#39;')
]
html_escapes = [(re.compile(pattern), replacement) for pattern, replacement in html_escapes]

def base_escape_html(num, text):
    #TODO normalize named entity references into num
    for pattern, replacement in html_escapes[:num]:
        text = pattern.sub(replacement, text)
    return text
    
escape_html_text = partial(base_escape_html, 3)
escape_html_attribute = partial(base_escape_html, 5)


