"""Mk. 500 is a strictly-targeted, component-based markdown micro-engine. It is
responsible for nothing more than parsing a writer's content and generating
some output strings. The primary focus of the engine is to create a streamlined,
powerful interface for a user who want to experiment and swap features in and
out.

In design, Mk. 500 has been approached as a form of simple compilation engine.
Thus, the framework supports rich state machines, input validataion and
forward/backward reference resolution. The analogous jobs of linking and loading
(such as applying output to templates) are left to other systems.

In addition to the engine itself, Mk. 500 comes with a library of plugins that
supports an expressive markdown langauge targeted at programmers wishing to
deploy content to the web.

Copyright (c) 2012, Eric Demko
This software is licensed under the Modified BSD License.
See COPYING for more details."""

import sys
from inspect import *
from libzan import *
from .util import *

# ===================== #
# == Plugin Wrangler == #
# ===================== #

class Registry:
    plugins = set()
    
    @classmethod
    def metadata(cls, tagname, value):
        assert tagname
        return tagname, value #STUB
    
class Plugin:
    def __init__(self, state):
        self.state = state

    @staticmethod
    def factory(cls, state):
        if (cls.__init__ is object.__init__
        or  len(getfullargspec(cls.__init__).args) == 1):
            out = cls()
            Plugin.__init__(out, state)
            return out
        else:
            return cls(state)

def plugin(cls):
    Registry.plugins.add(cls)
    return cls

def priority(num):
    def impl(func):
        func.priority = num
        return func
    return impl    

# ===================== #
# == Data Structures == #
# ===================== #

class Output(dict):
    def __init__(self, metadata):
        super().__init__()
        self.metadata = metadata

class Block(Located):
    def __init__(self, start_line, lines):
        super().__init__((start_line, start_line+len(lines)-1) if start_line is not None else None)
        self.lines = lines
    
    def __len__(self): return len(self.lines)
    def __bool__(self): return bool(self.lines)
    def __iter__(self): return iter(self.lines)
    def __getitem__(self, i): return self.lines[i]

class Line(Located):
    def __init__(self, text, loc=None):
        if loc is None:
            try: loc = lexical_bind('block').loc
            except TypeError: pass
                #TODO make it a warning if loc is None and I can't bind lexically
        elif isinstance(loc, Block):
            loc = loc.loc
        super().__init__(loc) #TODO set up location
        self.text = text
    
    def __len__(self): return len(self.text)
    def __bool__(self): return bool(self.text)

class Element:
    @classmethod
    def factory(cls, *args, **kwargs):
        out = cls(None)
        out.build(*args, **kwargs)
        return out
    def build(self, *args, **kwargs):
        self.parse(*args, **kwargs)

class Division(Located, Element):
    def __init__(self, item=None, loc=None):
        if isinstance(item, Block):
            loc = item.loc if loc is None else loc
            lines = item.lines
        elif iterable(item):
            if loc is None:
                try: self.loc = lexical_bind('block').loc
                except TypeError: self.loc = None
                    #TODO make it a warning if loc is None and I can't bind lexically
            lines = list(item)
            #MAYBE this should be harder, like, only allow strings in the list
        else:
            lines = []
        super().__init__(loc)
        self.parse(lines)

class Span(Located, Element):
    def __init__(self, item=None, loc=None):
        if isinstance(item, Line):
            super().__init__(item.loc if loc is None else loc)
            text = item.text
        elif isinstance(item, str):
            if loc is None:
                try: loc = lexical_bind('line', 'block').loc
                except TypeError: pass
                    #TODO make it a warning if loc is None and I can't bind lexically
            text = item
        else:
            text = None
        if text is not None:
            self.parse(text)

# ========== #
# == Main == #
# ========== #

class Main:
    def __init__(self, config):
        self.source = (FileSource(config['ifile']) if 'ifile' in config
                       else StreamSource(sys.stdin))
        self.plugins = config.get("plugins", always)
        self.postfilters = config.get("postfilter", '').split()
        self.format = config['format']
    def run(self):
        with self.source as source:
            # 1. Determine metadata
            metadata, included = extract_metadata(source)
            #TODO actually perform the inclusion (use libzan.saturate, prolly)
            output = Output(metadata)
            #metadata = freeze(metadata)
            # 2. Split apart segments
            segments = extract_segments(source)
            if not segments: segments[0] = Segment(0)
            # 3. Dispatch each segment to the pipeline
            for key, segment in segments.items():
                state = State(None, metadata, self.format, self.plugins, self.postfilters)
                output[key] = handle_segment(state, segment)
            return output

def run(configuration):
    return Main(configuration).run()

# ========================= #
# == Metadata Extraction == #
# ========================= #

indent_detector = r'(\s+)'
base_attribute_detector = r'([a-zA-Z0-9 _-]+?){}\s*(.*(?:\r?\n|\r|$))'
attribute_detector = {
    None: re.compile(base_attribute_detector.format(r'(:|\s*=)')),
    '=': re.compile(base_attribute_detector.format(r'\s*=')),
    ':': re.compile(base_attribute_detector.format(r':')),
    'include': re.compile(r'#include\s+(.+)$')
}

def extract_metadata(source):
    metadata, included = dict(), set()
    syntax = None #undetermined
    while True:
        # 1. Determine if there is an attribute definition
        detection = attribute_detector[syntax].match(source.line)
        inclusion = attribute_detector['include'].match(source.line)
        if not (detection or inclusion): break #wouldn't it be nice to have a do...until?
        # 2a. If it's an inclusion, then only track the filename
        if inclusion:
            included.add(inclusion.groups()[0].strip())
            source.advance()
            continue
        # 2b. Extract the name and first line of an attribute definition
        if syntax is None: #we haven't established a syntax yet
            key, syntax, value = detection.groups()
            syntax = syntax.strip()
        else:
            key, value = detection.groups()
        source.advance()
        # 3. Extract further lines for multi-line attributes
        indent = re_find(re.match(r'\s+', source.line))           #accumulate indented lines
        if indent:
            while source.line.startswith(indent):
                value += source.line[len(indent):]
                source.advance()
        # 4. Normalize attribute name and parse attribute value
        key, value = Registry.metadata(key, chomp(value))
        metadata[key] = value
    return metadata, included

# ======================= #
# == Segment Detection == #
# ======================= #

segment_matchers = [
    (re.compile(r'\s*\$\s*()\s*\$?\s*$'), lambda x: None),
    (re.compile(r'\s*\$\s*(\d+)\s*\$?\s*$'), lambda x: int(x)),
    (re.compile(r'\s*\$\s*([\w\d_-]+)\s*\$?\s*$'), lambda x: x.lower())
]

def detect_segment_start(source):
    if isempty(source.line): return False, None
    for matcher, adapter in segment_matchers:
        match = matcher.match(source.line)
        if match:
            return True, adapter(match.groups()[0])
    else:
        return False, None

def extract_segments(source):
    def make_segment():
        return Block(source.loc, [])
    # Advance to content
    while source.line and isempty(source.line): source.advance()
    segments, unnamed_segments, implicit_seg = dict(), [], make_segment()
    current, seg_start = implicit_seg, False
    while source.line:
        # Advance from segment definition to start of content
        if seg_start:
            while source.line and isempty(source.line): source.advance()
            seg_start = False
        # Detect whether a segment starts on this line
        exists, key = detect_segment_start(source)
        if exists:
            if key is None:
                unnamed_segments.append(make_segment())
                current = unnamed_segments[-1]
            else:
                segments[key] = make_segment()
                current = segments[key]
            seg_start = True
        else:
            current.lines.append(source.line)
        source.advance()
    # Deal with the first segment (if not explicit)
    if implicit_seg:
        if 0 not in segments: segments[0] = implicit_seg
        elif 'main' not in segments: segments['main'] = implicit_seg
        else: raise MarkdownError("Main segment already defined.")
    # Deal with unnamed segments
    i = 1
    for seg in unnamed_segments:
        while i in segments: i += 1
        segments[i] = seg
    return segments

# ======================== #
# == Pipeline Execution == #
# ======================== #

def handle_segment(state, segment):
    state.late_binding = False
    intermediate = handle_raw(state, segment)
    state.late_binding = True
    acc = ''
    for item in intermediate:
        if isinstance(item, str):
            acc += item
        elif callable(item):
            acc += handle_late_binding(state, item)
        else: assert False
    return state.dispatch(acc)

def handle_raw(state, block):
    acc = []
    leftover = block
    while leftover:
        handler, div, leftover = state.dispatch(leftover)
        data = [handler(div)]
        while data:
            item, data = data[0], data[1:]
            item, feedback = handle_parsed(state, item)
            if item: acc.append(item)
            if feedback: data = feedback + data
    return acc

def handle_parsed(state, item):
    #state = lexical_bind('state') #SPIFFY lexical binding is expensive. A small test in v0.2a turned ~300ms into ~80 ms
    if isinstance(item, str):
        return item, []
    elif isinstance(item, Block) or isinstance(item, Line):
        return None, handle_raw(state, item)
    elif isinstance(item, Element):
        return None, handle_printing(state, item)
    elif callable(item):
        if state.late_binding: return None, handle_late_binding(state, item)
        else: return item, []
    elif iterable(item):
        return None, list(item)
    elif item is None:
        return None, None
    else:
        raise MarkdownError("Expected str, Block, Line, Element, callable, iterable or None. Got {}".format(item.__class__))

def handle_late_binding(state, callback):
    data = callback(state)
    if isinstance(data, str):
        return data
    acc = ''
    if not iterable(data):
        data = [data]
    while data:
        item, data = data[0], data[1:]
        item, feedback = handle_parsed(state, item)
        if item: acc += item
        if feedback: data = feedback + data
    return acc

def handle_printing(state, elem):
    acc = []
    data = [state.dispatch(elem)(elem)]
    while data:
        item, data = data[0], data[1:]
        item, feedback = handle_parsed(state, item)
        if item: acc.append(item)
        if feedback: data = feedback + data
    return acc

# ==================== #
# == Pipeline State == #
# ==================== #

class State:
    def __init__(self, parent, metadata, format, plugin_loader, postfilters):
        self.metadata = metadata
        self.parent = parent
        self.format = format
        self.mode = Mode(self, plugin_loader)
        self.printers = self.load_printers()
        self.postfilters = self.load_postfilters(postfilters)
    
    def load_printers(self):
        acc = set()
        for plugin in self.mode.plugins:
            acc |= {method for name, method in getmembers(plugin, ismethod)
                    if name.startswith('print_')}
        return acc
    def load_postfilters(self, requests):
        def validate(S):
            if len(S) > 1: raise MarkdownError("Ambiguous postfilter.")
            elif S: return S.pop()
            else: return None
        def by_methodname(methodname):
            possible = {method for name, method in getmembers(plugin, ismethod)
                            if name.lower() == methodname}
            return validate(possible)
        def by_classname(classname):
            possible = {plugin.postfilter for plugin in self.mode.plugins
                        if hasattr(plugin, 'postfilter')
                        and plugin.__class__.__name__.lower() == classname}
            return validate(possible)
        # body
        acc = []
        for requested_name in requests:
            methodname = "postfilter_{}".format(requested_name.lower())
            classname = requested_name.lower()
            for plugin in self.mode.plugins:
                possible = by_methodname(methodname)
                if possible:
                    acc.append(possible)
                    break
                possible = by_classname(classname)
                if possible:
                    acc.append(possible)
                    break
            else: raise MarkdownError("No postfilter by the name of '{}' found.".format(requested_name))
        return acc
    
    def dispatch(self, item):
        if isinstance(item, Block):
            return self.mode.resolve_block(item)
        elif isinstance(item, Line):
            return self.mode.resolve_element(item)
        elif isinstance(item, Element):
            return self.resolve_printer(item.__class__)
        elif isinstance(item, str):
            return self.postfilter(item)
        else:
            raise MarkdownError("Only Block, Line, and Span clases can be dispatched. Got {}".format(item.__class__))
    
    def resolve_printer(self, cls):
        def check_name(name):
            name = name.lower()
            matches = {method for method in self.printers
                       if method.__name__.lower() == name}
            if len(matches) > 1:
                raise MarkdownError("Ambiguous printers for span '{}'.".format(cls.__name__))
            elif len(matches) == 1:
                return matches.pop()
            return None
        for name in ['print_{}_{}'.format(cls.__name__, self.format),
                     'print_{}'.format(cls.__name__)]:
            best = check_name(name)
            if best is not None: return best
        else:
            raise MarkdownError("No printer for span '{}'".format(cls.__name__))
    
    def postfilter(self, text):
        for postfilter in self.postfilters:
            text = postfilter(text)
        return text

    def get(self, name, default):
        return getattr(self, name) if hasattr(self, name) else default

class Mode:
    def __init__(self, state, plugin_loader):
        # 1. Detect all plugins
        if iterable(plugin_loader):
            self.plugins = {Plugin.factory(x, state) for x in plugin_loader}
        elif callable(plugin_loader):
            self.plugins = {Plugin.factory(x, state) for x in Registry.plugins
                            if plugin_loader(x)}
        else:
            raise MarkdownError('A plugin loader must be a list of plugins or a callable accepting a plugin and returning a boolean.')
        # 2. Load elements of those plugins
        self.blocks, self.elements, self.printers = set(), set(), set()
        for plugin in self.plugins:
            items = getmembers(plugin, ismethod)
            self.blocks |= {method for name, method in items
                            if name.startswith('is_block')}
            self.elements |= {method for name, method in items
                              if name.startswith('is_element')}
    
    def resolve_block(self, block):
        # 1. Determine possible handlers and the extent of the block they would handle
        possible = set()
        for is_active in self.blocks:
            #the format for activations is '(handler, start_index, end_index)' or 'False;
            activation = adapt_activation(is_active, block)
            if activation: possible.add(activation)
        # 2. Resolve best fit handler
        possible = get_non_intersecting(possible)
        handler, start, end = resolve(possible, block)
        # 3. Return handler and the two segments of the block
        sloc, eloc = (block.loc[0] + start, block.loc[0] + end) if block.loc else (None, None)
        take = Block(sloc, block.lines[start:end])
        leave = Block(eloc, block.lines[end:])
        return handler, take, leave
    def resolve_element(self, elements):
        # 1. Determine possible handlers and the extent of the block they would handle
        possible = set()
        for is_active in self.elements:
            #the format for activations is '(handler, start_index, end_index)' or 'False;
            activation = adapt_activation(is_active, elements)
            if activation: possible.add(activation)
        # 2. Resolve best fit handler
        possible = get_non_intersecting(possible)
        handler, start, end = resolve(possible, elements)
        # 3. Return handler and the two segments of the block
        take = Line(elements.text[start:end], elements.loc)
        leave = Line(elements.text[end:], elements.loc)
        return handler, take, leave

# ======================== #
# == Resolution Helpers == #
# ======================== #

#def get_priority(item):
#    return getattr(item, 'priority', 0)

def adapt_activation(is_active, item):
    activation = pad_tuple(3, is_active(item))
    #if the activation is a simple 'True', then resolve the handler in the plugin
    if not activation[0]:
        return False
    if activation[0] is True:
        activation = (getattr(is_active.__self__, is_active.__name__[3:]),) + activation[1:]
    #if any activation records have None as a start index, then they have matched the entire block
    if activation[1] is activation[2] is None:
        activation = (activation[0], 0, len(item))
    #append the priority of the match
    activation += (getattr(is_active, 'priority', 0),)
    return activation

def get_non_intersecting(possible):
    # 1. Determine intersections
    intersections = dict()
    #for pairs of distinct posssible handlers # |
    for handler in possible:                  # |
        intersections[handler] = set()        # |
        for other in possible:                # |
            if handler is not other:          #</
                #handlers canot intersect if the have a None end position
                if (handler[2] is not None and other[2] is not None
                #check for handlers that intersect...
                    and intersect(handler[1:], other[1:])
                #...but ignore intersections where the intersectee has a worse (higher) priority
                #i.e. the aftermath of instersections is not symmetric, and favors the better (lower) priority handler
                    and other[3] <= handler[3]):
                    intersections[handler].add(other)
    # 2. Determine handlers that survived (not intersected by better priority handler)
    keep = set()
    for handler, S in intersections.items():
        if not forsome(S, lambda x: x[3] < handler[3]):
            keep.add(handler)
    return keep
def intersect(range1, range2):
    return range1[1] > range2[0] or range1[0] < range2[1]

def resolve(possible, item):
    #if there are no posible handlers, then this is an error
    if not possible:
        raise MarkdownError("No handler for {}:\n{}".format('block' if isinstance(item, Block) else 'line', item))
    #find all the possibilities with the samllest and second smallest starting positions
    #if there is no second smallest starting position, then pad with a sentinel
    first, second = pad_iterable(2, splitby(lambda x: x[1], possible),
                                    [(None, len(item), len(item))])
    #find all the first possibilities that have the best (lowest) priority
    first = splitby(lambda x: x[3], first)[0]
    #if any matches are solid (don't have None as their end), remove all non-solid matches
    if forsome(first, lambda x: x[2] is not None):
        first = list(filter(lambda x: x[2] is not None, first))
    #if there are too many earliest, best priority handlers, this is an error
    if len(first) > 1:
        raise MarkdownError("Ambiguous handlers: '{}'.".format([(f[0].__name__, f[0].__self__.__class__.__name__, f[3]) for f in first]))
    #extract information about the handlers
    #we only need the start position of the second earliest handlers
    handler, first, second = first[0][0], first[0], second[0][1]
    #find start/end for what the handler will handle
    start, end = first[1], first[2] if first[2] is not None else second
    #if the handler cannot handle the beginning of the block, then this is an error
    if start != 0:
        raise MarkdownError("No handler for {}:\n{}".format('block' if isinstance(item, Block) else 'line', item[:start]))
    return handler, start, end
