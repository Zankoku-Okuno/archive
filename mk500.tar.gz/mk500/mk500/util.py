import os, sys
from os import path

# ============ #
# == Errors == # #TODO: make these more expressive
# ============ #

class MarkdownError(Exception): #REFAC rename
    pass

# ================= #
# == Diagnostics == #
# ================= #

class Located:
    def __init__(self, loc, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.loc = loc

# ====================== #
# == Input Management == #
# ====================== #

class Source(Located):
    def __init__(self, loc=0):
        super().__init__(loc)
        self.backbuffer = []
        self.line = None
    def advance(self):
        if self.backbuffer:
            self.line = self.backbuffer[0]
            self.backbuffer = self.backbuffer[1:]
        else:
            self.line = self.readline()
        self.loc += 1
        return self.line
    def reverse(self, reinput):
        if reinput:
            self.backbuffer += reinput
            self.backbuffer.append(self.line)
            self.advance()
        self.loc -= len(reinput)
        return self
    def __enter__(self):
        self.advance()
        return self
    def __exit__(self, eType, eValue, eTrace):
        self.line = None
        self.backbuffer = []

class StreamSource(Source):
    def __init__(self, stream):
        super().__init__()
        self.stream = stream
    def readline(self):
        return self.stream.readline()

class SourceBuilder(Source):
    def __init__(self, loc):
        super().__init__(loc)
        self.data = []
    def append(self, line):
        self.data.append(line)
    def readline(self):
        if self.data:
            out, self.data = self.data[0], self.data[1:]
            return out
        else:
            return ''

class FileSource(Source):
    def __init__(self, pathname):
        super().__init__()
        self.pathname = pathname
        self.file = None
    def readline(self):
        return self.file.readline()
    def __enter__(self):
        if not path.exists(self.pathname):
            raise MarkdownError("404: {}".format(self.pathname))
        self.file = open(self.pathname) #TODO make error checking more stringent
        return super().__enter__()
    def __exit__(self, eType, eValue, eTrace):
        super().__exit__(eType, eValue, eTrace)
        if self.file:
            self.file.close()
        self.file = None

# ======================== #
# == Include Resolution == #
# ======================== #

class Includer:
    def __init__(self, basepaths):
        self.basepaths = basepaths
    
    @staticmethod
    def path(arg1, *arg2):
        if not arg2:
            arg1, arg2 = '', (arg1,)
        return path.normpath(path.abspath(path.join(arg1, *arg2)))
    
    def __call__(self, filename, nocwd=False): #TESTME
        if not nocwd:
            attempt = Includer.path(filename)
            if path.exists(p):
                return attempt
        for base in self.basepaths:
            attempt = Includer.path(base, filename)
            if path.exists(attempt):
                return attempt
        else:
            lookedin = ', '.join(map("'{}'".format, self.basepaths))
            if not nocwd: lookedin = "'.', " + lookedin
            raise MarkdownError("Cannot open '{}'. Looked in directories {}.".format(filename, lookedin))

# ================== #
# == Random Stuff == #
# ================== #

def isempty(line):
    return not line.strip()

def re_find(regex_match):
    if not regex_match:
        return None
    else:
        return regex_match.string[regex_match.start():regex_match.end()]


