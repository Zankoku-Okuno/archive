from .common import *
from .core import Core

@mk500.plugin
class Okuno:
    # ============ #
    # == Header == #
    # ============ #
    header_extraction = re.compile(r'\s*(={6}|===?|---?)\s*(.+?)\s*\1\s*$')
    @priority(-1)
    def is_block_header(self, block):
        match = Okuno.header_extraction.match(block.lines[0])
        if match:
            return True, 0, 1
    def block_header(self, block):
        level, text = Okuno.header_extraction.match(block.lines[0]).groups()
        level = {'======': 2,
                 '===': 3, '==': 3,
                 '---': 4, '--': 4}[level]
        return Core.Header.factory(level, text)


    
    # =========== #
    # == Lists == #
    # =========== #
    bullet_detector = re.compile(r'(\s*)\*\s+')
    indent_detector = re.compile(r'(\s*)')
    def is_block_list(self, block):
        found_bullet = False
        for i, line in enumerate(block):
            if isempty(line):
                break
            elif not found_bullet and Okuno.bullet_detector.match(line):
                found_bullet = True
        else: found_bullet
        return (True, 0, i+1) if found_bullet else False
    def block_list(self, block):
        leading, trailing = [], []
        for first_bullet, line in enumerate(block):
            if Okuno.bullet_detector.match(line):
                break
            leading.append(line)
        #go until an unindent is found: all the acc lines are a Block
        def package(lines):
            if len(lines) == 1:
                return mk500.Line(lines[0].rstrip(), block.loc[0]+i-len(block))
            elif isinstance(lines, mk500.Block) or isinstance(lines, mk500.Line):
                return lines
            elif Okuno.bullet_detector.match(lines[1]):
                return [mk500.Line(lines[0].rstrip(), block.loc[0]+i-len(block)),
                        mk500.Block(block.loc[0]+i-len(block)+1, lines[1:])]
            else:
                return mk500.Block(block.loc[0]+i-len(block), lines)
        items = []
        indent = len(Okuno.bullet_detector.match(block[first_bullet]).groups()[0])
        trim = indent + 1
        for i, line in enumerate(block.lines[first_bullet:]):
            match = Okuno.bullet_detector.match(line)
            if match and len(match.groups()[0]) == indent:
                if items: items[-1] = package(items[-1])
                items.append([])
                line = line[trim:].lstrip()
            #FIXME allow trailing paragraph lines
            else:
                line = line[trim:]
            if line: items[-1].append(line)
        if items: items[-1] = package(items[-1])
        return Core.List.factory(False, items, leading, trailing)
