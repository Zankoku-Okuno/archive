from .common import *
from .core import Core

@mk500.plugin
class Gruber:
    # ============== #
    # == Emphasis == #
    # ============== #
    emphasis_detector = re.compile(r'(([*_])\2?)(?![\s,.:;!?]).*?(?<![\s,.:;!?])\1(?!\w)', re.I)
    def is_element_emphasis(self, line):
        match = Gruber.emphasis_detector.search(line.text)
        if match: return (True,) + match.span()
    def element_emphasis(self, line):
        if line.text.startswith("__"):
            return Core.Emphasis('**'+line.text[2:-2]+'**')
        elif line.text.startswith("_"):
            return Core.Emphasis('*'+line.text[1:-1]+'*')
        else: return Core.Emphasis(line.text)

    # =========== #
    # == Links == #
    # =========== #
    link_detector = re.compile(r'''\[(?P<text>[^\]]+)\](?:\((?P<target>[^\)]+?)(?:\s+(?P<q>['"])(?P<title>[^\)]*?)(?P=q))?\)|\[(?P<id>[^\]]*)\])''')
    def is_element_link(self, line):
        m = Gruber.link_detector.search(line.text)
        return False if not m else (True,) + m.span()
    def element_link(self, line):
        match = Gruber.link_detector.match(line.text).groupdict()
        text, target, title, id = match['text'], match['target'], match['title'], match['id']
        if target:
            return Core.Link.factory(text, target, title=title)
        else:
            if not id: id = text
            id = id.lower() #HAX why I need lower here?
            def bind_link(state):
                _target, _attrs = state.link_defs[id]
                return Core.Link.factory(text, _target, **_attrs)
            return bind_link
    link_def_detector = re.compile(r'\s*\[(.*?)\]:\s*(.*?)(?:\s+"(.*?)")?\s*$')
    def is_block_link_def(self, block):
        if not (block and Gruber.link_def_detector.match(block[0])):
            return False
        for i, line in enumerate(block):
            if not Gruber.link_def_detector.match(line):
                return True, 0, i
        else: return True
    def block_link_def(self, block):
        if not hasattr(self.state, 'link_defs'):
            self.state.link_defs = dict()
        for line in block:
            id, target, title = Gruber.link_def_detector.match(line).groups()
            data = {'title': title} if title else dict()
            self.state.link_defs[id] = (target, data)

    