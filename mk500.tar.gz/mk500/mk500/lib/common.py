from libzan import *
import re

import mk500
from mk500 import Division, Span, Line, priority
from ..util import isempty

# =============== #
# == Utilities == #
# =============== #

def smart_line_join(a, b):
    """Handles adding appropriate whitespace (or lack thereof) when two
    physical lines are concatenated as logical lines. Also removes
    hyphenation (at most one character) from words broken across a line."""
    if not a: return b.strip()
    elif not b: return a.strip()
    elif a[-1] == '-': return a[:-1] + b.strip()
    elif a[-1] == '/': return a + b.strip()
    else: return a + ' ' + b.strip()


html_escapes = [
    (r'&(?!#x?[a-z0-9A-F]+;|[a-zA-Z]+;)', '&#38;'),
    ('<', '&#60;'),
    ('>', '&#62;'),
    ('"', '&#34;'),
    ("'", '&#39;')
]
html_escapes = [(re.compile(pattern), replacement) for pattern, replacement in html_escapes]

def base_escape_html(num, text):
    #TODO normalize named entity references into num
    for pattern, replacement in html_escapes[:num]:
        text = pattern.sub(replacement, text)
    return text
    
escape_html_text = partial(base_escape_html, 3)
escape_html_attribute = partial(base_escape_html, 5)
