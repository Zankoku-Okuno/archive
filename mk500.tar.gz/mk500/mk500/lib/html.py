from .common import *

from .basic import SuperBasic, HTML

@mk500.plugin
class InlineHTML:
    def is_block_inline_html(self, block):
        fmatch = HTML.tag_detector.match(block[0].strip())
        if not fmatch: return False
        for i, line in enumerate(block[1:]):
            if isempty(line):
                lmatch = list(HTML.tag_detector.finditer(block[i]))
                lmatch = None if not lmatch else lmatch[-1]
                if not lmatch or lmatch.end() != len(block[i].strip()):
                    return False
                else:
                    return True, 0, i+1
        return True
    def block_inline_html(self, block):
        return SuperBasic.Passthrough(''.join(block.lines).strip())
    def is_element_inline_html(self, line):
        m = HTML.tag_detector.search(line.text)
        return False if not m else (True, m.start(), m.end())
    def element_inline_html(self, line):
        return HTML.HtmlElement(line.text)