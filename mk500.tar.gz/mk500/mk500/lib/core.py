from .common import *
from .basic import SuperBasic, HTML

@mk500.plugin
class Core:
	# ===================== #
    # == Data Structures == #
    # ===================== #
    class Header(SuperBasic.Text):
        def parse(self, text): raise NotImplementedError() #STUB
        def build(self, level, text):
            self.level, self.text = level, text
    
    class Emphasis(Span):
        def parse(self, text):
            if text.startswith('**'):
                self.build('em', 2, text[2:-2])
            elif (text.startswith('*')):
                self.build('em', 1, text[1:-1])
            elif (text.startswith('_')):
                self.build('u', 1, text[1:-1])
            else: assert False
        def build(self, kind, level, text):
            self.kind, self.level, self.text = kind, level, text
    
    class Link(Span):
        def parse(self, text): raise NotImplementedError() #STUB
        def build(self, text, target, **attrs):
            self.text = text
            self.target = target
            self.attrs = attrs

    class List(Division):
        def parse(self, lines): pass #STUB
        def build(self, numbering, items, lead_text, trail_text):
            self.numbering = numbering
            self.items = items
            self.lead_text, self.trail_text = lead_text, trail_text

    # ============== #
    # == Printers == #
    # ============== #
    def print_Header_html(self, span):
        tagname = 'h{}'.format(span.level)
        yield HTML.OpenElement(tagname)
        yield SuperBasic.Text(span.text)
        yield HTML.CloseElement(tagname)

    def print_Emphasis_html(self, span):
        if span.kind == 'em':
            kind = ['em', 'strong'][span.level-1]
        elif span.kind == 'u':
            kind = 'u'
        else: assert False
        yield HTML.OpenElement(kind)
        yield mk500.Line(span.text)
        yield HTML.CloseElement(kind)

    def print_Link_html(self, span):
        yield HTML.OpenElement('a', href=span.target, **span.attrs)
        yield SuperBasic.Text(span.text)
        yield HTML.CloseElement('a')

    def print_List_html(self, block):
        if block.lead_text or block.trail_text:
            yield HTML.OpenElement('p')
            yield SuperBasic.Text.factory(''.join(block.lead_text))
        if block.numbering is False:
            yield HTML.OpenElement('ul')
            for item in block.items:
                yield HTML.OpenElement('li')
                yield item
                yield HTML.CloseElement('li')
            yield HTML.CloseElement('ul')
        else: raise NotImplementedError() #STUB
        if block.lead_text or block.trail_text:
            yield SuperBasic.Text.factory(''.join(block.trail_text))
            yield HTML.CloseElement('p')
