from .common import *

@mk500.plugin
class SuperBasic:
    # ===================== #
    # == Data Structures == #
    # ===================== #
    class Passthrough(Span):
        def parse(self, text):
            self.text = text

    class Text(Span):
        def parse(self, text):
            self.text = text
    class Paragraph(Text): pass
    
    # ===================== #
    # == Block Detectors == #
    # ===================== #

    # == Strip leading blank lines from the source == #
    @priority(-Infinity)
    def is_block_blank(self, block):
        for i, line in enumerate(block):
            if not isempty(line):
                return (True, 0, i) if i > 0 else False
        return True
    def block_blank(self, block):
        return ''
    
    # == Extract Paragraphs == #
    @priority(Infinity)
    def is_block_paragraph(self, block):
        for i, line in enumerate(block):
            if isempty(line):
                return True, 0, i
        return True
    def block_paragraph(self, block):
        return SuperBasic.Paragraph(reduce(smart_line_join, block, ''))

    # ======================= #
    # == Element Detectors == #
    # ======================= #
    @priority(Infinity)
    def is_element_text(self, line):
        return True, 0, None
    def element_text(self, line):
        return SuperBasic.Text(line)
    
    # ============== #
    # == Printers == #
    # ============== #
    def print_Paragraph_html(self, span):
        yield HTML.OpenElement('p')
        yield Line(span.text)
        yield HTML.CloseElement('p')
    def print_Text_html(self, span):
        return escape_html_text(span.text)
    def print_Passthrough_html(self, span):
        return span.text

@mk500.plugin
class HTML:
    # =============== #
    # == Constants == #
    # =============== #
    open, close, void, comment = 'open', 'close', 'void', 'comment'
    
    html_attr = r'''[a-zA-Z][0-9a-zA-Z]*(?:\s*=\s*(?:'[^']*'|"[^"]*"|[^'"\s/>][^\s/>]*))?'''
    html_start_tag = r'''<[a-zA-Z][0-9a-zA-Z]*(?:\s+{})*\s*/?>'''.format(html_attr)
    html_close_tag = r'''</[a-zA-Z][0-9a-zA-Z]*\s*>'''
    html_comment = r'''<!--.*?-->'''
    html_tag = r'(?:{}|{}|{})'.format(html_start_tag, html_close_tag, html_comment)
    
    tag_detector = re.compile(r'\\?\\?{}'.format(html_tag))
    name_extractor = re.compile(r'<(/?[0-9a-zA-Z]+)')
    attr_extractor = re.compile(r'''([0-9a-zA-Z]+)(?:\s*=\s*('[^']*'|"[^"]*"|[^'"\s/>][^\s/>]*))?''')
    
    # ==================== #
    # == Data Structure == #
    # ==================== #
    class HtmlElement(Span):
        def parse(self, text):
            assert HTML.tag_detector.match(text)
            if text.startswith('<!--'):
                self.text = text
                return self.build(HTML.comment, None)
            match = HTML.name_extractor.match(text)
            if match:i = match.end()
            # 1. Determine tag name and type
            name = match.groups()[0]
            if name.startswith('/'):
                name = name[1:]
                type = HTML.close
            elif text.endswith('/>'):
                type = HTML.void
            else:
                type = HTML.open
            # 2. Extract attributes
            attributes = dict()
            while True:
                match = HTML.attr_extractor.search(text, i)
                if match is None: break
                i = match.end()
                key, value = match.groups()
                if value.startswith('"') or value.startswith("'"):
                    value = value[1:-1]
                #TODO ensure the key doesn't already exist
                attributes[key] = escape_html_attribute(value) #REFAC move to printing
            # 3. Pass on to build, where everything is validated
            self.build(type, name, **attributes)
        def build(self, type, name, **attrs):
            #TODO lookup custom tags
            #TODO validate tag info (including that close tags have no attributes)
            self.type = type
            self.name = name
            self.attrs = {k:v for k, v in attrs.items() if v is not None}
    # Shortcuts
    OpenElement = partial(HtmlElement.factory, open)
    CloseElement = partial(HtmlElement.factory, close)
    VoidElement = partial(HtmlElement.factory, void)
    
    # ============== #
    # == Printers == #
    # ============== #
    def print_HtmlElement_html(self, item):
        #TODO validate
        attrs = ''.join(' {}="{}"'.format(key, escape_html_attribute(value))
                         for key, value in item.attrs.items())
        if item.type == HTML.comment:
            return item.text
        elif item.type == HTML.open:
            return "<{}{}>".format(item.name, attrs)
        elif item.type == HTML.close:
            return "</{}{}>".format(item.name, attrs)
        elif item.type == HTML.void:
            return "<{}{}/>".format(item.name, attrs)
        else:
            raise Exception("TODO")
