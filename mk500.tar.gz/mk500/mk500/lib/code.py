from .common import *

from .basic import SuperBasic, HTML
from .core import Core

from pygments import highlight
from pygments.lexers import get_lexer_by_name, guess_lexer
from pygments.formatters import HtmlFormatter

@mk500.plugin
class Code:
    #MAYBE allow automatic generation of a css file (into the metadata?)

    # ===================== #
    # == Data Structures == #
    # ===================== #
    class CodeSpan(Span):
        def parse(self, text): raise NotImplementedError() #STUB
        def build(self, lang, text):
            self.lang, self.text = lang, text

    class CodeDiv(Division):
        def parse(self, lines):
            lang, _, attr_text = Code.open_block_detector.match(lines[0]).groups()
            lines = lines[1:-1]
            attributes = dict()
            if attr_text:
                i = 0
                while True:
                    match = HTML.attr_extractor.search(attr_text, i)
                    if match is None: break
                    else: i = match.end()
                    key, value = match.groups()
                    if value.startswith('"') or value.startswith("'"):
                        value = value[1:-1]
                    #TODO ensure the key doesn't already exist
                    attributes[key] = value
            self.build(lang, ''.join(lines), **attributes)
        def build(self, lang, text, **attrs):
            #TODO validate attrs
            self.lang, self.text, self.attrs = lang, text, attrs
    
    # =============== #
    # == Detectors == #
    # =============== #
    inline_detector = re.compile(r'([^\s~]+)?(~~~+)(.+?)\2', re.I)
    def is_element_code(self, line):
        match = Code.inline_detector.search(line.text)
        if match:
        	return (True,) + match.span()
    def element_code(self, line):
        lang, _, text = Code.inline_detector.match(line.text).groups()
        return Code.CodeSpan.factory(lang, text)

    open_block_detector = re.compile(r'(?:^|(?<=\s))([^\s]+)?(~~~+)(\s*{0}(?:\s+{0})*)?$'.format(HTML.html_attr), re.I)
    def is_block_code(self, block):
        match = Code.open_block_detector.match(block[0])
        if not match: return False
        close_detector = re.compile(r'\s*{}\s*$'.format(match.groups()[1]))
        for i, line in enumerate(block[1:]):
        	if close_detector.match(line):
        		return True, 0, i+2
        return True #TODO this should be an error
    def block_code(self, block):
        return Code.CodeDiv(block.lines)

    # ============== #
    # == Printers == #
    # ============== #
    def print_CodeSpan_html(self, span):
        if span.lang is None:
            yield HTML.OpenElement('code')
            yield SuperBasic.Text(span.text)
        else:
        	yield '<!--not implemented-->' #STUB incorportate pygments
        yield HTML.CloseElement('code')

    def print_CodeDiv_html(self, div):
        yield HTML.OpenElement('div', **{'class': 'codeblock'})
        if 'title' in div.attrs:
            yield Core.Header.factory(6, div.attrs['title'])
        if 'line' in div.attrs:
            line = div.attrs['line']
        else: line = 1
        if div.lang is None:
            if 'code' in self.state.metadata:
                cssclass = self.state.metadata['code'].lower()
                lexer = get_lexer_by_name(cssclass)
            else:
                lexer = guess_lexer(div.text)
                cssclass = re.sub(r'\s', '_', lexer.name.lower())
        else:
            lexer = get_lexer_by_name(div.lang.lower())
            cssclass = div.lang
        cssclass = re.sub(r'\+', 'p', cssclass)
        formatter = HtmlFormatter(linenos=True, linenostart=line)
        #if 'pygments' not in self.state.metadata:
        #    self.state.metadata['pygments'] = formatter.get_style_defs()
        yield highlight(div.text, lexer, formatter)
        yield HTML.CloseElement('div')
