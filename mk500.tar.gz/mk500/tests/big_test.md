real title: Test Me!
author: Zankoku Okuno
multiline attr: Goodbyte,
  cruel
  world!
#include includeme.metadata
fake title = not metadata

This is a simple paragraph.

& this is a
multi-line para-
graph. This line has a break after\
this one has a backslash\\

<span id=text=cool>This is in a span</span>
<br wrongattr='"'/> not an html block & so we get escapes

<p>this is a raw html block & has no escapes</p>

 ====== A HEADER ======
 === A Header ===
 --- a header ---
some *emphatically* **strong** text. [an inline link](example.com) and a [natural][] link.

[natural]: www.google.com "beter than bing!"


 $ Main $

some stuff


* a bulletted list
  * with a sublist
  * and a really big item that 
    just keeps going
* finish!

$

Here's an unnamed segment.

$ CODECODECODE $

some ~~~inline code~~~ followed by a ~~~block~~~:


C++~~~line=4
int main(int argc, char** argv) {

	return 0;
}
~~~