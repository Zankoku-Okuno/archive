#! /usr/bin/python3

import mk500
from libzan import *
from time import time


def _main():
    import mk500.lib #load plugins
    config = {
        'ifile': 'tests/big_test.md',
        'format': 'html',
#        'postfilter': 'pretty_indent'
    }
    t0 = time()
    output = mk500.run(config)
    t1 = time()
    debug('v'*72)
    debug("Running time:", round((t1-t0)*1000, 1), "ms")
    debug('-'*12, "config", '-'*36)
    debug(config)
    debug('-'*12, "metadata", '-'*36)
    debug(output.metadata)
    for key, segment in output.items():
        debug('-'*12, key, '-'*36)
        debug(segment)
    debug('^'*72)

if __name__ == '__main__':
    _main()
    