from functools import reduce, partial

always, never = lambda *x: True, lambda *x: False

Infinity = float('inf')

def identity(x=None):
    """Identity function of at most one argument. Returns None if no parameter
    is passed. If something like 'lambda *args: *args' is desired, use something
    like 'map(identity, args)'.
    
    If performance is a concern in functions that might accept and call identity
    often, it is as simple to check 'func is identity' as it is 'func is
    None'"""
    return x

iterable = lambda obj: hasattr(obj, '__iter__')

def debug(*args, **kwargs):
    print(*args, **kwargs)

def pad_tuple(size, item, pad=None):
    if not isinstance(item, tuple):
        item = (item,)
    if len(item) > size:
        return item[:size]
    return (item + (pad,)*size)[:size]
def pad_iterable(size, iterable, pad=None):
    return iterable[:size] + [pad]*(size - len(iterable))

def car(iterable, num=None):
    if num is None:
        for item in iterable:
            return item
    else:
        acc = []
        for i, item in enumerate(iterable):
            if i < num: acc.append(item)
            else: return acc

#TESTME get unittests for all of this stuff

def progn(*callables, recover=False):
    """Allows the creation of lambdas that have multiple statements.
    
    Accepts callables each of which can take zero arguments, executes all of
    them in order and returns the value of the last call. If no arguments were given to
    progn, then None is returned.
    
    By default, if any argument cannot be called with zero arguments, then progn
    immediately exits. However, if recover is True, then when an argument cannot
    be called with zero arguments, progn recovers, continues executing futher
    arguments and finally raises a TypeError (due to the first exception) when
    all arguments have been attempted. If one of the arguments raises an
    exception during the call, it is undefined whether progn will be able to
    recover.
    
    x = 2
    def eggs():
        global x
        x = x**x
    def ham(x, y): return x*y
    callback = progn(eggs, partial(ham, 137, 42))
    assert callback() == 137*42
    """
    last = None
    if recover:
        exception = None
        for call in callables:
            try:
                last = call()
            except TypeError as ex:
                if exception is None:
                    exception = ex
        if exception:
            raise exception
    else:
        for call in callables:
            last = call()
    return last

def chomp(self):
    """Removes one linefeed from the end of a string, provided there is one to
    remove. Recognizes LF, CR, and CR+LF."""
    if self.endswith('\r\n'):
        return self[:-2]
    elif any(map(self.endswith, '\n\r')):
        return self[:-1]
    else:
        return self

def forall(iterable, predicate):
    """Returns true if predicate is true of all the elements in iterable.
    Returns true if iterable is empty."""
    return all(map(predicate, iterable))
def forsome(iterable, predicate):
    """Returns true if predicate is true if at least one of the elements in
    iterable. Returns false if iterable is empty."""
    return any(map(predicate, iterable))
def forone(iterable, predicate):
    """Returns true if predicate is true of exactly one element of iterable.
    Returns false if iterable is empty."""
    found = False
    for item in iterable:
        if predicate(item):
            if found:
                return False
            else:
                found = True
    return found

def saturate(seed, next, predicate=always, prefilter=False):
    """Builds a set, starting from seed, containing the result of calling next
    on each element of seed. If predicate is given, elements are only added to
    the result if they meet the requirements of the predicate. If prefilter is
    true, then next will only be called on elements that meet the predicate.
    
    seed should be an iterable. next should have one parameter and return an
    iterable for which next may again be called on each element. predicate
    should have one parameter and return a boolean.
    
    The return value is an actual set, not a generator, since a generator would
    be no more space efficient."""
    found, tip, grow = set(), seed, set()
    while True:
        for item in tip:
            if predicate(item):
                found.add(item)
                grow |= {x for x in next(item) if x not in found}
            elif not prefilter:
                grow |= {x for x in next(item) if x not in found}
        if not grow:
            break
        tip, grow = grow, set()
    return found

def splitby(key, iterable):
    """Returns a list of sublists. The sublists are non-empty, stable (same
    order as input) subsets of the input iterable such that each element in the
    sublist are equal according to the passed key. The lists are ordered such
    that joining all of them would produce a sorted sequence."""
    ordered = sorted(iterable, key=key)
    acc, last_key = [], None
    for item in ordered:
        this_key = key(item)
        if this_key != last_key:
            acc.append([])
            last_key = this_key
        acc[-1].append(item)
    return acc

def freeze(container, unordered=False):
    """Convert the passed container into an immutable collection type. Sets
    become frozen sets, lists become tuples, and dictionaries become a tuple of
    pairs (key, value). Other iterables become a tuple by default, but can be
    converted to a frozenset if unordered is set to True
    
    Already immutable types are left alone (i.e. this function is
    idempotent)."""
    if isinstance(container, set):
        return frozenset(container)
    elif isinstance(container, list):
        return tuple(container)
    if isinstance(container, dict):
        return freeze(container.items())
    elif forsome((frozenset, tuple), partial(isinstance, container)):
        return container
    elif unordered:
        return frozenset(container)
    else:
        return tuple(container)

def tags(*args):
    """Decotator that simply defines a 'tags' attribute on the decorated
    object. These tags can later be used to select objects from collections, or
    really whatever is desired."""
    def impl(obj):
        obj.tags = set(args)
    return impl

def lexical_bind(*names):
    """Attempts to return the local variable in the caller's scope whose name is
    the same as that passed to this function. If further names are specified,
    these are used as backup variable names."""
    from inspect import stack
    caller_vars = stack()[2][0].f_locals #has to be two, since calling lexical_bind introduces an extra stack frame
    for name in names:
        if name in caller_vars:
            return caller_vars[name]
    else:
        raise TypeError("Cannot resolve lexically bound name '{}'.".format(names[0]))

class Iterator:
    """Mixin allowing classes to be their own iterator."""
    def __iter__(self):
        return self

#TODO @classproperty

#TODO properties for matching the proxy interface
_base_mangle = "__base_{}__".format
_base_unmangle = lambda name: name[7:-2]
_proxy_mangle = "__proxy_{}__".format
class _Proxy(type):
    def __new__(cls, name, bases, namespace, **kwargs):
        result = type.__new__(cls, name, bases, dict(namespace))
        for base in bases:
            if hasattr(base, "__px_wrap__"):
                result.__px_wrap__ |= base.__px_wrap__
            if hasattr(base, "__px_inject__"):
                result.__px_inject__ |= base.__px_inject__
        result.__px_eject__ = {_base_mangle(x) for x
                               in result.__px_wrap__ | result.__px_inject__}
        return result

class BaseProxy(metaclass=_Proxy):
    __px_wrap__, __px_inject__ = frozenset(), frozenset()
    def __init__(self, base_obj):
        #TODO what happens if you wrap a proxy in a proxy? same/different proxy class?
        object.__setattr__(self, "__px_base__", base_obj)
        for name in self.__px_inject__:
            object.__setattr__(self, _base_mangle(name), getattr(self.__px_base__, name))
            object.__setattr__(self.__px_base__, name, getattr(self, _proxy_mangle(name)))
        object.__setattr__(self, "__init__", self.__px_base__.__init__)
    def __del__(self): del self.__px_base__
    
    def __getattr__(self, name):
        if name in self.__class__.__px_wrap__:
            return getattr(self, _proxy_mangle(name))
        elif name in self.__px_eject__:
            name = _base_unmangle(name)
        return getattr(self.__px_base__, name)
    def __setattr__(self, name, value):
        #TODO what if it's wrapped/injected?
        #FIXME setting properties isn't working right
        if name in self.__px_wrap__:
            object.__setattr__(self, _base_mangle(name), value)
        if name in self.__px_inject__:
            object.__setattr__(self, _base_mangle(name), value)
            object.__setattr__(self.__px_base__, name, value)
        elif hasattr(self.__px_base__, name):
            setattr(self.__px_base__, name, value)
        else:
            object.__setattr__(self, name, value)
    def __delattr__(self, name):
        if name in self.__px_wrap__:
            object.__delattr__(self, _base_mangle(name), value)
        elif name in self.__px_inject__:
            object.__delattr__(self, _base_mangle(name), value)
            object.__delattr__(self.__px_base__, name, value)
        elif hasattr(self.__px_base__, name):
            delattr(self.__px_base__, name)
        else:
            object.__delattr__(self, name)
    
    #TODO research descriptors: __get__, __set__, __delete__, __slots__

class TonsOfSpecials: #FIXME
    def __format__(self, format_spec): return self.__px_base__.__format__(format_spec)
    def __str__(self): return str(self.__px_base__)
    def __repr__(self): return repr(self.__px_base__)
    def __bytes__(self): return bytes(self.__px_base__)
    def __hash__(self): return hash(self.__px_base__)
    
    def __bool__(self): return bool(self.__px_base__)
    def __lt__(self, other): return self.__px_base__ < other
    def __le__(self, other): return self.__px_base__ <= other
    def __eq__(self, other): return self.__px_base__ == other
    def __ne__(self, other): return self.__px_base__ != other
    def __gt__(self, other): return self.__px_base__ > other
    def __ge__(self, other): return self.__px_base__ >= other
    
    #TODO override isinstance/issubclass dynamically
    
    def __call__(self, *args, **kwargs): return self.__px_base__(*args, **kwargs)
    def __enter__(self): return self.__px_base__.__enter__()
    def __exit__(self): return self.__px_base__.__exit__()
    
    def __len__(self): return len(self.__px_base__)
    def __getitem__(self, key): return self.__px_base__[key]
    def __setitem__(self, key, value): self.__px_base__[key] = value
    def __delitem__(self, key): del self.__px_base__[key]
    def __iter__(self): return self.__px_base__.__iter__(self)
    def __reversed__(self): return self.__px_base__.__reversed__(self)
    def __contains__(self, item): return item in self.__px_base__
    
    def __add__(a, b): return a.__px_base__ + b
    def __sub__(a, b): return a.__px_base__ - b
    def __mul__(a, b): return a.__px_base__ * b
    def __truediv__(a, b): return a.__px_base__ / b
    def __floordiv__(a, b): return a.__px_base__ // b
    def __mod__(a, b): return a.__px_base__ % b
    def __divmod__(a, b): return divmod(a.__px_base__, b)
    def __pow__(a, b, modulo=None): return a.__px_base__**b if modulo is None else pow(a.__px_base__, b, modulo)
    def __lshift__(a, b): return a.__px_base__ << b
    def __rshift__(a, b): return a.__px_base__ >> b
    def __and__(a, b): return a.__px_base__ << b
    def __xor__(a, b): return a.__px_base__ & b
    def __or__(a, b): return a.__px_base__ | b
    
    def __radd__(b, a): return a + b.__px_base__
    def __rsub__(b, a): return a - b.__px_base__
    def __rmul__(b, a): return a * b.__px_base__
    def __rtruediv__(b, a): return a / b.__px_base__
    def __rfloordiv__(b, a): return a // b.__px_base__
    def __rmod__(b, a): return a % b.__px_base__
    def __rdivmod__(b, a): return divmod(a, b.__px_base__)
    def __rpow__(b, a): return a**b.__px_base__
    def __rlshift__(b, a): return a << b.__px_base__
    def __rrshift__(b, a): return a >> b.__px_base__
    def __rand__(b, a): return a << b.__px_base__
    def __rxor__(b, a): return a & b.__px_base__
    def __ror__(b, a): return a | b.__px_base__
    
    def __iadd__(a, b):
        a.__px_base__ += b
        return a
    def __isub__(a, b):
        a.__px_base__ -= b
        return a
    def __imul__(a, b):
        a.__px_base__ *= b
        return a
    def __itruediv__(a, b):
        a.__px_base__ /= b
        return a
    def __ifloordiv__(a, b):
        a.__px_base__ //= b
        return a
    def __imod__(a, b):
        a.__px_base__ %= b
        return a
    def __idivmod__(a, b):
        a.__px_base__.__idivmod__(b)
        return a
    def __ipow__(a, b, modulo=None):
        if modulo is None: a.__px_base__ **= b
        else: a.__px_base__.__ipow__(b, modulo)
        return a
    def __ilshift__(a, b):
        a.__px_base__ <<= b
        return a
    def __irshift__(a, b):
        a.__px_base__ >>= b
        return a
    def __iand__(a, b):
        a.__px_base__ &= b
        return a
    def __ixor__(a, b):
        a.__px_base__ ^= b
        return a
    def __ior__(a, b):
        a.__px_base__ |= b
        return a
    
    def __neg__(self): return self.__class__(-self.__px_base__)
    def __pos__(self):
        res = +self.__px_base__
        if res is self.__px_base__: return self
        else: return self.__class__(res)
    def __abs__(self): return abs(a.__px_base__)
    def __invert__(self): return ~a.__px_base__
    
    def __complex__(self): return complex(self.__px_base__)
    def __int__(self): return int(self.__px_base__)
    def __float__(self): return float(self.__px_base__)
    def __round__(self, n=None): return round(self.__px_base__) if n is None else round(self.__px_base__, n)
    def __index__(self): return self.__px_base__.__index__
    
    
    
    #TODO other special methods


#DELETEME
class Foo(BaseProxy):
    __px_inject__ = {'f'}
    __px_wrap__ = {'g', 'x'}
    def __proxy_f__(self, arg1, arg2):
        print("injection:")
        self.__base_f__(arg1, arg2)
    def __proxy_g__(self, arg1, arg2):
        print("wrapping:")
        self.__base_g__(arg1, arg2)
    @property
    def __proxy_x__(self):
        return self.__base_x__**self.__base_x__
class Bar:
    x = 3
    def __init__(self):
        self.counter = 0
    def f(self, a1, a2):
        print(a1)
        if a2 is not None:
            self.f(a2, None)
    def g(self, a1, a2):
        self.f(a1, a2)
        if a1: self.g(a1-1, a2)
    def __len__(self): return 7
    def __call__(self):
        self.f(1,2)
        self.counter += 1
