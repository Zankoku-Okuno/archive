#! /usr/bin/python3

import os, sys, shutil
from os import path

#I can accpet input like this:
#every colon in the keys/values is replaced with two colons
#then, delimit key1:value1:key2:value2:...
#should be easy to build/parse and pass on command-line, as long as the dictionary isfull of strings, and strings alone

class CompilerIO:
    def __init__(self, ifile, ofile):
        self.ifilename = ifile
        self.ofilename = ofile
    def __enter__(self):
        self.ifile = open(self.ifilename, 'rt')
        self.ofile = open(self.ofilename+'.tmp', 'wt') if self.ofilename is not None else sys.stdout
            
        
        return self
    def __exit__(self, eType, eValue, eTrace):
        if self.ifile: self.ifile.close()
        if self.ofilename is not None:
            if self.ofile: self.ofile.close()
            if path.exists(self.ofilename+'.tmp'):
                if not eType:
                    shutil.move(self.ofilename+'.tmp', self.ofilename)
                else:
                    os.remove(self.ofilename+'.tmp')
    
    def readline(self):
        return self.ifile.readline()
    def readlines(self):
        return self.ifile.readlines()
    def write(self, data):
        return self.ofile.write(data)


def compile(src, data, dst, *exclude):
    import re
    regex = re.compile(r'<!--\s*var\s*:\s*(.+?)\s*-->', re.IGNORECASE)
    with CompilerIO(src, dst) as io:
        for line in io.readlines():
            match = regex.search(line)
            while match:
                var = match.groups()[0]
                io.write(line[:match.start()])
                io.write(data[var] if var not in exclude else line[match.start():match.end()])
                line = line[match.end():]
                match = regex.search(line)
            io.write(line)

if __name__ == '__main__':
    import argparse
    import re
    parser = argparse.ArgumentParser(description='''Simple template enigne focused on static websites.
Accepts a dictionary on stdin of the format "<key>:<value>:<key>:<value>:..." with ":"" in the data escaped with "::".
Outputs compiled template to stdout.''')
    parser.add_argument('template', type=str,
                        help='filename where the template is stored.')
    parser.add_argument('-i', '--input', type=open, nargs=1, default=sys.stdin,
                        help='input data file')
    parser.add_argument('-o', '--output', type=str, nargs=1,
                        help='output file')
    parser.add_argument('-x', '--no-subst', dest='ignore', action='append', default=[],
                        help='ignore the named variables in the template')
    args = parser.parse_args()
    def parse_data():
        single_colon = re.compile(r'(?<!:):(?!:)')
        double_colon = re.compile(r'::')
        accing_key = True
        key, value = '', ''
        acc = dict()
        for line in args.input.readlines():
            while line:
                match = single_colon.search(line)
                start, end = match.span() if match else (len(line), len(line))
                if accing_key:
                    key += line[:start]
                else:
                    value += line[:start]
                line = line[end:]
                if match:
                    accing_key = not accing_key
                    if accing_key:
                        acc[key] = double_colon.sub(':', value)
                        key, value = '', ''
        if key:
            acc[key] = double_colon.sub(':', value)
        #Special little wrinkles
        if 'date' in acc:
            def format_date(date):
                day = date[8:10]
                if day.startswith('0'): day = day[1:]
                if day in {'11', '12', '13'}: suffix = 'th'
                elif day[-1] == '1': suffix = 'st'
                elif day[-1] == '2': suffix = 'nd'
                elif day[-1] == '3': suffix = 'rd'
                else: suffix = 'th'
                month = ['January', 'Feburary', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][int(date[5:7], 10)-1]
                year = date[0:4]
                return '{}<sup>{}</sup> {} {}'.format(day, suffix, month, year)
            acc['pretty-date'] = format_date(acc['date'])
        #end
        return acc
    compile(args.template, parse_data(), args.output, *args.ignore)