#! /usr/bin/python3

import sys, re
import mk500, mk500.lib, blog

colon_escaper = re.compile(':')
def escape(text):
	return colon_escaper.sub('::', str(text))
write = lambda *args: print(*args, sep='', end='')


plugin_suites = {
	'default': lambda x: x not in {blog.RecentParagraph},
	'recent': lambda x: x in {mk500.lib.HTML, blog.RecentParagraph}
}


default_config_values = {
	'plugins': plugin_suites['default'],
	'format': 'html'
}

if __name__ == '__main__':
	options = []
	if len(sys.argv) > 1:
		for arg in sys.argv[1:]:
			if arg.startswith("--"):
				options.append(arg[2:])
	sys.argv = list(filter(lambda x: not x.startswith("--"), sys.argv))
	config = dict()
	if ':' not in sys.argv[1]:
		config['ifile'] = sys.argv[1]
		i = 2
	else:
		i = 1
	if i < len(sys.argv) and sys.argv[i].startswith('='):
		bodyname = sys.argv[i][1:]
		i += 1
	else: bodyname = None
	while i < len(sys.argv):
		colon = sys.argv[i].index(':')
		config[sys.argv[i][:colon]] = sys.argv[i][colon+1:]
		i += 1
	for key, value in default_config_values.items():
		if key not in config:
			config[key] = value
	data = mk500.run(config)
	if bodyname:
		if 'main' in data:
			data[bodyname] = data['main']
			del data['main']
		elif 0 in data:
			data[bodyname] = data[0]
			del data[0]
	if "simple" in options:
		write(data[bodyname])
	else:
		for key, value in data.metadata.items():
			if value:
				write(escape(key), ':', escape(value), ':')
		for key, value in data.items():
			if value:
				write(escape(key), ':', escape(value), ':')
	