#! /usr/bin/python3
import sys
if __name__ == '__main__':
	MAX = int(sys.argv[1])
	n = 0
	while n < MAX:
		data = sys.stdin.readline().split()[:MAX]
		if not data: break
		for item in data: print(item)
		n += len(data)