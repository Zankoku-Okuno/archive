#! /usr/bin/python3

import sys
from datetime import date
from glob import glob

preamble = '''title: 
tagline: 
author: Zankoku Okuno
date: {}
tags: 

$ abstract $



$ main $


'''

if __name__ == '__main__':
	if len(sys.argv) >= 2 and sys.argv[1] == '-p':
		basename = "src/prepublish"
		today = sys.argv[2] if len(sys.argv) >= 3 else 'anon'
	else:
		today = date.today()
		basename = 'src/content/blog'
	filename = '{}-{}'.format(today, len(glob('{}/{}-*'.format(basename, today))))
	with open('{}/{}'.format(basename, filename), 'wt') as f:
		f.write(preamble.format(today))