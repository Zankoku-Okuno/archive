from libzan import *
import re

import mk500
from mk500 import Division, Span, Line, priority
from mk500.lib import SuperBasic

@mk500.plugin
class RecentParagraph(SuperBasic):
	def __init__(self, state):
		self.num = 0
		self.limit = state.get('limit', 5)
	@priority(Infinity)
	def block_paragraph(self, block):
		if self.num >= self.limit:
			return None
		else:
			self.num += 1
			return super().block_paragraph(block)