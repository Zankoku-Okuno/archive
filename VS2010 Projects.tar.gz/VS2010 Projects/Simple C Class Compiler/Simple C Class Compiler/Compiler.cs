﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SCCCompiler
{
    class Compiler
    {
        public static AllClasses ClassRegistry = new AllClasses();
        public static AllMethods MethodRegistry = new AllMethods();

        public static string Header()
        {
            var _out = ClassRegistry.Header();
            foreach(var m in MethodRegistry)
            {
                _out += m.Header();
            }

            //TODO generate method dispatch macros
            return _out;
        }

        public static string Generate()
        {
            var acc = "#incude \"classes.h\"\n\n";
            foreach(var c in ClassRegistry)
            {
                acc += c.Generate();
            }
            return acc;
        }

    }
}
