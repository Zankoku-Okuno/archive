﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace SCCCompiler
{
    class AllClasses
    {

        List<ClassStructure> registered = new List<ClassStructure>();

        public void Add(ClassStructure registrant)
        {
            var registeredNames = from c in this.registered
                                  select c.Name;
            if (registeredNames.Contains(registrant.Name))
                throw new Exception("Class " + registrant.Name + " already defined!");
            this.registered.Add(registrant);
        }

        public string Header()
        {
            string acc = "typedef enum {\n\t", concat = "";
            foreach (var c in this.registered)
            {
                acc += concat + c.Name + "_class";
                concat = ",";
            }
            acc += "\n} class_enum;\n\n";
            foreach (var c in this.registered)
                acc += c.Header();
            return acc;
        }

        public string Generate()
        {
            string acc = "";
            foreach (var c in this.registered)
                acc += c.Generate();
            return acc;
        }

        public IEnumerator<ClassStructure> GetEnumerator()
        {
            return this.registered.GetEnumerator();
        }

    }

    class AllMethods
    {
        List<MethodStructure> registered = new List<MethodStructure>();

        public void Add(MethodStructure registrant)
        {
            var registeredNames = from m in this.registered
                                  select m.FullName;
            if (registeredNames.Contains(registrant.FullName))
                throw new Exception("Method " + registrant.Name + " already defined in class " + registrant.Container.Name + "!");
            this.registered.Add(registrant);
        }

        public IEnumerator<MethodStructure> GetEnumerator()
        {
            return this.registered.GetEnumerator();
        }

    }

    class MethodStructure
    {
        public ClassStructure Container { get; set; }
        public String Name { get; set;  }
        String parameters;
        String return_type;
        String body;

        public MethodStructure(ClassStructure container, String return_type, String name, String parameters, String body)
        {
            this.Container = container;
            this.Name = name;
            this.return_type = return_type;
            this.parameters = parameters;
            this.body = Regex.Replace(body.TrimEnd(), "self.", "self->");
        }

        public string Header()
        {
            return this.return_type + " " + this.FullName + this.Args + ";\n";
        }

        public string Generate()
        {
            return this.return_type + " " + this.FullName + this.Args + " {" + this.body + "\n}\n\n";
        }

        public string FullName { get { return this.Name + "_" + this.Container.Name; } }
        public string Args { get
        {
            return "(" +
                this.Container.Name + "* self" + (this.parameters.Equals("") ? "" : ", ") +
                this.parameters +
                ")";
        } }

    }

    class ClassStructure
    {
        public String Name { get; set;  }
        String body = "";
        String constructor_body = null;
        String destructor_body = null;
        public List<MethodStructure> Methods { get; set; }

        public ClassStructure(String name)
        {
            this.Name = name;
            this.Methods = new List<MethodStructure>();
        }

        public void AddBody(String stuff)
        {
            stuff = Regex.Replace(stuff, "\n(\\s*\n)+", "\n");
            this.body += stuff;
        }

        public void AddMethod(MethodStructure method)
        {
            foreach (MethodStructure m in this.Methods)
                if (m.Name == method.Name)
                    throw new Exception("Duplicate methods.");
            this.Methods.Add(method);
        }

        public string Header()
        {
            var _out = "typedef struct " + this.Name + " {\n\tclass_enum __class__;\n";
            _out += this.body.TrimEnd();
            _out += "\n} " + this.Name + ";\n\n";
            return _out;
        }

        public string Generate()
        {
            var _out = "// ====== " + this.Name + " ====== //\n\n";
            //TODO generate constructor and destructor
            foreach(var method in this.Methods)
                _out += method.Generate();
            return _out;
        }

        public String _body() { return this.body; }
        
    }
}
