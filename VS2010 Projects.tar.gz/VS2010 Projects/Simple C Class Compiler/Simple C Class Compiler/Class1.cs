﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace SCCCompiler
{
    class Class1
    {
        public static int Main(String[] args)
        {
            var test_str = "\n\tint x;\n\n\n\tint y;\n\n\tdef void reset(int x, int y) {\n\t\tself.x = x, self.y = y;\n\t\t\"quote\\\"}\";\n\t}\n}\n\nclass Point3D {}\n";
            var test = new TopLevel(test_str);
            var o = test.Build("Point2D");

            Console.WriteLine("Input:");
            Console.WriteLine(test_str);
            Console.WriteLine("classes.h:");
            Console.WriteLine(Compiler.Header());
            Console.WriteLine("classes.c:");
            Console.WriteLine(Compiler.Generate());
            Console.WriteLine("Remaining:");
            Console.WriteLine(test._input());
            
            
            
            
            Console.ReadLine();
            return 0;
        }
    }
}
