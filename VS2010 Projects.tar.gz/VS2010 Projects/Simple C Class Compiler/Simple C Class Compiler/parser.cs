﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace SCCCompiler
{
    class TopLevel
    {
        public String _input() { return this.input; }

        String input;
        public TopLevel(String input)
        {
            this.input = input;
        }

        public ClassStructure Build(String name)
        {
            var body = FindClassBounds();
            var _out = new ClassBody(body).Build(name);
            Compiler.ClassRegistry.Add(_out);
            return _out;
        }


        public String FindClassBounds()
        {
            int i = 0, depth = 1, mode = 0;
            for(; i < this.input.Length && depth > 0; ++i)
            {
                switch (mode)
                {
                    case 0: //normal
                        switch (this.input[i])
                        {
                            case '{': ++depth; break;
                            case '}': --depth; break;
                            case '\"': mode = 1; break;
                            case '\'': mode = 3; break;
                        }
                        break;
                    case 1: //string
                        switch (this.input[i])
                        {
                            case '\\': ++mode; break;
                            case '\"': mode = 0; break;
                            case '\n': throw new Exception("Unclosed string literal.");
                        }
                        break;
                    case 2: //string escape
                        --mode;
                        break;
                    case 3: //character
                        switch (this.input[i])
                        {
                            case '\\': ++mode; break;
                            case '\'': mode = 0; break;
                            case '\n': throw new Exception("Unclosed character literal.");
                        }
                        break;
                    case 4: //character escape
                        --mode;
                        break;
                }
            }
            if ((mode|depth) != 0)
                throw new Exception("Bad structure.");
            var _out = this.input.Substring(0, i - 1);
            this.input = this.input.Substring(i);
            return _out;
        }

    }

    class ClassBody
    {
        public String _input() { return this.input; }

        String input;
        public ClassBody(String input)
        {
            this.input = input;
        }

        public ClassStructure Build(String name)
        {
            var _out = new ClassStructure(name);
            do
            {
                var match = Regex.Match(this.input, "($|\n)\\s*def\\s+");
                if (match.Index == 0 && match.Length == 0)
                    break;
                _out.AddBody(this.input.Substring(0, match.Index));
                this.input = this.input.Substring(match.Index + match.Length);
                String returnType = this.GetReturnType();
                String methodName = this.GetMethodName();
                String parameterList = this.GetParamList();
                String methodBody = this.FindMethodBounds();
                var method = new MethodStructure(_out, returnType, methodName, parameterList, methodBody);
                _out.AddMethod(method);
                Compiler.MethodRegistry.Add(method);
            } while (true);
            
            
            _out.AddBody(this.input);
            return _out;
        }

        private String GetReturnType()
        {
            var m = Regex.Match(this.input, "\\s+");
            var _out = this.input.Substring(0, m.Index);
            this.input = this.input.Substring(m.Index + m.Length);
            return _out;
        }
        private String GetMethodName()
        {
            var _out = this.input.Substring(0, this.input.IndexOf('(')).Trim();
            this.input = this.input.Substring(this.input.IndexOf('(') + 1);
            return _out;
        }
        private String GetParamList()
        {
            var _out = this.input.Substring(0, this.input.IndexOf(')')).Trim();
            this.input = this.input.Substring(this.input.IndexOf('{') + 1);
            return _out;
        }

        public String FindMethodBounds()
        {
            int i = 0, depth = 1, mode = 0;
            for (; i < this.input.Length && depth > 0; ++i)
            {
                switch (mode)
                {
                    case 0: //normal
                        switch (this.input[i])
                        {
                            case '{': ++depth; break;
                            case '}': --depth; break;
                            case '\"': mode = 1; break;
                            case '\'': mode = 3; break;
                        }
                        break;
                    case 1: //string
                        switch (this.input[i])
                        {
                            case '\\': ++mode; break;
                            case '\"': mode = 0; break;
                            case '\n': throw new Exception("Unclosed string literal.");
                        }
                        break;
                    case 2: //string escape
                        --mode;
                        break;
                    case 3: //character
                        switch (this.input[i])
                        {
                            case '\\': ++mode; break;
                            case '\'': mode = 0; break;
                            case '\n': throw new Exception("Unclosed character literal.");
                        }
                        break;
                    case 4: //character escape
                        --mode;
                        break;
                }
            }
            if ((mode | depth) != 0)
                throw new Exception("Bad structure.");
            var _out = this.input.Substring(0, i - 1);
            this.input = this.input.Substring(i);
            return _out;
        }
    }

}
