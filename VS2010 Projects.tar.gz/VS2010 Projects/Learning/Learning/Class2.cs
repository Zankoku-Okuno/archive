﻿using System;
namespace Project1 {
 class Quine {
  public static void Main(string[] args) {
   var escapes = new string[] { ", ", "\"", "\\", " };" };
   var lines = new string[] { "using System;", "namespace Project1 {", " class Quine {", "  public static void Main(string[] args) {" };
   var partials = new string[] { "   var escapes = new string[] { ", "   var lines = new string[] { ", "   var partials = new string[] { ", "   var moarLines = new string[] { " };
   var moarLines = new string[] { "   var q = escapes[1];", "   var cs = escapes[0];", "   var e = escapes[2];", "   var sc = escapes[3];", "   foreach(string line in lines)", "    Console.WriteLine(line);", "   Console.Write(partials[0]);", "   Console.WriteLine(q+cs+q+cs+q+e+q+q+cs+q+e+e+q+cs+q+sc+q+sc);", "   Console.Write(partials[1] + q + lines[0]);", "   for (int i = 1; i != lines.Length; ++i)", "    Console.Write(q + cs + q + lines[i]);", "   Console.WriteLine(q + sc);", "   Console.Write(partials[2] + q + partials[0]);", "   for (int i = 1; i != partials.Length; ++i)", "    Console.Write(q + cs + q + partials[i]);", "   Console.WriteLine(q + sc);", "   Console.Write(partials[3] + q + moarLines[0]);", "   for (int i = 1; i != moarLines.Length; ++i)", "    Console.Write(q + cs + q + moarLines[i]);", "   Console.WriteLine(q + sc);", "   foreach (string line in moarLines)", "     Console.WriteLine(line);", "   Console.ReadLine();", "  }", " }", "}" };
   var q = escapes[1];
   var cs = escapes[0];
   var e = escapes[2];
   var sc = escapes[3];
   foreach(string line in lines)
    Console.WriteLine(line);
   Console.Write(partials[0]);
   Console.WriteLine(q+cs+q+cs+q+e+q+q+cs+q+e+e+q+cs+q+sc+q+sc);
   Console.Write(partials[1] + q + lines[0]);
   for (int i = 1; i != lines.Length; ++i)
    Console.Write(q + cs + q + lines[i]);
   Console.WriteLine(q + sc);
   Console.Write(partials[2] + q + partials[0]);
   for (int i = 1; i != partials.Length; ++i)
    Console.Write(q + cs + q + partials[i]);
   Console.WriteLine(q + sc);
   Console.Write(partials[3] + q + moarLines[0]);
   for (int i = 1; i != moarLines.Length; ++i)
    Console.Write(q + cs + q + moarLines[i]);
   Console.WriteLine(q + sc);
   foreach (string line in moarLines)
     Console.WriteLine(line);
   Console.ReadLine();
  }
 }
}
