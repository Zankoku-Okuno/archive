﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project1
{
    static class Learning
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Who might you be?");
            var name = Console.ReadLine();
            Console.WriteLine("Ah, {0}, bonsoir!", name);

            int[] arr = { 2, 4, 0, 3, 1, 7, 6 };
            arr = arr.intsort();
            for (int i = 0; i != arr.Length; ++i)
                Console.Write(arr[i] + " ");
            


            Console.ReadLine();

        }

        public static int[] intsort(this int[] array)
        {
            int test, min, temp;
            for (int sorted = 0; sorted != array.Length; ++sorted)
            {
                min = sorted;
                for (test = sorted + 1; test != array.Length; ++test)
                    if (array[test] < array[min])
                        min = test;
                temp = array[sorted];
                array[sorted] = array[min];
                array[min] = temp;
            }
            return array;
        }

    }

}
