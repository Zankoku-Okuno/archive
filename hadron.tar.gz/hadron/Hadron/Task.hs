{-#LANGUAGE OverloadedStrings, GeneralizedNewtypeDeriving #-}
module Hadron.Task (
      Task
    , Ident
    , TaskDef
    , defTask
    , docTask
    , Insp, Inspector
    , InspResult(..)
    , fresh, stale, problem
    , getConfig
    , setConfig
    , Exec, Recipe
    ) where

import Data.Text (Text)
import Control.Applicative
import Control.Monad
import Control.Monad.State


type Ident = String --TODO possibly make this safer
type Config = [(Ident, Text)] --TODO make this faster than an AList

newtype TaskDef = TaskDef Task
data Task = Task {
      taskName :: Ident
    , taskDoc :: Text
    , taskArgs :: [Text]
    , taskConfig :: Config
    , taskInspect :: Inspector
    , taskRecipe :: Recipe
    , taskClean :: Recipe
}

--FIXME tasks really should have unique names within a project, so let's monad it up to support this
--tasks need to provide cleanup code along with the creation code
defTask :: Ident -> Inspector -> (Recipe, Recipe) -> TaskDef
defTask name insp (exec, clean) = TaskDef $ Task {
      taskName = name
    , taskDoc = ""
    , taskArgs = []
    , taskConfig = []
    , taskInspect = insp
    , taskRecipe = exec
    , taskClean = clean
}

docTask :: TaskDef -> Text -> TaskDef
docTask (TaskDef task) docstr = TaskDef $ task { taskDoc = docstr }

configTask :: Task -> Config -> Task
configTask task new = task { taskConfig = new ++ taskConfig task }


data InspResult =
      Fresh
    | Stale [Task]
    | Error String --TODO could be an error due to improper dependency call or due to an IO error

newtype Insp a = Insp { unInsp :: StateT IState IO a }
    deriving (Functor, Applicative, Monad, MonadIO)
type Inspector = Insp InspResult
data IState = ISt {
      istDepTable :: [(Task, [Task])]
    , istErrTable :: [(Task, String)]
    , istConfig :: Config
}

inspect :: Task -> Inspector
inspect task = do
    oldConfig <- Insp $ gets istConfig
    preresult <- taskInspect task --TODO catch all errors from IO
    result <- case preresult of
        Stale deps -> do
            newConfig <- Insp $ gets istConfig
            pure . Stale $ flip configTask newConfig <$> deps
        _ -> pure preresult
    out <- case result of
        Fresh -> pure ()
        Stale deps -> do
            Insp $ modify $ addDependencies task deps
            mapM_ inspect deps
        Error msg -> do
            Insp $ modify $ \s -> s { istErrTable = (task, msg) : istErrTable s }
    Insp $ modify $ \s -> s { istConfig = oldConfig }
    pure result

getConfig :: Ident -> Insp (Maybe Text)
getConfig name = Insp $ lookup name <$> gets istConfig
setConfig :: Ident -> Text -> Insp ()
setConfig name val = Insp . modify $ \s -> s { istConfig = (name, val) : istConfig s }

fresh :: Inspector
fresh = pure Fresh
stale :: [Task] -> Inspector
stale = pure . Stale
problem :: String -> Inspector
problem = pure . Error

addDependencies :: Task -> [Task] -> IState -> IState
addDependencies task deps st = case lookup task (istDepTable st) of
    Nothing -> st { istDepTable = (task, deps) : istDepTable st }
    Just before -> st { istDepTable = (task, deps++before) : istDepTable st }






--TODO add logging
newtype Exec a = Exec { unExec :: IO a }
    deriving (Functor, Applicative, Monad)
type Recipe = Exec ()

exec :: Exec () -> IO Bool --perform the actions and return whether it succeeded
exec = undefined --TODO

runTask :: Task -> IO Bool --follow the recipe and return whether it succeeded
runTask = undefined



instance Eq Task where
    a == b =  taskName a == taskName b
           && taskArgs a == taskArgs b
           && taskConfig a == taskConfig b

instance MonadIO Exec where
    liftIO action = Exec . liftIO $ action -- `finally` TODO