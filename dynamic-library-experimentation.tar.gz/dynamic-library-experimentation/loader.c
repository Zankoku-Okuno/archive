
#include <stdlib.h>
#include <stdio.h>

#include <dlfcn.h>

void (*foo)(void);
int (*sna)(int);
void* dne;


int main(int argc, char** argv) {
	//one argument, the lib to load
	if (argc != 2) {
		printf("Invalid arguments: supply exactly one path to a dynamic library.\n");
		exit(1);
	}

	//Open the library file and check for any errors
	void* lib_handle;
	if ((lib_handle = dlopen(argv[1], RTLD_LAZY|RTLD_LOCAL)) == NULL) {
        fputs (dlerror(), stderr);
        exit(1);
    }
	
	//load two functions, sna & foo
	if ((foo = dlsym(lib_handle, "foo")) == NULL) {
		fputs (dlerror(), stderr);
        exit(1);
    }
	if ((sna = dlsym(lib_handle, "sna")) == NULL) {
		fputs (dlerror(), stderr);
        exit(1);
    }

    //use the loaded stuff
	{
		foo();
		printf("%d: %d, %d: %d\n", 2, sna(2), -6, sna(-6));
	}
	
	//clean up after the library
	//WARNING: do this after you're done with the libraries, not after your'e done loading
	dlclose(lib_handle);
	lib_handle = NULL;

	return 0;
}