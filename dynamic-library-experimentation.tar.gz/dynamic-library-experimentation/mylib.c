#include <stdio.h>

void foo() {
	printf("Goodbyte, cruel world!\n");
}

int sna(int x) {
	return x < 0 ? x/2 : x*2;
}