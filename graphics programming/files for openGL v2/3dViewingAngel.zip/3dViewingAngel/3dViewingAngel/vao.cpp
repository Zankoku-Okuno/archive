#ifndef __VAO_CPP__
#define __VAO_CPP__

#include "vao.h"

VAO::VAO(unsigned int length) {
	_length = length;
	_cursor = 0;
	size = length*sizeof(vec4);
	points = new vec4[length];
	normals = new vec4[length];
	colors = new vec4[length];
    
	GLuint vao;
    glGenVertexArrays( 1, &vao );
    glBindVertexArray( vao );
}
VAO::~VAO() {
	delete[] colors;
	delete[] normals;
	delete[] points;
}

void VAO::push(const vec4 vertex, const vec4 color) {
	points[_cursor] = vertex;
	colors[_cursor] = color;
	++_cursor;
}
void VAO::recolor(const vec4 color) {
	colors[_cursor++] = color;
}
void VAO::genFlatNormals() {
	for (unsigned int i = 0; i < _length; i += 3)
	{
		vec4 A = points[i], B = points[i+1], C = points[i+2];
		normals[i] = normals[i+1] = normals[i+2] = vec4(normalize(cross(B-A, C-A)), 0);
	}
}

void VAO::init(GLuint program) {
	glGenBuffers( 1, &buffer );
	glBindBuffer( GL_ARRAY_BUFFER, buffer );

	// set up handles on the GPU
    vPosition = glGetAttribLocation( program, "vPosition" );
	vNormal = glGetAttribLocation( program, "vNormal" );
    vColor = glGetAttribLocation( program, "vColor" ); 
    
}
void VAO::sendToGPU() {
	glEnableVertexAttribArray( vPosition );
    glVertexAttribPointer( vPosition, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0) );
	glEnableVertexAttribArray( vNormal );
    glVertexAttribPointer( vNormal, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(size) );
	glEnableVertexAttribArray( vColor );
    glVertexAttribPointer( vColor, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(2*size) );

	glBufferData(GL_ARRAY_BUFFER, 3*size, NULL, GL_STATIC_DRAW);
	glBufferSubData(GL_ARRAY_BUFFER, 0,      size, points);
	glBufferSubData(GL_ARRAY_BUFFER, size,   size, normals);
	glBufferSubData(GL_ARRAY_BUFFER, 2*size, size, colors);
}
void VAO::redraw() {
    glDrawArrays(GL_TRIANGLES, 0, _length);
}
void VAO::reset() { _cursor = 0; }

#endif