#ifndef __ENTITY_H__
#define __ENTITY_H__

#include "model.h"

class Entity {
	Model* model;
public:
	vec3 vel, angVel;
	vec4 pos;
	vec3 rot;
	bool isAlive;
	Entity(Model* model);
	void init(GLuint program);
	void accelerate(vec4 rate);
	void rotate(vec3 angAccel);
	void move();
	virtual void draw();
};

#endif
