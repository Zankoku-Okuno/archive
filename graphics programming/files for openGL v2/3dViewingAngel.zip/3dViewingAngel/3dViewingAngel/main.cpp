//
// Perspective view of a color cube using LookAt() and Ortho()
//
// Colors are assigned to each vertex and then the rasterizer interpolates
//   those colors across the triangles.
//

#include "Angel.h"
#include "entity.h"
#include <iostream>

int fps = 60;

Model* colorcube;
Model* star;

Entity* player;
Entity* player2;



// Viewing transformation parameters

vec4 eye = vec4(11, 10, 13, 1); //location of eye

GLfloat zNear = 0.5, zFar = 300.0; //bounds of frustrum
GLfloat fovy = 60, aspect = 1;

// Location of parameters in the shaders

//3d viewport
GLuint model;
GLuint view;
GLuint projection;
//light parameters
GLuint intensities;
GLuint sun, sunColor;
GLuint playerLight, playerColor;


//----------------------------------------------------------------------------

// OpenGL initialization
void init()
{
	//set up openGL settings
	glEnable(GL_CULL_FACE); //backface culling
	glEnable(GL_DEPTH_TEST); //depth buffering
	glDepthMask(GL_TRUE);
	glDepthFunc(GL_LESS);
	glDepthRange(0, 1);
	glEnable(GL_BLEND); //alpha mode
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glClearColor(0, 0, 0, 1); //clear color

	// Load shaders and use the resulting shader program
    GLuint program = InitShader( "vshader41.glsl", "fshader41.glsl" );
    glUseProgram(program);
	model       = glGetUniformLocation( program, "model" );
	view        = glGetUniformLocation( program, "view" );
	projection  = glGetUniformLocation( program, "projection" );
	intensities = glGetUniformLocation( program, "intensity" );
	sun         = glGetUniformLocation( program, "sun" );
	sunColor    = glGetUniformLocation( program, "sunColor" );
	playerColor = glGetUniformLocation( program, "playerColor" );
	playerLight = glGetUniformLocation( program, "playerPosition" );

	//build models
	colorcube = new ColorCube();
    colorcube->init(program);
	star = new Star();
    star->init(program);

	//set up world and entities
    glUniformMatrix4fv( projection, 1, GL_TRUE, Perspective(fovy, aspect, zNear, zFar) );
	glUniform4f(sun, 1,1,1,0);
	glUniform4f(sunColor, 0.7f,0.5f,1,1);
	glUniform4f(playerColor, 1,1,1,1);
	//glUniform4f(playerColor, 1,1,1,1);
	player = new Entity(star);
	player2 = new Entity(colorcube);
    
    
}

//----------------------------------------------------------------------------

void display(void)
{
    static vec4 at( 0.0, 0.0, 0.0, 1.0 );
    static vec4 up( 0.0, 1.0, 0.0, 0.0 );
	
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	glUniformMatrix4fv( view, 1, GL_TRUE, LookAt( eye, at, up ) );
	vec4 lightSource = Translate(player->pos)*Rotate3D(player->rot)*vec4(0.4f,0.3f,0,1);
	glUniform4f( playerLight, lightSource.x, lightSource.y, lightSource.z, 1 );
	
	glUniform4f(intensities, 0.2f, 0.8f, 0, 0);
	star->load();
	player->draw();
	colorcube->load();
	player2->draw();
	
	glUniform4f(intensities, 1, 0, 0, 0); //GUI gets different lighting
	glUniformMatrix4fv(model, 1, GL_TRUE, mat4(1));
	glBegin(GL_LINE_STRIP);
	glColor4f(0,1,1,1);
	glVertex3f(8,8,8);
	glVertex3f(-8,8,8);
	glVertex3f(-8,-8,8);
	glVertex3f(8,-8,8);
	glVertex3f(8,8,8);
	glEnd();
	glBegin(GL_LINE_STRIP);
	glColor4f(1,1,1,1);
	glVertex3f(8,8,-8);
	glVertex3f(-8,8,-8);
	glVertex3f(-8,-8,-8);
	glVertex3f(8,-8,-8);
	glVertex3f(8,8,-8);
	glEnd();
	glBegin(GL_LINES);
	glVertex3f(8,8,-8); glVertex3f(8,8,8); 
	glVertex3f(-8,8,-8); glVertex3f(-8,8,8); 
	glVertex3f(-8,-8,-8); glVertex3f(-8,-8,8); 
	glVertex3f(8,-8,-8); glVertex3f(8,-8,8);
	glEnd();


    glutSwapBuffers();
}

//----------------------------------------------------------------------------

void specialKeyboard(int key, int x, int y) {
	switch(key) {
	case 101: //UP
		player->accelerate(vec4(0.03f,0,0,0)); break;
	case 103: //DOWN
		player->accelerate(vec4(-0.03f,0,0,0)); break;
	case 100: //LEFT
		player->rotate(vec3(0,2,0)); break;
	case 102: //RIGHT
		player->rotate(vec3(0,-2,0)); break;
	}
}

void keyboard(unsigned char key, int x, int y)
{
    switch(key) {
		case 033: // Escape Key
		case 'q': case 'Q':
			exit(EXIT_SUCCESS);
			break;

		case 'x': player->accelerate(vec4(0,0.03f,0,0)); break;
		case 'z': player->accelerate(vec4(0,-0.03f,0,0)); break;
		
		case 's': player->vel = vec3(0); break;
		case 'a': player->angVel = vec3(0); break;
		case ' ': player->vel = vec3(0);
				  player->angVel = vec3(0); break;

		case 'f':
			glutFullScreenToggle();
			break;


    }
}

void animator(int value) {
	player->move();
	glutPostRedisplay();
	glutTimerFunc(1000/fps, animator, value);
}

//----------------------------------------------------------------------------

void reshape(int width, int height)
{
    glViewport(0, 0, width, height);
	aspect = (GLfloat)width/(GLfloat)height;
    glUniformMatrix4fv( projection, 1, GL_TRUE, Perspective(fovy, aspect, zNear, zFar) );
}

//----------------------------------------------------------------------------
int main(int argc, char **argv)
{
    glutInit( &argc, argv );
    glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH );
    glutInitWindowSize(512, 512);
    glutCreateWindow("Ast3roids");

    glewInit();

    init();

    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeyboard);
    glutReshapeFunc(reshape);
	glutTimerFunc(1000/fps, animator, 0);
    glutMainLoop();
    return 0;
}

