#ifndef __MODEL_H__
#define __MODEL_H__

#include "Angel.h"
#include "vao.h"

/*
 An abstract class that provides the framework for modeling. For any given (class of) model, simply define a subclass.
 The subclass needs to implement rebuild. After creating the model, you will need to call init. To draw the model to the screen, call draw (this also forces a model update.
 If parts of the model are static (not per-frame animated), then it is more efficient to implement this drawing in the build method.
*/
class Model {
protected:
	VAO vao;
	GLuint matrix;
	vec4 _color;
	void polygon(const unsigned int n, const vec4 points[]);
	void polygon(const unsigned int n, const vec4 points[], const vec4 color);
	void polygon(const unsigned int n, const vec4 points[], const vec4 colors[]);
	virtual void build(void);
public:
	Model(const unsigned int numVertices);
	void init(GLuint program);
	virtual void rebuild(void) = 0;
	void load();
	void draw(const mat4& model_matrix);
};

class ColorCube : public Model {
protected:
	void quad(int a, int b, int c, int d);
public:
	virtual void rebuild();
	ColorCube();
};

class Star : public Model {
public:
	void rebuild();
	Star();
};





#endif