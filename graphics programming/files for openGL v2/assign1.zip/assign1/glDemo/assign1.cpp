#include "assign1.h"

using namespace std;

//a set of points to draw
vector<xyPoint> pointSet = vector<xyPoint>();
//how to draw them
GLenum draw_style = GL_POINTS;
float r = 1, g = 1, b = 1;

int main (int argc, char** argv) {
	// Initialize GLUT
	glutInit(&argc, argv);

	// Set up some memory buffers for our display
	glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGBA|GLUT_DEPTH);
	// Set the window size
	glutInitWindowSize(800, 600);
	// Create the window with the title "Triangle"
	glutCreateWindow("Point Placer!!!1!");
	
	// bind event handlers
	glutReshapeFunc(changeViewport);
	glutDisplayFunc(render);
	glutKeyboardFunc(keyboardHandler);
	glutMouseFunc(mouseHandler);

	if (glewInit() != GLEW_OK) {
		fprintf(stderr, "GLEW error");
		return 1;
	}
	
	// Start up a loop that runs in the background (you never see it).
	glutMainLoop();
	return 0;
}





// Here is the function that gets called each time the window needs to be redrawn.
// It is the "paint" method for our program, and is set up from the glutDisplayFunc in main
void render() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glPolygonMode(GL_FRONT, GL_POLYGON);

	glutInitDisplayMode (GLUT_DOUBLE|GLUT_RGBA);

	float r1 = 0.2f, r2 = 1;
	glBegin(draw_style);
		glColor3f(r, g, b);
		for(vector<xyPoint>::iterator iter = pointSet.begin(); iter != pointSet.end(); ++iter)
			glVertex3f(iter->x, iter->y, 0);
	glEnd();

	glutSwapBuffers();
}

void keyboardHandler(unsigned char key, int x, int y) {
	switch (key) {
		case 'p': draw_style = GL_POINTS; break;
		case 'l': draw_style = GL_LINE_STRIP; break;
		case 't': draw_style = GL_TRIANGLE_STRIP; break;

		case 'r': r = 1; g = b = 0; break;
		case 'g': g = 1; r = b = 0; break;
		case 'b': b = 1; r = g = 0; break;
	}
	glutPostRedisplay();
}

void mouseHandler(int button, int state, int x, int y) {
	if (state == GLUT_DOWN) {
		float xRel = x*2.0f / glutGet(GLUT_WINDOW_WIDTH) - 1;
		float yRel = 1 - y*2.0f / glutGet(GLUT_WINDOW_HEIGHT);
		pointSet.emplace_back(xyPoint(xRel, yRel));
		glutPostRedisplay();
	}
}






// Any time the window is resized, this function gets called.  It's setup to the 
// "glutReshapeFunc" in main.
void changeViewport(int w, int h){
	glViewport(0, 0, w, h);
}
