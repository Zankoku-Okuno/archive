#include <GL/glew.h>
#include <GL/freeglut.h>
#include <iostream>
#include <cstdio>
#include <cmath>
#include <vector>

struct xyPoint {
	float x, y;
	xyPoint(float arg1, float arg2) : x(arg1), y(arg2) {}
};

void mouseHandler(int button, int state, int x, int y);
void keyboardHandler(unsigned char key, int x, int y);
void render();


void changeViewport(int w, int h);


