#ifndef __MODEL_CPP__
#define __MODEL_CPP__

#include "model.h"

//---------------------------------------------------
// Model (base class)

Model::Model(const unsigned int numVertices) : vao(VAO(numVertices)), _color(vec4(1)) {}
void Model::init(GLuint program) {
	vao.init(program);
	build();
}
void Model::build(void) { rebuild(); }
void Model::draw(const bool flag) {
	if (flag) {
		vao.reset();
		rebuild();
		vao.sendToGPU();
	}
	vao.draw();
}

inline
void Model::polygon(const unsigned int n, const vec4 points[]) {
	polygon(n, points, _color);
}
void Model::polygon(const unsigned int n, const vec4 points[], const vec4 color) {
	if (n < 3) return;
	for(unsigned int i = 1; i < n-1; ++i) {
		vao.push(points[0], color);
		vao.push(points[i], color);
		vao.push(points[i+1], color);
	}
}
void Model::polygon(const unsigned int n, const vec4 points[], const vec4 colors[]) {
	if (n < 3) return;
	for(unsigned int i = 1; i < n-1; ++i) {
		vao.push(points[0], colors[0]);
		vao.push(points[i], colors[i]);
		vao.push(points[i+1], colors[i+1]);
	}
}

//---------------------------------------------------
// Color Cube

void ColorCube::quad(int a, int b, int c, int d)
{
	// Vertices of a unit cube centered at origin, sides aligned with axes
	static vec4 vertices[8] = {
		vec4(-0.5, -0.5, -0.5,	1.0),
		vec4(-0.5, -0.5,  0.5,	1.0),
		vec4(-0.5,  0.5, -0.5,	1.0),
		vec4( 0.5, -0.5, -0.5,	1.0),
		vec4( 0.5,  0.5, -0.5,	1.0),
		vec4( 0.5, -0.5,  0.5,	1.0),
		vec4(-0.5,  0.5,  0.5,	1.0),
		vec4( 0.5,  0.5,  0.5,	1.0)
	};
	// RGBA colors
	static vec4 vertex_colors[8] = {
		vec4(1.0, 1.0, 1.0, 1.0),  // white
		vec4(0.0, 1.0, 1.0, 1.0),   // cyan
		vec4(1.0, 0.0, 1.0, 1.0),  // magenta
		vec4(1.0, 1.0, 0.0, 1.0),  // yellow
		vec4(1.0, 0.0, 0.0, 1.0),  // red
		vec4(0.0, 1.0, 0.0, 1.0),  // green
		vec4(0.0, 0.0, 1.0, 1.0),  // blue
		vec4(0.0, 0.0, 0.0, 1.0)  // black
	};
	int n = 4;
	vec4 points[] = {vertices[a], vertices[b], vertices[c], vertices[d]};
	vec4 colors[] = {vertex_colors[a], vertex_colors[b], vertex_colors[c], vertex_colors[d]};
	polygon(n, points, colors);
}

ColorCube::ColorCube() : Model(36) {}
void ColorCube::rebuild() {
	quad(0, 1, 6, 2);
	quad(0, 2, 4, 3);
	quad(0, 3, 5, 1);
	quad(2, 6, 7, 4);
	quad(7, 6, 1, 5);
	quad(7, 5, 3, 4);
	vao.createFlatSurfaceNormals();
}


#endif
