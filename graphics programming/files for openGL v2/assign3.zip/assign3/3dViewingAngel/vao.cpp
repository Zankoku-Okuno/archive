#ifndef __VAO_CPP__
#define __VAO_CPP__

#include "vao.h"

VAO::VAO(unsigned int length) {
	_length = length;
	_cursor = 0;
	size = length*sizeof(vec4);
	points = new vec4[length];
	colors = new vec4[length];
	normals = new vec4[length];
}
/*VAO::~VAO() { //I understand now why this is giving me errors, but is there a nice way around it?
	delete[] colors;
	delete[] points;
}*/

//inline
vec4 VAO::peek_vertex(void) { return points[_cursor]; }

void VAO::push(const vec4 vertex, const vec4 color) {
	points[_cursor] = vertex;
	colors[_cursor] = color;
	++_cursor;
}

GLfloat VAO::peek_z(void) { return points[_cursor].z; }
void VAO::set_z(GLfloat value) { points[_cursor].z = value; }
void VAO::recolor(const vec4 color) { colors[_cursor++] = color; }
void VAO::createFlatSurfaceNormals() {
	for (int i = 0; i < _length; i += 3)
	{
		vec4 A = points[i], B = points[i+1], C = points[i+2];
		normals[i] = normals[i+1] = normals[i+2] = vec4(normalize(cross(B-A, C-A)), 0);
	}
}

void VAO::init(GLuint program) {
	glGenBuffers( 1, &buffer );
	glBindBuffer( GL_ARRAY_BUFFER, buffer );

	// set up vertex arrays
    GLuint vPos = glGetAttribLocation( program, "vPos" );
    glEnableVertexAttribArray( vPos );
    glVertexAttribPointer( vPos, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0) );

	GLuint vNrm = glGetAttribLocation(program, "vNrm");
	glEnableVertexAttribArray(vNrm);
	glVertexAttribPointer(vNrm, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(size));

    GLuint vColor = glGetAttribLocation( program, "vCol" ); 
    glEnableVertexAttribArray( vColor );
    glVertexAttribPointer( vColor, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(2*size) );
}
void VAO::sendToGPU() {
	glBufferData(GL_ARRAY_BUFFER, size*3, NULL, GL_STATIC_DRAW);
	glBufferSubData(GL_ARRAY_BUFFER, 0, size, points);
	glBufferSubData(GL_ARRAY_BUFFER, size, size, normals);
	glBufferSubData(GL_ARRAY_BUFFER, size*2, size, colors);
}
void VAO::draw() {
    glDrawArrays(GL_TRIANGLES, 0, _length);
}
void VAO::reset(void) { _cursor = 0; }

#endif