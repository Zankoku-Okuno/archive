#ifndef __VAO_H__
#define __VAO_H__

#include "Angel.h"

class VAO {
	unsigned int _cursor;
	unsigned int _length;
	GLuint buffer;
	vec4* points;
	vec4* colors;
	vec4* normals;
public:
	unsigned int size;
	VAO(unsigned int length=0);
	/*~VAO() { //I understand now why this is giving me errors, but is there a nice way around it?
		delete[] colors;
		delete[] points;
	}*/

	vec4 peek_vertex(void);
	void push(const vec4 vertex, const vec4 color);

	GLfloat peek_z(void);
	void set_z(GLfloat value);
	void recolor(const vec4 color);
	void createFlatSurfaceNormals();

	void init(GLuint program);
	void sendToGPU(void);
	void draw(void);
	void reset(void);
};

#endif