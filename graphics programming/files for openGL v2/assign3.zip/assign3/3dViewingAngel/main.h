#include "Angel.h"
#include "entity.h"
#include <iostream>


//Entity* oneloc = new Entity(new ColorCube());
Entity* player = new Entity(new ColorCube());
GLfloat  zNear = 0.5, zFar = 300.0, fovy = 60, aspect = 1;
const int fps = 30;

const GLfloat eyeSpeed = 0.5f, rotSpeed = 2;

int main(int argc, char **argv);

extern vec4 eye; //location of eye


void init();
void display(void);
void specialKeyboard(int key, int x, int y);
void keyboard(unsigned char key, int x, int y);
void animator(int value);
void reshape(int width, int height);