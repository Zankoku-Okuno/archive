#ifndef __ENTITY_H__
#define __ENTITY_H__

#include "model.h"

class Entity {
	Model* model;
	GLuint matrix;
public:
	vec4 pos;
	vec3 rot;

	Entity(Model* model) :
	model(model),
	pos(vec4(0,0,0,1)),
	rot(0)
	{}
	
	void init(GLuint program) {
		matrix = glGetUniformLocation( program, "model" );
		model->init(program);
	}
	void draw(const bool restructure=false) {
		glUniformMatrix4fv (matrix, 1, GL_TRUE, Translate(pos)*Rotate3D(rot));
		model->draw(restructure);
	}
};


#endif