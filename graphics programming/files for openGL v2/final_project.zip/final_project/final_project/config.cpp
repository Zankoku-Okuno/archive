#ifndef __CONFIG_CPP__
#define __CONFIG_CPP__

#include "main.h"

int fps = 30;

//World parameters
float mainThrusters = 0.03f;
float maneuveringThrusters = 2;

float barrelSpeed = 0.3f;
float bulletSize = 0.1f;
int bulletLifetime = 2*fps;


//Lighting Functions
void worldLighting() {
	vec4 lightSource = Translate(player->pos)*Rotate3D(player->rot)*vec4(0.4f,0.3f,0,1);
	glUniform4f(playerLight, lightSource.x, lightSource.y, lightSource.z, 1);
	glUniform4f(intensities, 0.4f, 0.8f, 0, 0);
}
void bulletLighting() {
	glUniform4f(intensities, 0, 0, 0, 1);
}


void loadSun() {
	glUniform4f(sunDirection, -1,1,-1,0);
	glUniform4f(sunColor, 0.7f,0.5f,1,1);
}
void loadPlayerLight() {
	glUniform4f(playerColor, 1,1,1,1);
}


//Veiwport Functions
vec4 eye = vec4(11, 10, 13, 1);
void loadEye() {
	glUniform4f(eyeLoc, eye.x,eye.y,eye.z,0);
}

GLfloat zNear = 0.5, zFar = 300.0; //bounds of frustrum
GLfloat fovy = 60, aspect = 1;
void perspective3D() {
    glUniformMatrix4fv(projection, 1, GL_TRUE, Perspective(fovy, aspect, zNear, zFar));
}
void perspectiveHUD() {
    glUniformMatrix4fv(projection, 1, GL_TRUE, mat4(1));
}

#endif