#ifndef __MAIN_H__
#define __MAIN_H__

#include <vector>
#include "Angel.h"
#include "entity.h"


//Game data
extern bool paused;

extern Model* whiteCube, *brownCube, *star, *frame;

extern Entity* player;
extern std::vector<Entity*> asteroids, bullets;

// Location of parameters in the shaders

//3d viewport
extern GLuint model, view, projection;
//light parameters
extern GLuint intensities, eyeLoc, sunDirection, sunColor, playerLight, playerColor;

extern int fps;

extern vec4 eye;
void loadEye();
void loadSun();
void loadPlayerLight();

extern float barrelSpeed;
extern float bulletSize;
extern int bulletLifetime;






extern GLfloat zNear, zFar, fovy, aspect;
void perspective3D();
void perspectiveHUD();



void worldLighting();
void bulletLighting();

extern float mainThrusters;
extern float maneuveringThrusters;

#endif