#ifndef __MODEL_CPP__
#define __MODEL_CPP__

#include "model.h"



Model::Model(const unsigned int numVertices) : vao(VAO(numVertices)), _color(vec4(1)) {}
void Model::init(GLuint program) {
	vao.init(program);
    matrix = glGetUniformLocation( program, "model" );
	vao.reset();
	build();
}
void Model::build(void) { rebuild(); vao.sendToGPU(); }
void Model::load() {
	vao.sendToGPU();
}
void Model::draw(const mat4& model_matrix) {
	glUniformMatrix4fv(matrix, 1, GL_TRUE, model_matrix);
	vao.redraw();
}


void Model::polygon(const unsigned int n, const vec4 points[]) {
	polygon(n, points, _color);
}
void Model::polygon(const unsigned int n, const vec4 points[], const vec4 color) {
	if (n < 3) return;
	for(unsigned int i = 1; i < n-1; ++i) {
		vao.push(points[0], color);
		vao.push(points[i], color);
		vao.push(points[i+1], color);
	}
}
void Model::polygon(const unsigned int n, const vec4 points[], const vec4 colors[]) {
	if (n < 3) return;
	for(unsigned int i = 1; i < n-1; ++i) {
		vao.push(points[0], colors[0]);
		vao.push(points[i], colors[i]);
		vao.push(points[i+1], colors[i+1]);
	}
}

Cube::Cube() : Model(36) {}
void Cube::rebuild() {
	quad(0, 1, 6, 2);
	quad(0, 2, 4, 3);
	quad(0, 3, 5, 1);
	quad(2, 6, 7, 4);
	quad(7, 6, 1, 5);
	quad(7, 5, 3, 4);
	vao.genFlatNormals();
}
void Cube::quad(int a, int b, int c, int d)
{
	// Vertices of a unit cube centered at origin, sides aligned with axes
	static const vec4 vertices[8] = {
		vec4(-0.5, -0.5, -0.5,	1.0),
		vec4(-0.5, -0.5,  0.5,	1.0),
		vec4(-0.5,  0.5, -0.5,	1.0),
		vec4( 0.5, -0.5, -0.5,	1.0),
		vec4( 0.5,  0.5, -0.5,	1.0),
		vec4( 0.5, -0.5,  0.5,	1.0),
		vec4(-0.5,  0.5,  0.5,	1.0),
		vec4( 0.5,  0.5,  0.5,	1.0)
	};
	// RGBA colors
	int n = 4;
	vec4 points[] = {vertices[a], vertices[b], vertices[c], vertices[d]};
	vec4 colors[] = {vertex_color(a), vertex_color(b), vertex_color(c), vertex_color(d)};
	polygon(n, points, colors);
}
vec4 Cube::vertex_color(int i) {
	return vec4(1,1,0,0.5);
}

ColorCube::ColorCube() : Cube() {}
vec4 ColorCube::vertex_color(int i) {
	static const vec4 vertex_colors[8] = {
		vec4(1.0, 1.0, 1.0, 1.0),  // white
		vec4(0.0, 1.0, 1.0, 1.0),   // cyan
		vec4(1.0, 0.0, 1.0, 1.0),  // magenta
		vec4(1.0, 1.0, 0.0, 1.0),  // yellow
		vec4(1.0, 0.0, 0.0, 1.0),  // red
		vec4(0.0, 1.0, 0.0, 1.0),  // green
		vec4(0.0, 0.0, 1.0, 1.0),  // blue
		vec4(0.0, 0.0, 0.0, 1.0)  // black
	};
	return vertex_colors[i];
}


Star::Star() : Model(72) {}
void Star::rebuild() {
	static float thickness = 0.25f,
				 radius = .4f,
				 ratio = 3;
	static vec4 color = vec4(0.7f,0.7f,0.85f,1);
	vec4 top   = vec4(0, thickness, 0, 1),
		 bot   = vec4(0, -thickness, 0, 1),
		 point = vec4(radius*ratio, 0, 0, 1),
		 side  = RotateY(-46)*vec4(radius, 0, 0, 1);
	for(int i = 0; i < 5; ++i) {
		vao.push(top, color);
		vao.push(side, color);
		vao.push(point, color);
		vao.push(bot, color);
		vao.push(point, color);
		vao.push(side, color);
		side = RotateY(72)*side;
		vao.push(top, color);
		vao.push(point, color);
		vao.push(side, color);
		vao.push(bot, color);
		vao.push(side, color);
		vao.push(point, color);
		point = RotateY(72)*point;
	}
	vao.genFlatNormals();
	vao.reset();
	for (int i = 0; i < 12; ++i)
		vao.recolor(vec4(0.5f,1,0.7f,0.7f));
}

CubeAsteroid::CubeAsteroid() : Cube() {}
vec4 CubeAsteroid::vertex_color(int i) {
	//return vec4(0.388f,0.216f,0.114f,1);
	return vec4(0.286f,0.157f, 0.106f, 1);
}

WorldFrame::WorldFrame() : Model(24) {}
void WorldFrame::rebuild() {
	vec4 color = vec4(1,0,0,0.5f);
	vao.push(vec4(8,8,-8,1), color); vao.push(vec4(-8,8,-8,1), color);
	vao.push(vec4(8,8,8,1), color); vao.push(vec4(8,8,-8,1), color);
	vao.push(vec4(-8,8,8,1), color); vao.push(vec4(-8,8,-8,1), color);
	vao.push(vec4(8,8,8,1), color); vao.push(vec4(-8,8,8,1), color);
	vao.push(vec4(8,8,-8,1), color); vao.push(vec4(8,-8,-8,1), color);
	vao.push(vec4(8,8,8,1), color); vao.push(vec4(8,-8,8,1), color);
	vao.push(vec4(-8,8,8,1), color); vao.push(vec4(-8,-8,8,1), color);
	vao.push(vec4(-8,8,-8,1), color); vao.push(vec4(-8,-8,-8,1), color);
	vao.push(vec4(8,-8,8,1), color); vao.push(vec4(-8,-8,8,1), color);
	vao.push(vec4(8,-8,8,1), color); vao.push(vec4(8,-8,-8,1), color);
	vao.push(vec4(-8,-8,8,1), color); vao.push(vec4(-8,-8,-8,1), color);
	vao.push(vec4(8,-8,-8,1), color); vao.push(vec4(-8,-8,-8,1), color);
}
void WorldFrame::draw(const mat4& model_matrix) {
	glUniformMatrix4fv(matrix, 1, GL_TRUE, model_matrix);
	glDrawArrays(GL_LINES, 0, 24);
}




#endif
