//
// Perspective view of a color cube using LookAt() and Ortho()
//
// Colors are assigned to each vertex and then the rasterizer interpolates
//   those colors across the triangles.
//

#include <iostream>
#include <cstdlib>
#include "main.h"

using namespace std;


//Game data
int level = 0;
bool paused = true;

Model* whiteCube;
Model* brownCube;
Model* star;
Model* frame;

Entity* player;
std::vector<Entity*> asteroids;
std::vector<Entity*> bullets;

//Shader pointers
GLuint model, view, projection;
GLuint intensities, eyeLoc, sunDirection, sunColor, playerLight, playerColor;

//Game algorithms
float randFloat() {
	return (float)rand()/RAND_MAX;
}
vec3 randDirection() {
	return normalize(vec3(randFloat()-0.5f, randFloat()-0.5f, randFloat()-0.5f));
}
Entity* genBullet() {
	Entity* bullet = new Entity(whiteCube);
	vec4 barrelVel = Rotate3D(player->rot)*vec4(barrelSpeed,0,0,0);
	bullet->pos = player->pos + Rotate3D(player->rot)*vec4(1.2f,0,0,1);
	bullet->angVel = randDirection()*6;
	bullet->vel = player->vel + vec3(barrelVel.x, barrelVel.y, barrelVel.z);
	bullet->scale = bulletSize;
	bullet->lifetime = bulletLifetime;
	return bullet;
}
void genAsteroid(const vec4& pos, const vec3& vel, const float& scale) {
	for(int j = 1; j <=2; ++j) {
		Entity* asteroid = new Entity(brownCube);
		asteroid->pos = pos; asteroid->pos.w = 1;
		asteroid->vel = vel;
		asteroid->rot = vec3(j*1.3f,j*0.4f,j*0.9f)*60;
		asteroid->scale = scale;
		asteroid->angVel = vec3(j*19%3, j*13%3, j*17%3);
		asteroids.push_back(asteroid);
	}
}

void initializeLevel() {
	int limit = (level%2 == 0) ? 3*level/2 + 2 : 3*level/2 + 3;
	player->isAlive = true;
	for (int i = 0; i < asteroids.size(); ++i)
		delete asteroids[i];
	asteroids.clear();
	for (int i = 1; i <= limit; ++i)
		genAsteroid(randDirection()*8, randDirection()*1.5*0.05f, (i%3 == 0) ? 0.5f : (i%3 == 1) ? 0.8f : 1.5f);
	for (int i = 0; i < bullets.size(); ++i)
		delete bullets[i];
	bullets.clear();
	cout << "Level " << level << ": " << limit << " asteroids... begin!" << endl;
}




//----------------------------------------------------------------------------

// OpenGL initialization
void init()
{
	//set up openGL settings
	glEnable(GL_CULL_FACE); //backface culling
	glEnable(GL_DEPTH_TEST); //depth buffering
	glDepthMask(GL_TRUE);
	glDepthFunc(GL_LESS);
	glDepthRange(0, 1);
	glEnable(GL_BLEND); //alpha mode
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glClearColor(0, 0, 0, 1); //clear color

	// Load shaders and use the resulting shader program
    GLuint program = InitShader( "vshader41.glsl", "fshader41.glsl" );
    glUseProgram(program);
	model        = glGetUniformLocation( program, "model" );
	view         = glGetUniformLocation( program, "view" );
	projection   = glGetUniformLocation( program, "projection" );
	intensities  = glGetUniformLocation( program, "intensity" );
	eyeLoc       = glGetUniformLocation( program, "eye" );
	sunDirection = glGetUniformLocation( program, "sun" );
	sunColor     = glGetUniformLocation( program, "sunColor" );
	playerColor  = glGetUniformLocation( program, "playerColor" );
	playerLight  = glGetUniformLocation( program, "playerPosition" );

	//build models
	whiteCube = new Cube();
    whiteCube->init(program);
	brownCube = new CubeAsteroid();
    brownCube->init(program);
	star = new Star();
    star->init(program);
	frame = new WorldFrame();
	frame->init(program);

	//set up world and entities
	perspective3D();
	loadEye();
	loadSun();
	loadPlayerLight();
	player = new Entity(star);
	bullets = vector<Entity*>();
	asteroids = vector<Entity*>();
    initializeLevel();
    
}

//----------------------------------------------------------------------------

void display(void)
{
    static vec4 at( 0.0, 0.0, 0.0, 1.0 );
    static vec4 up( 0.0, 1.0, 0.0, 0.0 );
	
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	glUniformMatrix4fv( view, 1, GL_TRUE, LookAt( eye, at, up ) );
	worldLighting();
	star->load();
	player->draw();
	brownCube->load();
	for (int i = 0; i < asteroids.size(); ++i)
		asteroids[i]->draw();
	bulletLighting();
	whiteCube->load();
	for (int i = 0; i < bullets.size(); ++i)
		bullets[i]->draw();

	glUniform4f(intensities, 0, 0, 0, (player->isAlive) ? 0.5f : 1.0f);
	frame->load();
	frame->draw(mat4(1));



    glutSwapBuffers();
}

//----------------------------------------------------------------------------

void animator(int value) {
	if (asteroids.size() == 0) {
		paused = true;
		if(player->isAlive) ++level;
		initializeLevel();
	}
	if(!paused) {
		//movement
		player->move();
		for (int i = 0; i < bullets.size(); ++i)
			bullets[i]->move();
		for (int i = 0; i < asteroids.size(); ++i)
			asteroids[i]->move();
		//timers countdown
		for (int i = 0; i < bullets.size(); ++i) {
			if (bullets[i]->lifetime <= 0)
				bullets[i]->isAlive = false;
			else --bullets[i]->lifetime;
		}
		//collision detection
		for (int i = 0; i < asteroids.size(); i+=2) {
			float actualDistance = length(asteroids[i]->pos - player->pos);
			float collisionDistance = (asteroids[i]->scale + 1)/2;
			if (actualDistance <= collisionDistance) {
					asteroids[i]->isAlive = false; asteroids[i+1]->isAlive = false;
					player->isAlive = false;
			}
			for (int j = 0; j < bullets.size(); ++j) {
				actualDistance = length(asteroids[i]->pos - bullets[j]->pos);
				collisionDistance = (asteroids[i]->scale + bullets[j]->scale)/2;
				if (actualDistance <= collisionDistance)
				{
					asteroids[i]->isAlive = false; asteroids[i+1]->isAlive = false;
					bullets[j]->isAlive = false;
				}
			}
			for (int j = 0; j < i; j+=2) {
				actualDistance = length(asteroids[i]->pos - asteroids[j]->pos);
				collisionDistance = (asteroids[i]->scale + asteroids[j]->scale)/2;
				if (actualDistance <= collisionDistance)
				{
					asteroids[i]->isAlive = false; asteroids[i+1]->isAlive = false;
					asteroids[j]->isAlive = false; asteroids[j+1]->isAlive = false;
				}
			}
		}
		//collision handling
		for (int i = asteroids.size()-1; i >= 0; --i)
			if (!asteroids[i]->isAlive) {
				Entity* tmp = asteroids[i];
				asteroids.erase(asteroids.begin()+i);
				float scale;
				if (i%2 && (scale = 0.71f*tmp->scale) >= 0.5f) {
					vec3 v1 = randDirection()*2*0.05f;
					vec3 v2 = tmp->vel - v1;
					genAsteroid(tmp->pos+scale*normalize(v1), v1, scale);
					genAsteroid(tmp->pos+scale*normalize(v2), v2, scale);
				}
				delete tmp;
			}
		for (int i = bullets.size()-1; i >= 0; --i)
			if (!bullets[i]->isAlive) {
				delete bullets[i];
				bullets.erase(bullets.begin()+i);
			}
	}
	glutTimerFunc(1000/fps, animator, value);
	glutPostRedisplay();
}

//----------------------------------------------------------------------------

void specialKeyboard(int key, int x, int y) {
	switch(key) {
	case 101: //UP
		if (!paused) player->accelerate(vec4(mainThrusters,0,0,0)); break;
	case 103: //DOWN
		if (!paused) player->accelerate(vec4(-mainThrusters,0,0,0)); break;
	case 100: //LEFT
		if (!paused) player->rotate(vec3(0,maneuveringThrusters,0)); break;
	case 102: //RIGHT
		if (!paused) player->rotate(vec3(0,-maneuveringThrusters,0)); break;
	}
}

void keyboard(unsigned char key, int x, int y)
{
    switch(key) {
		case 033: // Escape Key
		case 'q': case 'Q':
			exit(EXIT_SUCCESS); break;
		case 'p':
			paused = !paused; break;
		case 'r':
			initializeLevel(); break;
		case 'f':
			glutFullScreenToggle(); break;
		
		case 'x': if (!paused) player->accelerate(vec4(0,mainThrusters,0,0)); break;
		case 'z': if (!paused) player->accelerate(vec4(0,-mainThrusters,0,0)); break;
		
		case 's': if (!paused) player->vel = vec3(0); break;
		case 'a': if (!paused) player->angVel = vec3(0); break;
		case ' ': if (!paused) {
				bullets.push_back(genBullet());
			} break;
    }
}

//----------------------------------------------------------------------------

void reshape(int width, int height)
{
    glViewport(0, 0, width, height);
	aspect = (GLfloat)width/(GLfloat)height;
    glUniformMatrix4fv( projection, 1, GL_TRUE, Perspective(fovy, aspect, zNear, zFar) );
}

//----------------------------------------------------------------------------
int main(int argc, char **argv)
{
    glutInit( &argc, argv );
    glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH );
    glutInitWindowSize(512, 512);
    glutCreateWindow("Ast3roids");

    glewInit();

    init();

    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeyboard);
    glutReshapeFunc(reshape);
	glutTimerFunc(1000/fps, animator, 0);
    glutMainLoop();
    return 0;
}

