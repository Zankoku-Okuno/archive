#ifndef __VAO_H__
#define __VAO_H__

#include "Angel.h"

class VAO {
	unsigned int _cursor;
	unsigned int _length;
	GLuint buffer, vPosition, vNormal, vColor;
public:
	vec4* points;
	vec4* normals;
	vec4* colors;
	unsigned int size;
	VAO(unsigned int length=0);
	~VAO();

	void push(const vec4 vertex, const vec4 color);
	void recolor(const vec4 color);
	void genFlatNormals();

	void init(GLuint program);
	void sendToGPU();
	void redraw();
	void reset();

};

#endif