#ifndef __ENTITY_CPP__
#define __ENTITY_CPP__

#include "Angel.h"
#include "entity.h"

Entity::Entity(Model* model) :
	model(model),
	vel(0), angVel(0),
	pos(vec3(0)),
	rot(0),
	scale(1),
	isAlive(true)
{}

void Entity::init(GLuint program) {
	model->init(program);
}

void Entity::accelerate(vec4 rate) {
	vec4 dv = Rotate3D(rot)*rate;
	vel.x += dv.x;
	vel.y += dv.y;
	vel.z += dv.z;
}

void Entity::rotate(vec3 angAccel) {
	angVel.x += angAccel.x;
	angVel.y += angAccel.y;
	angVel.z += angAccel.z;
}

void Entity::move() {
	pos.x += vel.x;
	pos.y += vel.y;
	pos.z += vel.z;
	rot.x += angVel.x;
	rot.y += angVel.y;
	rot.z += angVel.z;

	if (pos.x > 8) pos.x -= 16;
	if (pos.x < -8) pos.x += 16;
	if (pos.y > 8) pos.y -= 16;
	if (pos.y < -8) pos.y += 16;
	if (pos.z > 8) pos.z -= 16;
	if (pos.z < -8) pos.z += 16;
}

void Entity::draw() {
	mat4 inPlace = Scale(scale)*Rotate3D(rot);
	model->draw(Translate(pos)*inPlace);
	model->draw(Translate(pos+vec3(0,0,16))*inPlace);
	model->draw(Translate(pos+vec3(0,16,0))*inPlace);
	model->draw(Translate(pos+vec3(0,16,16))*inPlace);
	model->draw(Translate(pos+vec3(16,0,0))*inPlace);
	model->draw(Translate(pos+vec3(16,0,16))*inPlace);
	model->draw(Translate(pos+vec3(16,16,0))*inPlace);
	model->draw(Translate(pos+vec3(16,16,16))*inPlace);
	model->draw(Translate(pos+vec3(0,0,-16))*inPlace);
	model->draw(Translate(pos+vec3(0,-16,0))*inPlace);
	model->draw(Translate(pos+vec3(0,-16,-16))*inPlace);
	model->draw(Translate(pos+vec3(-16,0,0))*inPlace);
	model->draw(Translate(pos+vec3(-16,0,-16))*inPlace);
	model->draw(Translate(pos+vec3(-16,-16,0))*inPlace);
	model->draw(Translate(pos+vec3(-16,-16,-16))*inPlace);
}



#endif