#ifndef __KEYBOARD_H__
#define __KEYBOARD_H__

struct KeyboardState {
	bool w,a,s,d,shift,space;
}

void keyPress(unsigned char key, int x, int y)
{
	switch(key) {
		case 033: // Escape Key
		case 'q': case 'Q':
			exit(EXIT_SUCCESS);
			break;

		case 'x': player->pos.x += 0.5; break;
		case 'X': player->pos.x -= 0.5; break;
		case 'y': player->pos.y += 0.5; break;
		case 'Y': player->pos.y -= 0.5; break;
		case 'z': player->pos.z += 0.5; break;
		case 'Z': player->pos.z -= 0.5; break;
		case 'r': eye *= 0.9f; eye.w = 1; break;
		case 'R': eye *= 1.1f; eye.w = 1; break;

		case 'a': player->rot.z += 2; break;
		case 's': player->rot.z -= 2; break;
    }
}


#endif