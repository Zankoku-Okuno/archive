/*
	In order to get this to render in real-time, I needed a peculiar optimization.

	Before, I was building the model's vertices according to a simple quarternary recursive process. This was causing too much lag, even when there was no animation.

	Now, I have translated the recursion into an iteration that builds the model level-by level. It still computes and stores the same number of vertices, but it gives a different order to the vertex list (such that lower-level vertices are earier in the list).
	This simple change reduced the dramatically (where before it took up more than one CPU on my dual-core, it now took up about 20% of one CPU.)

	Furthermore, it made animation conceptually simpler, since now I could go not only cube-by-cube, but also level-by-level (which is great, since the z-coordinates are the ones animated).
	With animation, CPU time hovers about 40% of one CPU. Note, this is all on a 2006 computer.

	A few more optimizations and I'm saving 25% on my CPU cycles. I thought about switching to a cubic interpolation with my newfound cycles, but I don't think it would make the rendering any better aesthetically.

	Nonetheless, this crap could be done on a graphics card. I know theoretically how to do it in CUDA; that's really simple, but I don't really know how to make the shaders do it for me.
*/

#include "main.h"


//----------------------------------------------------------------------------
int main(int argc, char **argv)
{
    glutInit( &argc, argv );
    glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH );
    glutInitWindowSize(512, 512);
    glutCreateWindow("Cantor Carpets");

    glewInit();

    init();

    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeyboard);
    glutReshapeFunc(reshape);
	glutTimerFunc(0, animator, 0);
    glutMainLoop();
    return 0;
}


// Location of parameters in the shaders
GLuint  model_view;  // model-view matrix
GLuint  projection; // projection matrix
void init() {
	// Load shaders and use the resulting shader program
    GLuint program = InitShader( "vshader41.glsl", "fshader41.glsl" );
    glUseProgram(program);
	
    model_view = glGetUniformLocation( program, "model_view" );
    projection = glGetUniformLocation( program, "projection" );
    
    glDisable( GL_DEPTH_TEST );
    glClearColor(0, 0, 0, 1);

    model->init(program);
}

//----------------------------------------------------------------------------
// Rendering

bool restructure = true;

void display(void) {
	glEnable(GL_CULL_FACE);
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

    static vec4 at( 0.0, 0.0, 0.0, 1.0 );
    static vec4 up( 0.0, 1.0, 0.0, 0.0 );

    mat4  mv = LookAt( eye, at, up )*Rotate3D(rot);
    glUniformMatrix4fv( model_view, 1, GL_TRUE, mv );

	mat4 p = isOrtho
			 ? Ortho(-aspect, aspect, -1, 1, zNear, zFar)
			 : Perspective(fovy, aspect, zNear, zFar);
    glUniformMatrix4fv( projection, 1, GL_TRUE, p );

	model->draw(restructure);
	restructure = false;

    glutSwapBuffers();
}

void animator(int value) {
	restructure = true;
	glutPostRedisplay();
	glutTimerFunc(1000/fps, animator, value);
}
//----------------------------------------------------------------------------
//User Input

vec3 rot = vec3(0, 0, 0);
vec4 eye = vec4(10, 10, 10, 1);
bool isOrtho = true;

void keyboard(unsigned char key, int x, int y) {
    switch(key) {
		case 033: // Escape Key
		case 'q': case 'Q':
			exit(EXIT_SUCCESS);
			break;

		case 'x': eye.x += eyeSpeed; break;
		case 'X': eye.x -= eyeSpeed; break;
		case 'y': eye.y += eyeSpeed; break;
		case 'Y': eye.y -= eyeSpeed; break;
		case 'z': eye.z += eyeSpeed; break;
		case 'Z': eye.z -= eyeSpeed; break;
		case 'r': eye += vec4(eyeSpeed, 0); break;
		case 'R': eye -= vec4(eyeSpeed, 0); break;

		case 'a': rot.z += rotSpeed; break;
		case 's': rot.z -= rotSpeed; break;

		case 'o': case 'O': isOrtho = true; break;
		case 'p': case 'P': isOrtho = false; break;
		case ' ': // reset values to their defaults
			eye = vec4(10, 1);
			rot = vec3();
			break;

		case 'f':
			glutFullScreenToggle();
			break;
		case 'l':  // set values to AWESOME!
			eye = vec4(0, 0, 3.24f, 1);
			rot = vec3(100, 0, -70);
			break;
		default:
			std::cout << eye << ", " << rot << std::endl;
			break;
    }
    glutPostRedisplay();
}

void specialKeyboard(int key, int x, int y) {
	switch(key) {
	case GLUT_KEY_UP:
		rot.x += rotSpeed; break;
	case GLUT_KEY_DOWN:
		rot.x -= rotSpeed; break;
	case GLUT_KEY_LEFT:
		rot.y += rotSpeed; break;
	case GLUT_KEY_RIGHT:
		rot.y -= rotSpeed; break;
	}
    glutPostRedisplay();
}

//----------------------------------------------------------------------------
//Booring!

void reshape(int width, int height)
{
    glViewport(0, 0, width, height);
	aspect = (GLfloat)width/(GLfloat)height;
}

