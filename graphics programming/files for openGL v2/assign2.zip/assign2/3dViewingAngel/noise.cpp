#include "noise.h"
#include <iostream>

using namespace std;


unsigned int integral_noise_source(int x, int seed) {
	static unsigned int i32 = 0xffffffff;
	x = (x ^ (x<<19)) & i32;
	x = (x + seed) & i32;
	x = ((x<<11) | (x>>21)) & i32;
	return x*(x*x*59231+7915383) & i32;
}
float noise_source(int x, int seed) {
	return 1.0f - (float)integral_noise_source(x, seed) / 0xffffffff;
}


float Generator::operator[](int x) {
	return noise_source(x, seed);
}

void PerlinGenerator::addHarmonic(float amplitude, float frequency) {
	harmonics.push_back(pair<float, float>(amplitude, frequency));
}

float PerlinGenerator::operator[](float x) {
	float y = 0;
	for (unsigned int i = 0; i < harmonics.size(); ++i) {
		y += harmonics[i].first * interpolator(source, x * harmonics[i].second);
	}
	return y;
}
