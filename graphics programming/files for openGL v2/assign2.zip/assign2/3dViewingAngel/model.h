#ifndef __MODEL_H__
#define __MODEL_H__

#include "Angel.h"
#include "vao.h"
#include "noise.h"
#include "interpolate.h"

/*
 An abstract class that provides the framework for modeling. For any given (class of) model, simply define a subclass.
 The subclass needs to implement rebuild. After creating the model, you will need to call init. To draw the model to the screen, call draw (this also forces a model update.
 If parts of the model are static (not per-frame animated), then it is more efficient to implement this drawing in the build method.
*/
class Model {
protected:
	VAO vao;
	vec4 _color;
	void polygon(const unsigned int n, const vec4 points[]);
	void polygon(const unsigned int n, const vec4 points[], const vec4 color);
	void polygon(const unsigned int n, const vec4 points[], const vec4 colors[]);
	virtual void build(void);
	virtual void rebuild(void) = 0;
public:
	Model(const unsigned int numVertices);
	void init(GLuint program);
	void draw(const bool rebuild=false);
};

/*
 A table with infinitely many legs, but which takes up zero floorspace!
 A jellyfish with infinitely many tendrils, but no sense of smell!
 */
class CantorCarpet : public Model {
	unsigned int levels;
	GLfloat* offset_cloud;
	GLfloat t;
	PerlinGenerator noise;
	vec3* build_level(unsigned int length, const vec3 origins[], const vec2& dimension, unsigned int* cloud_cursor);
	GLfloat dz, thickness;
	void emplace_cube(const vec3& origin, const vec2& dimension,
					  vec3*const last_drawn, unsigned int* last_drawn_cursor, unsigned int* cloud_cursor);
protected:
	void monocube(const vec3& origin, const vec2& dimension);
	void build(void);
	void rebuild(void);
public:
	CantorCarpet(unsigned int levels);
};

class ColorCube : public Model {
	void quad(int a, int b, int c, int d);
	void rebuild(void);
public:
	ColorCube();
};






#endif