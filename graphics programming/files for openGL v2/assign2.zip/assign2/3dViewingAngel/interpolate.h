#include "noise.h"

/*
 A namespace for holding different interpolation algorithms/dimentionality.
*/
namespace interpolate {
	float linear(Generator& source, float x);
	float cosine(Generator& source, float x);
	float cubic(Generator& source, float x);
}