
#ifndef _NOISE_H_
#define _NOISE_H_
#include <utility>
#include <vector>

//Source for all random numbers
float noise_source(int x, int seed);


//TODO an abstract generator class

//Nice syntax and automaic seed management
class Generator {
	int seed;
public:
	Generator(int seed) : seed(seed) {}
	float operator[](int x);
};

//Data structure for harmonic management: also gives a generator access point
class PerlinGenerator {
	Generator source;
	std::vector<std::pair<float, float> > harmonics;
public:
	float (*interpolator)(Generator&, float);
	PerlinGenerator(int seed) : source(seed), interpolator(0) {}
	void addHarmonic(float amplitude, float frequency);
	float operator[](float x);
};

class Perlin2DGenerator {
private:
	class Perlin2DHelper1 {
		float operator[](float y);
	};
public:
	Perlin2DHelper1 operator[](float x);
};



#endif