#include "interpolate.h"
#include <math.h>

float interpolate::linear(Generator& source, float x) {
	int n = (int)floor(x);
	float linear = x - n;
	return linear*source[n+1] + (1-linear)*source[n];
}

float interpolate::cosine(Generator& source, float x) {
	int n = (int)floor(x);
	float f = (1 - cos((x-n)*3.1415927f))/2;
	return source[n]*(1-f) + source[n+1]*f;
}

float interpolate::cubic(Generator& source, float x) {
	int n = (int)floor(x);
	float linear = x - n;
	float squared = linear*linear;
	float cubed = squared * linear;

	float forward_slope = source[n+2] - source[n+1],
		  backward_slope = source[n-1] - source[n],
		  pointyness = source[n+1] - source[n-1];
	float P = forward_slope - backward_slope;
	float Q = backward_slope - P;
	float R = pointyness;
	
	return P*cubed + Q*squared + R*linear + source[n];
}