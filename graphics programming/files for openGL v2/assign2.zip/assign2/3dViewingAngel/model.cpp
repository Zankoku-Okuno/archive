#ifndef __MODEL_CPP__
#define __MODEL_CPP__

#include "model.h"

//---------------------------------------------------
// Cantor Carpet

const GLfloat fill = 0.3f;
const GLfloat one_third = 1.0f/3;
const GLfloat two_thirds = 1 - one_third;

inline unsigned int count_filled_tree(unsigned int levels, unsigned int branches=2) {
	unsigned int out = 0;
	for(unsigned int i = 0, leaves = 1; i < levels; ++i, leaves *= branches)
		out += leaves;
	return out;
}

CantorCarpet::CantorCarpet(unsigned int levels) :
	Model(count_filled_tree(levels, 4)*36),
	levels(levels),
	noise(PerlinGenerator(8088)),
	t(0),
	dz(2.0f/levels), thickness(fill*dz) { //is this correct? (according to standard)
	noise.interpolator = interpolate::cosine;
	noise.addHarmonic(.6f, 1);
	noise.addHarmonic(.3f, 1.5f);
	noise.addHarmonic(.1f, 3.5f);
	offset_cloud = new GLfloat[count_filled_tree(levels, 4)];
}

void CantorCarpet::build(void) {
	vec3* last_drawn = new vec3[1], *temp = NULL; unsigned int length = 1;
	unsigned int last_drawn_cursor = 0, cloud_cursor = 0;

	vec3 origin = vec3(-1, -1, -1); vec2 dimension = vec2(2, dz);
	emplace_cube(origin, vec2(dimension.x, dimension.y*fill), last_drawn, &last_drawn_cursor, &cloud_cursor);
	for(unsigned int i = 1; i != levels; ++i, length *= 4) {
		dimension.x *= one_third;
		temp = build_level(length, last_drawn, dimension, &cloud_cursor);
		delete[] last_drawn; last_drawn = temp; temp = NULL;
	}
	delete[] last_drawn;
}

vec3* CantorCarpet::build_level(unsigned int length, const vec3 origins[], const vec2& dimension, unsigned int* cloud_cursor) {
	vec3* drawn = new vec3[4*length];
	GLfloat partition = 2*dimension.x;
	vec2 offset_dimension = vec2(dimension.x, thickness);
	for(unsigned int i = 0, j = 0; i != length; ++i) {
		vec3 base = origins[i]; base.z += dimension.y;
							 emplace_cube(base, offset_dimension, drawn, &j, cloud_cursor);
		base.x += partition; emplace_cube(base, offset_dimension, drawn, &j, cloud_cursor);
		base.y += partition; emplace_cube(base, offset_dimension, drawn, &j, cloud_cursor);
		base.x -= partition; emplace_cube(base, offset_dimension, drawn, &j, cloud_cursor);
	}
	return drawn;
}

void CantorCarpet::emplace_cube(const vec3& origin, const vec2& dimension,
								vec3*const last_drawn, unsigned int* last_drawn_cursor, unsigned int* cloud_cursor) {
	monocube(origin, vec2(dimension.x, dimension.y*fill));
	last_drawn[(*last_drawn_cursor)++] = origin;
	offset_cloud[(*cloud_cursor)++] = noise[origin.x*53 + origin.y*13 + origin.z*7]*8;
}

void CantorCarpet::rebuild(void) {
	static const bool moving_vertices[36] = {
		false, true,  true,  false, true,  false, //0-5
		false, false, false, false, false, false, //6-11
		false, false, true,  false, true,  true,  //12-17
		false, true,  true,  false, true,  false, //18-23
		true,  true,  true,  true,  true,  true,  //24-29
		true,  true,  false, true,  false, false  //30-35
	};

	vec4 color = vec4(noise[t]/2, 0.7f, 1, 0.7f);
	GLfloat lax_z = -1 + thickness, gap = dz-thickness;
	unsigned int cloud_cursor = 0;

	for(unsigned int level = 0, cubes = 1;
		level != levels;
		++level, cubes *= 4, lax_z += dz)
	{
		for(int cube = 0; cube != cubes; ++cube) {
			register GLfloat offset = lax_z + gap*noise[offset_cloud[cloud_cursor++] + t];
			for(int i = 0; i != 36; ++i) {
				if (moving_vertices[i]) vao.set_z(offset);
				vao.recolor(color);
			}
		}
		color.z *= 0.9f;
		color.w *= 0.9f;
	}
	t += 0.02f;
}

//Draws a single axis-aligned rectangular prism.
void CantorCarpet::monocube(const vec3& o, const vec2& d) {
	static const vec4 vertices[8] = {
		vec4(0, 0, 0, 1),
		vec4(0, 0, 1, 1),
		vec4(0, 1, 0, 1),
		vec4(1, 0, 0, 1),
		vec4(1, 1, 0, 1),
		vec4(1, 0, 1, 1),
		vec4(0, 1, 1, 1),
		vec4(1, 1, 1, 1)
	};
	mat4 transform = Translate(o.x, o.y, o.z)*Scale(d.x, d.x, d.y);
	vec4 p[8]; for(int i = 0; i != 8; ++i) p[i] = transform*vertices[i];
	{ vec4 q1[4] = {p[0], p[1], p[6], p[2]}; polygon(4, q1); }
	{ vec4 q2[4] = {p[0], p[2], p[4], p[3]}; polygon(4, q2); }
	{ vec4 q3[4] = {p[0], p[3], p[5], p[1]}; polygon(4, q3); }
	{ vec4 q4[4] = {p[2], p[6], p[7], p[4]}; polygon(4, q4); }
	{ vec4 q5[4] = {p[7], p[6], p[1], p[5]}; polygon(4, q5); }
	{ vec4 q6[4] = {p[7], p[5], p[3], p[4]}; polygon(4, q6); }
}


//---------------------------------------------------
// Model (base class)

Model::Model(const unsigned int numVertices) : vao(VAO(numVertices)), _color(vec4(1)) {}
void Model::init(GLuint program) {
	vao.init(program);
	build();
}
void Model::build(void) { rebuild(); }
void Model::draw(const bool flag) {
	if (flag) {
		vao.reset();
		rebuild();
		vao.sendToGPU();
	}
	vao.draw();
}

inline
void Model::polygon(const unsigned int n, const vec4 points[]) {
	polygon(n, points, _color);
}
void Model::polygon(const unsigned int n, const vec4 points[], const vec4 color) {
	if (n < 3) return;
	for(unsigned int i = 1; i < n-1; ++i) {
		vao.push(points[0], color);
		vao.push(points[i], color);
		vao.push(points[i+1], color);
	}
}
void Model::polygon(const unsigned int n, const vec4 points[], const vec4 colors[]) {
	if (n < 3) return;
	for(unsigned int i = 1; i < n-1; ++i) {
		vao.push(points[0], colors[0]);
		vao.push(points[i], colors[i]);
		vao.push(points[i+1], colors[i+1]);
	}
}

//---------------------------------------------------
// Color Cube

void ColorCube::quad(int a, int b, int c, int d)
{
	// Vertices of a unit cube centered at origin, sides aligned with axes
	static vec4 vertices[8] = {
		vec4(-0.5, -0.5, -0.5,	1.0),
		vec4(-0.5, -0.5,  0.5,	1.0),
		vec4(-0.5,  0.5, -0.5,	1.0),
		vec4( 0.5, -0.5, -0.5,	1.0),
		vec4( 0.5,  0.5, -0.5,	1.0),
		vec4( 0.5, -0.5,  0.5,	1.0),
		vec4(-0.5,  0.5,  0.5,	1.0),
		vec4( 0.5,  0.5,  0.5,	1.0)
	};
	// RGBA colors
	static vec4 vertex_colors[8] = {
		vec4(1.0, 1.0, 1.0, 1.0),  // white
		vec4(0.0, 1.0, 1.0, 1.0),   // cyan
		vec4(1.0, 0.0, 1.0, 1.0),  // magenta
		vec4(1.0, 1.0, 0.0, 1.0),  // yellow
		vec4(1.0, 0.0, 0.0, 1.0),  // red
		vec4(0.0, 1.0, 0.0, 1.0),  // green
		vec4(0.0, 0.0, 1.0, 1.0),  // blue
		vec4(0.0, 0.0, 0.0, 1.0)  // black
	};
	int n = 4;
	vec4 points[] = {vertices[a], vertices[b], vertices[c], vertices[d]};
	vec4 colors[] = {vertex_colors[a], vertex_colors[b], vertex_colors[c], vertex_colors[d]};
	polygon(n, points, colors);
}

ColorCube::ColorCube() : Model(36) {}
void ColorCube::rebuild() {
	quad(0, 1, 6, 2);
	quad(0, 2, 4, 3);
	quad(0, 3, 5, 1);
	quad(2, 6, 7, 4);
	quad(7, 6, 1, 5);
	quad(7, 5, 3, 4);
}


#endif
