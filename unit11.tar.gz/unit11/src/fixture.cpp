#include <vector>
#include <stdexcept>
#include "unit11/dialect.h"
#include "unit11/registry.hpp"
#include "unit11/fixture.hpp"
#include "unit11/diagnose.hpp"
using namespace std;
using namespace unit11;


Fixture& unit11::getFixture() {
	static Fixture value{__FILE__, __LINE__ - 1};
	return value;
  }

void Fixture::set_up_impl() {
	pass; //TODO raise a NotImplementedError equivalent
}
void Fixture::tear_down_impl() {
	pass; //TODO raise a NotImplementedError equivalent
}


void Fixture::fail(basic_Diagnostic* diagnose) {
	_status = diagnose;
	Registry() += this;
}
const basic_Diagnostic& Fixture::diagnose() const {
	if (_status == nil)
		throw runtime_error("Attempted to diagnose a fixture that has no problem: not implemented.");
	return *_status;
}

bool Fixture::set_up() {
	if (_status != nil) return false;
	try {
		set_up_impl();
		return true;
	}
	catch (...) {
		fail(handle_error(me));
		return false;
	}
}
bool Fixture::tear_down() {
	if (_status != nil) return false;
	try {
		tear_down_impl();
		return true;
	}
	catch (...) {
		fail(handle_error(me));
		return false;
	}
}

Fixture::Fixture(string file, int line)
 : LocationMixin(file, line)
 , _status(nil)
{}
Fixture::~Fixture() {
	if (_status != nil)
		delete _status;
}


