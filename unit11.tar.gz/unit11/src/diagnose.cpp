#include <string>
#include <typeinfo>
#include "unit11/diagnose.hpp"
#include "unit11/dialect.h"

namespace unit11 { static std::string unmangle(const std::string); }

using namespace std;
using namespace unit11;

/* ============== *
 * Location Mixin *
 * ============== */
LocationMixin::LocationMixin(string file, int line)
 : _file{file}
 , _line{line}
{}
/*LocationMixin::LocationMixin(string&& file, int line)
 : _file{file}
 , _line{line}
{}*/
const string& LocationMixin::file() const { return _file; }
int LocationMixin::line() const { return _line; }
void LocationMixin::location(string file, int line) {
	_file = file;
	_line = line;
}

/* ================ *
 * Basic Diagnostic *
 * ================ */
basic_Diagnostic::basic_Diagnostic(CaseStatus status, string&& file, int line)
 : LocationMixin(file, line)
 , _status{status}
{}
CaseStatus basic_Diagnostic::status() const {
	return _status;
}

/* =================== *
 * Basic Check Failure *
 * =================== */
basic_CheckFailureDiagnostic::basic_CheckFailureDiagnostic(string&& expr, std::string&& file, int&& line)
 : basic_Diagnostic(CaseStatus::Failure, move(file), line)
 , _expression(expr)
{}
const string& basic_CheckFailureDiagnostic::name() const {
	static const string value = "test failure";
	return value;
}
const string& basic_CheckFailureDiagnostic::what() const {
	return _expression;
}

/* ==================== *
 * Unhandled Exceptions *
 * ==================== */
UnhandledExceptionDiagnostic::UnhandledExceptionDiagnostic(const std::exception& ex)
	 : basic_Diagnostic(CaseStatus::Error)
	 , _name{unmangle(typeid(ex).name())}
	 , _what{ex.what()}
	{}

const string& UnhandledExceptionDiagnostic::name() const {
	return _name;
}
const string& UnhandledExceptionDiagnostic::what() const {
	return _what;
}
const string& UnhandledExceptionDiagnostic::detail() const {
	static const string value = "no details available";
	/*TODO: make this print a stack trace
	http://stackoverflow.com/questions/4636456/stack-trace-for-c-using-gcc?lq=1
	*/
	return value;
}


UnknownUnhandledThrowDiagnostic::UnknownUnhandledThrowDiagnostic()
 : basic_Diagnostic(CaseStatus::Error)
{}

const string& UnknownUnhandledThrowDiagnostic::name() const {
	static const string value = "unknown exception type";
	return value;
}
const string& UnknownUnhandledThrowDiagnostic::what() const {
	static const string value = "unknown";
	return value;
}
const string& UnknownUnhandledThrowDiagnostic::detail() const {
	static const string value = "no details available";
	/*TODO: make this print a stack trace
	http://stackoverflow.com/questions/4636456/stack-trace-for-c-using-gcc?lq=1
	*/
	return value;
}

/*
 * Exception dispatcher that guards test cases.
 */
basic_Diagnostic* unit11::handle_error(const LocationMixin& test) {
	basic_Diagnostic* it;
	try { throw; }
	//TODO catch the timeout exception specially
	//TODO figure out what to do about bad_alloc (skip the rest of the tests and print what we've got)
	catch (exception& ex) {
		it = new UnhandledExceptionDiagnostic{ex};
	}
	catch (exception* ex) {
		it = new UnhandledExceptionDiagnostic{*ex};
	}
	catch (...) {
		it = new UnknownUnhandledThrowDiagnostic{};
	}
	it->location(test.file(), test.line());
	return it;
}

/* ====================== *
 * Compilation Unit-local *
 * ====================== */

/*
 * Name unmangler
 */
static string unit11::unmangle(const string mangled) {
	return mangled; //TODO
}

