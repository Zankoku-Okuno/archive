#include <string>
#include "unit11/dialect.h"
#include "unit11/suite.hpp"
using namespace std;
using namespace unit11;


const Suite& unit11::getSuite() {
	static const Suite value{"default"};
	return value;
  }

Suite::Suite(string name) : _name{name} {}

const string& Suite::name() const {
	return _name;//TODO raise a NotImplementedError equivalent
}




