#include <string>
#include <vector>
#include <exception>
#include <stdexcept>
#include <csignal>
#include "unit11/dialect.h"
#include "unit11/test-case.hpp"
#include "unit11/registry.hpp"
#include "unit11/fixture.hpp"
#include "unit11/diagnose.hpp"

void abort_handler(int) { throw unit11::SigAbrt(); }
void fpe_handler(int) { throw unit11::SigFpe(); }
void ill_handler(int) { throw unit11::SigIll(); }
void segfault_handler(int) { throw unit11::SigSegV(); }

using namespace std;
using namespace unit11;

/* ===================== *
 * During Test Execution *
 * ===================== */

void basic_Case::skip() {
	_status.pure = CaseStatus::Skipped;
}

void basic_Case::run() {
	/*fixtures have their own diagnostics: if a fixture fails, it's not right to blame the test cases that use it, just skip affected test cases*/
	if (!_fixture.set_up())
		return skip();
	auto old_abrt_handler = signal(SIGABRT, abort_handler);
	auto old_fpe_handler = signal(SIGFPE, fpe_handler);
	auto old_ill_handler = signal(SIGILL, ill_handler);
	auto old_segv_handler = signal(SIGSEGV, segfault_handler);
	//TODO check that they are not SIG_ERR
	try {
		//TODO start up the thread that triggers timeout
		_status.pure = CaseStatus::Running;
		my run_test();
		//TODO reset thread that triggers timeout
		if (!_detected_problem) _status.pure = CaseStatus::Success;
	}
	catch(...) {
		fail(handle_error(me));
	}
	_fixture.tear_down();
	signal(SIGABRT, old_abrt_handler);
	signal(SIGFPE, old_fpe_handler);
	signal(SIGILL, old_ill_handler);
	signal(SIGABRT, old_segv_handler);
}

void basic_Case::fail(basic_Diagnostic* problem) {
	_detected_problem = true;
	_status.diagnostic = problem;
	problem = nil;
}

/* ==================== *
 * After Test Execution *
 * ==================== */

bool basic_Case::has_problem() const {
	return _detected_problem
		|| _status.pure == CaseStatus::Outstanding
		|| _status.pure == CaseStatus::Running;
}

CaseStatus basic_Case::status() const {
	return _detected_problem ? _status.diagnostic->status() : _status.pure;
}

const basic_Diagnostic& basic_Case::diagnose() const {
	if (!_detected_problem)
		throw runtime_error("Attempted to diagnose a test case that has no true problem: not implemented."); //TODO
	return *_status.diagnostic;
}

/* =========== *
 * Boilerplate *
 * =========== */

basic_Case::basic_Case(const Suite& s, Fixture& f, string&& file, int line)
	: LocationMixin(move(file), line)
	, _suite(s)
	, _fixture(f)
	, _detected_problem{false}
{
	_status.pure = CaseStatus::Outstanding;
	Registry() += this;
}
basic_Case::~basic_Case() {
	if( _detected_problem
	 && _status.diagnostic != nil)
		delete _status.diagnostic;
}

const Suite& basic_Case::suite() const {
	return _suite;
}
const Fixture& basic_Case::fixture() const {
	return _fixture;
}

