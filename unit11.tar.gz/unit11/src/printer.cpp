#include <vector>
#include <string>
#include <iostream>
#include "unit11/dialect.h"
#include "unit11/registry.hpp"
#include "unit11/fixture.hpp"
#include "unit11/test-case.hpp"
#include "unit11/diagnose.hpp"
#include "unit11/printer.hpp"

using namespace std;
using namespace unit11;


static string prefix(CaseStatus status) {
	switch (status) {
		case CaseStatus::Outstanding:
			return "? ";
		case CaseStatus::Skipped:
			return "- ";
		case CaseStatus::Running:
			return "* ";
		case CaseStatus::Success:
			return ". ";
		case CaseStatus::Failure:
			return "F ";
		case CaseStatus::Error:
			return "E ";
	}
}

void default_printer::print(const basic_Case& test) {
	clog << prefix(test.status()) << test.description() << endl;
}

static void print_item(const basic_Case& test, const string& status) {
	const basic_Diagnostic& diagnostic = test.diagnose();
	clog << "================================================================================" << endl
		 << status << ": " << test.description() << endl
		 << diagnostic.file() << ":" << diagnostic.line() << endl
		 << "--------------------------------------------------------------------------------" << endl
		 << diagnostic.name() << ": " << diagnostic.what() << endl
		 << diagnostic.detail() << endl;
}
static void print_item(const Fixture& fixture, const string& status) {
	vector<const basic_Case*> affected{};
	for (auto test : Registry())
		if (&test->fixture() == &fixture && test->status() == CaseStatus::Skipped)
			affected.push_back(test);

	const basic_Diagnostic& diagnostic = fixture.diagnose();
	clog << "================================================================================" << endl
		 << status << ": " /*<< test.description() << endl*/ //TODO what do I write here?
		 << diagnostic.file() << ":" << diagnostic.line() << endl
		 << "--------------------------------------------------------------------------------" << endl
		 << diagnostic.name() << ": " << diagnostic.what() << endl
		 << diagnostic.detail() << endl
		 << "--------------------------------------------------------------------------------" << endl;
	if (affected.size() == 0)
		clog << "Affected no tests." << endl;
	else {
		clog << "Affected these tests:" << endl;
		for (auto test : affected)
			clog << "    " << test->description()
				 << " (" << test->file() << ":" << test->line() << ")" << endl;
	}
}

string plural_test(unsigned int num) {
	return num == 1 ? "test" : "tests";
}

void default_printer::print(const RegistryType& registry) {
	for (auto test : registry)
		if (test->status() == CaseStatus::Failure)
			print_item(*test, "FAILURE");
	for (auto test : registry)
		if (test->status() == CaseStatus::Error)
			print_item(*test, "ERROR");
	for (auto fixture : registry.failed_fixtures())
		print_item(*fixture, "BAD FIXTURE");
	unsigned int counts[6]{0, 0, 0, 0, 0, 0};
	unsigned int it;
	for (auto test : registry)
		++counts[(int)test->status()];
	clog << "================================================================================" << endl;
	if (it = registry.size() - (counts[(int)CaseStatus::Success] + counts[(int)CaseStatus::Skipped])) {
		clog << "FAILURES: " << it << " " << plural_test(it) << " failed." << endl;
		if (it = registry.failed_fixtures().size())
			clog << "          " << it << " " << (it == 1 ? "fixture":"fixtures") << " failed." << endl;
	}
	else
		clog << "OK. All tests pass." << endl;
		
	clog << "--------------------------------------------------------------------------------" << endl
		 << "Summary: " << registry.size() << " " << plural_test(registry.size()) << " run in ???s." << endl
		 << "    " << (it = counts[(int)CaseStatus::Success]) << " success" << (it == 1 ? "":"es") << endl;
	if (it = counts[(int)CaseStatus::Failure])
		 clog << "    " << it << " failure" << (it == 1 ? "":"s") << endl;
	if (it = counts[(int)CaseStatus::Error])
		 clog << "    " << it << " error" << (it == 1 ? "":"s") << endl;
	if (it = counts[(int)CaseStatus::Outstanding] + counts[(int)CaseStatus::Running])
		clog << "    " << it << " " << plural_test(it) << " unfinished" << endl;
	if (it = counts[(int)CaseStatus::Skipped])
		clog << "    " << it << " " << plural_test(it) << " skipped" << endl;
	clog << "================================================================================" << endl;
}