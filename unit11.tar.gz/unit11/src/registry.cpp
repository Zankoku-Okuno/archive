#include <vector>
#include "unit11/dialect.h"
#include "unit11/registry.hpp"
#include "unit11/test-case.hpp"
#include "unit11/diagnose.hpp"
#include "unit11/printer.hpp"

using namespace std;
using namespace unit11;


bool unit11::default_selector(const basic_Case&) {
	return true;
}

RegistryType& unit11::Registry() {
	static RegistryType value{};
	return value;
}


RegistryType& RegistryType::operator+=(basic_Case* that) {
	my push_back(that);
	return me;
}
RegistryType& RegistryType::operator+=(const Fixture* that) {
	_failed_fixtures.push_back(that);
	return me;
}

void RegistryType::run_tests(RegistryType::TestSelector select) {
	for(auto test : me) {
		if (select(*test))
			test->run();
		else
			test->skip();
		if (_printer != nil) _printer->print(*test);
	}
}

RegistryType& RegistryType::set(basic_Printer* printer) { _printer = printer; }

void RegistryType::main(basic_Printer* printer, TestSelector selector) {
	set(printer);
	run_tests(selector);
	if (_printer != nil) _printer->print(me);
}
void RegistryType::main(TestSelector selector) {
	auto printer = new default_printer{};
	try {
		main(printer, selector);
		delete printer;
	}
	catch(...) {
		delete printer;
		throw;
	}
}
int RegistryType::num_failures() const {
	int value = my failed_fixtures().size();
	for (auto test : me)
		if (test->status() == CaseStatus::Failure || test->status() == CaseStatus::Error)
			++value;
	return value;
}