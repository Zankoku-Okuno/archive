#include <string>
#include "unit11/dialect.h"
#include "unit11/failures.hpp"
using namespace std;
using namespace unit11;


CheckTrueFailureDiagnostic::CheckTrueFailureDiagnostic(string&& expr, std::string&& file, int&& line)
 : basic_CheckFailureDiagnostic(move(expr), move(file), move(line))
{} //FIXME after we get inheriting constructors

const string& CheckTrueFailureDiagnostic::detail() const {
	static const string value = "'false' is not 'true'";
	return value;
}