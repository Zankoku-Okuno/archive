#include <iostream>
#include <string>
#include <vector>
#include <stdexcept>
#include <typeinfo>
#include <csignal>
#include "unit11.h"

#include "unit11/dialect.h"

using namespace std;

static int assert_counter = 0, failure_counter = 0;
#define assert(expr) STATEMENT(\
  ++assert_counter;\
  if (!(expr)) {\
	++failure_counter;\
	cout << " ==== Assertion Error: " << __FILE__ << ':' << __LINE__ << " ====" << endl;\
  }\
)

/* =========== *
 * Environment *
 * =========== */

static bool fixture_ran = false;

class MyCaseType : public unit11::basic_Case {
  friend void run_all_bootstrap_tests();
public:
  MyCaseType() : unit11::basic_Case(getSuite(),getFixture(), __FILE__, __LINE__) {}
protected:
  void run_test();
  const string& description() const {
  	static const string value = "Goodbyte, cruel world!";
  	return value;
  }
} MyCase{};
void MyCaseType::run_test() {}


/* Here, we have the nice syntax at work. */
SUITE(fnord)
{  
  FIXTURE {
	  bool been_set_up = false;
    bool been_torn_down = false;
  }

  SETUP {
    fixture::been_set_up = true;
  }
  TEARDOWN {
    fixture::been_torn_down = true;
  }
  
  NAMED_FACT(SuiteCase, "Help! I'm trapped in a suitecase!") {
    fixture_ran = true;
  }
}

NAMED_FACT(FailCase, "Failures occur.") {
  CHECK(false);
}

NAMED_FACT(ExceptionCase, "Just keep trying me.") {
  throw runtime_error{"BANG! BANG!"};
}
NAMED_FACT(ThrowPointer, "It throws dumb stuff.") {
  throw new exception();
}
NAMED_FACT(ThrowCase, "It throws weird stuff.") {
  throw 1;
}

SUITE(nogo) {
  FIXTURE {
    bool teardown_run = false;
  }
  SETUP {
    throw runtime_error("not implemented");
  }
  TEARDOWN {
    fixture::teardown_run = true;
  }
  NAMED_FACT(FixFail1, "Either it's me...") {}
  NAMED_FACT(FixFail2, "...or it's me.") {}
}
SUITE(notit) {
  FIXTURE {
    bool setup_run = false;
  }
  SETUP {
    fixture::setup_run = true;
  }
  TEARDOWN {
    throw runtime_error("not implemented");
  }
  NAMED_FACT(FixFail3, "Could be me...") { fixture::setup_run = false; }
  NAMED_FACT(FixFail4, "...or could be me.") { fixture::setup_run = false; }
}


NAMED_FACT(SegTest, "Segfaults are caught.") {
  raise(SIGSEGV);
}

/* ====== *
 * Runner *
 * ====== */


void run_all_bootstrap_tests() {
  assert(unit11::Registry().size() == 11);
  assert(MyCase.description() == "Goodbyte, cruel world!");
  assert(MyCase.suite().name() == "default");
  assert(FailCase.suite().name() == "default");
  assert(ExceptionCase.suite().name() == "default");
  assert(ThrowCase.suite().name() == "default");
  assert(unit11_suite_fnord::SuiteCase.suite().name() == "fnord");
  assert(MyCase.status() == unit11::CaseStatus::Outstanding);
  assert(FailCase.status() == unit11::CaseStatus::Outstanding);
  assert(ExceptionCase.status() == unit11::CaseStatus::Outstanding);
  assert(ThrowPointer.status() == unit11::CaseStatus::Outstanding);
  assert(ThrowCase.status() == unit11::CaseStatus::Outstanding);
  assert(SegTest.status() == unit11::CaseStatus::Outstanding);
  assert(unit11_suite_fnord::SuiteCase.status() == unit11::CaseStatus::Outstanding);
  assert(unit11_suite_nogo::FixFail1.status() == unit11::CaseStatus::Outstanding);
  assert(unit11_suite_nogo::FixFail2.status() == unit11::CaseStatus::Outstanding);
  assert(unit11_suite_notit::FixFail3.status() == unit11::CaseStatus::Outstanding);
  assert(unit11_suite_notit::FixFail4.status() == unit11::CaseStatus::Outstanding);
  
  
  MyCase.skip();
  assert(!MyCase.has_problem());
  assert(MyCase.status() == unit11::CaseStatus::Skipped);
  FailCase.run();
  assert(FailCase.has_problem());
  assert(FailCase.status() == unit11::CaseStatus::Failure);
  ExceptionCase.run();
  assert(ExceptionCase.has_problem());
  assert(ExceptionCase.status() == unit11::CaseStatus::Error);
  ThrowCase.run();
  assert(ThrowCase.has_problem());
  assert(ThrowCase.status() == unit11::CaseStatus::Error);
  ThrowPointer.run();
  assert(ThrowPointer.has_problem());
  assert(ThrowPointer.status() == unit11::CaseStatus::Error);
  unit11_suite_fnord::SuiteCase.run();
  assert(!unit11_suite_fnord::SuiteCase.has_problem());
  assert(unit11_suite_fnord::SuiteCase.status() == unit11::CaseStatus::Success);
  assert(fixture_ran);
  assert(unit11_suite_fnord::fixture::been_set_up);
  assert(unit11_suite_fnord::fixture::been_torn_down);
  SegTest.run();
  assert(SegTest.has_problem());
  assert(SegTest.status() == unit11::CaseStatus::Error);
  unit11_suite_nogo::FixFail1.run(); unit11_suite_nogo::FixFail2.run();
  assert(unit11_suite_nogo::FixFail1.status() == unit11::CaseStatus::Skipped);
  assert(unit11_suite_nogo::FixFail2.status() == unit11::CaseStatus::Skipped);
  assert(!unit11_suite_nogo::fixture::teardown_run);
  unit11_suite_notit::FixFail3.run(); unit11_suite_notit::FixFail4.run();
  assert(unit11_suite_notit::FixFail3.status() == unit11::CaseStatus::Success);
  assert(unit11_suite_notit::FixFail4.status() == unit11::CaseStatus::Skipped);
  assert(!unit11_suite_notit::fixture::setup_run);

  

  
  
  //TODO test that throws an exception pointer
  //TODO test that causes a segfault
  //TODO cause a bad_alloc?
}

int main(int argc, char** argv) {
  cout << "========== BEGIN TESTING ==========" << endl;
  run_all_bootstrap_tests();
  //unit11::default_printer{}.print(unit11::Registry());
  cout << "=========== END TESTING ===========" << endl;
  cout << "Results: ";
  if (failure_counter == 0) cout << "OK (" << assert_counter << " tests run)";
  else cout << "FAILURE (" << failure_counter << " out of " << assert_counter << ")";
  cout << endl;
  cout << "=========== END REPORT ============" << endl;
  return failure_counter;
}
