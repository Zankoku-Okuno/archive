#include <iostream>
#include <string>
#include <tuple>
#include "../include/dialect.h"

#define do_something STATEMENT(a = (++b, 8))


using namespace std;

class Me {
  friend ostream& operator<<(ostream&, const Me&);
  int _i;
public:
  Me(int i=137) : _i(i) {}
} singleton{42};

ostream& operator<<(ostream& out, const Me& self) {
  return out << self._i;
}

template<typename... Args>
class Callable {
protected:
  tuple<Args...> data;
public:
  Callable(Args... args) : data{args...} {}
  virtual bool run() const =0;
};

class Call : public Callable<int, int, int> {
public:
  Call(int a, int b, int c) : Callable{a,b,c} {}
  bool run() const {
    return get<0>(data) + get<1>(data) < get<2>(data);
  }
};


template<typename... Args>
constexpr int tuple_length(const tuple<Args...>& t) {
	return sizeof...(Args);
}



struct V {
	virtual void exec() = 0;
};
struct C : public V {
	virtual void exec() { cout << "hi" << endl; }
	V& factory() { 
		return *this;
	}
};

int main(int argc, char** argv) {
/*	cout << Call(3,4,5).run() << ' ' << Call(1,3,5).run() << endl;
	cout << tuple_length(make_tuple(1,2,3)) << endl;
	int a, b;
	do_something;
	//a = 8, ++b;
	cout << a << ' ' << b << endl;
	cout << make_tuple(1,2,3,5) << endl;
	Call a{1,2,3}; Call* ap = &a;
	cout << ap->run() << endl;
*/	int a = 13, b = 7;
	cout << a << ' ' << b << endl;
	a ^= b;
	cout << a << ' ' << b << endl;
	b ^= a;
	cout << a << ' ' << b << endl;
	a ^= b;
	cout << a << ' ' << b << endl;
	//given a1, b1
	// a2 = a1 ^ b1
	// b2 = b1 ^ a2 = b1 ^ a1 ^ b1 = b1^b1 ^ a1 = 0 ^ a1 = a1
	// a3 = a2 ^ b2 = (a1 ^ b1) ^ (b1 ^ a1 ^ b1) = a1^a1 ^ b1 ^ b1^b1 = 0 ^ b1 ^ 0 = b1
	//done

	char s1[6] = "hello";
	string s2{s1};
	s1[1] = 'a';
	cout << s1 << " -> " << s2 << endl;

	V& v = C{}.factory();
	v.exec();

}
