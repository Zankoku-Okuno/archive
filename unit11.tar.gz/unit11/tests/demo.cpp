/*
 * On my system (gcc4.6.3), the following command successfully ran this test:
 *
 * g++ -std=c++0x tests/demo.cpp -lunit11 && ./a.out && rm a.out
 */

#include <unit11.h>

UNIT11_MAIN

FACT("Hello, world!") {
	CHECK(2 + 2 == 4);
}
FACT("Goodbyte, cruel world!") {
	CHECK(2 + 2 == 5);
}
