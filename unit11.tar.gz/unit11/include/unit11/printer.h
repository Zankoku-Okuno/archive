#ifndef __PRINTER_H__
#define __PRINTER_H__
namespace unit11 {


class basic_Printer;

class default_printer;

}
#endif