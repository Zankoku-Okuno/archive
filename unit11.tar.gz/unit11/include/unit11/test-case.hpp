#ifndef __TEST_CASE_HPP__
#define __TEST_CASE_HPP__
#include "unit11/test-case.h"
#include "unit11/suite.h"
#include "unit11/fixture.h"
#include "unit11/diagnose.h"
namespace unit11 {

/* 
 * Abstract base class from which all test cases should derive.
 * Provides implementations to determine suite and fixture, as well as run and report.
 */
class basic_Case : public LocationMixin {
public:
	/* ====== *
	 * Memory *
	 * ====== */
	/* Call to set up suite & fixture and automatically register. */
	basic_Case(const Suite& s, Fixture& f, std::string&& file, int line);
	virtual ~basic_Case();
	/* Explicity state the protocol for copy and move. */
	basic_Case& operator=(basic_Case&) = delete;
	basic_Case& operator=(basic_Case&&) = delete;
	
	/* ========== *
	 * Properties
	 * ========== */
	const Suite& suite() const;
	const Fixture& fixture() const;
	/* Override to provide a description of what this test case does. */
	virtual const std::string& description() const = 0;
	CaseStatus status() const;

	/* ================= *
	 * Framework Methods *
	 * ================= */
	/* Runs the test, along with al set up, teardown and safety code. */
	void run();
	/* Marks the test as skipped. */
	void skip();
	/* Return whether there was a problem (the test was not properly run, the test failed, an error occured during the test) */
	bool has_problem() const;
	/* Get a diagnosis of the problem that occurred. If there was no problem with the test, this is undefined. */
	const basic_Diagnostic& diagnose() const;
protected:
	/* Override to provide test code. */
	virtual void run_test() = 0;
	
	/* Call from run_test to signal an assertion failure. */
	void fail(basic_Diagnostic*);
private:
	/* ===================== *
	 * Implementation Detail *
	 * ===================== */
	const Suite& _suite;
	Fixture& _fixture;
	bool _detected_problem;
	union {
		CaseStatus pure; 				//iff !_detected_problem
		basic_Diagnostic* diagnostic;	//iff  _detected_problem
	} _status;
};


}
#endif