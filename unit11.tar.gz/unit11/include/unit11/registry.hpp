#ifndef __REGISTRY_HPP__
#define __REGISTRY_HPP__
#include "unit11/registry.h"
#include "unit11/fixture.h"
#include "unit11/test-case.h"
#include "unit11/printer.hpp"
namespace unit11 {

bool default_selector(const basic_Case&);

/*
 * Singleton type that accumuates test cases.
 */
class RegistryType : private std::vector<basic_Case*> {
	typedef std::vector<basic_Case*> inherited;
	typedef bool (*TestSelector)(const basic_Case&);
public:
	/* ====== *
	 * Memory *
	 * ====== */
	RegistryType() = default;
	~RegistryType() = default;
	RegistryType(const RegistryType&) = delete;
	RegistryType(RegistryType&&) = delete;
	RegistryType& operator=(const RegistryType&) = delete;
	RegistryType& operator=(RegistryType&&) = delete;
	
	/* ============ *
	 * Passthroughs *
	 * ============ */
	size_t size() const noexcept { return inherited::size(); }
	inherited::iterator begin() { return inherited::begin(); }
	inherited::iterator end() { return inherited::end(); }
	inherited::const_iterator begin() const { return inherited::cbegin(); }
	inherited::const_iterator end() const { return inherited::cend(); }
	const std::vector<const Fixture*>& failed_fixtures() const { return _failed_fixtures; }

	/* ================= *
	 * New Functionality *
	 * ================= */
	/* Register a test case. */
	RegistryType& operator+=(basic_Case*);
	/* Signal that a fixture has failed. */
	RegistryType& operator+=(const Fixture*);
	/* Ready a printer */
	RegistryType& set(basic_Printer*);
	/* Simple ways to run tests */
	void run_tests(TestSelector=default_selector);
	void main(basic_Printer*, TestSelector=default_selector);
	void main(TestSelector=default_selector);
	/* ========== *
	 * Properties *
	 * ========== */
	int num_failures() const;
private:
	std::vector<const Fixture*> _failed_fixtures;
	basic_Printer* _printer;
};




}
#endif