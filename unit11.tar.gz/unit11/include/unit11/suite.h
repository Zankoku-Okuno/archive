#ifndef __SUITE_H__
#define __SUITE_H__
namespace unit11 {


class Suite;


}
#endif