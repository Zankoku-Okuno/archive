#ifndef __SUITE_HPP__
#define __SUITE_HPP__
#include "unit11/suite.h"
namespace unit11 {


const Suite& getSuite();

/* Base class for all suites.
   Suites currently only provide a name, which could be used usefully to filter tests.
*/
class Suite {
public:
	/* Create a suite with the passed name. */
	Suite(std::string);
	/* Return the name of the Suite. */
	const std::string& name() const;
	//TODO some sort of Suite order, maybe?
private:
	const std::string _name;
};


}
#endif