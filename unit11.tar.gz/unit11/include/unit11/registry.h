#ifndef __REGISTRY_H__
#define __REGISTRY_H__
namespace unit11 {

/* Singleton class that contains lists of tests. */
class RegistryType;
/* Singleton access */
RegistryType& Registry();

/* Singleton class that partitions tests into run/skip sets.
 A Selector is meant to be overridable by the user. A default is given in
 ???. TODO
*/
class SelectorType;
/* Singleton accessor. */
SelectorType& Selector();

}
#endif