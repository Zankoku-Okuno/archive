/* ======= *
 * Helpers *
 * ======= */

#define HERE __FILE__, __LINE__

#define NAMED_SUITE(name)   MERGE(unit11_suite_,name)
#define UNIQUE_FIXTURE      AnonFixture
#define UNIQUE_CASE         MERGE(AnonCase, __LINE__)

/* ====== *
 * Suites *
 * ====== */

#define GROUP namespace NAMED_SUITE(__LINE__)

#define SUITE(name)                           \
namespace NAMED_SUITE(name) {                 \
  const unit11::Suite& getSuite() {           \
    static const unit11::Suite value{#name};  \
    return value;                             \
  }                                           \
}                                             \
namespace NAMED_SUITE(name)

/* ======== *
 * Fixtures *
 * ======== */

//TODO A_FIXTURE defines a group and a fixture at once

#define FIXTURE                                   \
class UNIQUE_FIXTURE : public unit11::Fixture {   \
public:                                           \
  UNIQUE_FIXTURE(std::string file, int line)           \
   : Fixture(file, line) {}                       \
  /*override*/ void set_up_impl();                \
  /*override*/ void tear_down_impl();             \
};                                                \
unit11::Fixture& getFixture() {                   \
  static UNIQUE_FIXTURE value{HERE};              \
  return value;                                   \
}                                                 \
namespace fixture

#define SETUP    void UNIQUE_FIXTURE::set_up_impl()
#define TEARDOWN void UNIQUE_FIXTURE::tear_down_impl()

/* ===== *
 * Facts *
 * ===== */

#define NAMED_FACT(name, desc_str)                     \
class MERGE(name, Type) : public unit11::basic_Case {  \
public:                                                \
  MERGE(name, Type)()                                  \
   : unit11::basic_Case(getSuite(),getFixture(), HERE) \
  {}                                                   \
protected:                                             \
  void run_test();                                     \
  const std::string& description() const {                  \
    static const std::string out = desc_str;                \
    return out;                                        \
  }                                                    \
} name{};                                              \
void MERGE(name, Type)::run_test()


#define FACT(desc_str)  NAMED_FACT(UNIQUE_CASE, desc_str)

/* ========== *
 * Assertions *
 * ========== */

#define CHECK(expr) STATEMENT(                                   \
  if (expr) pass;                                                \
  else {                                                         \
    fail(new unit11::CheckTrueFailureDiagnostic{#expr, HERE});   \
    return;                                                      \
  }                                                              \
)

/* ==== *
 * Main *
 * ==== */

#define UNIT11_MAIN                   \
int main(int argc, char** argv) {     \
  unit11::Registry().main();         \
  return unit11::Registry().num_failures();   \
}
