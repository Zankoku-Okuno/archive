#ifndef __FIXTURE_HPP__
#define __FIXTURE_HPP__
#include "unit11/fixture.h"
#include "unit11/diagnose.h"
namespace unit11 {


/* Return the default fixture.
 Can be overridden in other namespaces to provide non-default Fixtures.
*/
Fixture& getFixture();

/* Abstract base class for all fixtures.
   Fixtures provide reusable set up and tear down for test cases.
*/
class Fixture : public LocationMixin {
public:
	/* ====== *
	 * Memory *
	 * ====== */
	Fixture(std::string, int);
	~Fixture();
	/* ========== *
	 * Properties *
	 * ========== */
	const basic_Diagnostic& diagnose() const;
	/* ================= *
	 * Framework Methods *
	 * ================= */
	/* User-provided code initializes global variables. */
	virtual void set_up_impl();
	/* User-provided code de-initializes global variables symmetrically to set_up. */
	virtual void tear_down_impl();


	void fail(basic_Diagnostic*);
	/* These are called to do error handling during setup/teardown. */
	bool set_up();
	bool tear_down();
private:
	basic_Diagnostic* _status/* = nil*/; //TODO when implemented
};


}
#endif