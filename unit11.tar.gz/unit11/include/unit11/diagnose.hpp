#ifndef __DIAGNOSE_HPP__
#define __DIAGNOSE_HPP__
#include "unit11/diagnose.h"
namespace unit11 {

/*
 * Lightweight test case status flags.
 */
enum class CaseStatus { Outstanding, Skipped, Running, Success, Failure, Error };


/*
 * Abstract base class for all kinds of diagnostic detail.
 */
class basic_Diagnostic : public LocationMixin {
public:
	/* ====== *
	 * Memory *
	 * ====== */
	/* All diagnostics must record information on where the error occurred. */
	basic_Diagnostic(CaseStatus, std::string&& file="unknown file", int line=~0);
	//TODO explicity handle memory semantics

	/* ========== *
	 * Properties *
	 * ========== */
	/* Information describing the problem. */
	CaseStatus status() const;
	virtual const std::string& name() const = 0;
	virtual const std::string& what() const = 0;
	virtual const std::string& detail() const = 0;
private:
	CaseStatus _status; //TODO when implemented
};

/*
 * Abstract base class for all diagnostics caused by assertion check failures.
 */
class basic_CheckFailureDiagnostic : public basic_Diagnostic {
public:
	/* ====== *
	 * Memory *
	 * ====== */
	/* All check failures must have an expression. */
	basic_CheckFailureDiagnostic(std::string&& expr, std::string&& file, int&& line);

	/* ========== *
	 * Properties *
	 * ========== */
	/*override*/ const std::string& name() const;
	/*override*/ const std::string& what() const;
	virtual const std::string& detail() const = 0;
private:
	/* ===================== *
	 * Implementation Detail *
	 * ===================== */
	const std::string _expression;
};

/*
 * Failure diagnostics caused by an unhandled exception.
 */
class UnhandledExceptionDiagnostic : public basic_Diagnostic {
public:
	/* ====== *
	 * Memory *
	 * ====== */
	UnhandledExceptionDiagnostic(const std::exception&);
	//TODO explicit specs of copy/move/delete
	/* ========== *
	 * Properties *
	 * ========== */
	/*override*/ const std::string& name() const;
	/*override*/ const std::string& what() const;
	/*override*/ const std::string& detail() const;
private:
	/* ===================== *
	 * Implementation Detail *
	 * ===================== */
	const std::string _name;
	const std::string _what;
};

/*
 * Failure diagnostics caused by an unhandled unknown object throw
 */
class UnknownUnhandledThrowDiagnostic : public basic_Diagnostic {
public:
	UnknownUnhandledThrowDiagnostic();

	/* ========== *
	 * Properties *
	 * ========== */
	/*override*/ const std::string& name() const;
	/*override*/ const std::string& what() const;
	/*override*/ const std::string& detail() const;
private:
	const std::string _type;
};



/* Failure diagnostics caused by the test taking too long to complete. */
//class TimeoutDiagnostic; //STUB
/* Failure diagnostics caused by system failures such as segfaults. */
//class ErrorDiagnostic; //STUB


/*
 * Exceptions to propagate error signals to the framework.
 */
struct SigAbrt : std::exception {
	/*override*/ const char* what() const throw() { return "Abort signal raised."; }
};
struct SigFpe : std::exception {
	/*override*/ const char* what() const throw() { return "Floating point error occurred."; }
};
struct SigIll : std::exception {
	/*override*/ const char* what() const throw() { return "Illegal instruction attempted."; }
};
struct SigSegV : std::exception {
	/*override*/ const char* what() const throw() { return "Segmentation violation detected."; }
};


}
#endif