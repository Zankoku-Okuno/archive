#ifndef __DIAGNOSE_H__
#define __DIAGNOSE_H__
namespace unit11 {

/*
 * Mixin to handle location information.
 */
class LocationMixin {
public:
	LocationMixin(std::string file, int line);
	/*LocationMixin(std::string&& file, int line); // ambiguous, for some reason*/
	/* ========== *
	 * Properties *
	 * ========== */
	const std::string& file() const;
	int line() const;
	void location(std::string, int);
private:
	/* ===================== *
	 * Implementation Detail *
	 * ===================== */
	std::string _file;
	int _line;
};

enum class CaseStatus;
class basic_Diagnostic;
class basic_CheckFailureDiagnostic;

class UnhandledExceptionDiagnostic;
class UnknownUnhandledThrowDiagnostic;
class TimeoutDiagnostic;
class ErrorDiagnostic;

basic_Diagnostic* handle_error(const LocationMixin&);

}
#endif