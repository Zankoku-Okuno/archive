#ifndef __FAILURES_HPP__
#define __FAILURES_HPP__
#include "unit11/failures.h"
#include "unit11/diagnose.hpp"
namespace unit11 {


class CheckTrueFailureDiagnostic : public basic_CheckFailureDiagnostic {
public:
	CheckTrueFailureDiagnostic(std::string&& expr, std::string&& file, int&& line);
	const std::string& detail() const;
};


}
#endif