#ifndef __FAILURES_H__
#define __FAILURES_H__
#include "diagnose.h"
namespace unit11 {


class CheckTrueFailureDiagnostic;
class CheckFalseFailureDiagnostic;

class CheckEqualFailureDiagnostic;
class CheckNearEqualFailureDiagnostic;

class CheckRaisesFailureDiagnostic;


}
#endif