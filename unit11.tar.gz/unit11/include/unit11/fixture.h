#ifndef __FIXTURE_H__
#define __FIXTURE_H__
namespace unit11 {


class Fixture;


}
#endif