#ifndef __PRINTER_HPP__
#define __PRINTER_HPP__
#include "unit11/registry.h"
#include "unit11/test-case.h"
namespace unit11 {


class basic_Printer {
public:
	virtual void print(const basic_Case&) = 0;
	virtual void print(const RegistryType&) = 0;
};

class default_printer : public basic_Printer {
public:
	/*override*/ void print(const basic_Case&);
	/*override*/ void print(const RegistryType&);
private:

};


}
#endif