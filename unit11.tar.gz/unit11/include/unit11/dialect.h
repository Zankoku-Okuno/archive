#ifndef __DIALECT_H__
#define __DIALECT_H__

#include <iostream>
#include <tuple>

//** Meta-macros **//
#define pass			(void)0
#define STATEMENT(...)	if(true) { __VA_ARGS__; } else pass

#define MERGE_IMPL(a,b) a##b
#define MERGE(a,b) MERGE_IMPL(a,b)

//** Syntax **//
#define elif			else if
#define forever			while(true)
#define loop			forever
#define until(cond)		if (cond) break; else pass
#define scase			break; case
#define sdefault		break; default
//TODO figure out if there's a way to simulate try/else

//** Nice definitions **//
#define nil 	nullptr
#define always	[](...) { return true; }
#define never	[](...) { return false; }




//** Compile-time counter **//
template<unsigned int I> struct COUNTER {};

//** Instance References **//
	//For pointers to instance: this/that
	//For references to instance: self/other
	//For contents of ponter to instance: me/you
#define me	(*this)
#define you	(*that)
	//For members of instance (through pointer): my/thy
#define my	this->
#define thy	that->


template<class Tuple, unsigned int I>
std::ostream& print_tuple(std::ostream& out, const Tuple& t, COUNTER<I>) {
  return print_tuple(out, t, COUNTER<I-1>()) << ", " << std::get<I>(t);
}

template<class Tuple>
std::ostream& print_tuple(std::ostream& out, const Tuple& t, COUNTER<0>) {
  return out << std::get<0>(t);
}

template<class... Args>
std::ostream& operator<<(std::ostream& out, const std::tuple<Args...>& t) {
  return out << "(", print_tuple(out, t, COUNTER<sizeof...(Args)-1>()) << ")";
}

#endif