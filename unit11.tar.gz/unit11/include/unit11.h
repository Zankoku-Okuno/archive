#include <vector>
#include <string>
#include <iostream>

#include "unit11/registry.hpp"
#include "unit11/test-case.hpp"
#include "unit11/diagnose.hpp"
#include "unit11/failures.hpp"

#include "unit11/suite.hpp"
#include "unit11/fixture.hpp"

#include "unit11/dialect.h"
#include "unit11/macros.h"

using unit11::getSuite;
using unit11::getFixture;
