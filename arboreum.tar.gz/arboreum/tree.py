def isleaf(child):
    return not isinstance(child, Tree)

class Tree:
    """An n-ary tree, suitable for a parse tree.
    
    Each node has data associated with it, which may be accessed (read/write) in
    the same way a Token may be accessed. Indexing numerically into a tree
    returns the child at that index; thus, an nth-dimentional index into the
    tree returns an nth-level child."""
    def __init__(self, token=None):
        self._direct_data = {'_node_data', '_children', '_LEAF'}
        from .token import Token
        if isinstance(token, Token):
            self._node_data = token
        else:
            self._node_data = Token(token)
        self._children = []
        #I MAYBE need a (weak) reference to the parent
    
    def __len__(self):
        return len(self._children)
    def __iter__(self):
        "Returns an iterator over the immediate children of this tree."
        return self._children.__iter__()
    
    def __getitem__(self, key):
        if isinstance(key, int):
            return self._children[key]
        if key == "_LEAF":
            return self._LEAF()
        try:
            return self[int(key)]
        except ValueError: pass
        return self._node_data[key]
    def __getattr__(self, name):
        return getattr(self._node_data, name)
    
    def __setitem__(self, key, value):
        if isinstance(key, int):
            self._children[key] = value
        else:
            try:
                self[int(key)] = value
            except ValueError: pass
            self._node_data[key] = value
    def __setattr__(self, name, value):
        if name == '_direct_data' or name in self._direct_data:
            super().__setattr__(name, value)
        else:
            self._node_data[name] = value

class TreeBuilder(Tree):
    """Provides functionality to build a Tree as if iterating using an in-order
    traversal. After having been built, the object is still useable as a Tree
    object."""
    def __init__(self, token=None):
        super().__init__(token)
        self._direct_data.add('_is_open')
        self._is_open = True
    
    def open(self, token=None):
        """Creates a new sub-tree (branch) on the tree with node data from the
        passed token. The branch appears at final position of an in-order
        traversal."""
        self.append(TreeBuilder(token))
    def append(self, leaf):
        """Adds a leaf to the tree. The leaf appear at the final position of an
        in-order traversal."""
        self._delve(lambda x: x._children.append(leaf))
    def close(self):
        """Prevents an interior node from gaining any further children, i.e.
        finished a branch. The node closed is the final not-yet-closed node of
        an in-order traversal."""
        self._delve(lambda x: x.__close())
    def __close(self):
        if self._is_open:
            self._is_open = False
        else:
            raise Exception() #TODO more specific
    
    def _delve(self, program):
        if self._children and isinstance(self[-1], TreeBuilder) and self[-1]._is_open:
            self._children[-1]._delve(program)
        else:
            program(self)