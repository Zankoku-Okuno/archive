class Token:
    """For the purposes of this library, tokens are used to manage data in a
    node of a tree (interior or leaf).
    
    The data stored in tokens may be accessed (read/write) in one of two ways.
    First, a string may be used to index into the token, returning the
    associated data. This is useful if string data from a file is interpreted to
    get a token's data, since the data can be used directly. Second, data may be
    acessed using the familar dot syntax. This is useful when a python script
    has a hard-coded access to a token's data, since a string need not be built
    to index in.
    
    Note that '_ATTR' must be accessed with a dot, if it is to be accessed at
    all. Accessing it as a string will cause an error."""
    def __init__(self, contents=None, **kwargs):
        self._ATTR = kwargs
        self._DATA = contents
    
    def __getattr__(self, name):
        if name in self._ATTR:
            return self._ATTR[name]
        else:
            raise AttributeError(name)
    def __getitem__(self, name):
        if not name or name == "_ATTR":
            raise ValueError(name)
        if name == '_DATA':
           return self._DATA
        try: return self._ATTR[name]
        except KeyError: raise AttributeError(name)
    def __setattr__(self, name, value):
        if name in {'_ATTR', '_DATA'}:
            super().__setattr__(name, value)
        else:
            self._ATTR[name] = value
    def __setitem__(self, key, value):
        if not isinstance(key, str):
            raise AttributeError(key)
        if not key or key == "_ATTR":
            raise ValueError(key)
        self._ATTR[key] = value