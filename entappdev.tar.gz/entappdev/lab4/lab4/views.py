from django.shortcuts import *
from lab4.impl.models import *

def home(request):
	return render(request, "products.html", {'xs': Product.objects.all()})

class LineItem:
	def __init__(self, prod, qty):
		self.pk = prod.pk
		self.name = prod.name
		self.qty = qty
		self.price = prod.price * qty

def cart(request):
	xs = { LineItem(get_object_or_404(Product, pk=x), qty) for x, qty in request.session.get('cart', dict()).items()}
	total = sum(x.price for x in xs)
	return render(request, "cart.html", {'xs': xs, 'total': total})

def add(request, pk):
	get_object_or_404(Product, pk=pk)
	if 'cart' not in request.session:
		request.session['cart'] = dict()
	if pk not in request.session['cart']:
		request.session['cart'][pk] = 0
	request.session['cart'][pk] += 1
	request.session.modified = True
	return redirect('products')

def remove(request, pk):
	del request.session['cart'][pk]
	request.session.modified = True
	return redirect('cart')

def checkout(request):
	del request.session['cart']
	return redirect('products')