from django.db.models import *
from decimal import Decimal

class Product(Model):
    name = TextField()
    price = DecimalField(decimal_places=2, max_digits=10)

