from django.conf.urls import patterns, include, url

import views

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()

urlpatterns = patterns('',
    url(r'^$', views.home, name='products'),
    url(r'^cart$', views.cart, name='cart'),
    url(r'^add/(?P<pk>\d+)$', views.add, name='add'),
    url(r'^del/(?P<pk>\d+)$', views.remove, name='del'),
    url(r'^checkout$', views.checkout, name='checkout'),
    # Examples:
    # url(r'^$', 'lab4.views.home', name='home'),
    # url(r'^lab4/', include('lab4.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    # url(r'^admin/', include(admin.site.urls)),
)
