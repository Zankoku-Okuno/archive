module Handler.Greet where

import Import
import qualified Data.Text as T

getGreetR :: Handler Html
getGreetR = do
  (widget, enctype) <- generateFormPost nameForm
  defaultLayout $ do
    setTitle "Who are you?"
    $(widgetFile "who")

postGreetR :: Handler Html
postGreetR = do
  ((result, widget), enctype) <- runFormPost nameForm
  case result of
    FormSuccess name -> do
      defaultLayout $ do
        setTitle . toHtml . T.concat $ ["Hello, ", name, "!"]
        $(widgetFile "greet")
    _ -> defaultLayout $ do
      setTitle "Who are you?"
      $(widgetFile "who")

nameForm :: Form Text
nameForm = renderDivs $ areq textField "Who are you?" Nothing
