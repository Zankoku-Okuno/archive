module Handler.GreetA where

import Import
import qualified Data.Text as T

getGreetAR :: Handler Value
getGreetAR = do
  Just name <- lookupGetParam "field"
  return $ toJSON $ T.concat ["Hajimemashite, ", name, "!"]
