module Handler.FastGreet where

import Import

getFastGreetR :: Handler Html
getFastGreetR = defaultLayout $(widgetFile "fast_greet")
