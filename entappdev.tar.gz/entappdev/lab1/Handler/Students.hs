module Handler.Students where

import Import

getStudentsR :: Handler Html
getStudentsR = error "Not yet implemented: getStudentsR"
