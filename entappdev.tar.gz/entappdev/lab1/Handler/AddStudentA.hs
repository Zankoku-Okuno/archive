module Handler.AddStudentA where

import Import

postAddStudentAR :: Handler Html
postAddStudentAR = error "Not yet implemented: postAddStudentAR"
