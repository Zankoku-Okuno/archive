{-# LANGUAGE TupleSections, OverloadedStrings #-}
module Handler.Home where

import Import
import Data.Time.Clock
import Data.Time.Calendar
import Control.Monad

import Text.Julius (rawJS)

import CarData

-- This is a handler function for the GET request method on the HomeR
-- resource pattern. All of your resource patterns are defined in
-- config/routes
--
-- The majority of the code you will write in Yesod lives in these handler
-- functions. You can spread them across multiple files if you are so
-- inclined, or create a single monolithic file.
getHomeR :: Handler Html
getHomeR = do
    (formWidget, formEnctype) <- generateFormPost carForm
    let submission = Nothing :: Maybe (Int, (Text, Text), Int)
        handlerName = "getHomeR" :: Text
    defaultLayout $ do
        aDomId <- newIdent
        setTitle "Welcome To Yesod!"
        $(widgetFile "homepage")

postHomeR :: Handler Html
postHomeR = do
    ((result, formWidget), formEnctype) <- runFormPost carForm
    let handlerName = "postHomeR" :: Text
        submission = case result of
            FormSuccess res -> Just res
            _ -> Nothing

    defaultLayout $ do
        aDomId <- newIdent
        setTitle "Welcome To Yesod!"
        $(widgetFile "homepage")

carForm :: Form (Int, (Text, Text), Int)
carForm = renderDivs $ (,,)
       <$> areq carYearField "Year" Nothing
       <*> areq makeModelField "Make & Model" Nothing
       <*> areq zipField "Zipcode" Nothing
    where
    carYearField = checkM nonFuture $ checkBool (>= 1900) ("Cars weren't around back then!" :: Text)  intField
      where
      nonFuture y = do
        y' <- liftIO currentYear
        return $ if y <= (y' + 1)
          then Right y
          else Left ("No time machines allowed!" :: Text)
      currentYear = do
        (year, _, _) <- liftM (toGregorian . utctDay) getCurrentTime
        return . fromInteger $ year
    zipField = checkBool (\x -> 10000 <= x && x <= 99999) ("Invalid zipcode." :: Text) intField

makeModelField :: Field Handler (Text, Text)
makeModelField = Field {
    fieldParse = \rawVals _fileVals ->
      case rawVals of
        [make, model] | make == "" || model == "" -> return (Left "Enter both make & model")
                      | otherwise -> return (validate make model)
        [] -> return (Right Nothing)
        _ -> return (Left "Enter both make & model")
  , fieldView = \idAttr nameAttr otherAttrs result isReq -> do
      let (make,model) = either (flip (,) "") id result
      [whamlet|
        <select ##{idAttr}-make name=#{nameAttr} *{otherAttrs}>
          <option value="">-- Select Make --
          $forall item <- map fst makeModelOptions
            <option value=#{item} :item == make:selected>#{item}
        <select ##{idAttr}-model name=#{nameAttr} *{otherAttrs}>
          <option value="">--Select Model--
          $maybe models <- lookup make makeModelOptions
            $forall item <- models
              <option value=#{item} :item == model:selected>#{item}
      |]
      toWidget [julius|
        $(function () {
        function gotModels(models) {
          $("##{rawJS idAttr}-model option:not(:first)").remove();
          $.each(models, function(i, x) {
            $("##{rawJS idAttr}-model").append($("<option>", {
              value: x,
              text: x
            }));
          });
        }
        $("##{rawJS idAttr}-make").change(function () {
          $.getJSON("@{AjaxModelsR}", {
              "make": $("##{rawJS idAttr}-make option:selected").val()
            }, gotModels)
        });
      });
      |]
  , fieldEnctype = UrlEncoded
}
  where isChecked item (Right (item', _)) = item == item'
        isChecked item (Left item') = item == item'
        validate make model = maybe 
          (Left "Invalid make")
          (\makes -> if model `elem` makes then Right $ Just (make, model) else Left "Invalid model")
          (lookup make makeModelOptions)

