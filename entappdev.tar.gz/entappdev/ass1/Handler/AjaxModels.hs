module Handler.AjaxModels where

import Import
import CarData

getAjaxModelsR :: Handler Value
getAjaxModelsR = do
    Just make <- lookupGetParam "make"
    if make == ""
        then return $ toJSON ([] :: [Text])
        else maybe notFound (return . toJSON) (lookup make makeModelOptions)
