module CarData where

import Data.Text

makeModelOptions :: [(Text, [Text])]
makeModelOptions =
    [ ("Chevrolet", 
        [ "Cobalt"
        , "Impala"
        , "Malibu"
        , "Silverado"
        , "Suburban"
        , "Tahoe" ])
    , ("Chrysler", 
        [ "300"
        , "Crossfire"
        , "Pacifica"
        , "PT Cruiser"
        , "Sebring"
        , "Town & Country" ])
    , ("Dodge", 
        [ "Charger"
        , "Dakota"
        , "Durango"
        , "Grand Caravan"
        , "Magnum"
        , "Ram 1500" ])
    , ("Ford", 
        [ "Escape"
        , "Expedition"
        , "Explorer"
        , "F-150"
        , "Mustang"
        , "Taurus" ])
    , ("GMC", 
        [ "Acadia"
        , "Canyon"
        , "Envoy"
        , "Sierra"
        , "Yukon"
        , "Yukon XL" ])
    , ("Jeep", 
        [ "Commander"
        , "Compass"
        , "Grand Cerokee"
        , "Liberty"
        , "Wrangler"
        , "Wrangerl Unlimited" ])
    ]