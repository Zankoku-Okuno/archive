from django.shortcuts import *
from ass3._ass3.models import *

def question(request):
	voted = request.session.get('voted', False)
	poll = YesNoQuestion.objects.get(pk=1)
	if not voted and request.method == 'POST' and 'foo' in request.POST:
		voted = True
		if request.POST['foo'] == 'y':
			poll.y += 1
		elif request.POST['foo'] == 'n':
			poll.n += 1
		else: voted = False
		poll.save()
		request.session['voted'] = voted
	return render(request, "question.html", {'poll':poll,'yes':100*poll.y/(poll.y+poll.n), 'no':100*poll.n/(poll.y+poll.n), 'voted':voted})
