from django.db.models import *

class YesNoQuestion(Model):
	q = TextField()
	y = IntegerField()
	n = IntegerField()
