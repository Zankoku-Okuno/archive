{-# LANGUAGE TupleSections, OverloadedStrings #-}
module Handler.Home where

import Import


getHomeR :: Handler Html
getHomeR = do
    guests <- runDB $ guestNames
    defaultLayout $ do
        setTitle "Welcome To Yesod!"
        $(widgetFile "homepage")

guestNames :: YesodDB App [Html]
guestNames = do
        allData <- selectList [] []
        return $ map project allData
        where project (Entity _ (Signup name _)) = name