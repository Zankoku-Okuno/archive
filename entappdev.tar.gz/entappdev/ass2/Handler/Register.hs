module Handler.Register where

import Import
import Control.Monad

getRegisterR :: Handler Html
getRegisterR = do
    (formWidget, formEnctype) <- generateFormPost guestForm
    let submission = Nothing :: Maybe (Text, Text)
    defaultLayout $ do
        setTitle "Totally Not a Phishing Site"
        $(widgetFile "register")

postRegisterR :: Handler Html
postRegisterR = do
    ((result, formWidget), formEnctype) <- runFormPost guestForm
    let submission = case result of
            FormSuccess (n, e) -> Just (toHtml n, e)
            _ -> Nothing
    case submission of
        Nothing -> defaultLayout $ do
            setTitle "Totally Not a Phishing Site"
            $(widgetFile "register")
        Just (name, email) -> do
            msg <- runDB $ doSignin name email
            setMessage $ toHtml msg
            redirect HomeR

guestForm :: Form (Text, Text)
guestForm = renderDivs $ (,)
    <$> areq textField "Name" Nothing
    <*> areq emailField "Email" Nothing


doSignin :: Html -> Text -> YesodDB App Text
doSignin n e = do
    exists <- liftM (maybe False (const True)) (getBy $ UniqueEntity n e)
    when (not exists) (void . insert $ Signup n e)
    return $ if exists then "You've already signed the book." else "Welcome!"