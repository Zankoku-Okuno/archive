from django.conf.urls import patterns, include, url

from impl import views

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()

urlpatterns = patterns('',
    url(r'^$', views.home, name='products'),
    url(r'^cart$', views.cart, name='cart'),
    url(r'^add/(?P<pk>\d+)$', views.add, name='add'),
    url(r'^del/(?P<pk>\d+)$', views.remove, name='del'),
    url(r'^checkout$', views.checkout, name='checkout'),
    url(r'^confirm$', views.confirm, name='confirm'),
    url(r'^accounts/login/$', 'django.contrib.auth.views.login', {'template_name': 'login.html'}),
    url(r'^accounts/logout/$', views.logout, name='logout'),
)
