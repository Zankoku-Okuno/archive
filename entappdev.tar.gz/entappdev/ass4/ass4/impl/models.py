from django.db.models import *
from annoying.fields import JSONField
from django.contrib.auth.models import User
from decimal import Decimal

class Product(Model):
    name = TextField()
    price = DecimalField(decimal_places=2, max_digits=10)

class Cart(Model):
    user = ForeignKey(User)
    ship_address = TextField()
    cart = JSONField()
