from django.shortcuts import *
from django.contrib.auth.decorators import login_required
from annoying.decorators import render_to
from ass4.impl.models import *

@login_required
@render_to("products.html")
def home(request):
	return { 'xs': Product.objects.all() }

class LineItem:
	def __init__(self, prod, qty):
		self.pk = prod.pk
		self.name = prod.name
		self.qty = qty
		self.price = prod.price * qty

@login_required
@render_to("cart.html")
def cart(request):
	xs = { LineItem(get_object_or_404(Product, pk=x), qty) for x, qty in request.session.get('cart', dict()).items()}
	total = sum(x.price for x in xs)
	return { 'xs': xs, 'total': total }

@login_required
def add(request, pk):
	get_object_or_404(Product, pk=pk)
	if 'cart' not in request.session:
		request.session['cart'] = dict()
	if pk not in request.session['cart']:
		request.session['cart'][pk] = 0
	request.session['cart'][pk] += 1
	request.session.modified = True
	return redirect('products')

@login_required
def remove(request, pk):
	del request.session['cart'][pk]
	request.session.modified = True
	return redirect('cart')

@login_required
@render_to("shipping.html")
def checkout(request):
	return {}

@login_required
def confirm(request):
	addr = request.POST['address']
	Cart.objects.create(user=request.user, ship_address=addr, cart=request.session['cart'])
	del request.session['cart']
	return redirect('products')

def logout(request):
	from django.contrib import auth
	auth.logout(request)
	return redirect('products')

