from django.db.models import *

class PhoneBookEntry(Model):
	name = TextField()
	number = TextField()

	def __str__(self): return self.name