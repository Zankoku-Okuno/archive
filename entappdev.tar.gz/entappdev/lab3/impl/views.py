from django.shortcuts import *
from impl.models import *
from django.forms import *

class PhoneForm(Form):
	who = ModelChoiceField(queryset=PhoneBookEntry.objects.all())

def main(request):
	form = PhoneForm(request.GET)
	if form.is_valid():
		person = form.cleaned_data['who']
	else:
		form = PhoneForm()
		person = None
	return render(request, "home.html", {'form': form, 'person': person})