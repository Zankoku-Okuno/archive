from mk500 import *

#a Span class that carries the code for activation/parsing
#a live span that carries its own state information as well as a reference to a more gobal state
#   lives throughout a program execution, but there may be sub-programs
#a Span that holds input data

#a Block class that carries the code for activation/parsing
#a live block that carries its own state information as well as a reference to a more global state



#TODO fenced code:
#starts with a line of tildes + options
#enters fenced mode
#exits fenced mode when another line of tildes appears (same number?)
#may need to exit immediately if len(block)>1 and block[0] and block[-1] both match tildes
#once I've extraceted the code, I can do anything I want with it


# ============== #
# == Metadata == #
# ============== #

@metadata
def blogish(tag):
    if tag in {'author', 'title'}:
        return str
    elif tag == 'version':
        def interpret(value):
            version = re.match(r'\s*(?:v(?:ersion)?[ -]?)?\s*(\d+(?:\.\d+)*)[ -]?(a(?:lpha)?|b(?:eta)?|c(?:andidate)?)?\s*-?\s*(.*)$', value)
            quantity, quality, branch = version.groups()
            quantity = tuple((int(x) for x in quantity.split('.')))
            if quality is not None:
                if quality.startswith('a'): quality = 'alpha'
                elif quality.startswith('b'): quality = 'beta'
                elif quality.startswith('c'): quality = 'candidate'
                else: quality = None
            if not branch: branch = 'main'
            else: branch = branch.strip()
            return (branch, quantity, quality)
        return interpret
    else:
        raise MetadataAttributeError(tag)

# ================ #
# == Plain Text == #
# ================ #

@block('article', priority=Infinity) #TODO consider common tags
class Paragraph:
    def activate(self, block):
        return True
    
    def parse(self, block):
        first = True
        for logical_line in bodytext(block):
            if first: first = False
            else: yield self.LineBreak()
            while logical_line:
                elem, logical_line = self.state.elements(logical_line)
                yield elem
                #handler, take = self.state.dispatch_span(logical_line)
                #yield handler.parse(logical_line[:take])
                #logical_line = logical_line[take:]

@span('article', priority=Infinity)
class Text:
    @element
    def factory(self, text):
        self.text = text
    
    def activate(self, span):
        return 0, None
    def parse(self, span):
        return self.Text(span)

@span('article')
class LineBreak:
    pass

@Text.printer('html')
def html_text(elem):
    return escape_basic(elem.text)
@LineBreak.printer('html')
def html_linebreak(elem):
    return "<br />"


@Paragraph.printer('html')
def html_par(elements):
    yield "<p>"
    for elem in elements:
        yield elem
    yield "</p>"

# ============= #
# == Headers == #
# ============= #

@block('article', priority=0) #TODO consider common tags
class Header:
    @span('article')
    class HeaderElement:
        @element
        def factory(self, text, level):
            self.text = text
            self.level = level
    
    hash_syntax = re.compile(r'^\s*(#{1,6})\s*(.+?)\s*(?<!#)\1?\s*$')
    #hash_syntax = re.compile(r'^\s*(#{1,6})\s*(.+?)[ \t]*(?<!#)(?:\1\s*|)$') #SPIFFY that by chomping the line before here, I could use the above regex
    under_syntax = re.compile(r'^\s*(-|=)+\s*$')
    okuno_syntax = re.compile(r'\s*(={6}|===?|---?)\s*(.+?)\s*\1\s*$')
    

    def activate(self, block):
        if not block: return False
        if len(block) >= 2 and Header.under_syntax.match(block[1]):
            return block[:2], block[2:]
        if (Header.okuno_syntax.match(block[0])
        or Header.hash_syntax.match(block[0])):
            return block[:1], block[1:]
    
    def parse(self, block):
        assert(block)
        if len(block) >= 2:
            under = Header.under_syntax.match(block[1])
            yield self.HeaderElement(block[0].strip(), {'=': 2, '-': 3}[under.groups()[0]])
            return
        okuno = Header.okuno_syntax.match(block[0])
        if okuno:
            level = okuno.groups()[0]
            if len(level) == 6: level = 2
            elif level[0] == '=': level = 3
            elif level[0] == '-': level = 4
            yield self.HeaderElement(okuno.groups()[1], level)
            return
        hash = Header.hash_syntax.match(block[0])
        if hash:
            yield self.HeaderElement(hash.groups()[1], len(hash.groups()[0]))
            return

@Header.printer('html')
def html_header(elements):
    for elem in elements:
        yield "<h{}>".format(elem.level)
        yield html_text(elem)
        yield "</h{}>".format(elem.level)

# ================= #
# == Inline HTML == #
# ================= #

html_attr = r'''[a-zA-Z][0-9a-zA-Z]*(?:\s*=\s*(?:'[^']*'|"[^"]*"|[^'"\s/>][^\s/>]*))?'''
html_start_tag = r'''<[a-zA-Z][0-9a-zA-Z]*(?:\s+{})*\s*/?>'''.format(html_attr)
html_close_tag = r'''</[a-zA-Z][0-9a-zA-Z]*\s*>'''
html_tag = r'(?:{}|{})'.format(html_start_tag, html_close_tag)

class HtmlBlockMode(Mode):
    def __init__(self, parent):
        self.span_features = {x for x in parent.span_features if x.__class__ in {InlineHTML, Text} }

@block('article', priority=0)
class BlockHTML:
    def activate(self, block):
        return re.match(r'^\s*{}\s*$'.format(html_tag), block[0])
    def parse(self, block):
        logical_line, building = [], True
        for line in block:
            if line.endswith('\\\\'):
                logical_line.append(line[:-1])
                building = False
            elif line.endswith('\\'):
                logical_line.append(line[:-1])
            else:
                logical_line.append(line)
                building = False
            if not building:
                logical_line = ''.join(logical_line)+'\n'
                while logical_line:
                    #TODO modify mode to only allow text and html handlers
                    elem, logical_line = self.state.elements(logical_line)
                    yield elem
                logical_line, builing = [], True

@span('article', priority=0)
class InlineHTML:
    @element
    def factory(self, type, name, **attrs):
        self.name = name
        self.type = type
        self.attributes = attrs
    
    tag_detector = re.compile(r'\\?\\?{}'.format(html_tag))
    name_extractor = re.compile(r'<(/?[0-9a-zA-Z]+)')
    attr_extractor = re.compile(r'''([0-9a-zA-Z]+)(?:\s*=\s*('[^']*'|"[^"]*"|[^'"\s/>][^\s/>]*))?''')
    def activate(self, span):
        m = InlineHTML.tag_detector.search(span)
        return False if not m else m.span()
    def parse(self, span):
        #span = span[1:]
        if span.startswith('\\') and not span.startswith('\\\\'):
            return self.Text(span[1:])
        elif span.startswith('\\\\'): span = span[2:]
        name = InlineHTML.name_extractor.match(span)
        begin_search = name.end()
        if name:
            name = name.groups()[0]
            if name.startswith('/'):
                name = name[1:]
                type = 'close'
            elif span.endswith('/>'):
                type = 'void'
            else:
                type = 'open'
        
        attributes = dict()
        while True:
            match = InlineHTML.attr_extractor.search(span, begin_search)
            if match is None: break
            begin_search = match.end()
            key, value = match.groups()
            if value.startswith('"') or value.startswith("'"):
                value = value[1:-1]
            else:
                value = escape_unquoted_attribute(value)
            #TODO ensure the key doesn't already exist
            attributes[key] = escape_attribute(value)
        
        #TODO lookup custom tags
        #TODO validate tag info (including that close tags have no attributes)
        return self.InlineHTML(type, name, **attributes)

@BlockHTML.printer('html')
def html_html(elements):
    yield '\n'
    for elem in elements:
        yield elem

@InlineHTML.printer('html')
def html_passthrough(elem):
    acc = '<'
    if elem.type == 'close': acc += '/'
    acc += elem.name
    for key, value in elem.attributes.items():
        if value:
            acc += ' {}="{}"'.format(key, escape_attribute(value))
    if elem.type == 'void': acc += ' /'
    acc += '>'
    return acc

# =========== #
# == Links == #
# =========== #

@span('article', priority=0)
class Link:
    @element
    def factory(self, text, target, **kwargs):
        self.text = text
        self.target = target
        for key, value in kwargs.items():
            setattr(self, key, value)
    detector = re.compile(r'''\[(?P<text>[^\]]+)\](?:\((?P<target>[^\)]+?)(?:\s+(?P<q>['"])(?P<title>[^\)]*?)(?P=q))?\)|\[(?P<id>[^\]]*)\])''')
    def activate(self, span):
        m = Link.detector.search(span)
        return False if not m else m.span()
    def parse(self, span):
        match = Link.detector.match(span).groupdict()
        text, target, title, id = match['text'], match['target'], match['title'], match['id']
        if target:
            return self.Link(text, target, title=title)
        else:
            if not id: id = text.lower() #HAX why I need lower here?
            def bind_link(state):
                if not hasattr(state, 'link_ids') or id.lower() not in state.link_ids:
                    raise Exception("TODO")
                link_info = state.link_ids[id]
                return self.Link(text, link_info['target'], title=link_info['title'])
            return bind_link

@Link.printer('html')
def html_link(elem):
    assert elem.target
    if elem.title: yield InlineHTML(None).factory('open', 'a', href=elem.target, title=elem.title)
    else: yield InlineHTML(None).factory('open', 'a', href=elem.target)
    yield html_text(elem)
    yield InlineHTML(None).factory('close', 'a')

@block('article', priority=0)
class LinkDefinition:
    detector = re.compile(r'\s*\[([^\]]+)\]:\s+(.+?)(?:"([^"]*)")?$')
    def activate(self, block):
        if not block: return False
        for i, line in enumerate(block):
            if not LinkDefinition.detector.match(line):
                if not i: return False
                else: return block[:i], block[i:]
        return block
    def parse(self, block):
        for line in block:
            extract = LinkDefinition.detector.match(line).groups()
            if not hasattr(self.state, 'link_ids'):
                self.state.link_ids = dict()
            self.state.link_ids[extract[0].lower()] = {'target': extract[1], 'title': extract[2]}

@printer('html', LinkDefinition)
def no_print(elements):
    return []

# =============== #
# == Utilities == #
# =============== #

def bodytext(block):
    """"Merges physical lines down to logical lines. It removes whitespace from
    around a line, checks for hard breaks (<br /> tags), and escaped hard
    breaks. Any consecutive lines that are not hard broken are merged into a
    single line. Furthermore assures that no blank logical lines are issued;
    in particular, immediately consecutive line breaks will be generated as one
    line break."""
    def line_joiner(a, b):
        """Handles adding appropriate whitespace (or lack thereof) when two
        physical lines are concatenated as logical lines. Also removes
        hyphenation (at most one character) from words broken across a line."""
        if not a: return b
        elif not b: return a
        elif a[-1] == '-': return a[:-1] + b
        elif a[-1] == '/': return a + b
        else: return a + ' ' + b
    buffer, broken = '', False
    for line in block:
        line = line.strip()
        could_break = line and line[-1] == '\\'
        escaped = could_break and len(line) >= 2 and line[-2] == '\\'
        if could_break: line = line[:-1]
        buffer = line_joiner(buffer, line)
        broken = could_break and not escaped #or: not (could_break implies escaped)
        if broken:
            if buffer: yield buffer
            buffer = ''
    if buffer: yield buffer

def escape_basic(text):
    entities = [
        ('&amp;'    , re.compile(r'&(?!#?[a-z0-9A-F]+;)')),
        ('&lt;'     , re.compile('<')),
        ('&gt;'     , re.compile('>'))
    ]
    for replacement, pattern in entities:
        text = pattern.sub(replacement, text)
    return text
def escape_attribute(text):
    text = escape_basic(text)
    entities = [
        ('&quote;'   , re.compile('"')),
        ('&#39;'     , re.compile("'"))
    ]
    for replacement, pattern in entities:
        text = pattern.sub(replacement, text)
    return text
def escape_unquoted_attribute(text):
    entities = [
        ('&#96;'   , re.compile('`')),
        ('&#61;'     , re.compile('='))
    ]
    for replacement, pattern in entities:
        text = pattern.sub(replacement, text)
    return text


#So, inline html should be: put a backslash in front ov every tag, you're
#escaped for the one tag (not it's enclosure)

#now, I'd like to keep a stack full of tags generated and make sure they all
#match up. Theis way, I can really do error reporting during compilation

#in-line python? I'm really tempted, but I need to know how to link the
#environment up with itself and its print with some stream in the main
#environment for collection. 
