"""Mk. 500 is a strictly-targeted, component-based markdown micro-engine. It is
responsible for nothing more than parsing a writer's content files and
generating markup. Markup generation has been approached as a form of
compilation: therefore, Mk. 500 attempts to validate and diagnose errors during
generation, rather than leaving the user to detect them manually in deployment.

Under default operation, most of the syntax is inspired by John Gruber's
Markdown, the extensions for Markdown in Python, and LaTeX. However, even this
core syntax is implemented as pluggable components, and can be easily swapped
out.

Mk. 500 comes from the Roman numeral 'D', representing 500. 'Mk. D' is /clearly/
a massive abrreviation for markdown and so tha name thus a stealth unix pun."""

import os, sys
from os import path

import re

from libzan import *
from math import floor, ceil as ceiling

# ============ #
# == Errors == # #TODO: make these more expressive
# ============ #

class MarkdownError(Exception):
    pass
class MetadataAttributeError(MarkdownError):
    def __init__(self, attr):
        super().__init__("No metadata attribute exists for '{}'".format(attr))
class DoubleMetadataDefinitionError(MetadataAttributeError):
    def __init__(self, attr):
        Exception.__init__(self, "Metadata attribute '{}' is already defined.".format(attr))

# ================ #
# == Data Model == #
# ================ #

class Configuration:
    def __init__(self,
                 has_metadata=True,
                 include_features=set(),
                 exclude_features=set(),
                 output_format='plaintext'):
        self.has_metadata = has_metadata
        def feature_filter(feature):
            return (forsome(include_features, lambda x: x in feature.tags)
                and forall(exclude_features, lambda x: x not in feature.tags))
        self.feature_filter = feature_filter
        self.output_format = output_format
        #TODO consider more options

class FileSource:
    def __init__(self, pathname):
        if not path.exists(pathname):
            raise MarkdownError("404: {}".format(pathname))
        self.pathname = pathname
        self.file = None
        self.backbuffer = []
        self.line = None
    def __enter__(self):
        self.file = open(self.pathname)
        self.advance()
        return self
    def __exit__(self, eType, eValue, eTrace):
        self.line = None
        self.backbuffer = []
        if self.file:
            self.file.close()
        self.file = None
    def advance(self):
        if self.backbuffer:
            self.line = self.backbuffer[0]
            self.backbuffer = self.backbuffer[1:]
        else:
            self.line = self.file.readline()
            
        return self.line
    def reverse(self, reinput):
        if reinput:
            self.backbuffer += reinput
            self.backbuffer.append(self.line)
            self.advance()

class Mode:
    def resolve_block(self, block):
        """The default resolution algorithm for the State is to match the lowest
        priority feature that it knows about."""
        priority, best = Infinity, dict()
        for possible in self.block_features:
            if possible.priority < priority:
                activation = possible.activate(block)
                if activation:
                    priority, best = possible.priority, {possible: activation}
            elif possible.priority == priority:
                activation = possible.activate(block)
                if activation:
                    assert possible not in best
                    best[possible] = activation
        return self.adapt_block(block, best)
    def resolve_span(self, span):
        #1. Determine possible handlers and the extent of the span they would handle
        possible = set()
        for x in self.span_features:
            active = x.activate(span)
            #the format for an element is '(handler, start_index, end_index)'
            if active: possible.add((x,) + active)
        #2. Determine intersections
        intersections = dict()
        #for pairs of distinct posssible handlers # |
        for handler in possible:                  # |
            intersections[handler] = set()        # |
            for other in possible:                # |
                if handler is not other:          #</
                    #handlers canot intersect if the have a None end position
                    if (handler[2] is not None and other[2] is not None
                    #check for handlers that intersect...
                        and intersect(handler[1:], other[1:])
                    #...but ignore intersections where the intersectee has a worse (higher) priority
                    #i.e. the aftermath of instersections is not symmetric, and favors the better (lower) priority handler
                        and other[0].priority <= handler[0].priority):
                        intersections[handler].add(other)
        #3. Determine handlers that survived (not intersected by better priority handler)
        keep = set()
        for handler, S in intersections.items():
            if not forsome(S, lambda x: x[0].priority < handler[0].priority):
                keep.add(handler)
        #4. Create output format unless error is detected
        return self.adapt_span(span, keep)
        
        ## Examples of Intersections and their Aftermath: ##
        
        #bad_pritority
        #        good_priority  <-- take this one
        
        #some_priority          <-- survives, possible ambiguity
        #       same_priority   <-- survives, possible ambiguity
        
        #good_priority          <-- take this one
        #       bad_priority
        
        #bad_pritority          <-- destroyed by the higher priority
        #        good_priority  <-- survives, but being early is better than having good priority
        #worse                  <-- take this one, not ambiguous
    
    def adapt_block(self, block, best):
        if len(best) == 1:
            for handler, split in best.items():
                if isinstance(split, tuple):
                    assert len(split) == 2
                    take, leave = split[0], split[1]
                else:
                    take, leave = block, None
                return handler, take, leave
        elif len(best) == 0:
            raise MarkdownError("No handler for block:\n{}".format(block))
        else:
            raise MarkdownError("Ambiguous handlers: '{}'.".format([(f.__class__.__name__, f.priority) for f in best]))
    def adapt_span(self, span, possible):
        #if there are no posible handlers, then this is an error
        if not possible:
            raise MarkdownError("No handler for span:\n{}".format(span))
        #find all the possibilities with the samllest and second smallest starting positions
        first, second = ( splitby(possible, lambda x: x[1])[0:2]
        #if there is no second smallest starting position, then pad with a sentinel
                         + [[(None, len(span), len(span))]] )[0:2]
        #find all the first possibilities that have the best (lowest) priority
        first = splitby(first, lambda x: x[0].priority)[0]
        #if there are too many earliest, best priority handlers, this is an error
        if len(first) > 1:
            raise MarkdownError("Ambiguous handlers: '{}'.".format([(f.__class__.__name__, f.priority) for f in first]))
        #extract information about the handlers
        #we only need the start position of the second earliest handlers
        first, second = first[0], second[0][1]
        #find start/end for what the handler will handle
        start, end = first[1], first[2] if first[2] is not None else second
        #if the handler cannot handle the beginning of the span, then this is an error
        if start != 0:
            raise MarkdownError("No handler for span:\n{}".format(span[:start]))
        #all we need are the handler and how many characters to take
        return first[0], end

class State(Mode):
    """Manages the execution environment of a single parser."""
    def __init__(self, feature_filter):
        self.block_features = {x(self) for x in Registry.block_features if feature_filter(x)}
        self.span_features = {x(self) for x in Registry.span_features if feature_filter(x)}
        for span in self.span_features:
            for block in self.block_features:
                setattr(block, span.__class__.__name__, span.factory)
            for other in self.span_features:
                setattr(other, span.__class__.__name__, span.factory)
        self.mode = self
    
    def elements(self, line):
        handler, take = self.dispatch_span(line)
        return handler.parse(line[:take]), line[take:]
    def subparse(self, source):
        pass #STUB create blocks
    
    def dispatch_block(self, block):
        """Decides what resolution algorithm is used based on the current mode.
        The default resolution unit is the State itself."""
        return self.mode.resolve_block(block)
    def dispatch_span(self, span):
        return self.mode.resolve_span(span)
    
#TODO: everything has to keep track of line number & source file for diagnostics

# =============== #
# == Framework == #
# =============== #

class Registry:
    """Tracks all features defined."""
    block_features = set()
    span_features = set()
    _block_priority = 0
    _span_priority = 0
    @classmethod
    def add_block(cls, handler):
        if not hasattr(cls, "priority"):
            Registry._block_priority = Registry.auto_priority(Registry._block_priority)
            handler.priority = Registry._block_priority
        Registry._block_priority = handler.priority
        Registry.block_features.add(handler)
    @classmethod
    def add_span(cls, handler):
        if not hasattr(cls, "priority"):
            Registry._span_priority = Registry.auto_priority(Registry._span_priority)
            handler.priority = Registry._span_priority
        Registry._span_priority = handler.priority
        Registry.span_features.add(handler)
    @classmethod
    def auto_priority(cls, source):
        return floor(1 + source)
    @staticmethod
    def metadata(tag):
        raise MetadataAttributeError(tag)

def metadata(func):
    Registry.metadata = func
    return func

#TODO a mode decorator
#I want to allow the user to modify a "mode". In normal mode, everything gets
#passed through all the block type detectors. In a user mode, block type
#detectors can be overridden. This should allow for things like lists with
#paragraphs inside, or multi-paragraph, complex block-quotes (when you hit a
#block quote, switch to block quote level 1, then remove the blockquote-y-ness
#from the front of all the strings, call a new parser manually, and )

class Feature(type):
    """Responsible for detecting and generating output for a block or span.
    
    Features register printers that will generate output from the parsed input.
    For blocks, this means generating streams of span features. For spans, this
    means generating strings (or whatever the underlying medium of your output
    is).
    
    When features become active (an instance of a feature class is constructed),
    that instance gains access to its parent though its state field. Since the
    parent will be longer-lived that the feature it spawned, this is a good way
    to maintain data from call to call.
    
    Configuration will examine tags applied to a feature in order to filter what
    features should be active or inactive during a particular parsing run.
    
    The priority of a feature helps determine which feature should be active in
    case two or more features vie for the same input."""
    @staticmethod
    def factory(cls, tags, priority, kind):
        old_init = cls.__init__
        def injection(self, parent):
            self.state = parent
            old_init(self)
        cls.__init__ = injection                            #make sure an active feature always has a parent (eve during its written __init__ method)
        cls.tags = tags                                     #apply tags to the feature
        cls.registry = dict()                               #create a registry mechanism for printers
        cls.printer = lambda x: printer(x, cls)
        return cls

def block(*tags, priority=None):
    """A decorator that creates and registers a block feature.
    
    A block feature is a component that is queried and activated as sections of
    input text lines are retrieved from file. Thus, a block shuold accept an
    iterable of input lines and output an interable of elements."""
    def impl(cls):
        cls = Feature.factory(cls, tags, priority, 'block')
        Registry.add_block(cls)
        if priority is not None:
            cls.priority = priority
        return cls
    return impl

def span(*tags, priority=None):
    """A decorator that creates and registers a span feature.
    
    A span feature is a component that is queried and activated as blocks are
    being parsed into span objects. Thus, a span should accept stretches of
    input text and output a single span object."""
    def impl(cls):
        if not hasattr(cls, "activate"):
            cls.activate = lambda self, span: False
        if not hasattr(cls, "factory"):
            def default_factory(self):
                pass
            cls.factory = element(default_factory)
        cls.factory = property(cls.factory)
        cls = Feature.factory(cls, tags, priority, 'span')
        Registry.add_span(cls)
        if priority is not None:
            cls.priority = priority
        return cls
    return impl

def element(func):
    """HOLYSHITHOLYSHITHOLYSHITHOLYSHIT"""
    def factory(self):
        class Element:
            registry = self.registry
            __init__ = func
        return Element
    return factory #SPIFFY for some reason, having the span decorator make a property out out factory is correct, doing it here is not

def printer(output_format, *handlers):
    """Decorator that registers a printer with handlers for a given output
    format (e.g. html, LaTeX &c)"""
    def impl(func):
        for handler in handlers:
            handler.registry[output_format] = func
        return func
    return impl

# ================== #
# == Input/Output == #
# ================== #

# ==================== #
# == Random Utility == #
# ==================== #

def isempty(line):
    return line and not line.strip()

def peek_set(S):
    for x in S: return x

def re_find(regex_match):
    if not regex_match:
        return None
    else:
        return regex_match.string[regex_match.start():regex_match.end()]

def splitby(iterable, key=identity):
    """Returns a list of sublists. The sublists are non-empty, stable (same
    order as input) subsets of the input iterable such that each element in the
    sublist are equal according to the passed key. The lists are ordered such
    that joining all of them would produce a sorted sequence."""
    ordered = sorted(iterable, key=key)
    acc, last_key = [], None
    for item in ordered:
        this_key = key(item)
        if this_key != last_key:
            acc.append([])
            last_key = this_key
        acc[-1].append(item)
    return acc

def best_in_class(*iterables, key=identity, compare=max):
    for iter in iterables:
        yield compare(iter, key=key)

def intersect(range1, range2):
    return range1[1] > range2[0] or range1[0] < range2[1]



