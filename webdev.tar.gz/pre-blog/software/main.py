#! /usr/bin/python3


#Registry singleton collects all Handler classes, contains a metadata handler
#Handler classes have registries that collect printers
#configuration is setup by an external source, or defaults are used
#a metadata segment is optionally built
#   metadata key/value pairs are formed
#   the metadata handler is looked up for each key
#       the user actually writes a function that returns a parser function
#   the parser is run on the value and the key/parsed value is added to the metadata dictionary
#a parser creates a State object out of the registry
#   the user will have the option to filter Handlers
#   instances of Handler will be created (w/ reference to state obj) and added to the State object's default dispatcher
#as blocks are created, the state object is queried for dispatch
#   only certain handlers have been included in the state: those that match tag requirements (exists A, !exists B)
#   which returns (hopefully) a handler, an amount of the block to act on, and an amount of code to re-buffer to input
#   handlers are all given priority: lowest prioirty gets the gig
#the actionable block is then parsed into a stream of Element objects
#   this may modify the mode &/ mode data
#the handler is queried for a printer that matches the output format, and that printer is executed
#TODO forward references binding
#a postfilter (generally, accepting/returning a string) is run over the output
#the final output is, I dunno, whatever the user does with the metadata, positional segments and named segments

#TODO actually, we should have a list of printers so we can fallback if we don't find a suitable one

#libraries
#   dealing nicely with file i/o in templating use cases
#   how to join lines? do escapes?
#   html printers
#   markdown syntax


#TODO
#we should try to treat metadata as any other plugin
#however, as soon something (metadata or not) gets detected, we remove metadata
#from the registry 


from mk500 import *
from blog import *

# ============ #
# == Parser == #
# ============ #

def parser(pathname, config):
    state = State(config.feature_filter)
    #print(splitby(state.span_features, lambda x: x.priority))
    with FileSource(pathname) as file:
        #while isempty(file.line): file.advance()               #if first line is empty, there's no metadata
        if config.has_metadata:                                        #read/parse metadata
            metadata = dict()
            for key, value in metadata_items(file):
                if key in metadata:
                    raise DoubleMetadataDefinitionError(key)
                metadata[key] = value
            yield metadata
        segments, kwsegments = [[]], dict()
        cur_seg = segments[0]
        while file.line:                          
            while file.line and isempty(file.line):             #advance to content
                file.advance()
            block = []                                          #find physical lines in a block
            while file.line and not isempty(file.line):
                block.append(chomp(file.line))
                file.advance()
            handler, block, leftovers = state.dispatch_block(block)   #find a handler
            file.reverse(leftovers)
            data = handler.parse(block)                         #analyze input into structured data
            if config.output_format not in handler.registry:
                raise MarkdownError("'{}' has no printer for '{}' format.".format(handler.__class__.__name__, config.output_format))
            for elem in handler.registry[config.output_format](data):     #generate output
                cur_seg += expand(config.output_format, [elem])
        for i, seg in enumerate(segments):
            segments[i] = render(config.output_format, state, seg)
        #####################################################TODO postfiltering
        yield segments
        yield kwsegments

def expand(output_format, data):
    acc = []
    while data:
        elem, data = data[0], data[1:]
        if callable(elem):
            acc.append(elem)
        elif isinstance(elem, str) and acc and isinstance(acc[-1], str):
            acc[-1] += elem
        elif isinstance(elem, str):
            acc.append(elem)
        elif hasattr(elem, '__next__'):
            data = list(elem) + data
        else:
            if output_format not in elem.registry:
                #FIXME elem.__class__.__name__ wil always give 'Element'
                raise MarkdownError("'{}' has no printer for '{}' format.".format(elem.__class__.__qualname__, config.output_format))
            printed = elem.registry[output_format](elem)
            if isinstance(printed, str): data = [printed] + data
            else: data = list(printed) + data
    return acc

def render(output_format, state, elements):
    acc = ''
    while elements:
        elem, elements = elements[0], elements[1:]
        if callable(elem):   #reference binding
            elem = elem(state)
            if hasattr(elem, '__next__'): elements = list(elem) + elements
            else: elements = [elem] + elements
        elif hasattr(elem, '__next__'):#generator expansion
            elements = list(elem) + elements
        elif not isinstance(elem, str):#printer lookup
            if output_format not in elem.registry:
                raise MarkdownError("Element '{}' has no printer for '{}' format.".format(elem.__class__.__name__, config.output_format))
            printed = elem.registry[output_format](elem)
            if isinstance(printed, str): elements = [printed] + elements
            else: elements = list(printed) + elements
        else:#must have gotten it down to a string
            acc += elem
    return acc

indent_detector = r'(\s+)'
base_attribute_detector = r'([^\s].*?){}\s*(.*(?:\r?\n|\r|$))'
attribute_detector = {
    None: re.compile(base_attribute_detector.format(r'(:|\s*=)')),
    '=': re.compile(base_attribute_detector.format(r'\s*=')),
    ':': re.compile(base_attribute_detector.format(r':'))
}
def metadata_items(file):
    syntax, tag, acc = None, None, ''
    while True:
        detection = attribute_detector[syntax].match(file.line)
        if not detection: break #wouldn't it be nice to have a do...until?
        if syntax is None:
            tag, syntax, value = detection.groups()
            syntax = syntax.strip()
        else:
            tag, value = detection.groups()
        acc += value
        file.advance()
        indent = re_find(re.match(r'\s+', file.line))           #accumulate indented lines
        if indent:
            while file.line.startswith(indent):
                acc += file.line[len(indent):]
                file.advance()
        if tag:
            yield tag, Registry.metadata(tag)(chomp(acc))
        tag, acc = None, ''


# ========== #
# == Main == #
# ========== #

if __name__ == '__main__':
    _config = Configuration(has_metadata=True,
                           include_features={'article'},
                           exclude_features={'delme'},
                           output_format='html')
    metadata, segments, kwsegments = parser('test', _config)
    print('v'*80)
    print(metadata)
    print('-'*80)
    for seg in segments:
        print(seg)
    print('^'*80)




