#! C:\Python32\python

from cgi.htmlAPI import *

#print("Content-type:text\r\n\r\n")
try:
	vars = {
		'title': "CGI Test Index",
		'content': simple_segment(
			sec(1, "Testing Section",
			"Here's a place where I get to test out what exactly it is that I'm doing before handing it out",
			"(although, I guess it is already handed-out, isn't it?)"
			),
			sec(2, "Text",
			"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus in massa tellus, sit amet accumsan ante. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. In tortor neque, luctus at molestie id, faucibus eu mauris. Proin eget leo at arcu rhoncus congue. Vestibulum eget nisl id magna eleifend convallis ut ac mauris. Sed sit amet enim nunc. Sed pulvinar, nibh ut dignissim pharetra, odio ipsum interdum purus, ac adipiscing mauris mi eget mauris. Quisque sed pellentesque orci. Nullam adipiscing, libero ac molestie malesuada, mi tortor lobortis diam, quis eleifend nulla elit ut nulla. Integer id volutpat sem. In hac habitasse platea dictumst.",
			"Sed bibendum blandit odio nec volutpat. Nunc ut nunc turpis. Aenean tincidunt dui consectetur nulla viverra sit amet sollicitudin enim euismod. Phasellus at justo massa. Aenean condimentum mollis massa, eget euismod orci ultrices non. Nullam at nunc id turpis varius porta. Nullam pellentesque consequat erat, a porttitor nisi ullamcorper eget. Nam et mauris lacus, in laoreet nulla. Phasellus vulputate neque lobortis magna placerat luctus. Fusce sagittis laoreet mi, eu rutrum est tincidunt at. Ut blandit mollis vehicula. Fusce porta faucibus placerat. Donec id gravida risus."
			),
			href('dne', "Unvisited Link"),
			sec(2, "CSS", href('CSSresetTest.html', "CSS Reset")),
			sec(2, "CGI"),
			sec(3, "Very Basic",
			href('cgi/test.py', "CGI Test"),
			href('index.py', "Proof of concept")
			)),
		'quip': "Finding the Tree of Eternity requires many plantings."
	}
	
	
	
	from cgi import arboreum
	from cgi.structab import serve
	serve('index', vars, lambda: arboreum.run())
except Exception as e:
	from traceback import format_exc
	print(format_exc())
	
#