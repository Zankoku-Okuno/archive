
#====================================
#	engine.py
#	alpha v0.2 - 3 Jan 2012
#	Okuno Zankoku
#	- - - - - - - - - - - - - -
#	  This will drive all of the generated code, regardless of
#   language. The object model is essentially a tree: emitters can
#   contain strings or other emitters. Their main function is to
#   (surprise!) emit code in the form of a string, but not until
#   called on to do so. Thus, emitters deep in the structure can
#   be reliable modified, provided you still have access to it.
#     There are two major types of code-organization: sequantial
#   & embedded. Sequential structure is implemented by the emitter
#   class, which allows more code to be added to the end of
#   existing code. Embedded structure is implemented by the
#   templatizer class, which allows code to be inserted at the
#	end, just as the emitter, but also at a user-defined insertion
#	point. Thus, code can also be wrapped around other code.
#	  When writing an api, use of any part of this module is
#	welcome, but when using an api to generate a language document
#	structure, it's best only to use the various serve functions.
#	  The way to use append() & include() is just to put together
#	a comma-separated list of strings, Emitters and iterables. The
#	method automatically delves deep into the structure,
#	flattening it out to the str/Emitter level. Even tuples will
#	be removed, allowing seamless passing from one level of *arg
#	abstraction to the next.
#	TODO:
#		possibly make Emitter inherit str
#		pretty-print: do indents
#		options for printing
#		print out some header comments, too, maybe
#		abstract the empty element placeholder up to the various
#		  serve functions
#====================================

from functools import reduce as fold
from os import getcwd as cwd
from os import path



def strfold(input, adjoiner):
	if not input: return ''
	elif len(input) == 1: return str(input[0])
	else: return str(input[0]) + fold(lambda acc, i: acc+adjoiner+str(i), input[1:], '')

class Emitter:
	def __init__(self, *items):
		self._items = []
		self.append(items)

	def __str__(self):
		#TODO: maybe clean up the output to have a smaller/prettier/configurable output
		return strfold(self._items, '\n')

	def append(self, *items):
		return self.appendAll(items)
	def appendAll(self, items): #deprecated
		if isinstance(items, tuple):
			for item in items:
				self.appendAll(item)
		elif isinstance(items, Emitter) or isinstance(items, str):
			self.items().append(items)
		else:
			for item in items: self.appendAll(item)
		return self
	
	def attach(self, text):
		if not self.items(): return self.append(text)
		else:
			last = self.items()[-1]
			if isinstance(last, str):
				self.items()[-1] += text
				return self
			else:
				return self.items()[-1].attach(text)
	
	def items(self): return self._items

class Templatizer(Emitter):
	def __init__(self, front, back, *internals):
		self._header = Emitter(front)
		self._center = []
		self.include(internals)
		self._footer = Emitter(back)
	
	def __str__(self):
		if not self._center:
			return str(self._header)+"&#160;"+str(self._footer)
		return self.build('\n')
	
	def build(self, adjoiner):
		return adjoiner.join([str(self._header),
						  strfold(self._center, adjoiner),
						  str(self._footer)
						  ])
	
	def include(self, *items):
		return self.includeAll(items)
	def includeAll(self, items): #deprecated
		if items is None: return self
		elif isinstance(items, tuple):
			for item in items:
				self.includeAll(item)
		elif isinstance(items, Emitter) or isinstance(items, str):
			self._center.append(items)
		else:
			for item in items: self.includeAll(item)
		return self

	def items(self): return self._footer.items()

class Tagger(Templatizer):
	def __str__(self):
		if not self._center:
			return str(self._header)+"&#160;"+str(self._footer)
		return self.build('')


