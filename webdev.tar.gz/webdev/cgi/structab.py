# ====================================
#	structab.py
#	alpha v0.1 - 3 Jan 2012
#	Okuno Zankoku
#	- - - - - - - - - - - - - -
#	Short for structural abstraction, the technology behind the
#	Structural Abstraction Sheet, or SAS.
#	TODO: refactor it to be workably readable
# ====================================


import re
from . import engine

class Structure():
	def __init__(self, root):
		self._root = root
	def debug(self, root): #broken feature
		import cProfile
		cProfile.runctx('self.run(root)', {'root': root}, {'self': self}, sort='time')
		print("-->")
	def run(self, root=None): #root is a broken feature
		if root is None: return self._run()
		else:
			temp = self._root
			self._root = root
			self._run()
			self._root = temp
	
	def _run(self):
		return """Content-type:text/html

<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
{0}""".format(self.structure())
		return header+self.structure()

class Variable(engine.Emitter):
	def __init__(self, front, name, back):
		#TODO reject strings (in any param) that include newline
		#TODO reject name that includes back or any whitespace
		super().__init__("{0}{1}{2}".format(front, name, back))


from os import path, getcwd
from time import mktime, gmtime, clock
from datetime import *


def mtime(filename):
	t = path.getmtime(filename)
	return datetime.fromtimestamp(t)

def serve(src, vars, run): #TODO remove dependence on run 1-c-fun
	"check if compilation needed, and compile if so"
	"from a compiled .htwv, make variable replacements"
	"print the result"
	sas = path.join(getcwd(), src+'.py') #TODO: total windows hack
	htwv = path.join(getcwd(), src+'.htwv')
	deb = False
	#TODO this also needs to check if the sas was modified
	if path.exists(htwv):
		if (mtime(sas) - mtime(htwv)).total_seconds() > 2:#seconds
			compile(run(), re.compile(r'<!--sas (.+?) -->'), htwv)
	else:
		compile(run(), re.compile(r'<!--sas (.+?) -->'), htwv)
	import fileinput
	with fileinput.input(files=(htwv,)) as html:
		lineno = -1
		places = []
		for line in html:
			line = chomp(line)
			if lineno == -1:
				if line == "__end__":
					lineno += 1
				else:
					spl = line.split(' ')
					if spl[3] in vars:
						places.append( (
							int(spl[0]),
							int(spl[1]),
							int(spl[2]),
							spl[3]		))
			else:
				i = 0
				while places and lineno is places[0][0]:
					var = places[0]
					places = places[1:]
					print(line[i:var[1]], end='')
					print(vars[var[3]], end='')
					i = var[2]
				print(line[i:])
				lineno+=1

def chomp(s):
    return s[:-1] if s.endswith('\n') else s

def compile(emitter, signature, outfile):
	"from a given emitter, create variable header and append content"
	"""signature is a compiled regex"""
	content = str(emitter)
	f = open(path.join(getcwd(), outfile), 'w')
	lines = content.split('\n')
	for i in range(len(lines)):
		for m in signature.finditer(lines[i]):
			print("{0} {1} {2} {3}".format(
					i, m.start(), m.end(), m.group(1)),
				file=f)
		i+=1
	print('__end__', file=f)
	print(content, file=f)
	



#have a module with a run() function, call it and get back a big-ass emitter
#the emmiter will have <variable>s in it. Write out everything except for
#	the variables, which get replaced by "<!--sas [varname] -->"
#go through the text and find all places (line, colstart, colend) where
#	variables are renamed
#store those places at the top of the output file
#write a quick end-of-places delimiter
#store everything else immediately after that as generated
#the filename of the output should be the same as the input, but the extension
#	changed to .sas instead of .py (or whatever language you're writing in , I guess)

#the user goes to cgi scripted page, which does exactly one thing:
#make sure the .py is older than the .sas, if not, re-generate the .sas
#read in the places for replacement to a data structure
#print everything after the delimiter line-by-line, making replacements as dictated
#	by the data structure
#and the page should be generated (but be sure to actually pass in variables)