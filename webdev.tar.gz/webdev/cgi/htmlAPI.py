#====================================
#	htmlAPI.py
#	alpha v0.2 - 3 Jan 2012
#	Okuno Zankoku
#	- - - - - - - - - - - - - -
#	  This is an api suited for generating (x)html code. The
#	structure of a document using this api is likely to have a
#	similar structure to that of html itself.
#	  This module does not directly generate code, but rather
#	creates and returns objectsto the user.Of particular note are
#	a few methods of these generated objects:
#	 * append(*items):
#		This adds objects to the end of the object. The items may
#		be tuples, lists, string or Emitters, the method handles
#		flattening it out.
#	 * include(*items):
#		These put code into the relevant middle of the generated
#		object. The items are as in append().
#		Note that they aren't supported on every object: wherever
#		it doesn't make sense, pretty much.
#	 * attach(text):
#		Unlike append/include, attach does not create any document
#		structure. Instead, it attaches the passed string directly
#		to the last, deepest (therefore, string) object in the
#		structure.
#	TODO:
#		more internal validation features
#		more table features
#		support multiple types of nested list
#====================================

from .engine import Emitter
from .engine import Templatizer
from .engine import Tagger
from .structab import Variable


def var(varname):
	return Variable("<!--sas ", varname, " -->")

# ========================
#    HTML Tag Factories
# ========================
def _tagInfo(tagname, pairs):
	return "<{t}{a}".format(
			t=tagname,
			a=''.join([" {k}='{v}'".format(
				k=pair[0], v=pair[1]) for pair in pairs]
			))
def _tagDone(tagname):
	return "</{t}>".format(t=tagname)
#TODO allow direct insertion of items
def elem(tagname, *interior, pairs=[]):
	return Templatizer(_tagInfo(tagname, pairs) + ">",
					   _tagDone(tagname)
					).include(interior)
def ntag(tagname, pairs=[]):
	return Emitter(_tagInfo(tagname, pairs) + "/>")
def iltag(tagname, *interior, pairs=[]):
	return Tagger(_tagInfo(tagname, pairs) + ">",
				  _tagDone(tagname)
				).include(interior)
	
def cssAttr(id=None, cl=None, st=None):
	out = []
	if id: out.append(("id",id))
	if cl: out.append(("class",cl))
	if st: out.append(("style",st))
	return out

# --- Not actually a tag, but hey... --- #
def simple_segment(*items): return Emitter(items)

# ========================
#    Basic Structurals
# ========================
def html(header, *contents):
	"""Creates the html document object itself.
	header: semantically, the html header element. Use the head() function (or something similar) to fill this in.
	*contents: any elements you wish to display on the page (insert into the body)
	"""
	return elem("html",
				header, body(contents),
				pairs=[("xmlns", "http://www.w3.org/1999/xhtml")]
			)
def htmlProf(header, *contents):
	"""Creates the html document as in @see html(), but add an open comment marker to the end of the stream: remember to close it off for validity.
	"""
	return html(header, contents).append("<!--")

def head(title, stylesheets=[], favicon='favicon'):
	"""Generates a head element for your html document.
	title: the name to be displayed on tabs/top of windows/bookmarks/&c
	stylesheets: a list of stylesheets to be used, automatically formated "to css/NAME.css"
	favicon: the file name of a favicon, TODO: load multiple formats, but for now it's a .png
	"""
	return elem("head",
			ntag("meta", pairs=[
				("http-equiv", "Content-Type"),
				("content", "text/html; charset=UTF-8")
			]),
			"<title>{0}</title>".format(title),
			"<link rel='icon' href='{0}.png' type='image/png'/>".format(favicon),
			[
				"<link rel='stylesheet' href='css/{0}.css' type='text/css'/>".format(css)
				for css in stylesheets
			]
	)

def body(contents):
	return elem("body", contents)

def div(*contents, id=None, cl=None, st=None):
	"""Creates a div element which can be css-formatted with id&/class&/style
	using the id, cl, and st parameters, respectively.
	Resist the temptation to generate inline styles throughout documents.
	"""
	return elem("div", contents, pairs=cssAttr(id,cl,st))
def span(*contents, id=None, cl=None, st=None):
	"""Creates a span element which can be css-formatted with id&/class&/style
	using the id, cl, and st parameters, respectively.
	Resist the temptation to generate inline styles throughout documents.
	"""
	return iltag("span", contents, pairs=cssAttr(id,cl,st))

def href(url, display, target=None):
	"""Creates a hyperlink.
	url: the resource to link at
	display: the text/image that appears (though I guess it could be any element)
	target: as the html target attribute, if set
	"""
	return iltag("a", display,
				pairs=[("href",url)] + \
					([("target",target)] if target else [])
	)

# ========================
#      Text Creation
# ========================

def h(level, title):
	"""Creates a heading.
	level: lower numbers are larger headings; SEO wisdom dictates only use 0-level (biggest heading) once per page
	title: single object to display
	"""
	return iltag("h{0}".format(level+1), title)
	#TODO figure out how to validate the title
	#first-class-functions! weee! let the engine take in a function and use it to validate; now it's only tricky
	#???perhaps gamble on the chance that internal entities are the only ones that need to be validated

def p(*items):
	"""Creates a paragraph.
	*items: elements to include in the paragraph
	"""
	return iltag("p",
		[ _internal_validation(item) if isinstance(item, str) \
		 else item for item in items ]
	)

#TODO think about this! why only strings? not emitters?
def _internal_validation(text):
	import re
	return re.sub('&', '&#38;', text)
	#TODO expand validation

# ========================
#       Text Layout
# ========================

def sec(level, title, *pars):
	"""Automatically creates a section heading and add paragraphs afterwards. Note that sections are not a tree: they operate more like the LaTeX section macro, but offer some handiness for dealing with the limitations of html semantics.
	level & title: as in @see h()
	*pars: any paragraphs included in this section
	"""
	return h(level, title).append([p(par) for par in pars])

def br(*items):
	"""Puts a line break after each passed item. Used with no items, it simply adds a line break. Note that this function directly modifies the code string, so careful!
	*items: objects to decorate with line breaks
	"""
	if items: return Emitter(
		[ item+br() if isinstance(item, str) \
					else item.attach(br()) for item in items ])
	else: return "<br/>"


# ========================
#         Images
# ========================

def img(x, y, src, url=None, target=None):
	#TODO add alt-text support
	"""Creates an image. Good practices are enforced.
	x, y: width & height of the image, respecively
	src: name of the file in the img/ folder to display; automatically a png if no other extension is given
	url: when set, creates a image-hyperlink
	target: as target for @see href(); if set, url must also be set (the developer screwed up and I'm letting him know)
	"""
	assert not target or url, "Target passed to img, but no href specified."
	if url:
		return href(url, img(x,y, src), target)
	else:
		return ntag("img", pairs=[
						("src", "img/"+src + (".png" if '.' not in src else "")),
						("height", y),
						("width", x),
						("alt", "TODO")
					])
def antipixel(src, url=None, target=None):
	"""Creates a 15x80 antipixel/micro-banner.
	src, url & target: as in @see img()
	"""
	#TODO modify with still so mouse-over is glossed, click is darkened
	return img(80,15, 'antipixel/{0}'.format(src), url=url, target=target)


# ========================
#          Lists
# ========================

#TODO support more list types

def treeulist(tree): #TODO refactor to treeulist
	"""Given a (possibly nested) list of elements, put them all in a (just as possibly nested) list"""
	return elem("ul", [ nodeulist(node) for node in tree ])
def nodeulist(node):
	return iltag("li",
		[ treeulist(node) if isinstance(node, list) else node ]
	)

# ========================
#          Tables
# ========================

#TODO support table headers/footers
#TODO figure out colspan stuff

def table(input, id=None, cl=None, st=None):
	"""Supply a 2D nested list.
	The first level becomes rows, the second level becomes cells"""
	return elem("table",
				[ iltag("tr").includeAll(
					[ iltag("td").include(cell) for cell in row ]
				) for row in input ],
			pairs=cssAttr(id,cl,st)
	)












	








def strut(x=0,y=0,units='px'):
	return div(st=("height:{0}{1};".format(y, units) if y else '') + \
				  ("width:{0}{1};".format(x, units) if x else ''))

	

	

	