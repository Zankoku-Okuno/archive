#! C:\Python32\python

import re

print("Content-type:text/html\r\n\r\n")

print("""
<html><head></head><body>
{l}<br/>
{name}
</body></html>""".format(
	name = __name__,
	l = len(re.sub(r'[ ,\.]', '', "tellus, sit amet accumsan ante. Class aptent taciti sociosqu ad litora torquent per "))-66
))