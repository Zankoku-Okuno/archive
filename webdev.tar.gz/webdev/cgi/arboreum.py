

from . import engine
from .htmlAPI import *
from .structab import Structure






def run():
	return Arboreum().run()

class Arboreum(Structure):
	def __init__(self):
		super().__init__(html)
	def structure(self):
		return self._root(
			head(var('title'), stylesheets=['fonts', 'reset', 'arboreum']),
			div(id='backing'), div(id='box').include(
			self.titlebar(),
			docstring(),
			sidebar(),
			bioesquebar(),
			div(id='signature').include(img(100,100, 'white-seal.png')),
			content_pane(),
			div(id='tagline', cl='meany').include(br(
				"This page created in {0} seconds".format('<!--sas __runtime__ -->'),
				"More info",
				href("https://sites.google.com/site/okulang", "okulang"),
				"More info"
			)),
			"&#160;"
		))
		
	def titlebar(self):
		return div(id='titlebar').include(
			sec(0, "Arboreum", var('title'), " - Zankoku Okuno"),
			table(linksBuilder(
				['Okucore', 'Corpus', 'Okunlang', 'test'],
				['index.html',
				 'www.google.com',
				 'http://sites.google.com/site/Okulang',
				 '']
			)) )
		
	
def sidebar():
	return div(id='sidebar',cl='movey').include(
				navigation(),
				in_the_life(
					"Some stuff during a day happend a while ago.",
					"Content! Weeeee! Weeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee!"
			))

def content_pane():
	return div(id='content', cl='meany').include(var('content'))

def bioesquebar():
	return div(id='info').include(
			img(100,100, 'CMBRPortrait2Avatar.gif'),
			strut(y=15),
			br(antipixel('hand-code', url='cgi/test.py'),
			antipixel('python32'),
			antipixel('xhtml11'),
			antipixel('photoshop'),
			antipixel('apache')
		))



def linksBuilder(names, links):
	"takes two lists of equal length"
	out = [[], [], []]
	for i in range(min(len(names), len(links))):
		out[i%3].append(href(links[i], names[i]))
	return out

def docstring():
	return div(id="docstring-top").append(
		div(id="docstring").include(var('quip')),
		div(id="docstring-bottom")
	)

def navigation():
	return div().include(
		sec(1, "Navigation"),
			treeulist([
				"Abble",
				"Beal", [
					"1ne",
					"2wo"
				],"Clap"
			])
	)

def in_the_life(*posts):
	return div().include(
		sec(1, "In the Life", posts))
