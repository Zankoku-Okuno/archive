Izumi
=====

Izumi will be a programming language targeting the C level of abstraction, injecting the most useful programming techniques of the last several decades into a systems programming language with a minimum of fuss and magic.

Requirements
============

 * python3 interpreter (for bootstrapping)

Features
========

 * Strong typing
 * Compile-time overloading
 * Modular programming (ala ML)
 * Clear, uniform syntax
 * Bounded and dynamic arrays
 * No pointer arithmetic

Project Status
==============

It's pretty much all in the future. Step one is to hack together a simple Python implementation of the Izumi compiler frontend. As I do that, I'm deciding on how to handle the backend. Later, I will port it (with improvements) into Izumi itself. Finally, add libraries.
