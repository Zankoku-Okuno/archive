/*
 *  dialect.h
 *  This file is part of Izumi.
 *  Copyright (c) 2013, Okuno Zankoku
 *  All rights reserved. 
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice, this 
 *  list of conditions and the following disclaimer.
 *
 *  Redistributions in binary form must reproduce the above copyright notice,
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 *
 *  Neither the name of Okuno Zankoku nor the names of contributors may be used
 *  to endorse or promote products derived from this software without specific
 *  prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY OKUNO ZANKOKU "AS IS" AND ANY EXPRESS OR
 *  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 *  EVENT SHALL OKUNO ZANKOKU BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 *  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 *  ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef __IZUMI_DIALECT_H__
#define __IZUMI_DIALECT_H__

#include <assert.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "dialect/types.h"

// ====== Simple Stuff ======

/** Cuts down on a few characters. Same as else if. */
#define elif else if
/** Signals to the human that this conditional should not have an else clause. */
#define when if
/** Inverse of when. */
#define unless(cond) if(!(cond))

/** Explicit null statement. */
#define pass (void)0


// ====== For Human Eyes Only ======

#define FIXME
#define TODO
#define STUB
#define OPTZ
#define HAX
#define REFAC


// ====== Meta-macros ======

#define TOKENPASTE_IMPL(x, y) x ## y
#define TOKENPASTE(x, y) TOKENPASTE_IMPL(x, y)

/** Ensure that statement-y macros won't screw up the parser. */
#define MACRO_STATEMENT(...) \
    if (true) { __VA_ARGS__ } \
    else pass

/** Support new keywords that introduce blocks of code that can be broken out of. */
#define done while(0)

// ====== Errors ======

/** Print a message to stderr and die. */
#define error(msg, ...) MACRO_STATEMENT(\
    fprintf(stderr, msg, __VA_ARGS__);\
    abort();\
)

/** Mark unreachable/unimplemented sections of code cause loud failure. */
#define unreachable error("%s:%d -- unreachable code\n", __FILE__, __LINE__)

//TODO a more confgable msg, automatically fill url
#define unimplemented(url) error(\
    "Unimplemented: %s,%d.\n\tPlease help us by contributing at %s.\n",\
    __FILE__, __LINE__, url)

// ====== Loop Constructs ======

/** A loop that continues forever, or until broken. */
#define loop while(true)

/** Early exit from a loop. */
#define until(cond) if (!(cond)) break;

#define repeat(name, start, term) \
    for(int name = start, TOKENPASTE(_end, __LINE__) = term;\
        name < TOKENPASTE(_end, __LINE__);\
        ++name)


// ====== Goto Constructs ======

/** Cases that don't fall through.
    Between this, \c otherwise and \c fallinto, \c case and \c default are deprecated.
*/
#define match break; case
/** Flag for the human to realize that the next case can be fallen into.
    Between this and \c fallinto, bare \c default is deprecated.
*/
#define otherwise break; default
/** Flag for the human to realize that the next case can be fallen into.
    Between this and \c match, \c case is deprecated.
*/
#define fallinto

/** Define an exitwhen block.
    Multiple exit was introduced by Charles Zahn in 1974, and has somehow not been introduced in
    any language I know of, despite its utility.
    In this implementation, any statements may be executed in the body of the exitwhen.
    A break in the body escapes from the block without performing any whenexit action.
*/
#define exitwhen do
/** Exit from an exitwhen to the given whenexit label. */
#define exitto(l) goto l
/** Introduce a section of code to execute on a particular exit state.
    There is no fallthrough from one whenexit to the next.
*/
#define whenexit(l) break; l:;

/*
I want fallthrough!

if (...) {          if (...) {
    ...                 ...
    fallthrough;        goto _f1;
}                   }
else {              else {
    ...                 _f1: ...
}                   }


*/

/* I want loop-then-else
while(...) {    while(...) {}
    ...             ...
    break;          goto loopthen;
}               }
then {          {
    ...2            ...1
}                   goto loopend;
else {          }
    ...1        loopthen: {
}                   ...2
                } loopend:
*/


#endif