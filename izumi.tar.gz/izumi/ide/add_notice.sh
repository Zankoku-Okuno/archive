FILEPATH=$1
FILENAME=`echo $FILEPATH | sed 's/.*\///'`

cat ide/copyright $FILEPATH | sed s/@@FILENAME@@/$FILENAME/ > ide/.tmp && mv ide/.tmp $FILEPATH