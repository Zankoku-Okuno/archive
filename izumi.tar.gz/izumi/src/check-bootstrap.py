from bootstrap.ops import *
from bootstrap.lexer import *
from bootstrap.parser import *

operators = OpTable()
operators.prefix('!', 'fac')
operators.infix('!', 'index', 'r')
operators.infix('|', 'lor', 'r')
operators.infix('+', 'add', 'r')
operators.suffix('++', 'inc')
operators.circumfix('|', '|', 'abs')

print('='*12, 'Lexer OpTable', '='*12)
for op in operators.lexer_table:
	print(op)

print('='*12, 'Lexer', '='*12)
for tok in lex('test/lexer', operators):
	print(tok)

print('='*12, 'Parser', '='*12)
try:
	parser = Parser(operators, lex('test/parser', operators))
	print(parser.parsePass())
except IzumiParserError as ex:
	print(ex)


print('='*12, 'Done', '='*12)