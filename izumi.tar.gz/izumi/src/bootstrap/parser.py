from functools import partial

always = lambda x: True
def eq(x): return lambda x, y: x==y

class IzumiParserError(Exception):
	def __init__(self, expecting):
		super().__init__()
		self.expecting = expecting
	def __str__(self):
		acc = "Syntax error in file %s: expected" % self.expecting[0][1][0]
		for expect in self.expecting:
			if expect[0]:
				acc += "\n   `%s' on line %d col %d" % (expect[0], expect[1][1], expect[1][2])
		return acc

class Parser:
	def __init__(self, operators, tokens):
		self.operators = operators
		self.tokens = tokens
		self.position = 0
		self.expecting = [[]]
		self.available_control_structures = { partial(self.parsePass) }
		self.backtracks = []

	# ==================
	# === Primitives ===
	# ==================
	def test(self, kind=None, data=always, expect=''):
		tok = self.tokens[self.position]
		if (kind is None or kind == tok.kind) and data(tok.data):
			self.position += 1
			return tok
		else:
			raise IzumiParserError( [(expect, self.loc)] )

	def mark(self):
		state = (self.position, frozenset(self.available_control_structures))
		self.expecting.append([])
		return state
	def succeed(self):
		self.expecting.pop()
		return None
	def fail(self, state):
		self.position = state[0]
		self.available_control_structures = set(state[1])
	def alt(self, *choices, expecting=''):
		backtrack = self.mark()
		for choice in choices:
			try:
				choice()
			except IzumiParserError as ex:
				self.expecting[-1] += ex.expecting
				self.fail(backtrack)
			else:
				self.success()
				break
		else:
			if expecting:
				self.expecting[-1].append( (expecting, self.loc) )
			raise IzumiParserError( self.expecting.pop() )

	@property
	def loc(self):
		tok = self.tokens[self.position]
		return tok.file, tok.line, tok.col

	# ===============
	# === Parsers ===
	# ===============

	def parsePass(self):
		return self.test(kind='id', data=lambda x: x == 'pass', expect='pass')