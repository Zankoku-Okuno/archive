import re

def common_validate(manifest, realize):
	for x in manifest:
		if x not in '~!%^&*-+=|?<>':
			raise Exception("Bad operator manifestation.")
	if not re.match(r'^[a-zA-Z_][a-zA-Z_0-9]+$', realize):
		raise Exception("Bad operator realization.")

class OpTable:
	def __init__(self):
		#these sets all contain tuples: (<manifestation : str>, <realization : str>, <associativity>)
		#where the frontend recognizes manifestations and translates them into calls to the (possibly overloaded) realization
		#except for circumfixes, whole manifestation is a pair of strings
		self.prefixes = set()
		self.infixes = set()
		self.suffixes = set()
		self.circumfixes = set()

	def prefix(self, manifest, realize):
		common_validate(manifest, realize)
		#TODO cannot be a circumfix start
		self.prefixes.add((manifest, realize, ''))
	def infix(self, manifest, realize, assoc):
		common_validate(manifest, realize)
		self.infixes.add((manifest, realize, assoc))
	def suffix(self, manifest, realize):
		common_validate(manifest, realize)
		#TODO cannot be a circumfix end
		self.suffixes.add((manifest, realize, ''))
	def circumfix(self, manifest_start, manifest_end, realize):
		common_validate(manifest_start+manifest_end, realize)
		#TODO manifest end cannot be a prefix
		#TODO manifest end cannot be a suffix
		self.circumfixes.add(((manifest_start, manifest_end), realize, ''))

	@property
	def lexer_table(self):
		fst, snd = lambda x: x[0], lambda x: x[1]
		acc = ( set(map(fst, self.prefixes))
			  | set(map(fst, self.infixes))
			  | set(map(fst, self.suffixes))
			  | set(map(lambda x: fst(fst(x)), self.circumfixes))
			  | set(map(lambda x: snd(fst(x)), self.circumfixes))
			  )
		return sorted(acc, key=len, reverse=True)