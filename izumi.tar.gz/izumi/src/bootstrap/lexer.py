import re

identity = lambda x: x

class Loc:
    def __init__(self, file, line, col):
        self.file = file
        self.line = line
        self.col = col
        self.leading_ws = True

    def adv(self, data):
        for c in data:
            if c in {'\n', '\r'}:
                self.line += 1
                self.col = 1
            else:
                self.col += 1
        self.leading_ws = bool(data and data[-1] in {' ', '\n'})

class Token:
    def __init__(self, kind, data, loc):
        self.kind = kind
        self.data = data
        self.file = loc.file
        self.line = loc.line
        self.col  = loc.col
    def __str__(self):
        return "<Token: %s `%s' at `%s' %d:%d>" % (self.kind, str(self.data), self.file, self.line, self.col)

def match(regex, stream):
    m = re.match(regex, stream)
    if m is None:
        return '', stream
    else:
        s, e = m.span()
        return stream[s:e], stream[e:]


def lex(filename, operators):
    return list(_lex(filename, operators.lexer_table))
    #TODO normalize float literals
def _lex(filename, operators):
    with open(filename, "rt") as f:
        stream = f.read()
    loc = Loc(filename, 1, 1)
    while stream:
        # get rid of leading whitespace
        m, stream = match(r'([ \n]*(#[^\n]*\n?)?)*', stream)
        loc.adv(m)
        if not stream: break
        # go through the token matcher-handlers until one hits
        for regex, kind, f in _token_regexes:
            m, stream = match(regex, stream)
            if m:
                yield Token(kind, f(m), loc)
                loc.adv(m)
                break
        else:
            in_prefix_context = loc.leading_ws
            acc = []
            while re.match(r"[~!%^&*+=|?<>-]", stream):
                for op in operators:
                    if stream.startswith(op):
                        acc.append(op)
                        stream = stream[len(op):]
                        break
                else: break
            in_suffix_context = re.match(r'\s|$', stream)
            if acc and in_prefix_context and not in_suffix_context:
                kind = 'prefix'
            elif acc and not in_prefix_context and in_suffix_context:
                kind = 'suffix'
            elif len(acc) == 1:
                kind = 'infix'
            else:
                raise Exception("Lexer error in %s, line %d:%d." % (loc.file, loc.line, loc.col))
            for op in acc:
                yield Token(kind, op, loc)
                loc.adv(op)
        

def _decode_str(data):
    acc = []
    while data:
        if data[0] == '\\':
            if data[1] in 'uU':
                acc.append(int(data[2:6], 16))
                data = data[6:]
            elif data[1] in 'xX':
                acc.append(int(data[2:8], 16))
                data = data[8:]
            elif data[1] in 'abfnrt\\\'"':
                acc.append(ord({'a':'\a','b':'\b','f':'\f','n':'\n','r':'\r','t':'\t','\\':'\\','\'':'\'','"':'"'}[data[1]]))
                data = data[2:]
            elif data[1] in '0123456789':
                acc.append(int(data[1:3], 16))
                data = data[3:]
            else: raise Exception("String syntax error: `%s'" % data)
        else:
            acc.append(ord(data[0]))
            data = data[1:]
    return acc

def _decode_float(data):
    whole, frac = data.split('.')
    if 'e' in frac:
        frac, exp = frac.split('e')
    elif 'E' in frac:
        frac, exp = frac.split('E')
    else: exp = '0'
    whole, frac, exp = int(whole), int(frac), int(exp)
    return whole, frac, exp
def _decode_hex_float(data):
    data = data[2:]
    whole, frac = data.split('.')
    if 'h' in frac:
        frac, exp = frac.split('h')
    elif 'H' in frac:
        frac, exp = frac.split('H')
    else: exp = '0'
    whole, frac, exp = int(whole, 16), int(frac, 16), int(exp, 16)
    return whole, frac, exp

# here are some token matcher-handlers (all excepting operators, which are dynamic anyway)
_token_regexes = [
            (r'[a-zA-Z_][a-zA-Z_\d]*',   'id',             identity),
            (r'0[xX][0-9a-fA-F]+\.[0-9a-fA-F]+([hH][+-]?[0-9a-fA-F]+)?',
                                         'flo', _decode_hex_float),
            (r'0[oO][0-7]+\.[0-7]+',     'flo', lambda x: (int(x.split('.')[0][2:], 8), int(x.split('.')[1], 8), 0)),
            (r'0[bB][01]+\.[01]+',       'flo', lambda x: (int(x.split('.')[0][2:], 2), int(x.split('.')[1], 2), 0)),
            (r'\d+\.\d+([eE][+-]?\d+)?', 'flo', _decode_float),
            (r'0[xX][0-9a-fA-F]+',       'int',  lambda x: int(x[2:], 16)),
            (r'0[oO][0-7]+',             'int',  lambda x: int(x[2:], 8)),
            (r'0[bB][01]+',              'int',  lambda x: int(x[2:], 2)),
            (r'\d+',                     'int',            int),
            (r'::',                      'punc',           identity),
            (r'[()\[\]{},.;:]',          'punc',           identity),
            (r"'[ -~]'",                 'char', lambda x: ord(x[1])),
            (r"'\\[abfnrt\\\'\"]'",      'char', lambda x: ord(x[1])),
            (r"'\\[0-9a-fA-F]{2}'",      'char', lambda x: int(x[2:-1], 16)),
            (r"'\\[uU][0-9a-fA-F]{4}'",  'char', lambda x: int(x[3:-1], 16)),
            (r"'\\[xX](10|0[0-9a-fA-F])[0-9a-fA-F]{4}'",
                                         'char', lambda x: int(x[3:-1], 16)),
            (r'"([\n\t !#-\[\]-~]|\\[abfnrt\\\'\"]|\\[0-9a-fA-F]{2}|\\[uU][0-9a-fA-F]{4}|\\[xX](10|0[0-9a-fA-F])[0-9a-fA-F]{4})*"',
                                         'str', lambda x: _decode_str(x[1:-1])),
        ]