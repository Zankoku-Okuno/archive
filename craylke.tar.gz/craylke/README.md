# Craylke

The Craylke will be a new ISA and architecture with a cycle-accurate simulator. Well, considering there's no real-world version, 'cycle-accurate simulator' may be too strong a phrase, but the point is that I'll be working at the level of individual cycles.

The most fun part is that the design will be based primarily on the Cray-1 and friends. That is, it will be primarily batch-processing with address, scalar and vector registers. A secondary bank of registers serves as a sort-of manually managed cache system, but memory will otherwise not be hierarchical. On the other hand, I'm not intending to remain faithful to the roiginal designs. Likely new features are memory segmentation and protection, and operations on sub-words.

First priority is to get a working processor and I/O system, even something simple and incomplete. Then, I'll write a cross-assembler (probably in Scheme) and develop test applications as I flesh out the processor and I/O. After that, I figure I'll write a bootloader and a simple kernel for the Craylke. After porting the assembler, I'm liable to build a Lisp, and then a compiler, and from there, the sky's the limit!

## Goals

First and foremost: compute like it's 1969!

The hardware will have scalar and vector compute capabilities, relatively limited memory, and channel I/O. For it's target time, I'd like to hit supercomputer performance. That is, I'm looking to run at 80MHz with at least 2 flops per cycle sustained.

The operating system will be mostly batch-processing. The kernel will periodically interrupt the compute process and possibly schedule in a support process. Best of all, the vector processing unit will not be interrupted by kernel and interactive processes.

System processes will include a kernel, filesystem, assembler and shell, all running on the machine itself.

I'm even trying my best to use terminology that sounds 50 years old!

## But Why?

I've always wanted to build a simulator for a computer, and reading up on Cray's designs have given me a bit of inspiration.

Of course, this is a terrible reason to go out and spend man-months on a project, so I'll be only slowly working on this.

But hey, the more practice coding stuff, the better. I'm likely to come up with some new ideas as I build this thing, and I'll be a better programmer for it. At the very least, I'm sure that writing the system-level programs will teach me more than I ever thought I could know about systems programming.

## The Once and Future Status

I refuse to make any plans, predictions or promises until I have a behavoiral simulator.
