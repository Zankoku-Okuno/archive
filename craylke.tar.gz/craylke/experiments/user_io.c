#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <ncurses.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

typedef unsigned char byte;
typedef signed char ascii;

//never set both rdy and ack. when in critical section, both are zero. when waiting for input, rdy low. when ready for more input, ack high
typedef struct {
    bool rdy;
    bool ack;
    uint64_t data;
} SimplexChan;

int TERM_WIDTH = 80, TERM_HEIGHT = 24;
static SimplexChan keyboard = { .rdy = 0, .ack = 1, .data = 0 };
static WINDOW* terminal;

void* keyboard_driver(void* arg) {
    wchar_t input;
    while(true) {
        //block until we have input
        input = getch();
        if (input < 0) continue;
        if (keyboard.ack) {
            if (input < 128)
                keyboard.data = input;
            else {}
            keyboard.ack = false;
            keyboard.rdy = true;
        }
    }
} 

void die(char* blurb) {
    endwin();
    fprintf(stderr, "Craylke: ABORT!\n%s\n", blurb);
    exit(-1);
}

void term_start() {
    //initialize ncurses
    initscr();
    int x, y; getmaxyx(stdscr, y, x);
    if ((x < TERM_WIDTH + 2) | (y < TERM_HEIGHT + 4))
        die("Host terminal too small -- needs at least 82x28.");
    //configure ncurses
    //raw();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);
    //draw the Craylke maintenence console
    int x0 = (x-TERM_WIDTH)/2
      , y0 = (y-TERM_HEIGHT)/2;
    {
        //first, the marketing
        move(y0-2, x0);
        attron(A_BOLD);
        printw("Craylke %s", "zero");
        attroff(A_BOLD);
        move(y0+TERM_HEIGHT+1, x0+TERM_WIDTH/2-19);
        printw("Maintenance Console");
        move(y0+TERM_HEIGHT+1, x0+TERM_WIDTH-7);
        printw("s/n ???");
        //then, the monitor box
        terminal = newwin(TERM_HEIGHT+2, TERM_WIDTH+2, y0-1, x0-1);
        box(terminal, 0, 0);
        refresh();
        wrefresh(terminal);
    }
    //create the real window we'll use for the console
    terminal = newwin(TERM_HEIGHT, TERM_WIDTH, y0, x0);
    wrefresh(terminal);
    //start keyboard simulator
    pthread_t tid;
    if (pthread_create(&tid, NULL, keyboard_driver, NULL))
        die("Failed to create keyboard thread.");
}

/**
 * Move cursor on Craylke terminal to (x,y) coordinates.
 * return: true on success, false on error
 * error: x or y out of bounds
 */
bool term_position_cursor(int x, int y) {
    if ((0 <= x) & (x < TERM_WIDTH) & (0 <= y) & y < TERM_HEIGHT) {
        wmove(terminal, y, x);
        return true;
    } else return false;
}

int main(int argc, char** argv, char** envp) {
    term_start();

    char input;
    sleep(1);
    while(true) {
        if (keyboard.rdy) {
            waddch(terminal, (byte)keyboard.data);
            keyboard.rdy = false;
            keyboard.ack = true;
            wrefresh(terminal);
        }
        sleep(1);
    }
}
