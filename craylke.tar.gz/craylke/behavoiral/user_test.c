#include "include.h"
#include "mcu.h"

int main () {
	Simplex64 *channels[24];
	mcu_init(&channels[0], &channels[1]);

	uint64_t input;
	forever {
		if (!chan_s64_read(&input, channels[0])) continue;
		if (chan_s64_write(channels[1], input)) tick_screen();
	}
}