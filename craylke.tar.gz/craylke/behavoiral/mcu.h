/**
 * The "Maintenence Control Unit" (MCU) provided the Craylke user with a visual interface to control the system state.
 * 
 * This module provides console emulation (screen, keyboard and hardware buttons) for the MCU.
 */
#ifndef MCU_H
#define MCU_H
#include "include.h"
#include "channel.h"

/**
 * Call this to start the terminal and keyboard
 * out: 64-bit simplex channels for keyboard and terminal
 */
void mcu_init(Simplex64** keyboard, Simplex64** terminal);

/**
 * Send a clock signal to update the screen.
 */
void tick_screen(void);

#endif