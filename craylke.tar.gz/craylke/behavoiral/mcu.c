#include <time.h>
#include <ncurses.h>
#include <pthread.h>
#include "channel.h"

#define TERM_WIDTH 80
#define TERM_HEIGHT 24

static char* screen_err = "Failed to create terminal emulator.";
static char* small_screen = "Host terminal too small -- needs at least 82x28.";
static char* keyboard_err = "Failed to create keyboard emulator.";

static WINDOW* main_window = NULL;
static Simplex64* _keyboard = NULL;
static Simplex64* _screen = NULL;


/* ============ Hardware ============ */

void term_moverel(int dx, int dy) {
    int x, y;
    getyx(main_window, y,x);
    wmove(main_window, y+dy,x+dx);
}
void term_moveabs(byte dx, byte dy) {
    int x, y;
    getyx(main_window, y,x);
    if (dx < TERM_WIDTH) x = dx;
    if (dy < TERM_HEIGHT) y = dy;
    wmove(main_window, y,x);
}

void tick_screen(void) {
    assert(main_window);
    uint64_t data;
    if (!chan_s64_read(&data, _screen)) return;
    //8-byte control sequences begin with zero byte 8-byte aligned
    if (byten(0, data) == 0) {
        signed char x, y;
        switch (byten(1, data)) {
            case 0x01: //relative cursor movement
                x = byten(2, data); y = byten(3, data);
                term_moverel(x, y);
                break;
            case 0x02: //absolute cursor movement
                x = byten(2, data); y = byten(3, data);
                term_moveabs(x, y);
                break;
            default: break;
        }
    }
    //normal mode: write printable characters until first zero byte
    else {
        ascii output;
        for (uint i = 0; i < 8; ++i) {
            output = byten(0, data); data = nextbyte(data); //read off first character
            if (output < 0) pass; //ignore 8-bit characters
            elif (output == 127) wdelch(main_window); //delete character under cursor
            elif (output >= 32) { //printing character
                winsch(main_window, output);
                term_moverel(1, 0);
            }
            else switch(output) { //control characters
                case 0: return; //a zero byte ends character printing from this word
                case '\b':
                    term_moverel(-1, 0);
                    wdelch(main_window);
                    break;
                case '\n':
                    term_moverel(0, 1);
                    term_moveabs(0, 0xff);
                    break;
                //TODO handle more control characters
                default: break;
            }
        }
    }
}

uint64_t keyboard_signals(uint input) {
    if ((32 <= input) & (input <= 0xff))
        return input;
    switch (input) {
        case '\b': fallthru;
        case KEY_BACKSPACE: return '\b';
        case 27:            return 27; //TODO how can I use escape?
        case '\n': fallthru;
        case KEY_ENTER:     return '\n';
        case KEY_DC:        return 127;
        case KEY_LEFT:      return 0x00ff0100;
        case KEY_RIGHT:     return 0x00010100;
        case KEY_UP:        return 0xff000100;
        case KEY_DOWN:      return 0x01000100;
        case KEY_HOME:      return 0xff000200;
        case KEY_END:       return 0xff4f0200;
        case KEY_PPAGE:     return 0x00ff0200;
        case KEY_NPAGE:     return 0x17ff0200;
        case '\t':          return '\t';
        default: wprintw(main_window, "%d", input); return 0;
    }
}


/* ============ Initialization ============ */

void start_ncurses(void) {
    initscr(); //FIXME use newterm so I can check for errors myself
    // raw();
    cbreak();
    nl();
    noecho();
    set_escdelay(25);
    keypad(stdscr, TRUE);
}
void draw_screen(int x, int y) {
    //Craylke name
    move(y-2, x);
    attron(A_BOLD);
    printw("Craylke %s", "zero");
    attroff(A_BOLD);
    //Screen info
    move(y+TERM_HEIGHT+1, x+TERM_WIDTH/2-24);
    printw("Maintenance Control Unit");
    move(y+TERM_HEIGHT+1, x+TERM_WIDTH-7);
    printw("s/n ???"); //FIXME
    //Monitor box
    WINDOW* box_window = newwin(TERM_HEIGHT+2, TERM_WIDTH+2, y-1, x-1);
    box(box_window, 0, 0);
    refresh();
    wrefresh(box_window);
}
void* keyboard_emulator_thread(void* _) {
    uint key;
    forever {
        key = keyboard_signals(getch());
        if (key) chan_s64_write(_keyboard, key);
    }
}
void* screen_emulator_thread(void* _) {
    struct timespec t = {.tv_sec=0, .tv_nsec=33000000L}; //33e6ns = 33ms ~= 30Hz
    forever {
        wrefresh(main_window);
        nanosleep(&t, NULL);
    }
}
void mcu_init(Simplex64** keyboard, Simplex64** screen) {
    pthread_t _; int thread_err;
    //create channels
    _keyboard = chan_s64_create();
    if (_keyboard == NULL) die(keyboard_err);
    _screen = chan_s64_create();
    if (_screen == NULL) die(screen_err);
    //create screen and start refresh thread
    start_ncurses();
    int x, y; getmaxyx(stdscr, y, x);
    if ((x < TERM_WIDTH + 2) | (y < TERM_HEIGHT + 4)) die(small_screen);
    int x0 = (x-TERM_WIDTH)/2
      , y0 = (y-TERM_HEIGHT)/2;
    draw_screen(x0, y0);
    main_window = newwin(TERM_HEIGHT, TERM_WIDTH, y0, x0);
    if (main_window == NULL) die(screen_err);
    wrefresh(main_window);
    thread_err = pthread_create(&_, NULL, screen_emulator_thread, NULL);
    //start keyboard thread
    thread_err = pthread_create(&_, NULL, keyboard_emulator_thread, NULL);
    if (thread_err) die(keyboard_err);
    //hand out channels
    assert(_keyboard);
    assert(_screen);
    *keyboard = _keyboard;
    *screen = _screen;
}

