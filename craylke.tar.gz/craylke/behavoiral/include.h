#ifndef INCLUDE_H
#define INCLUDE_H


#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <assert.h>

typedef signed char ascii;
typedef unsigned char byte;
typedef unsigned int uint;

#define pass ((void)0)
#define elif else if
#define forever while (true)
#define fallthru pass

/**
 * Exit the emulator fast.
 * effect: print a standardized report including `diagnostic` and exit with failure
 */
void die(char* diagnostic);
/**
 * Called when we've reched unfinished code. Exits fast with message.
 */
void _unimplemented(char* file, uint line);
#define unimplemented _unimplemented(__FILE__, __LINE__)

#define byten(n, x) ((x) >> 8*(n) & 0xff)
#define nextbyte(x) ((x) >> 8)

#endif