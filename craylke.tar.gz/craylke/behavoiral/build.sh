#!/bin/bash
/usr/bin/gcc -std=c99 -D_XOPEN_SOURCE=700 *.c -lncurses -lpthread
