#include "channel.h"


struct Simplex64 {
	//the idea here is that not both rdy and ack are high
	bool rdy  //data available
	   , ack; //data recieved
	uint64_t data;
};

Simplex64* chan_s64_create(void) {
	Simplex64* channel;
	channel = malloc(sizeof *channel);
	channel->rdy = false;
	channel->ack = true;
	return channel;
}

bool chan_s64_read(uint64_t* buffer, Simplex64* channel) {
	if (!channel->rdy) return false;
	channel->rdy = false;
	*buffer = channel->data;
	channel->ack = true;
	return true;
}

bool chan_s64_write(Simplex64* channel, uint64_t data) {
	if (!channel->ack) return false;
	channel->ack = false;
	channel->data = data;
	channel->rdy = true;
	return true;
}
