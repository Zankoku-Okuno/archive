/**
 * This module implements the channels used throughout the Craylke.
 * 
 */
#ifndef CHANNEL_H
#define CHANNEL_H
#include "include.h"

/** 64-bit simplex channel */
struct Simplex64;
typedef struct Simplex64 Simplex64;

/**
 * Allocate and initialize a channel ready for writing.
 */
Simplex64* chan_s64_create(void);
/**
 * Non-blocking, atomic read from 64-bit simplex channel.
 * return: true iff successfully read
 * effects: `buffer` contains read data on success, or is undefined on failure
 *          `channel` is made ready to be written
 */
bool chan_s64_read(uint64_t* buffer, Simplex64* channel);
/**
 * Non-blocking, atomic write to 64-bit simplex channel.
 * return: true iff successfully written
 * effects: `channel` is made ready to be read
 */
bool chan_s64_write(Simplex64* channel, uint64_t data);


#endif