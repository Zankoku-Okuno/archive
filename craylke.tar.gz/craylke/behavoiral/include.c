#include "include.h"
#include <stdio.h>

void die(char* diagnostic) {
	fprintf(stderr, "ABORT!\n%s\n", diagnostic);
	exit(EXIT_FAILURE);
}
void _unimplemented(char* file, uint line) {
	fprintf(stderr, "Unimplemented: %s line %d\n", file, line);
	fprintf(stderr, "Help out at `https://github.com/Zanoku-Okuno/craylke'.\n");
	exit(EXIT_FAILURE);
}