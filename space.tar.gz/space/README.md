Ladies and gentlemen! 
=====================

Introducing the annoyingly-named esolang: ` `!

Sample
------

    Ceci ne pas un cat.

Academic Basis
--------------

Programs written in ` ` rely on the Fundamental Theorem of Arithmetic. Specifically:

    For s, t given, the following equation has exactly one solution:
        s+8*t = 2*a+3*b+5*c+k
    where k is relatively prime to 2*3*5 = 30

Specifications
--------------

A valid ` ` program consists of a number of space and tab characters interspersed with any other characters. The character encoding of the source file is implementation-defined, but is is recommended that at least UTF-8 be supported.

Let there be an arbitrary number of code cells indexed from zero upwards. The code cells, once filled, have the semantics of brainfuck. Execution begins with ip = 0. The program halts when ip reaches an unfilled cell. The code cells are filled by applying the following algorithm:

    Let the number of spaces be s and number of tabs be t. 
    s += 8*t
    i = 0
    do:
        #solve s = 2*a+3*b+5*c+k with k relatively prime to 30
        until a == b == c
        s, cell[i] = decode(a,b,c)
        i += 1
    
    def decode(a,b,c):
        |- !(a == b == c)
        m = max(a,b,c)
        if   a == b == m: a, '+'
        elif b == c == m: b, '>'
        elif a == c == m: c, '['
        elif a == m:      a, '-'
        elif b == m:      b, '<'
        else |- c == m:   c, ']'


There are an arbitrary number of data cells, open in both directions. The pointer begins at data cell zero.
Each data cell holds a signed integer. Data cells must at least be able to hold the values -1 through 127 inclusive. Behavior when reaching these limits is implementation-defined (e.g. it could be an error, there may be wrap around, or the limits may be extended or arbitrary, &c)

Input is loaded by an implementation-defined codec and stored consecutively beginning at data cell -1 down, encoded in UTF-32. All other negatively-indexed data cells are initialized to -1, and all non-negative cells are initialized to 0

Output is performed at program termination. Like input, output is buffered consecutively beginning at data cell -1 down to the first -1 value. The output buffer is flushed at program termination using an implementaion-defined codec. During this flush, if no data cell at a negative index with value -1, undefined behavior ensues. Attempting to print a value outside the range [0, 0x10ffff] results in undefined behavior.

Why?
----

Because I was curious to see if it was possible to build a Turing-complete programming language with only one token.

Obviously, you could just equate the count of tokens to the Gödel number of a valid brainfuck program, but that's boring, and requires a lot of tokens (usually more than you can store on disk). The difficulty with finding a denser encoding is to find an one that respects sequence.

Ok, well it's not that difficult. I knew I'd need recursion, and I started thinking about unique representations of integers. A few optimizations later, and you get ` `.

Status
------

- [ ] ` ` Interpreter: Well, I've got most of the VM loading in Octopus, and the rest will take less than a few tweets. Unfortunately, Octopus is not yet implemented.
- [ ] Prove Turing-complete: if I can compile brainfuck to ` `, then it must be Turing-complete.
- [ ] Better Specifications: These specs delve too far into the implementation.