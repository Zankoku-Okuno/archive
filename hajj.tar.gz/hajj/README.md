Hajj
====

Hajj is a schema combinator library.

Schema combinators generalize parser combinators by being able to act on
non-linearly structured data. In particular, here are some kinds of schema
that we support:

  * LinearSchema -- simply a parser combinator
  * TupleSchema -- specialized linear schema that ensures all and only the
                   data required is present
  * AssocParser -- use key-values pairs to apply sub-schema

Just like Parsec and Polyparse, the output may be packaged into any data
structure desired. If there are errors, position is reported appropriately.

Unlike Parsec, these schema combinators are composable by defualt (no more
frustration from guessing where to insert `try`).

Unlike Polyparse, we don't yet offer `commit`. This is due only to a lack of
understanding on the implementor's part, so is not a design decision. If you
want to tweak performance of your parser, schema combinators may be too general
a tool in the first place.


Here there be Dragons
=====================

Hajj was once just a data interchange format. Now, I've co-opted the name, but
may ressurrect the data format (or still have code lying about). Here's the
readme for that:

JSON is extremely easy to parse mechanicaally, but can be difficult for humans to read.

YAML is very readable, but complex enough to cause problems with speed, security, and human writability.

HAJJ embodies the best traits of both these data interchange languages to make it easy both for computers to communicate amongst themselves, as well as humans with computers (or even among themselves!).

Features
--------

 * Indentation-based syntax
 * Simple grammar (no more than one lookahead)
 * JSON-compatible
 * Schema Combinators

The schema combinators are where I think programmers will really find a benefit over other data exchange formats. They essentially provide an extensible, rich type system, allowing basic Hajj to not only validate at a syntax level, but also on a semantics level. Aribitrarily stringent checks can be performed by writing your own schemas, but the basic set included can be used to provide about the level of validation offered by a small but strong type system.

Examples
--------

TODO: explore the data lang

TODO: combinator library

FAQ
---

 * How's the project going?

<p><del>Under construction.</del></p>
<p><del>I have the monad!</del></p>
<p><del>A bunch of combinators are cooked and ready to serve! Also, there's a hacked-together renderer, but it works.</del></p>

The parser is finished! This completes phase one, and prepares the way for iterative complexity; a wishlist appears below:

<ul>
  Optional magic string describes both Hajj version and schema info.<br/>
  <del>Comments.</del><br/>
  <del>Allow spaces around commas.</del><br/>
  Base64 blobs.<br/>
  Optimizations and additional checks on interior data types.<br/>
  Ensure that Hajj really is compliant with JSON.<br/>
</ul>

 * What would I use this for?

Well, I'll have a high-level object file format. That doesn't even count the config files I'm likely to parse.

If you're doing AJAX, and you want to secure your application against malign structured data, a tiny schema made of combinators will have your data validated before you know it.

Further, as the combinators are written in a Turing-complete language, you can perform arbitrary composable validation checks. Acomplishing this in JSON, XML, or YAML would require embedding an interpreted language inside: slow and insecure. Validation in Haskell (the implementation language for now) is compiled, and therefore much safer and faster.

 * What does HAJJ stand for?

I'm a poststructuralist: the audience gets to decide the meaning, though I have a meaning in mind

I like the look of 'Hajj' better than 'HAJJ', so you may as well treat Hajj's capitalization as poststructural, also.
