module Hajj.Render (
      renderHajj
    , HajjRenderOptions (..)
    , defaultHajjRenderOptions
    ) where

import qualified Data.Map as Map
import qualified Data.Text as T

import Numeric (showHex)

import Control.Monad
import Control.Monad.Loops
import Control.Monad.Trans
import Control.Monad.State
import Control.Monad.Reader

import Hajj.Utils
import Hajj.Data


renderHajj :: HajjRenderOptions -> Hajj -> String
renderHajj opts hajj = flip evalState 0 $ flip runReaderT opts $ pp hajj

--TODO HajjToJson: map the data structure itself
data HajjRenderOptions = HajjRenderOptions { tabsize       :: Int
                                           , maxFlowString :: Maybe Int
                                           , lineWrap      :: Maybe Int
                                           , maxFlowList   :: Maybe Int
                                           , maxFlowDict   :: Maybe Int
                                           }
defaultHajjRenderOptions = HajjRenderOptions { tabsize       = 2
                                             , maxFlowString = Just 40
                                             , lineWrap      = Just 80
                                             , maxFlowList   = Just 2
                                             , maxFlowDict   = Just 1
                                             }


type HajjRender = ReaderT HajjRenderOptions (State Int)

pp :: Hajj -> HajjRender String
pp (HajjText x) | T.null x = return "\"\""
pp (HajjList []) = return "[]"
pp (HajjArr xs) | Map.null xs = return "[]"
pp (HajjMap xs) | Map.null xs = return "{}"

pp (HajjNum n) = return $ show n

pp x@(HajjText str) = inliney x >>= \inline -> if inline then flowStr else blockStr
    where
    flowStr = return $ if T.all (/= '\n') str then qEncode (T.unpack str) else qqEncode (T.unpack str)
    --FIXME if there are decently small lines, then block encode instead of fold encode
    blockStr = maybe (blockEncode $ T.unpack str) (const $ foldEncode $ T.unpack str) =<< asks lineWrap

pp list@(HajjList xs) = inliney list >>= \inline -> if inline then flow else block
    where
    flow = mkFlow "[" "," "]" pp xs
    block = mkBlock "" "- " pp xs

pp arr@(HajjArr xs) = do
        inline <- inliney arr
        let contig = all (uncurry (==)) $ zip [0..] $ Map.keys xs
        case (contig, inline) of
            (True, True) -> contigFlow
            (True, False) -> contigBlock
            (False, True) -> sparseFlow
            (False, False) -> sparseBlock
    where
    contigFlow = mkFlow "[" "," "]" pp (Map.elems xs)
    sparseFlow = mkFlow "{" "," "}" fmtPair (Map.toList xs)
    contigBlock = mkBlock "" "- " pp (Map.elems xs)
    sparseBlock = mkBlock "" "" fmtPair (Map.toList xs)
    fmtPair (k,v) = return . ((show k ++ ": ") ++) =<< pp v

pp dict@(HajjMap xs) = inliney dict >>= \inline -> if inline then flow else block
    where
    flow = mkFlow "{" "," "}" fmtPair (Map.toList xs)
    block = mkBlock "" "" fmtPair (Map.toList xs)
    fmtPair (k,v) = return . ((k ++ ": ") ++) =<< pp v



inliney :: Hajj -> HajjRender Bool
inliney (HajjNum _)    = return True
inliney (HajjText x)   = liftM ((not (T.null x) && T.head x == ' ') ||) (flowString x) --HAX why can't blocks encode strs that begin w/ whitespace?
inliney (HajjMap xs)   = liftM2 (&&) (flowDict $ Map.toList xs) (allM inliney $ Map.elems xs)
inliney (HajjList xs) = liftM2 (&&) (flowList xs) (allM inliney xs)
inliney (HajjArr xs) = liftM2 (&&) (flowDict $ Map.toList xs) (allM inliney $ Map.elems xs)

--MAYBE a more sophisticated judgement would look at what it takes to escape the string
flowString x = asks $ maybe True (T.length x <=) . maxFlowString
flowList xs = asks $ maybe True (length xs <=) . maxFlowList
flowDict xs = asks $ maybe True (length xs <=) . maxFlowDict


mkFlow pre mid post f xs = return . (pre++) . (++post) . intercalate mid =<< mapM f xs
mkBlock pre lead f xs = do
    depth <- liftM (+1) (lift get)
    lift $ put depth
    indentSize <- asks tabsize
    let indent = take (depth * indentSize) (repeat ' ')
    return . (pre ++) . concatMap (("\n" ++ indent ++ lead) ++) =<< mapM f xs


qEncode = ("'"++) . (++"'") . replaceWithSeq (== '\'') (const "''")
qqEncode str = ("\""++) . (++"\"") $ replaceWithSeq (not . printable . ord) replace str
    where
    printable x = (  between 0x20 0x7E x
                  || x `elem` [0x9, 0xD, 0x85]
                  || between 0xA0 0xD7FF x
                  || between 0xE000 0xFFFD x
                  || x >= 0x10000
                  )
    replace x | isSpecial x = humanEscape x
              | otherwise   = numEscape x
    isSpecial x = x `elem` "\\\"\n\0"
    humanEscape x = fromJust $ lookup x $ zip "\\\"\n\0" ["\\\\","\\\"","\\n","\\0"]
    numEscape x = "\\x" ++ pad ++ hex
        where
        hex = showHex (ord x) ""
        pad = take (4 - length hex) (repeat '0')
    between l h x = l <= x && x <= h

blockEncode :: String -> HajjRender String
blockEncode str = do
        depth <- liftM (+1) (lift get)
        indentSize <- asks tabsize
        let indent = replicate (depth * indentSize) ' '
        return $ "|\n" ++ indent ++ replaceWithSeq (=='\n') (const $ '\n':indent) str

--MAYBE try to insert newlines more intelligently:
--location of newline can vary by +-10%
--try to insert newline just before whitespace, else after whitespace, else in whitespace, else well, you just have to do what you have to do
foldEncode :: String -> HajjRender String
foldEncode str = do
        depth <- liftM (+1) (lift get)
        indentSize <- asks tabsize
        let indent = replicate (depth * indentSize) ' '
        line <- asks $ fromJust . lineWrap
        return $ ">\n" ++ indent ++ reverse (impl (indent++"\n") 0 line str "")
    where
    impl pre count line "" acc = acc
    impl pre count line (c:str) acc | count == line = impl pre 0         line (c:str) (pre++acc)
                                    | c == '\n'     = impl pre 0         line str     (pre++"\n"++acc)
                                    | otherwise     = impl pre (count+1) line str     (c:acc)
