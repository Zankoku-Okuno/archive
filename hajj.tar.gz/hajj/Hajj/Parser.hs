module Hajj.Parser (
      parseHajj
    ) where

import qualified Data.Text as T
import Data.Text (Text, pack, unpack)
import qualified Data.Map as Map

import Control.Monad
import Text.Parsec
import Text.Parsec.Char

import Hajj.Utils
import Hajj.Data (Hajj(..), hajjArrFromList)


--TODO parseFromHandle, parseFromFile
--TODO I want an interface that parses one hajj element at a time, and returns error for that elem or not
parseHajj :: String -> Either ParseError [Hajj]
parseHajj = runP impl startState ""
    where impl = many (parseHajjElem << resetIndent) << eof

parseHajjElem :: Parser Hajj
parseHajjElem =  parseDouble
             <|> parseQString         <|> parseQqString    <|> parseBlockString <|> parseFoldString
             <|> parseFlowArray       <|> parseBlockArray
             <|> parseFlowSparseArray <|> parseSparseArray
             <|> parseFlowMap         <|> parseBlockMap
             <|> parseBareString -- when all else fails, parse as a raw string
parseFlowElem :: Parser Hajj
parseFlowElem =  parseDouble    <|> parseQString         <|> parseQqString
             <|> parseFlowArray <|> parseFlowSparseArray <|> parseFlowMap


parseDouble :: Parser Hajj
parseDouble = do
        mult  <- liftM (maybe 1 (const (-1))) parseSign
        whole <- liftM (fromIntegral . atoi) (many1 digit)
        frac  <- liftM (maybe 0 atoMantissa) (optionMaybe $ char '.' >> many1 digit)
        expnt <- parseExp <|> return 1
        return $ HajjNum ((mult*whole+frac) * expnt)
    where
    parseExp = do
        oneOf "eE"
        mult  <- liftM (maybe 1 (const (-1))) parseSign
        whole <- liftM (fromIntegral . atoi) (many1 digit)
        return $ 10 ** (mult * whole)

parseBareString :: Parser Hajj
parseBareString = liftM (HajjText . pack) $ many1 (noneOf "\n\r")

parseQString :: Parser Hajj
parseQString = liftM (HajjText . pack) $ between2 (char '\'') (many $ c <|> try q)
    where c = noneOf "\'"
          q = liftM head (string "''")

parseQqString :: Parser Hajj
parseQqString = liftM (HajjText . pack) $ between2 (char '"') (many jsChar)

parseBlockString :: Parser Hajj
parseBlockString = wrap $ many (noneOf "\n") `sepBy1` try nextLine
    where wrap p = char '|' >> between parseIndent parseDedent (liftM (HajjText . pack . intercalate "\n") p)

parseFoldString :: Parser Hajj
parseFoldString = wrap $ foldedLine `sepBy1` try nextLine
    where
    wrap p = char '>' >> between parseIndent parseDedent (liftM (HajjText . T.concat) p)
    foldedLine = do
        body <- many (noneOf "\n")
        line <- many $ try $ (char '\n') << lookAhead (char '\n')
        return . pack $ body ++ line


parseFlowArray :: Parser Hajj
parseFlowArray = liftM (hajjArrFromList . zip [0..]) $ inBrackets (parseFlowElem `sepBy` elemSep)

parseBlockArray :: Parser Hajj
parseBlockArray = wrap $ (try (string "- ") >> parseHajjElem) `sepBy1` try nextLine
    where wrap p = liftM (hajjArrFromList . zip [0..]) $ between (try $ parseIndent >> lookAhead (char '-')) parseDedent p

parseSparseArray :: Parser Hajj
parseSparseArray = wrap $ (liftM2 (,) (index << kvSep) parseHajjElem) `sepBy1` try nextLine
    where wrap p = liftM hajjArrFromList $ between (try $ parseIndent >> lookAhead index) parseDedent p

parseFlowSparseArray :: Parser Hajj
parseFlowSparseArray = wrap $ (liftM2 (,) (index << kvSep) parseFlowElem) `sepBy1` elemSep
    where wrap p = liftM hajjArrFromList $ inBraces p (lookAhead index)

parseFlowMap :: Parser Hajj
parseFlowMap = wrap $ (liftM2 (,) (many idChar << kvSep) parseFlowElem) `sepBy` elemSep
    where wrap p = liftM (HajjMap . Map.fromList) $ inBraces p (notFollowedBy index)

parseBlockMap :: Parser Hajj
parseBlockMap = wrap $ (liftM2 (,) (many idChar << kvSep) parseHajjElem) `sepBy1` try nextLine
    where wrap p = liftM (HajjMap . Map.fromList) $ between (try $ parseIndent >> lookAhead idChar) parseDedent p


--TODO
--a magic string describing Hajj version and schema
--parseMagic :: Parser ???

parseSign :: Parser (Maybe ())
parseSign = optionMaybe $ skip (char '-') <|> (char '+' >> fail "")

index :: Parser Int
index = liftM atoi (many1 digit)

idChar :: Parser Char
idChar = letter <|> char '_' --TODO expand to include other text-sortof unicode points

jsChar :: Parser Char
jsChar = satisfy jsLetter <|> try escape <?> "string char"
    where
    jsLetter c = let x = ord c in ((0x20   <= x && x <= 0x7E)
                               ||  x `elem` [0x9, 0xA, 0xD, 0x85]
                               ||  (0xA0   <= x && x <= 0xD7FF)
                               ||  (0xE000 <= x && x <= 0xFFFD)
                               ||  x >= 0x10000)
                               && (not $ c `elem` "\\\"")
    escape = char '\\' >> (specialEscape <|> numEscape)
    specialEscape = oneOf "abfnrt\\\"" >>= return . fromJust . flip lookup (zip "abfnrt\\\"" ['\a','\b','\f','\n','\r','\t','\\','"'])
    numEscape = char 'x' >> liftM (chr . atoi16) (count 4 hexDigit)

elemSep :: Parser ()
elemSep = char ',' >> skipMany (char ' ')

kvSep :: Parser ()
kvSep = skip $ between2 (many $ char ' ') (char ':')

inBrackets :: Parser a -> Parser a
inBrackets = between (char '[' >> skipMany (char ' ')) (skipMany (char ' ') >> char ']')

inBraces :: Parser a -> Parser b -> Parser a
inBraces p la = between (try $ char '{' >> skipMany (char ' ') >> la) (skipMany (char ' ') >> char '}') p

nextLine :: Parser ()
nextLine = skip (many comment >> newline >> getIndent >>= string)

comment :: Parser String
comment = try $ newline >> skipMany (char ' ') >> char '#' >> many (noneOf "\n")

parseIndent :: Parser ()
parseIndent = skip (nextLine >> many1 (char ' ') >>= addIndent)

parseDedent :: Parser ()
parseDedent = (eof <|> dedent) >> popIndent
    where
    dedent = do
        indent <- getIndent
        indent' <- lookAhead $ newline >> many (char ' ')
        when (((<=) `on` length) indent indent') (fail "expecting dedent")



type Parser = Parsec String Indent

type Indent = [Int]
startState = [0]

addIndent :: String -> Parser ()
addIndent leading = let n = length leading in do
    stack@(peek:_) <- getState
    putState (peek+n : stack)

getIndent :: Parser String
getIndent = do
    (n:_) <- getState
    return $ take n (repeat ' ')

popIndent :: Parser ()
popIndent = do
    (_:stack) <- getState
    setState stack

resetIndent :: Parser ()
resetIndent = do
    eof <|> skip newline
    setState startState



skip p = p >> return ()
between2 x = between x x
