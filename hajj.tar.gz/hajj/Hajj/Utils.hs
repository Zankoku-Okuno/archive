module Hajj.Utils (
      module Data.Maybe
    , module Data.Function
    , module Data.List
    , module Data.Char
    , replaceWithSeq, rcons
    , atoi, atoMantissa, atoi16
    , (<<)
    ) where

import Data.Function
import Data.List

import Data.Char
import Data.Maybe

import Control.Monad


replaceWithSeq :: (Char -> Bool) -> (Char -> String) -> String -> String
replaceWithSeq trigger replace str = impl str ""
    where
    impl str acc = if length second /= 0
                     then impl (tail second) (acc ++ first ++ replace (head second))
                     else acc ++ first
        where (first, second) = span (not . trigger) str

rcons xs x = xs ++ [x]


atoi str = foldl (\acc x -> 10 * acc + x) 0 (map (subtract (ord '0') . ord) str)
atoMantissa str = foldr (\acc x -> acc/10 + x/10) 0.0 (map (fromIntegral . subtract (ord '0') . ord) str)
atoi16 str = foldl (\acc x -> 16 * acc + x) 0 (map (fromJust . flip lookup table) str)
    where table = [('0', 0),('1',1),('2',2),('3',3),('4',4),('5',5),('6',6),('7',7),('8',8),('9',9)
                  ,('a',10),('b',11),('c',12),('d',13),('e',14),('f',15)
                  ,('A',10),('B',11),('C',12),('D',13),('E',14),('F',15)
                  ]

f << g = do { x <- f; g; return x }
