module Hajj.Combinator (
	  module Hajj.Schema
	
	, choice
	, match
	, option
	, optionOr
	, expect
	, ensure

	, none
	, one
	, some
	, many
	, many1

	, skipOne
	, skipSome
	, skipMany
	, skipMany1
	) where

import Data.Maybe
import Data.Either
import Control.Monad
import Control.Monad.Trans
import Hajj.Schema


choice :: (Monad m, Hajji s) => [SchemaT s m a] -> SchemaT s m a
choice [] = fail ""
choice [schema] = schema
choice (schema:schemas) = maybe (choice schemas) return =<< option schema

match :: (Monad m, Hajji s) => SchemaT s m a -> SchemaT s m (Either s s)
match schema = do
	node <- currentNode
	result <- lift $ runSchemaT schema node
	case result of
		Right _ -> return . Right =<< currentNode
		Left _ -> return . Left =<< currentNode

option :: (Monad m, Hajji s) => SchemaT s m a -> SchemaT s m (Maybe a)
option schema = do
    node <- currentNode
    result <- lift $ runSchemaT schema node
    case result of
        Right val -> return $ Just val
        Left _ -> return Nothing

optionOr :: (Monad m, Hajji s) => a -> SchemaT s m a -> SchemaT s m a
optionOr def schema = liftM (maybe def id) (option schema)

expect :: (Monad m, Hajji s) => String -> SchemaT s m a -> SchemaT s m a
expect str schema = maybe (fail str) return =<< option schema

ensure :: (Monad m, Hajji s) => (a -> Bool) -> SchemaT s m a -> SchemaT s m a
ensure p schema = do
    result <- schema
    case p result of
        True  -> return result
        False -> fail ""


splitWith  :: (Monad m, Hajji s) => SchemaT s m a -> [s] -> SchemaT s m ([s], a, [s])
splitWith schema xs = impl [] xs
    where
    impl [] [] = fail "at least one datum"
    impl xs [x] = do
        result <- withNode x schema
        return (reverse xs, result, [])
    impl xs (x:xs') = do
        result <- withNode x (option schema)
        case result of
            Nothing -> impl (x:xs) xs'
            Just x -> return (reverse xs, x, xs')

none :: (Monad m, Hajji s) => SchemaT s m a -> [s] -> SchemaT s m ()
none schema [] = return ()
none schema (x:xs) = do
    result <- withNode x (option schema)
    case result of
        Just x -> fail "TODO unexpected"
        Nothing -> none schema xs


one :: (Monad m, Hajji s) => SchemaT s m a -> SchemaT s m a
one schema = do
    (_, x, xs) <- splitWith schema =<< collection
    none schema xs
    return x

some :: (Monad m, Hajji s) => SchemaT s m a -> SchemaT s m a
some schema = do
    (_, x, _) <- splitWith schema =<< collection
    return x

many :: (Monad m, Hajji s) => SchemaT s m a -> SchemaT s m [a]
many schema = do
    xs <- mapM (flip withNode (option schema)) =<< collection
    return [ fromJust x | x <- xs, isJust x]

many1 :: (Monad m, Hajji s) => SchemaT s m a -> SchemaT s m [a]
many1 schema = do
    (_, x, xs) <- splitWith schema =<< collection
    xs <- mapM (flip withNode (option schema)) xs
    return $ x:[ fromJust x | x <- xs, isJust x]


skipOne :: (Monad m, Hajji s) => SchemaT s m a -> SchemaT s m [s]
skipOne schema = do
	(pre, _, post) <- splitWith schema =<< collection
	none schema post
	return $ pre ++ post

skipSome :: (Monad m, Hajji s) => SchemaT s m a -> SchemaT s m [s]
skipSome schema = do
	(pre, _, post) <- splitWith schema =<< collection
	return $ pre ++ post

skipMany :: (Monad m, Hajji s) => SchemaT s m a -> SchemaT s m [s]
skipMany schema = do
	xs <- mapM (flip withNode (match schema)) =<< collection
	return $ lefts xs

skipMany1 ::(Monad m, Hajji s) => SchemaT s m a -> SchemaT s m [s]
skipMany1 schema = do
	(pre, _, xs) <- splitWith schema =<< collection
	post <- mapM (flip withNode (match schema)) xs
	return $ pre ++ lefts post
