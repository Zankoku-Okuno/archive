{-# LANGUAGE MultiParamTypeClasses, FunctionalDependencies #-}
module Hajj.Assoc.Prim where

import Data.Map (Map)
import qualified Data.Map as M
import Hajj.Prim


--newtype AssocSchemaT k v s p m a = A { unA :: (StateT (s, Map k v, p) (EitherT (SchemaError p v) m)) a }

--class Unnode p v | v -> p where
--    nodePos :: v -> p

--runAssocSchemaT :: Subschema (AssocSchemaT k) (Map k) v s p m a
--runAssocSchemaT = error "TODO"

----(<:>) :: (Ord k, Show k, Monad m) => k -> (p -> s -> t e -> m (Either (SchemaError p e) (a, s))) -> AssocSchemaT k (t e) s p m a
----key <:> action = A $ do
----    (s0, m, pos) <- get
----    case M.lookup key m of
----        Nothing -> lift . left $ Missing pos [show key]
----        Just val -> do
----            eResult <- lift . lift $ action pos s0 val
----            case eResult of
----                Left err -> lift . left $ err
----                Right (result, s') -> put (s', m, pos) >> return result


----type Subschema f t e s p m a = p -> s -> f e s p m a -> t e -> m (Either (SchemaError p e) a)
---- k -> (p -> s -> f e s p m a -> tSub e -> m (Either (SchemaError p e) a)) -> AssocSchemaT v s p m a

--(<+>) :: AssocSchemaT k v s p m (Map k a) -> AssocSchemaT k v s p m (Map k a) -> AssocSchemaT k v s p m (Map k a)
--a <+> b = error "TODO"