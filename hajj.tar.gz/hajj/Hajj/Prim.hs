module Hajj.Prim where

import Hajj.Prim.Schema






