module Hajj.Hajj (
	  module Hajj.Data
	, module Hajj.Render
	--TODO parser
	) where

import Hajj.Data (Hajj, Hajji(..))
import Hajj.Render