module Hajj.Data (
      Hajj (..)
    , Hajji (..)
    , hajjArrFromList
    ) where

import qualified Data.Text as T
import qualified Data.Map as Map
import Data.Map (Map)
import Data.Text (Text)
import Control.Applicative

import Hajj.Utils
import Hajj.Schema
import Hajj.Combinator


data Hajj = HajjNum  Double
          | HajjText Text
          | HajjList [Hajj]
          | HajjArr  (Map Int Hajj)
          | HajjMap  (Map String Hajj)
          --TODO HajjBytes which is base64-encoded; intro'd by =, line folded
    deriving (Show)

hajjArrFromList = HajjArr . Map.fromList

instance Hajji Hajj where
    index i schema = do
        node <- currentNode
        case node of
            HajjList xs -> if i < length xs
                             then withNode (xs !! i) schema
                             else schemaError ("array of length at least " ++ show i)
            HajjArr xs -> case Map.lookup i xs of
                              Just x -> withNode x schema
                              Nothing -> schemaError ("array of length at least " ++ show i)
            _ -> schemaError "array"
    field key schema = do
        node <- currentNode
        obj <- case node of
            HajjMap xs -> return xs
            _ -> schemaError "object"
        case Map.lookup key obj of
            Just x -> withNode x schema
            Nothing -> schemaError ("`" ++ key ++ "' field")
    collection = do 
        node <- currentNode
        case node of
            HajjMap  xs -> return $ Map.elems xs
            HajjList xs -> return xs
            HajjArr  xs -> return $ Map.elems xs
            _ -> schemaError "data collection"
    
    text = do
        node <- currentNode
        case node of
            HajjText str -> return str
            _ -> schemaError "string data"
    integer = floor <$> double
    double = do
        node <- currentNode
        case node of
            HajjNum x -> return x
            _ -> schemaError "numeric data"

    schemaError = formatSchemaError


