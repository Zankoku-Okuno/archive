module Hajj.Schema (
      Schema
    , runSchema
    , SchemaT
    , runSchemaT
    , currentNode
    , withNode
    , formatSchemaError
    , formatSchemaErrorTrim
    , Hajji (..)
    ) where

import Data.Char (digitToInt, isDigit)
import Data.Text (Text, pack, unpack, strip)
import Control.Applicative
import Control.Monad
import Control.Monad.State
import Control.Monad.Trans.Either
import Control.Monad.Identity


------ Schema ------
type Schema h = SchemaT h Identity

newtype SchemaT h m a = SchemaT { unSchema :: EitherT String (StateT h m) a }

runSchema :: (Hajji h) => Schema h a -> h -> Either String a
runSchema schema = runIdentity . runSchemaT schema

runSchemaT :: (Hajji h, Monad m) => SchemaT h m a -> h -> m (Either String a)
runSchemaT p input = do
    result <- runStateT (runEitherT (unSchema p)) input
    case result of
        (Left err, _) -> return $ Left err
        (Right val, _) -> return $ Right val


------ Hajji ------
class Hajji h where
    anyNode    :: (Monad m) => SchemaT h m h
    anyNode = currentNode
    index      :: (Monad m) => Int -> SchemaT h m a -> SchemaT h m a
    field      :: (Monad m) => String -> SchemaT h m a -> SchemaT h m a
    collection :: (Monad m) => SchemaT h m [h] --FIXME MAYBE abstract [] to Traversable
    
    text :: (Monad m) => SchemaT h m Text
    text = pack <$> string
    string :: (Monad m) => SchemaT h m String
    string = unpack <$> text
    double :: (Monad m) => SchemaT h m Double
    double = atof =<< unpack . strip <$> text
    integer :: (Monad m) => SchemaT h m Integer
    integer = atoi =<< unpack . strip <$> text

    schemaError :: (Monad m) => String -> SchemaT h m a
    schemaError = SchemaT . left


------ State Manipulation ------
currentNode :: (Hajji h, Monad m) => SchemaT h m h
currentNode = SchemaT $ lift get

withNode :: (Hajji h, Monad m) => h -> SchemaT h m a -> SchemaT h m a
withNode new p = do
    old <- currentNode
    SchemaT $ lift $ put new
    result <- p
    SchemaT $ lift $ put old
    return result

formatSchemaErrorTrim :: (Hajji h, Show h, Monad m) => Int -> String -> SchemaT h m a
formatSchemaErrorTrim lineLength str = SchemaT . left . trim lineLength =<< currentNode
    where
    trim n node = header ++ expect str ++ "Got: " ++ shorten (show node)
        where
        header = "Hajj Schema Error\n"
        expect [] = ""
        expect str = "Expecting " ++ str ++ ".\n"
        shorten str = if length str > maxLen then take (maxLen-3) str ++ "..." else str
        maxLen = n - length "Got: "

formatSchemaError :: (Hajji h, Show h, Monad m) => String -> SchemaT h m a
formatSchemaError = formatSchemaErrorTrim 80


------ Instances ------
instance (Hajji h, Monad m) => Functor (SchemaT h m) where
    fmap = liftM

instance (Hajji h, Monad m) => Applicative (SchemaT h m) where
    pure = return
    (<*>) = ap

instance (Hajji h, Monad m) => Monad (SchemaT h m) where
    return = SchemaT . return
    x >>= f = SchemaT (unSchema x >>= unSchema . f)

instance MonadTrans (SchemaT h) where
    lift = SchemaT . lift . lift

instance (MonadIO m, Hajji h) => MonadIO (SchemaT h m) where
    liftIO = lift . liftIO


------ Helpers ------
atoi :: (Hajji h, Monad m) => String -> SchemaT h m Integer
atoi s = case s of 
        ('-':cs) -> negate . accumInt <$> checkAllDigits cs
        ('+':cs) -> accumInt <$> checkAllDigits cs
        []       -> error "STUB"
        cs       -> accumInt <$> checkAllDigits cs
    where
    accumInt = foldl (\acc x -> 10 * acc + (fromIntegral . digitToInt) x) 0

atof :: (Hajji h, Monad m) => String -> SchemaT h m Double
atof s = case s of
        ('-':cs) -> ((-1.0) *) <$> decimalPoint cs
        ('+':cs) -> decimalPoint cs
        cs       -> decimalPoint cs
    where
    decimalPoint s = case (=='.') `break` s of
        ([], _) -> schemaError ("Not a number: " ++ s)
        (cstmp, []) -> case isExp `break` cstmp of
            ([], _) -> schemaError ("Not a number: " ++ s)
            (_, []) -> schemaError ("Not a number: " ++ s)
            (cs1, _:[]) -> schemaError ("Not a number: " ++ s)
            (cs1, _:cs3) -> do
                int <- fromIntegral <$> (atoi =<< checkAllDigits cs1)
                pow <- fromIntegral <$> (atoi =<< checkAllDigits cs3)
                return $ int * 10**pow
        (cs1, _:[]) -> schemaError ("Not a number: " ++ s)
        (cs1, _:cstmp) -> case isExp `break` cstmp of
            ([], _) -> schemaError ("Not a number: " ++ s)
            (cs2, []) -> do
                int <- fromIntegral <$> (atoi =<< checkAllDigits cs1)
                frc <- accumMantissa <$> checkAllDigits cs2
                return $ int + frc
            (cs2, _:[]) -> schemaError ("Not a number: " ++ s)
            (cs2, _:cs3) -> do
                int <- fromIntegral <$> (atoi =<< checkAllDigits cs1)
                frc <- accumMantissa <$> checkAllDigits cs2
                pow <- return 0
                return $ (int + frc) * 10**pow
    accumMantissa :: String -> Double
    accumMantissa = foldr (\x acc -> acc/10 + (fromIntegral . digitToInt) x/10) 0.0
    isExp c = c == 'e' || c == 'E'


checkAllDigits :: (Hajji h, Monad m) => String -> SchemaT h m String
checkAllDigits cs = if isDigit `all` cs then return cs else schemaError ("Not a number: " ++ cs)
