import Control.Monad.IO.Class

import qualified Data.Map as Map
import Data.Text (pack, unpack)

import Hajj.Utils
import Hajj.Hajj
import Hajj.Data (HajjData(..))
import Hajj.Combinator
import Hajj.Parser

main = do
        putStrLn $ renderHajj defaultHajjRenderOptions printdata
        putStrLn $ take 12 $ repeat '='
        result <- runHajjSchemaT testparser testdata
        case result of
            Right val -> putStrLn $ show val
            Left err -> putStrLn err
        putStrLn $ take 12 $ repeat '='
        putStrLn testInput
        putStrLn $ take 12 $ repeat '='
        let result = parseHajj testInput
        case result of
            Right val -> mapM putStrLn (map show val) >> return ()
            Left err -> putStrLn $ show err

    where
    testparser = do
        x <- field "data" string
        liftIO $ putStrLn $ unpack x
        field "num" (option $ ensure (< 6) double)
        field "arr" (many double)
        one double
    testdata = (HajjMap $ Map.fromList [("data", HajjText $ pack "Goodbyte, cruel world!"),
                         --("num", HajjNum (2*3.1415962)),
                         ("num", HajjNum 3.1415962),
                         ("arr", HajjArr $ Map.fromList [
                            (3, HajjNum (sqrt 3)),
                            (1, HajjNum (sqrt 2))
                            ])])
    printdata = HajjList $
                  [HajjArr $ Map.fromList [
                         (1, HajjNum 1),
                         (2, HajjText $ pack "   h'eeeeeee\12eeeeeeeeeeeeeeeee\neeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee\955l\\\"lo\0"),
                         (3, HajjNum 2)]
                  ,HajjMap $ Map.fromList [
                      ("qstr", HajjText $ pack "It's blah!"),
                      ("qqstr", HajjText $ pack "It's blah!\n"),
                      ("bstr", HajjText $ pack $ intercalate "\n" (("This outght to be big:"++replicate 70 'e'):replicate 6 "something something something")),
                      ("fstr", HajjText $ pack $ intercalate "\n" ("This outght to be big:":replicate 6 "something something something")),
                      ("fobj", HajjMap $ Map.fromList [("a", HajjNum 9e19)]),
                      ("farr", HajjArr $ Map.fromList [(0, HajjText $ pack "hi"),(1, HajjText $ pack "bye")])
                    ]]
                ++ (map (HajjNum . sqrt) [2,3,5,7,11,13])
    testInput = "2.300e9\n\
                \'\"Hello, world! It''s a me, Mario!\"'\n\
                \this is a bare string\n\
                \\"jsString\\n\\x03bb\"\n\
                \|\n  hello\n  \n  world\n\
                \>\n  goodbye \n  world\n\n  for good!\n\
                \[]\n[ 1, 2, [3.1415962] ]\n\
                \{ 5: 1.41 }\n{ 2 :4, 4 :16, 16:'inf' }\n\
                \{}\n{a:'a',b:2,c:[]}\n\n\
                \ - 'block list'\n - \n  3: 1\n  1: 2\n\n\
                \ #some comment\n\
                \ global: \n  localA: 3\n  localB: 3.14"
