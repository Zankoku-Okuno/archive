module Hajj.Prim.Point (
      PointSchemaT
    , satisfy
    ) where

import Hajj.Prim.Schema

newtype PointSchemaT p k v s m a  = P { unPoint  :: StateT s (ReaderT (v, p) (EitherT (SchemaError p k v) m)) a }


------ Instances ------
instance (Monad m) => Functor (PointSchemaT p k v s m) where
    fmap = liftM

instance (Monad m) => Applicative (PointSchemaT p k v s m) where
    pure = return
    (<*>) = ap

instance (Ord p, Monad m) => Alternative (PointSchemaT p k v s m) where
    empty = unexpected
    a <|> b = choice [a, b]

instance (Monad m) => Monad (PointSchemaT p k v s m) where
    return = P . return
    x >>= k = P $ unPoint x >>= unPoint . k

instance MonadTrans (PointSchemaT p k v s) where
    lift = P . lift . lift . lift


------ Top-Level ------
_run :: (Monad m) => (s, v, p) -> PointSchemaT p k v s m a -> m (Either (SchemaError p k v) (a, s))
_run (start, x, pos) (P action) = runEitherT $ runReaderT (runStateT action start) (x, pos)


------ Primitives ------
satisfy :: (Monad m) => (v -> Bool) -> PointSchemaT p k v s m v
satisfy predicate = P $ do
    (v, pos) <- lift ask
    if predicate v
        then return v
        else lift . lift . left $ Expected pos [Nothing] (Right v)

instance Subschema PointSchemaT where
    runSubschemaT action = S $ do
        s0 <- get
        node <- lift $ asks fst
        (pos, x) <- case node of
            Point  pos v -> return (pos, v)
            Linear pos _ -> lift . lift . left $ BadNode pos "point" node
            Assoc  pos _ -> lift . lift . left $ BadNode pos "point" node
        eResult <- lift . lift . lift . runEitherT $ runReaderT (runStateT (unPoint action) s0) (x, pos)
        case eResult of
            Left err -> lift . lift $ left err
            Right (result, s') -> put s' >> return result

    choice actions = P $ do
        s0 <- get
        (v, pos) <- lift ask
        go (s0, v, pos) Nothing actions
        where
        go s0 err [] = case err of
            Nothing -> unPoint unexpected
            Just err -> lift . lift . left $ err
        go s0 err1 (a:as) = do
            eResult <- lift . lift . lift $ _run s0 a
            case eResult of
                Left err2 -> do
                    case err1 of
                        Nothing -> go s0 (Just err2) actions
                        Just err1 -> go s0 (Just $ mergeErrors err1 err2) actions
                Right (result, s') -> put s' >> return result

    expect str action = P $ do
        s0 <- get
        (x, pos) <- lift ask
        eResult <- lift . lift . lift $ _run (s0, x, pos) action
        case eResult of
            Left err -> unPoint $ expected str
            Right (result, s') -> put s' >> return result
    expected str = P $ do
        (x, pos) <- lift ask
        lift . lift . left $ Expected pos [Just str] (Right x)
    unexpected = P $ do
        (x, pos) <- lift ask
        lift . lift . left $ Expected pos [Nothing] (Right x)

    getPos = P $ asks snd
    getState = P $ get
    getsState = (<$> getState)
    putState s' = P $ put s'
    putsState f = P $ put . f =<< get
    localState s' action = do
        s0 <- getState
        putState s'
        action <* putState s0

