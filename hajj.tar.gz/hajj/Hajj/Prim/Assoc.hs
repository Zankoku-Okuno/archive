module Hajj.Prim.Assoc where

import Hajj.Prim.Schema
import Data.Map (Map)
import qualified Data.Map as M


newtype AssocSchemaT p k v s m a  = D { unAssoc  :: StateT s (ReaderT (Map k (Hajj p k v), p) (EitherT (SchemaError p k v) m)) a }


------ Instances ------
instance (Monad m) => Functor (AssocSchemaT p k v s m) where
    fmap = liftM

instance (Monad m) => Applicative (AssocSchemaT p k v s m) where
    pure = return
    (<*>) = ap

instance (Ord p, Monad m) => Alternative (AssocSchemaT p k v s m) where
    empty = unexpected
    a <|> b = choice [a, b]

instance (Monad m) => Monad (AssocSchemaT p k v s m) where
    return = D . return
    x >>= k = D $ unAssoc x >>= unAssoc . k

instance MonadTrans (AssocSchemaT p k v s) where
    lift = D . lift . lift . lift


------ Top-level ------
_run :: (Monad m) => (s, Map k (Hajj p k v), p) -> AssocSchemaT p k v s m a -> m (Either (SchemaError p k v) (a, s))
_run (start, xs, pos) (D action) = runEitherT $ runReaderT (runStateT action start) (xs, pos)


------ Primitives ------
satisfy :: (Ord k, Subschema f, Monad m) => k -> f p k v s m a -> AssocSchemaT p k v s m a
satisfy key schema = D $ do
    (m, pos) <- ask
    s0 <- get
    case M.lookup key m of
        Nothing  -> lift . lift . left $ Missing pos [key]
        Just val -> do 
            eResult <- lift . lift . lift $ runSchemaT s0 (runSubschemaT schema) val
            case eResult of
                Left err -> lift . lift $ left err
                Right (result, s') -> put s' >> return result

infix 5 <:>
(<:>) :: (Ord k, Subschema f, Monad m) => k -> f p k v s m a -> AssocSchemaT p k v s m (Map k a)
key <:> schema = M.singleton key <$> satisfy key schema

infixr 4 <+>
(<+>) :: (Ord k, Monad m) => AssocSchemaT p k v s m (Map k a) -> AssocSchemaT p k v s m (Map k a) -> AssocSchemaT p k v s m (Map k a)
a <+> b = M.union <$> b <*> a

dict :: (Ord k, Monad m) => Map k (AssocSchemaT p k v s m a) -> AssocSchemaT p k v s m (Map k a)
dict as = foldr go (return M.empty) (M.toList as)
    where
    go (k, schema) acc = acc <+> k <:> schema
    

instance Subschema AssocSchemaT where
    runSubschemaT action = S $ do
        s0 <- get
        node <- lift $ asks fst
        (pos, xs) <- case node of
            Point  pos _  -> lift . lift . left $ BadNode pos "assoc" node
            Linear pos _  -> lift . lift . left $ BadNode pos "assoc" node
            Assoc  pos xs -> return (pos, xs)
        eResult <- lift . lift . lift $ _run (s0, xs, pos) action
        case eResult of
            Left err -> lift . lift $ left err
            Right (result, s') -> put s' >> return result

    choice actions = D $ do
        s0 <- get
        (xs, pos) <- lift ask
        go (s0, xs, pos) Nothing actions
        where
        go s0 err [] = case err of
            Nothing -> unAssoc unexpected
            Just err -> lift . lift . left $ err
        go s0 err1 (a:as) = do
            eResult <- lift . lift . lift $ _run s0 a
            case eResult of
                Left err2 -> do
                    case err1 of
                        Nothing -> go s0 (Just err2) actions
                        Just err1 -> go s0 (Just $ mergeErrors err1 err2) actions
                Right (result, s') -> put s' >> return result

    expect str action = D $ do
        s0 <- get
        (x, pos) <- lift ask
        eResult <- lift . lift . lift $ _run (s0, x, pos) action
        case eResult of
            Left err -> unAssoc $ expected str
            Right (result, s') -> put s' >> return result
    expected str = D $ do
        (xs, pos) <- lift ask
        lift . lift . left $ MalformedDict pos [Just str] xs
    unexpected = D $ do
        (xs, pos) <- lift ask
        lift . lift . left $ MalformedDict pos [Nothing] xs

    getPos = D $ asks snd
    getState = D $ get
    getsState = (<$> getState)
    putState s' = D $ put s'
    putsState f = D $ put . f =<< get
    localState s' action = do
        s0 <- getState
        putState s'
        action <* putState s0

