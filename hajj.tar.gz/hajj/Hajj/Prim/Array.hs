module Hajj.Prim.Array where

import Hajj.Prim.Schema


newtype ArraySchemaT p k v s m a  = A { unArray  :: StateT s (ReaderT ([Hajj p k v], p) (EitherT (SchemaError p k v) m)) a }


------ Instances ------
instance (Monad m) => Functor (ArraySchemaT p k v s m) where
    fmap = liftM

instance (Monad m) => Applicative (ArraySchemaT p k v s m) where
    pure = return
    (<*>) = ap

instance (Ord p, Monad m) => Alternative (ArraySchemaT p k v s m) where
    empty = unexpected
    a <|> b = choice [a, b]

instance (Monad m) => Monad (ArraySchemaT p k v s m) where
    return = A . return
    x >>= k = A $ unArray x >>= unArray . k

instance MonadTrans (ArraySchemaT p k v s) where
    lift = A . lift . lift . lift


------ Top-level ------
_run :: (Monad m) => (s, [Hajj p k v], p) -> ArraySchemaT p k v s m a -> m (Either (SchemaError p k v) (a, s))
_run (start, xs, pos) (A action) = runEitherT $ runReaderT (runStateT action start) (xs, pos)


------ Primitives ------

instance Subschema AssocSchemaT where
    runSubschemaT action = S $ do
        s0 <- get
        node <- lift $ asks fst
        (pos, xs) <- case node of
            Point  pos _  -> lift . lift . left $ BadNode pos "assoc" node
            Linear pos _  -> lift . lift . left $ BadNode pos "assoc" node
            Assoc  pos xs -> return (pos, xs)
        eResult <- lift . lift . lift $ _run (s0, xs, pos) action
        case eResult of
            Left err -> lift . lift $ left err
            Right (result, s') -> put s' >> return result

    choice actions = D $ do
        s0 <- get
        (xs, pos) <- lift ask
        go (s0, xs, pos) Nothing actions
        where
        go s0 err [] = case err of
            Nothing -> unAssoc unexpected
            Just err -> lift . lift . left $ err
        go s0 err1 (a:as) = do
            eResult <- lift . lift . lift $ _run s0 a
            case eResult of
                Left err2 -> do
                    case err1 of
                        Nothing -> go s0 (Just err2) actions
                        Just err1 -> go s0 (Just $ mergeErrors err1 err2) actions
                Right (result, s') -> put s' >> return result

    expect str action = D $ do
        s0 <- get
        (x, pos) <- lift ask
        eResult <- lift . lift . lift $ _run (s0, x, pos) action
        case eResult of
            Left err -> unAssoc $ expected str
            Right (result, s') -> put s' >> return result
    expected str = D $ do
        (xs, pos) <- lift ask
        lift . lift . left $ MalformedDict pos [Just str] xs
    unexpected = D $ do
        (xs, pos) <- lift ask
        lift . lift . left $ MalformedDict pos [Nothing] xs

    getPos = D $ asks snd
    getState = D $ get
    getsState = (<$> getState)
    putState s' = D $ put s'
    putsState f = D $ put . f =<< get
    localState s' action = do
        s0 <- getState
        putState s'
        action <* putState s0

