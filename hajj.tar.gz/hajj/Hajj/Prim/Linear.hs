{-# LANGUAGE MultiParamTypeClasses, FunctionalDependencies, FlexibleInstances #-}
module Hajj.Prim.Linear (
      LinearSchemaT
    , Stream(..)
    , satisfy, endOfInput
    ) where

import Hajj.Prim.Schema


newtype LinearSchemaT p k v s m a = L { unLinear :: (StateT (s, [v], p) (EitherT (SchemaError p k v) m)) a }

class Stream p v | v -> p where
    updatePos :: p -> v -> p


------ Instances ------
instance (Monad m) => Functor (LinearSchemaT p k v s m) where
    fmap = liftM

instance (Monad m) => Applicative (LinearSchemaT p k v s m) where
    pure = return
    (<*>) = ap

instance (Ord p, Monad m) => Alternative (LinearSchemaT p k v s m) where
    empty = unexpected
    a <|> b = choice [a, b]

instance (Monad m) => Monad (LinearSchemaT p k v s m) where
    return = L . return
    x >>= k = L $ unLinear x >>= unLinear . k

instance MonadTrans (LinearSchemaT p k v s) where
    lift = L . lift . lift


------ Top-level ------
_run :: (Monad m) => (s, [v], p) -> LinearSchemaT p k v s m a -> m (Either (SchemaError p k v) (a, (s, [v], p)))
_run start (L action) = runEitherT $ runStateT action start


------ Primitives ------
{-| Parse one input element that satisfies the predicate. -}
satisfy :: (Stream p v, Monad m) => (v -> Bool) -> LinearSchemaT p k v s m v
satisfy p = L $ do
    (s, stream, pos) <- get
    case stream of
        [] -> unLinear unexpected
        (x:stream') -> if p x
            then do
                put (s, stream', updatePos pos x)
                return x
            else unLinear unexpected

{-| Parse the end of the input stream. -}
endOfInput :: (Monad m) => LinearSchemaT p k v s m ()
endOfInput = L $ do
    (_, stream, _) <- get
    case stream of
        [] -> return ()
        _ -> unLinear $ expected "end of input"

instance Subschema LinearSchemaT where
    runSubschemaT (L action) = S $ do
        s0 <- get
        node <- asks fst
        (pos, xs) <- case node of
            Point  pos _  -> lift . lift . left $ BadNode pos "linear" node
            Linear pos xs -> return (pos, xs)
            Assoc  pos _  -> lift . lift . left $ BadNode pos "linear" node
        eResult <- lift . lift . lift $ runEitherT $ runStateT action (s0, xs, pos)
        case eResult of
            Left err -> lift . lift $ left err
            Right (result, (s', _, _)) -> put s' >> return result

    choice actions = L $ do
        s0 <- get
        go s0 Nothing actions
        where
        go s0 err [] = case err of
            Nothing -> unLinear unexpected
            Just err -> lift . left $ err
        go s0 err1 (a:as) = do
            eResult <- lift . lift $ _run s0 a
            case eResult of
                Left err2 -> do
                    case err1 of
                        Nothing -> go s0 (Just err2) actions
                        Just err1 -> go s0 (Just $ mergeErrors err1 err2) actions
                Right (result, s') -> put s' >> return result

    expect str action = L $ do
        s0 <- get
        eResult <- lift . lift $ _run s0 action
        case eResult of
            Left _ -> unLinear $ expected str
            Right (result, s') -> put s' >> return result
    expected str = L $ do
        (_, stream, pos) <- get
        lift . left . Expected pos [Just str] $ case stream of
            []        -> Left "end of input"
            (found:_) -> Right found
    unexpected = L $ do
        (_, stream, pos) <- get
        lift . left $ Expected pos [Nothing] $ case stream of
            []        -> Left "end of input"
            (found:_) -> Right found

    getPos = L $ get >>= \(_, _, pos) -> return pos
    getState = L $ get >>= \(s, _, _) -> return s
    getsState = (<$> getState)
    putState s' = L $ do
        (_, stream, pos) <- get
        put (s', stream, pos)
    putsState f = putState . f =<< getState
    localState s' action = do
        s0 <- getState
        putState s'
        action <* putState s0

