module Hajj.Prim.Schema (
      module Control.Applicative
    , module Control.Monad
    , module Control.Monad.Reader
    , module Control.Monad.State
    , module Control.Monad.Trans
    , module Control.Monad.Trans.Either
    , Hajj(..)
    , SchemaT(..)
    , runSchemaT
    , SchemaError(..)
    , Subschema(..)
    , mergeErrors
    ) where


import Data.Maybe
import Data.Map (Map)

import Control.Applicative
import Control.Monad
import Control.Monad.Reader
import Control.Monad.State
import Control.Monad.Trans
import Control.Monad.Trans.Either

data Hajj p k v = Point  p v
                | Linear p [v]
                | Array  p [Hajj p k v]
                | Assoc  p (Map k (Hajj p k v))

newtype SchemaT p k v s m a = S { unSchema :: StateT s (ReaderT (Hajj p k v, p) (EitherT (SchemaError p k v) m)) a }

data SchemaError p k v = BadNode       { _nWhere :: p, _nExpect :: String,         _nFound :: Hajj p k v         }
                       | Expected      { _eWhere :: p, _eExpect :: [Maybe String], _eFound :: (Either String v)  }
                       | MalformedArr  { _aWhere :: p, _aExpect :: [Maybe String], _aFound :: [Hajj p k v]       }
                       | MalformedDict { _dWhere :: p, _dExpect :: [Maybe String], _dFound :: Map k (Hajj p k v) }
                       | Missing       { _mWhere :: p, _mMissing :: [k]                                          }
                       | Unknown                    p


runSchemaT :: (Monad m) => s -> SchemaT p k v s m a -> Hajj p k v -> m (Either (SchemaError p k v) (a, s))
runSchemaT s0 (S action) node = runEitherT $ runReaderT (runStateT action s0) (node, getHajjPosition node)

class Subschema f where
    runSubschemaT :: (Monad m) => f p k v s m a -> SchemaT p k v s m a

    {-| Take the first schema that succeeds. -}
    choice :: (Ord p, Monad m) => [f p k v s m a] -> f p k v s m a

    {-| If the passed schema fails, report as if failure occured here with the passed explanation. -}
    expect :: (Monad m) => String -> f p k v s m a -> f p k v s m a
    {-| Fail, providing a report of an expected element. -}
    expected :: (Monad m) => String -> f p k v s m a
    {-| Fail, without known exepcted element. -}
    unexpected :: (Monad m) => f p k v s m a

    {-| Get the current parser position. -}
    getPos :: (Monad m) => f p k v s m p
    {-| Get the current user state. -}
    getState :: (Monad m) => f p k v s m s
    {-| Get a view of the current user state, processed by the passed function. -}
    getsState :: (Monad m) => (s -> a) -> f p k v s m a
    {-| Change the user state of the parser. -}
    putState :: (Monad m) => s -> f p k v s m ()
    {-| Modify the user state of the parser with the passed function. -}
    putsState :: (Monad m) => (s -> s) -> f p k v s m ()
    {-| Validate a schema with a new user state. Reset the user state when complete. -}
    localState :: (Monad m) => s -> f p k v s m a -> f p k v s m a


infixl 3 <?>
{-| Flipped version of 'expect'. -}
(<?>) :: (Subschema f, Monad m) => f p k v s m a -> String -> f p k v s m a
(<?>) = flip expect

------ Helpers ------
getHajjPosition :: Hajj p k v -> p
getHajjPosition (Point pos _) = pos
getHajjPosition (Linear pos _) = pos
getHajjPosition (Assoc pos _) = pos

getErrPosition :: SchemaError p k v -> p
getErrPosition (Expected pos _ _) = pos
getErrPosition (BadNode pos _ _) = pos
getErrPosition (MalformedDict pos _ _) = pos
getErrPosition (Missing pos _) = pos
getErrPosition (Unknown pos) = pos

mergeErrors :: (Ord p) => SchemaError p k v -> SchemaError p k v -> SchemaError p k v 
mergeErrors a b = let posA = getErrPosition a
                      posB = getErrPosition b
                  in if posA < posB then b else if posA > posB then a else _merge a b
    where
    --homogenous merge
    _merge a@(BadNode _ _ _) (BadNode _ _ _) = a
    _merge (Expected pos expect1 found) (Expected _ expect2 _) = case catMaybes (expect1++expect2) of
        [] -> (Expected pos [Nothing] found)
        errs -> (Expected pos (map Just errs) found)
    _merge (MalformedArr pos expect1 found) (MalformedArr _ expect2 _) = case catMaybes (expect1++expect2) of
        [] -> (MalformedArr pos [Nothing] found)
        errs -> (MalformedArr pos (map Just errs) found)
    _merge (MalformedDict pos expect1 found) (MalformedDict _ expect2 _) = case catMaybes (expect1++expect2) of
        [] -> (MalformedDict pos [Nothing] found)
        errs -> (MalformedDict pos (map Just errs) found)
    _merge (Missing pos ks1) (Missing _ ks2) = Missing pos (ks1 ++ ks2)
    _merge a@(Unknown _)      (Unknown _)      = a
    --heterogenous merge
    _merge a@(BadNode _ _ _) b       = a
    _merge a b@(BadNode _ _ _)       = b
    _merge a@(Expected _ _ _) b      = a
    _merge a b@(Expected _ _ _)      = b
    _merge a@(MalformedArr _ _ _) b  = a
    _merge a b@(MalformedArr _ _ _)  = b
    _merge a@(MalformedDict _ _ _) b = a
    _merge a b@(MalformedDict _ _ _) = b
    _merge a@(Missing _ _) b         = a
    _merge a b@(Missing _ _)         = b
