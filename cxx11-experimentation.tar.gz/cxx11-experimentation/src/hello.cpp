#include "hello.hpp"
#include <iostream>

using namespace std;

int main(int argc, char* argv[]) {
  printer();
  return 0;
}

void printer() {
  cout << "Goodbyte, cruel world!" << endl;
}
