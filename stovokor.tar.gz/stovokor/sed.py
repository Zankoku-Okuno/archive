from .matcher import *

class Reader:
    def __init__(self, driver, output):
        self.matcher = Matcher(driver)
        self.token_lookahead_buffer = ''
        self.output = output
    
    def feed(self, input):
        if len(input) != 1:
            for char in input:
                self.feed(char)
        else:
            self.buffer(input)
            if not self.matcher.could_be(self.token_lookahead_buffer):
                self.flush()
    
    def buffer(self, char):
        self.last_char_read = char
        self.token_lookahead_buffer += char
    
    def flush(self):
        token_length, token_matcher = self.matcher.match(self.token_lookahead_buffer)
        token_string = self.token_lookahead_buffer[:token_length]
        self.token_lookahead_buffer = self.token_lookahead_buffer[token_length:]
        self.output.append(self.create_token(token_string, token_matcher))
        self.matcher.reset()
        self.refeed()
    
    def refeed(self):
        leftovers = self.token_lookahead_buffer
        self.token_lookahead_buffer = ''
        self.feed(leftovers)
    
    def create_token(self, token_string, token_matcher):
        return token_string
    
    def eof(self):
        while self.token_lookahead_buffer:
            self.matcher.eof(self.token_lookahead_buffer)
            self.flush()
        if hasattr(self.output, 'eof'):
            self.output.eof()



#REFAC keeping track of location into a mixin
#REFAC creating a Token for the arboreum.Tree elsewhere, like to a different lib
class AnnotatingReader(Reader):
    def __init__(self, driver, output):
        super().__init__(driver, output)
        self.column = 1
        self.lineno = 1
    
    def create_token(self, token_string, token_matcher):
        out = (token_string, token_matcher, (self.lineno, self.column))
        self._update_location(token_string)
        return out
    
    def _update_location(self, token_string):
        for char in token_string:
            if char in {'\n', '\r'}: #FIXME pre-process newlines
                self.column = 1
                self.lineno += 1
            #TODO figure out how to process tabs
            else:
                self.column += 1