"""A number of matchers devoted to matching particular sorts of tokens.

These sub-matchers, like the main matcher itself must be fed characters
one-at-a-time, calling the could_be_method with progressively longer input
strings. """

from functools import reduce

class AlphabetMatcher:
    def __init__(self, alphabet):
        self.alphabet = alphabet
        self.compatible = self.alphabet.compatible
        self.reset()
    
    def could_be(self, input):
        """Returns the number of distinct tokens that this matcher could
        possibly detect at the start of the input string. Tokens that have
        already been detected are not included in this number."""
        if len(input) != 1 + self.max_length:
            return 0
        elif len(input) == 1 or self.compatible(input[-2], input[-1]):
            self.max_length += 1
            return 1
        else:
            return 0
    
    def eof(self):
        """Notifies the matcher that the end of the input has arrived. If there
        is a possible match, then it must be _the_ match."""
        pass
    
    def match(self):
        """Returns the length of the token which this matcher has detected.
        
        Should not be called until either could_be() returns 0 on the same input
        string, or the end of input has been reached."""
        return (self.max_length, self.alphabet)
    
    def reset(self):
        """Reinitializes this matcher so that it may look for matches in a
        different location. Must be called after a token has matched in the
        input stream (regardles of whether the match was from this matcher)."""
        self.max_length = 0

class KeywordMatcher:
    def __init__(self, keywords, alphabet):
        self._keywords = keywords
        self.compatible = alphabet.compatible
        self.reset()
    
    def could_be(self, input):
        """Returns the number of distinct tokens that this matcher could
        possibly detect at the start of the input string. Tokens that have
        already been detected are not included in this number."""
        if self.best_possible is not self.definite:
            if not self.compatible(input[-2], input[-1]):
                self.definite = self.best_possible
            self.best_possible = None
        candidates = {kw for kw in self.possible if kw.match(input)}
        if candidates:
            self.best_possible = candidates.pop()
        self.possible = {kw for kw in self.possible if kw.could_be(input)}
        return _num(self.possible, self.best_possible)
    
    def eof(self):
        """Notifies the matcher that the end of the input has arived. If there
        is a possible match, then it must be _the_ match."""
        self.definite = self.best_possible
        self.best_possible = None
        self.possible = set()
    
    def match(self):
        """Returns a pair. The first element is the length of the token which
        this matcher has detected. The second is the keyword that made the
        match. If no match has been detected, returns (0, None).
        
        Should not be called until either could_be() returns 0 on the same input
        string, or the end of input has been reached."""
        return (0, None) if self.definite is None \
               else (len(self.definite.pattern), self.definite)
    
    def reset(self):
        """Reinitializes this matcher so that it may look for matches in a
        different location. Must be called after a token has matched in the
        input stream (regardles of whether the match was from this matcher)."""
        self.possible = self._keywords
        self.best_possible = None
        self.definite = None

class PatternMatcher:
    #what should be done about ambiguity here? since we may have agents of the
    #same length with differing backreferences. I suppose we can take the one
    #with the most backreferences, but what if, say, two agents differ only in
    #the fact that one of the backreference names is different (but the
    #contained data is the same and all othe rbackreferences and lengths are the
    #same)
    #MAYBE I should raise an error when the ambiguity cannot be solved
    
    #choose the 'simplest' regex: the one with the fewest states, likely
    #alternatively, choose the most 'specific': w/ the most states
    #or, finally, give each pattern a priority
    #if there's still a tie, choose the agent with the most b/rs
    
    def __init__(self, patterns, alphabet):
        self._patterns = patterns
        self.compatible = alphabet.compatible #MAYBE we don't need to check compatibility on patterns, they override the local structures
        from genregex.engine import Automaton
        self._automatons = {Automaton(pat.graph): pat for pat in self._patterns}
        self.reset()
    
    def could_be(self, input):
        """Returns the number of distinct tokens that this matcher could
        possibly detect at the start of the input string. Tokens that have
        already been detected are not included in this number."""
        #print(input) #DEBUG
        for automaton in self.possible:
            automaton.input(input[-1])
        if self.best_possible:
            if not self.compatible(input[-2], input[-1]):
                self.definite = self.best_possible
            self.best_possible = set()
        self.best_possible = reduce(lambda acc,a: acc |
                                      { (agent, self._automatons[a])
                                          for agent in a.terminal() },
                                    self.possible, set())
        self.possible = {a for a in self.possible if a.potential()}
        return len(self.possible) + len(self.best_possible)
    
    def eof(self):
        """Notifies the matcher that the end of the input has arived. If there
        is a possible match, then it must be _the_ match."""
        if self.best_possible:
            self.definite = self.best_possible
        self.best_possible = set()
        self.possible = set()
    
    def match(self):
        """Returns a pair. The first element is the length of the token which
        this matcher has detected. The second is the pattern that made the
        match. If no match has been detected, returns (0, None).
        
        Should not be called until either could_be() returns 0 on the same input
        string, or the end of input has been reached."""
        if not self.definite:
            return (0, None)
        elif len(self.definite) != 1:
            most_important = max(map(lambda x: x[1].priority, self.definite))
            self.definite = {m for m in self.definite if m[1].priority == most_important}
            if len(self.definite) != 1:
                patterns = {m[1] for m in self.definite}
                if len(patterns) != 1:
                    least_states = min(map(lambda x: x.size(), patterns))
                    patterns = {p for p in patterns if p.size() == least_states}
                    if len(patterns) != 1:
                        raise Exception() #TODO more specific
                pattern = patterns.pop()
                self.definite = {m for m in self.definite if m[1] == pattern}
                if len(self.definite) != 1:
                    pass #TODO
                    #if still multiple, chose the one w/ the most b/rs
        agent, pattern = self.definite.pop()
        return (agent.bounds.end, pattern) #FIXME return a pattern
    
    def reset(self):
        """Reinitializes this matcher so that it may look for matches in a
        different location. Must be called after a token has matched in the
        input stream (regardles of whether the match was from this matcher)."""
        self.possible = {a for a in self._automatons}
        for automaton in self.possible:
            automaton.flush()
            automaton.spawn()
        self.best_possible = set()
        self.definite = set()

class DelimiterMatcher: #OPTZ this matches prbly in O(n^2) on the length of the input, since the input keeps getting fed back in, and the constant is prbly pretty high, too I need to cache results in something other than ye olde quantum.delimiter
    def __init__(self, delimiters):
        self._delimiters = delimiters
        self.reset()
    
    def is_active(self):
        """Returns whether we are trying to find the end of a particular
        delimited token, rather than still trying to match the start of any
        delimiter."""
        return self.active is not None
    
    def could_be(self, input):
        """Returns the number of distinct tokens that this matcher could
        possibly detect at the start of the input string. Tokens that have
        already been detected are not included in this number."""
        if self.is_active():
            return 0 if self.active.count(input) == (0,0) else 1
        else:
            candidates = {d for d in self.possible if d.match(input)}
            if candidates:
                self.best_possible = candidates.pop()
            self.possible = {d for d in self.possible if d.could_be(input)}
            if not self.possible:
                self.active = self.best_possible
            return _num(self.possible, self.best_possible)
    
    def eof(self):
        """Notifies the matcher that the end of the input has arived. If there
        is a possible match, then it must be _the_ match."""
        self.active = self.best_possible
        self.best_possible = None
        self.possible = set()
    
    def match(self, input):
        """Returns a pair. The first element is the length of the token which
        this matcher has detected. The second is the delimiter that made the
        match. If no match has been detected, returns (0, None).
        
        Should not be called until either could_be() returns 0 on the same input
        string, or the end of input has been reached."""
        if not self.is_active():
            return (0, None)
        finish = len(self.active.begin)
        unclosed_starts, unclosed_weaves = self.active.count(input[:finish])
        while unclosed_starts > 0 or 0 < unclosed_weaves:
            finish += 1
            if finish > len(input):
                break #MAYBE raise an error
            unclosed_starts, unclosed_weaves = self.active.count(input[:finish])
        return (finish, self.active)
    
    def reset(self):
        """Reinitializes this matcher so that it may look for matches in a
        different location. Must be called after a token has matched in the
        input stream (regardles of whether the match was from this matcher)."""
        self.possible = self._delimiters
        self.best_possible = None
        self.active = None

def _num(possible, best_possible):
    return len(possible) + (1 if best_possible is not None else 0)




