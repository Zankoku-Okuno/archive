"""Provides utilities that help define and detect nonlocal structures.

Nonlocal structures are: keywords, regex patterns and delimited sublanguages.
They are nonlocal because relations between characters in distant parts of the
string can influence whether the structure is valid. E.g. the string "1.34.0e4"
is not a valid number because it contains two periods in the base. Note that the
two periods do not neighbor each other, so a local structure does not suffice to
discriminate between the above invalid string and the valid "1.340e4.".

In case you don't know much about how python relates quantum mechanics, quantum
mechanics (the proper stuff) is a nonlocal theory. In python, 'nonlocal' is a
reserved word, so I can't name my module 'nonlocal'. Thus: quantum (i.e.
nonlocal) structures vs. local structures. (aside: you know, Scala allows
backticks around a name to un-keywordize it; and C# allows the @-prefix)

"""

from functools import reduce

def _partial(standard, input):
    return len(input) < len(standard) and \
           input == standard[:len(input)]
def _full(standard, input):
    return len(standard) <= len(input) and \
           standard == input[:len(standard)]

class Keyword:
    def __init__(self, string):
        self.pattern = string
    
    def could_be(self, input):
        """Returns whether the input might eventually begin with this keyword's
        pattern."""
        return _partial(self.pattern, input)
    
    def match(self, input):
        """Returns whether the input begins with this keyword's pattern."""
        return _full(self.pattern, input)

class Pattern:
    def __init__(self, regex, priority = 0):
        from genregex.thompson import textex
        self.graph = textex.compile(regex)
        self.pattern = regex
        self.priority = priority #zero is least-prioritized
    
    def size(self):
        return self.graph.size()
    
    def could_be(self, input):
        """Returns whether the input might eventually begin with this keyword's
        pattern."""
        pass #STUB
    
    def match(self, input):
        """Returns whether the input begins with this keyword's pattern."""
        pass #STUB

class Delimiter:
    def __init__(self, name, begin, end, escape=None, weave=None, unweave=None): #MAYBE expand this interface with overrides for not_X and not_not_X
        if unweave is None and weave is not None:
            raise ValueError("Must specify unweave if weave specified.")
        
        
        self.name = name
        self.__create_beginning(begin, end, escape)
        self.__create_weaving(weave, unweave, escape)
        
        self._summary = [self.begin, self.end, self.not_end, self.not_not_end,
                         self.weave, self.not_weave, self.unweave, self.not_unweave]
        self._summary = [x for x in self._summary if x is not None]
        
    def could_be(self, input):
        """Returns whether the input might eventually begin with the start
        sequence for this delimiter."""
        return _partial(self.begin, input)
    def match(self, input):
        """Returns whether the input begins with the start sequence for this
        delimiter."""
        return _full(self.begin, input)
    
    def _can_decide(self, input):
        for i in self._summary:
            if _partial(i, input):
                return False
        else:
            return True
    def _decide(self, input):
        return reduce(lambda x,y: y if len(y) > len(x) else x,
                      filter(lambda x: _full(x, input), self._summary),
                      input[0])
    def can_count(self, input):
        while input:
            if self._can_decide(input):
                input = input[len(self._decide(input)):]
            else: return False
        return True
    def count(self, input): #OPTZ make a generator (figure out how generators work)
        #WARNING if the input does not contain the start symbol, but the start symbol is aliased, problems may occur
        unclosed_weaves, unclosed_starts = 0, 0
        weaving = False
        if _full(self.begin, input):
            unclosed_starts += 1
            input = input[len(self.begin):]
        while input:
            if weaving:
                res = self.__count_helper(input, self.not_unweave, None, self.begin, self.unweave, (1,0), (0,-1))
            else:
                res = self.__count_helper(input, self.not_end, self.not_not_end, self.weave, self.end, (0,1), (-1,0))
            input = input[res[0]:]
            if res[1]: weaving = not weaving
            unclosed_starts += res[2]
            unclosed_weaves += res[3]
        return (unclosed_starts, unclosed_weaves)
    def __count_helper(self, input, the_not, the_not_not, the_start, the_end, open, close):
        decision = self._decide(input)
        length = len(decision)
        if decision == the_not:
            return (length, False, 0, 0)
        if decision == the_start:
            return (length, True, open[0], open[1])
        if decision in {the_end, the_not_not}:
            return (length, True, close[0], close[1])
        return (1, False, 0, 0)
    
    # == Construction of all the keywords ==
    def __create_beginning(self, begin, end, escape):
        self.begin = begin
        self.end = end
        self.not_end = None if escape is None else escape + end[0]
        self.not_not_end = None if escape is None else 2*escape + end
    def __create_weaving(self, weave, unweave, escape):
        #print([weave, unweave, escape]) #DEBUG
        self.weave = weave
        self.not_weave = None if None in {escape, weave} else escape + weave[0]
        self.unweave = None if weave is None else unweave
        self.not_unweave = None if None in {escape, unweave} else escape + unweave[0]
        #MAYBE need a not not unweave



