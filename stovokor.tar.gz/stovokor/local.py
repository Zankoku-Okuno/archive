"""Provides utilities that help define and detect local structures.

A local structure is one defined purely by how one character relates to its
immediate neighbors. That is, token build of local characters meet only one
criterion: each character is compatible with both the character before it (if
any) and the character after it (if any).

This is specifically defined against keywords, sublanguages and patterns, all of
which have a much heavier structure, where distant characters may relate to each
other, such as the 'f' and 'r' in the key word "for" or the '.' and the 'e' in
".057e6" """

_NONPRINTING_CODES = {ord('\0')} #TODO

# ========================
# == Types of Alphabets ==
# ========================

class BaseAlphabet:
    """Provides the basic data structure and access methods that all alphabets
    use. Leaves compatibility decisions to subclasses."""
    
    default = "_DEFAULT_PHONEME"
    def __init__(self):
        self._phonemes = dict() #from name to phoneme
    
    def __getitem__(self, char):
        """Returns a set of phoneme names to which the passed character
        belongs."""
        return self._accumulate(self._secure(char))
    
    def __setitem__(self, name, phoneme):
        """Adds a phoneme to the alphabet.
        
        It may be passed a phoneme or a string. If passed a string, it
        constructs a phoneme from that string."""
        if name in {self.default}:
            raise KeyError("Phoneme {0} is reserved.".format(name))
        if isinstance(phoneme, str):
            phoneme = Phoneme(phoneme)
        self._phonemes[name] = phoneme
    
    def compatible(self, char1, char2):
        """Returns whether the two passed characters could be adjecent in a
        non-pattern/keyword token."""
        raise NotImplementedError()
    
    def _secure(self, char):
        if isinstance(char, str):
            if len(char) != 1:
                raise ValueError("Expected single character.")
            char = ord(char)
        if not isinstance(char, int):
            raise ValueError("Expected unicode character code.")
        return char
    def _accumulate(self, char):
        out = set()
        for name in self._phonemes:
            if char in self._phonemes[name]:
                out.add(name)
        if not out:
            return {self.default}
        return out
    
    # Wrappers over Phoneme
    def add(self, phoneme_name, item):
        self._malloc(phoneme_name)
        self._phonemes[phoneme_name].add(item)
    def add_all(self, phoneme_name, string):
        self._malloc(phoneme_name)
        self._phonemes[phoneme_name].add_all(string)
    def add_range(self, phoneme_name, start_char, end_char):
        self._malloc(phoneme_name)
        self._phonemes[phoneme_name].add_range(start_char, end_char)
    def _malloc(self, name):
        if name not in self._phonemes:
            self._phonemes[name] = Phoneme()

class FriendlyAlphabet(BaseAlphabet):
    "An alphabet where all characters are compatible."
    def compatible(self, char1, char2):
        return True
class DisjointAlphabet(BaseAlphabet):
    "An alphabet where all characters are incompatible."
    def compatible(self, char1, char2):
        return False

class RichAlphabet(BaseAlphabet):
    separator = "_SEPARATOR_PHONEME"
    loner = "_LONERS_PHONEME"
    #MAYBE a sticky phoneme that attaches to any neighbor
    
    def _accumulate(self, char):
        if char in _NONPRINTING_CODES: return set()
        return super()._accumulate(char)
    
    def compatible(self, char1, char2):
        p1, p2 = self[char1], self[char2]
        if self.loner in p1 or self.loner in p2:
            return False
        if self.separator in p1 or self.separator in p2:
            return self.separator in p1 and self.separator in p2
        if self.default in p1 or self.default in p2:
            return super().compatible(char1, char2)
        return p1 & p2

# =======================
# == Phoneme Structure ==
# =======================

class Phoneme:
    def __init__(self, initial_chars=""):
        self._chars = set()
        self.add_all(initial_chars)
    
    def __contains__(self, char):
        """Returns whether this phoneme includes the passed character."""
        if isinstance(char, str): char = ord(char)
        return char in self._chars
    def __iter__(self):
        return map(lambda x: chr(x), self._chars).__iter__()
    
    def add(self, item):
        """Adds a single character or codepoint to this phoneme."""
        if isinstance(item, str): item = ord(item)
        if item not in _NONPRINTING_CODES:
            self._chars.add(item)
    def add_all(self, iterable):
        """Adds all the characters in the passed string to this phoneme."""
        for char in iterable:
            self.add(char)
    def add_range(self, start_char, end_char):
        """Adds all unicode code points between the start and end characters,
        inclusive. Whitespace is not added."""
        for codepoint in range(ord(start_char), ord(end_char)+1):
            self.add(codepoint)

    def remove(self, item):
        """Removes a single character or codepoint from this phoneme, if it
        exists."""
        if isinstance(item, str): item = ord(item)
        if item in self._chars:
            self._chars.remove(item)
    def remove_all(self, iterable):
        for char in iterable:
            self.remove(char)



