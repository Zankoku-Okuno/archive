class Driver:
    def __init__(self, alphabet, set_of_keywords, set_of_patterns, set_of_delimiters):
        self.alphabet = alphabet
        self.keywords = set_of_keywords
        self.patterns = set_of_patterns
        self.delimiters = set_of_delimiters

from .submatcher import *

class Matcher:
    def __init__(self, driver):
        self.alphabet_matcher = AlphabetMatcher(driver.alphabet)
        self.keyword_matcher = KeywordMatcher(driver.keywords, driver.alphabet)
        self.pattern_matcher = PatternMatcher(driver.patterns, driver.alphabet)
        self.delimiter_matcher = DelimiterMatcher(driver.delimiters)
        self._summary = {self.alphabet_matcher, self.keyword_matcher, self.pattern_matcher, self.delimiter_matcher}
        self.reset()
    
    def could_be(self, input):
        delims = self.delimiter_matcher.could_be(input)
        if not delims and self.delimiter_matcher.is_active():
            return delims
        phones = self.alphabet_matcher.could_be(input)
        kws = self.keyword_matcher.could_be(input)
        pats = self.pattern_matcher.could_be(input)
        return phones + kws + pats + delims
    
    def match(self, input):
        delim = self.delimiter_matcher.match(input)
        if delim != (0, None):
            return (delim[0], ('delimited', delim[1]))
        phone = self.alphabet_matcher.match()
        kw = self.keyword_matcher.match()
        pat = self.pattern_matcher.match()
        max_len = max(map(lambda x: x[0], [phone, kw, pat]))
        if kw[0] == max_len:
            return (kw[0], ('keyword', kw[1]))
        if pat[0] == max_len:
            return (pat[0], ('pattern', pat[1]))
        if phone[0] == max_len:
            return (phone[0], ('alphabet', phone[1]))
    
    def eof(self, input):
        for matcher in self._summary:
            matcher.eof()
    
    def reset(self):
        for matcher in self._summary:
            matcher.reset()




