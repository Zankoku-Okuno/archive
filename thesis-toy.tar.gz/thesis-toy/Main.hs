module Main where

import System.IO
import System.Exit
import Language.SFCC

main :: IO ()
main = do
	input <- getContents
	expr <- case parseFile "__repl__" input of
		Left err -> print err >> exitFailure
		Right val -> return val
	e_val <- runSFCC expr
	case e_val of
		Left err -> print err >> exitFailure
		Right val -> print val >> exitSuccess
