module Language.SFCC.Support where

import Control.Applicative
import Control.Monad

import Data.Maybe
import qualified Data.Map as Map
import Data.Map (Map)
import Data.List (intercalate)

import Data.IORef


{------ Abstract Syntax ------}

data Expr = NilVal
          | IntVal Integer
          | StrVal String
          | ListVal [Expr]
          | StructVal (Map Symbol Expr) --FIXME allow any non-abstract immutable value as a key
          | RefVal (IORef Expr)
          | Prim Primitive
          | SysPrim ([Expr] -> IO (Either Error Expr))
          | Form SpecialForm
          | Closure Env [Symbol] Expr
          | LazyClosure Env [Symbol] Expr
          | Symbol Symbol
          | List [Expr]
          | Struct [(Symbol, Expr)]
          --TODO slice and sliceBy expressions
          | Test Expr [SubData]
          | Access Expr [SubData]
          | Update Expr [SubData] Expr
          | Delete Expr [SubData]
          | Thunk (IORef (Either (Env, Expr) Expr))
          | Combine Expr [Expr]

data SubData = Field Symbol | Index Expr

data Primitive = 
    -- arithmetic
      Add | Sub | Mul | Div | Mod | Pow
    -- bitwise ops
    | BitMask | BitMerge | BitDiff | BitCompl
    -- lists
    | Len | Cat | Cut
    -- structs and variants
    | MergeStruct | AllAttrs
    | GetAttr | SetAttr | HasAttr | DelAttr
    -- chars and strings
    -- reference cells
    | New | Deref | Assign
    -- relationals
    | Eq | Lt | Gt | Lte | Gte
    -- conversions
    -- system interface
    deriving (Eq, Ord, Enum, Show)

data SpecialForm =
      Lambda | LazyLambda
    | Begin | Local
    | Cond
    | Def | LazyDef
    | LazyLet
    | Module | Export | Load | Import
    deriving (Eq, Ord, Enum, Show)

instance Show Expr where
    show NilVal = "()"
    show (IntVal n) = show n
    show (StrVal s) = show s
    show (ListVal xs) = "[" ++ intercalate " " (show <$> xs) ++ "]"
    show (StructVal map) = "{" ++ intercalate " " (showField <$> Map.toList map) ++ "}"
        where showBinding (x, v) = x ++ ": " ++ show v
    show (Prim x) = show x
    show (SysPrim _) = "<system primitive>"
    show (Form x) = show x
    show (Closure _ _ _) = "<lambda>"
    show (LazyClosure _ _ _) = "<lambda>"
    show (Symbol x) = x
    show (List xs) = "[" ++ intercalate " " (show <$> xs) ++ "]"
    show (Struct map) = "{" ++ intercalate " " (showField <$> map) ++ "}"
    show (Access e sub) = show e ++ concatMap show sub
    show (Update e sub e') = show e ++ concatMap show sub ++ "=" ++ show e'
    show (Thunk _) = "<thunk>"
    show (Combine f xs) = "(" ++ intercalate " " (show <$> f:xs) ++ ")"
showField (x, e) = x ++ ": " ++ show e

instance Show SubData where
    show (Field x) = '.' : show x
    show (Index i) = "[" ++ show i ++ "]"

{------ Values and Errors ------}

isVal :: Expr -> Bool
isVal NilVal = True
isVal (IntVal _) = True
isVal (StrVal _) = True
isVal (ListVal _) = True
isVal (StructVal _) = True
isVal (RefVal _) = True
isVal (Prim _) = True
isVal (SysPrim _) = True
isVal (Form _) = True
isVal (Closure _ _ _) = True
isVal (LazyClosure _ _ _) = True
isVal _ = False

data Error =
      SpecialFormError String
    | ScopeError Symbol -- ^ could not find symbol in scope
    | IndexError Expr Expr -- ^ index out of list bounds
    | FieldError Expr Symbol -- ^ attribute not stored on dictionary/module
    | CombinationError Expr -- ^ cannot call value
    | NumArgumentsError Int Int -- ^ function expected n arguments, but got m
    | TypeError [Expr] -- ^ function was passed values of unexpected type
    deriving (Show)


arity :: Primitive -> Int
arity prim | prim `elem` [
      BitCompl
    , Len
    , New, Deref
    ] = 1
arity prim | prim `elem` [
      Add, Sub, Mul, Div, Mod, Pow
    , BitMask, BitMerge, BitDiff
    , Cat, Cut
    , MergeStruct
    , Eq, Lt, Gt, Lte, Gte
    , Assign
    ] = 2

newThunk :: Env -> Expr -> IO Expr
newThunk env expr@(Symbol x) = do
    val_m <- env `getAttr` x
    case val_m of
        Just thunk@(Thunk _) -> pure thunk
        _ -> Thunk <$> newIORef (Left (env, expr))
newThunk env expr = Thunk <$> newIORef (Left (env, expr))

normIx :: Expr -> Expr -> Either Error Int
normIx (IntVal preN) x@(ListVal xs) = do
    when (preN < fromIntegral (minBound :: Int)) $ Left $ IndexError x (IntVal preN)
    when (fromIntegral (maxBound :: Int) < preN) $ Left $ IndexError x (IntVal preN)
    pure $ if preN >= 0 then fromIntegral preN else length xs + fromIntegral preN

{------ Environments ------}

type Symbol = String
data Env = Env {
      bindings :: IORef (Map Symbol Expr)
    , parent :: Maybe Env
    }
    deriving (Eq)

hasAttr :: Env -> Symbol -> IO Bool
hasAttr e x = do
    r <- Map.member x <$> readIORef (bindings e)
    if r
        then pure True
        else maybe (pure False) (`hasAttr` x) (parent e)

getAttr :: Env -> Symbol -> IO (Maybe Expr)
getAttr e x = do
    r <- Map.lookup x <$> readIORef (bindings e)
    if isNothing r
        then maybe (pure Nothing) (`getAttr` x) (parent e)
        else pure r

setAttr :: Env -> Symbol -> Expr -> IO ()
setAttr e x v = modifyIORef (bindings e) (Map.insert x v)

setAttrs :: Env -> [(Symbol, Expr)] -> IO ()
setAttrs e attrs = modifyIORef (bindings e) (Map.fromList attrs `Map.union`)

newStartEnv :: IO Env
newStartEnv = do
    bindings <- newIORef $ Map.fromList [
        -- arithmetic
          ("add", Prim Add), ("sub", Prim Sub)
        , ("mul", Prim Mul), ("div", Prim Div), ("mod", Prim Mod)
        , ("pow", Prim Pow)
        -- relationals
        , ("eq", Prim Eq)
        , ("lt", Prim Lt), ("gt", Prim Gt)
        , ("lte", Prim Lte), ("gte", Prim Gte)
        -- bitwise ops
        , ("bitmask", Prim BitMask), ("bitmerge", Prim BitMerge)
        , ("bitdiff", Prim BitDiff), ("bitcompl", Prim BitCompl)
        -- list ops
        , ("len", Prim Len), ("cat", Prim Cat), ("cut", Prim Cut)
        -- structure ops
        , ("merge", Prim MergeStruct)
        -- reference cells
        , ("new", Prim New)
        , ("rd", Prim Deref), ("wt", Prim Assign)
        --FIXME add more initial bindings for primitives
        -- special forms
        , ("fn", Form Lambda), ("lambda", Form LazyLambda)
        , ("cond", Form Cond)
        , ("begin", Form Begin), ("local", Form Local)
        , ("def", Form Def), ("lazy", Form LazyDef)
        , ("let", Form LazyLet)
        ] 
    pure $ Env bindings Nothing

newChildEnv :: Env -> IO Env
newChildEnv env = do
    bindings <- newIORef $ Map.empty
    pure $ Env bindings (Just env)


{------ Continuations ------}

type Cont = [ContItem]
data ContItem = ListCont [Expr] {-hole-} [Expr]
              | StructCont (Map Symbol Expr) String {-hole-} [(Symbol, Expr)]
              | ThunkCont (IORef (Either (Env, Expr) Expr))
              | CombinatorCont {-hole-} [Expr]
              | EagerApplyCont Expr     [Expr] {-hole-} [Expr]
              | RestoreEnv Env
              | SeqCont {-hole-} [Expr]
              | CondCont {-hole-} Expr [(Expr, Expr)] Expr
              | DefCont Symbol {-hole-}
              | ExistsCont {-hole-} [SubData]
              | ExistsIndexCont Expr [SubData] {-hole-}
              | AccessCont {-hole-} [SubData]
              | AccessIndexCont Expr [SubData] {-hole-}
              | SlotCont {-hole-} [SubData] (Maybe Expr)
              | SlotIndexCont Expr {-hole-} [SubData] (Maybe Expr)
              | UpdateCont Expr SubData {-hole-}

type MetaCont = [MetaContItem]
data MetaContItem = Cont Cont
                  --TODO pushed handler, onWind, onUnwind, onAbort

atHalt :: MetaCont -> Bool
atHalt [] = True
atHalt [Cont []] = True
atHalt _ = False

--TODO find a handler and split by it
