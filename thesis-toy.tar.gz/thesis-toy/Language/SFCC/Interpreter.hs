{-# LANGUAGE GeneralizedNewtypeDeriving #-}
module Language.SFCC.Interpreter where

import Control.Applicative
import Control.Monad
import Control.Monad.State
import Control.Monad.Trans.Either

import Data.Maybe
import Data.Ratio ((%))
import Data.Bits
import Data.IORef
import qualified Data.Map as Map

import Language.SFCC.Support
import Language.SFCC.SpecialForms


newtype SFCC a = SFCC { sfccMachine :: EitherT Error (StateT MachineState IO) a }
    deriving (Functor, Applicative, Monad, MonadIO)
data MachineState = State {
      currentEnv :: Env
    , metaCont :: MetaCont
    }

runSFCC :: Expr -> IO (Either Error Expr)
runSFCC expr = do
    env <- newStartEnv
    --FIXME move the primitives to Ammonite.System
    let printLn [x] = Right NilVal <$ print x
        printLn args = pure . Left $ NumArgumentsError 1 (length args)
    env `setAttr` "printLn" $ SysPrim printLn
    --END FIXME
    let start = State {
          currentEnv = env
        , metaCont = []
        }
    (val_e, state) <- flip runStateT start $ runEitherT $ sfccMachine (eval expr)
    --FIXME do a stack dump
    pure val_e


eval :: Expr -> SFCC Expr
eval (Symbol x) = do
    env <- SFCC . lift $ gets currentEnv
    m_val <- liftIO $ env `getAttr` x
    case m_val of
        Nothing -> SFCC . left $ ScopeError x
        Just (Thunk cell) -> do
            thunk <- liftIO $ readIORef cell
            case thunk of
                Left (thunkEnv, (Thunk _)) -> error "non-zonked thunk"
                Left (thunkEnv, e) -> do
                    -- move to the thunk's environment
                    State evalEnv metaCont <- SFCC . lift $ get
                    wind (RestoreEnv evalEnv)
                    SFCC . lift $ modify (\s -> s { currentEnv = thunkEnv })
                    -- force the thunk
                    wind (ThunkCont cell) >> eval e
                Right val -> provide val
        Just val -> provide val
eval (List []) = provide (ListVal [])
eval (List (x:xs)) = wind (ListCont [] xs) >> eval x
eval (Struct []) = provide $ StructVal Map.empty
eval (Struct ((k, v):kvs)) = wind (StructCont Map.empty k kvs) >> eval v
eval (Test e route) = wind (ExistsCont route) >> eval e
eval (Access e route) = wind (AccessCont route) >> eval e
eval (Update e route e') = wind (SlotCont route (Just e')) >> eval e
eval (Delete e route) = wind (SlotCont route Nothing) >> eval e
eval (Combine f args) = wind (CombinatorCont args) >> eval f
eval x | isVal x = do
    cont <- SFCC . lift $ gets metaCont
    if atHalt cont
        then pure x
        else provide x

apply :: Expr -> [Expr] -> SFCC Expr
apply f@(Closure defEnv params body) args = do
    -- check params match args
    when (length params /= length args) $
        SFCC . left $ NumArgumentsError (length params) (length args)
    -- move from caller env to child of defining env
    State callEnv metaCont <- SFCC . lift $ get
    wind (RestoreEnv callEnv)
    env' <- liftIO $ newChildEnv defEnv
    SFCC . lift $ modify (\s -> s { currentEnv = env' })
    -- bind args to parameters and eval body
    liftIO $ env' `setAttrs` zip params args
    eval body
apply f@(LazyClosure defEnv params body) args = do
    -- check params match args
    when (length params /= length args) $
        SFCC . left $ NumArgumentsError (length params) (length args)
    -- move from caller env to child of defining env
    State callEnv metaCont <- SFCC . lift $ get
    wind (RestoreEnv callEnv)
    env' <- liftIO $ newChildEnv defEnv
    SFCC . lift $ modify (\s -> s { currentEnv = env' })
    -- create thunks for every arg
    -- FIXME if an iteration takes a lazy argument that gets passed through, the thunk will grow on each iteration
        -- the fix is to see if the arg is a symbol which is bound to a thunk
        -- if so, do not re-wrap the thunk 
        -- that's all in the newThunk logic
    thunks <- liftIO $ newThunk callEnv `mapM` args
    --bind thunks to params and eval body
    liftIO $ env' `setAttrs` zip params thunks
    eval body

apply (Form Lambda) args = do
    (params, body) <- SFCC . hoistEither $ lambdaForm args
    env <- SFCC . lift $ gets currentEnv
    provide $ Closure env params body
apply (Form LazyLambda) args = do
    (params, body) <- SFCC . hoistEither $ lambdaForm args
    env <- SFCC . lift $ gets currentEnv
    provide $ LazyClosure env params body
apply (Form Begin) [] = SFCC . left $ SpecialFormError "malformed begin"
apply (Form Begin) (next:rest) = do
    wind (SeqCont rest)
    eval next
apply (Form Cond) branches = do
    (mainBranches, elseBranch) <- SFCC . hoistEither $ condForm branches
    case mainBranches of
        [] -> eval elseBranch
        ((firstPredicate, firstBranch) : restBranches) -> do
            wind (CondCont firstBranch restBranches elseBranch)
            eval firstPredicate
apply (Form Local) [] = SFCC . left $ SpecialFormError "malformed local"
apply (Form Local) (next:rest) = do
    env <- SFCC . lift $ gets currentEnv
    env' <- liftIO $ newChildEnv env
    wind (RestoreEnv env)
    SFCC . modify $ \s -> s { currentEnv = env' }
    wind (SeqCont rest)
    eval next
apply (Form Def) args = do
    (x, v) <- SFCC . hoistEither $ defForm args
    case v of
        Left expr -> wind (DefCont x) >> eval expr
        Right (params, body) -> do
            env <- SFCC . lift $ gets currentEnv
            liftIO $ env `setAttr` x $ Closure env params body
            provide NilVal
apply (Form LazyDef) args = do
    (x, v) <- SFCC . hoistEither $ defForm args
    env <- SFCC . lift $ gets currentEnv
    case v of
        Left expr -> liftIO $ env `setAttr` x =<< newThunk env expr
        Right (params, body) -> liftIO $
            env `setAttr` x $ LazyClosure env params body
    provide NilVal
apply (Form f) args = error $ "form unimplemented: " ++ show f

apply (Prim prim) args@[x] | arity prim == 1 = do
     case (prim, x) of
        (BitCompl, IntVal x) -> provide $ IntVal (complement x)
        (Len, ListVal xs) -> provide $ IntVal (fromIntegral $ length xs)
        (New, val0) -> provide =<< RefVal <$> liftIO (newIORef val0)
        (Deref, RefVal cell) -> provide =<< liftIO (readIORef cell)
        --TODO more builin definitions
        --TODO user-defined definitions
        _ -> SFCC . left $ TypeError args
apply (Prim prim) args@[x, y] | arity prim == 2 = do
    case (prim, x, y) of
        (Add, IntVal x, IntVal y) -> provide $ IntVal (x + y)
        (Sub, IntVal x, IntVal y) -> provide $ IntVal (x - y)
        (Mul, IntVal x, IntVal y) -> provide $ IntVal (x * y)
        (Div, IntVal x, IntVal y) -> provide $ IntVal (x `div` y)
        (Mod, IntVal x, IntVal y) -> provide $ IntVal (x `mod` y)
        (Pow, IntVal x, IntVal y) -> provide $ IntVal (round $ (x%1) ^^ y)
        (BitMask, IntVal x, IntVal y) -> provide $ IntVal (x .&. y)
        (BitMerge, IntVal x, IntVal y) -> provide $ IntVal (x .|. y)
        (BitDiff, IntVal x, IntVal y) -> provide $ IntVal (x `xor` y)
        (Cat, ListVal xs, ListVal ys) -> provide $ ListVal (xs ++ ys)
        (Cut, ListVal xs, IntVal preN) -> do
            n <- SFCC . hoistEither $ normIx (IntVal preN) (ListVal xs)
            when (n < 0 || length xs < n) $ SFCC . left $ IndexError x (IntVal preN)
            let (ys, zs) = splitAt n xs
            provide $ ListVal [ListVal ys, ListVal zs]
        (MergeStruct, StructVal x, StructVal y) -> provide $ StructVal $ Map.union y x -- haskell is left-biased, Amon is right-
        (Eq, IntVal x, IntVal y) -> provide $ if x == y then IntVal 1 else IntVal 0
        (Lt, IntVal x, IntVal y) -> provide $ if x < y then IntVal 1 else IntVal 0
        (Gt, IntVal x, IntVal y) -> provide $ if x > y then IntVal 1 else IntVal 0
        (Lte, IntVal x, IntVal y) -> provide $ if x <= y then IntVal 1 else IntVal 0
        (Gte, IntVal x, IntVal y) -> provide $ if x >= y then IntVal 1 else IntVal 0
        (Assign, RefVal cell, val') -> do
            liftIO $ writeIORef cell val'
            provide val'
        --TODO more builin definitions
        --TODO user-defined definitions
        _ -> SFCC . left $ TypeError args
apply (Prim prim) args = SFCC . left $ NumArgumentsError (arity prim) (length args)
apply (SysPrim action) args = do
    result <- liftIO $ action args
    val <- SFCC $ hoistEither result
    provide val

wind :: ContItem -> SFCC ()
wind k@(RestoreEnv _) = SFCC . lift $ do
    State env metaCont <- get
    case metaCont of
        _ | atHalt metaCont -> pure ()
        Cont (RestoreEnv _ : _) : _ -> pure ()
        Cont cont : metaCont -> put $ State env (Cont (k:cont) : metaCont)
wind k = SFCC . lift $ do
    State env metaCont <- get
    case metaCont of
        [] -> put $ State env [Cont [k]]
        (Cont cont:metaCont) -> put $ State env (Cont (k:cont) : metaCont)
        --TODO cases for stack markers

windApply :: Expr -> [Expr] -> SFCC Expr
windApply f@(Closure _ _ _) [] = apply f []
windApply f@(Closure _ _ _) (arg:args) = do
    wind $ EagerApplyCont f [] args
    eval arg
windApply f@(LazyClosure _ _ _) args = apply f args
windApply f@(Prim _) [] = apply f []
windApply f@(Prim _) (arg:args) = do
    wind $ EagerApplyCont f [] args
    eval arg
windApply f@(SysPrim _) [] = apply f []
windApply f@(SysPrim _) (arg:args) = do
    wind $ EagerApplyCont f [] args
    eval arg
windApply f@(Form _) args = apply f args

provide :: Expr -> SFCC Expr
provide val = do
    metaCont <- SFCC . lift $ gets metaCont
    case metaCont of
        _ | atHalt metaCont -> pure val
        (Cont []:_) -> popCont >> provide val
        (Cont (k:_):_) -> case k of
            ------ Thunk Forcing ------
            -- base case: remember the result of evaluating the thunk, then move on
            ThunkCont cell -> do
                liftIO $ writeIORef cell (Right val)
                popCont >> provide val
            ------ Context Restoration ------
            RestoreEnv env -> do
                popCont
                SFCC . lift $ modify (\s -> s { currentEnv = env })
                provide val
            -- TODO I'll have to save/restore location as well for good stack traces
            ------ Lists ------
            -- base case: list elements evaluated
            ListCont rev_xs [] ->
                popCont >> provide (ListVal $ reverse (val:rev_xs))
            -- recusive case: append provided value and evaluate another list element
            ListCont rev_xs (x:rest) ->
                swapCont (ListCont (val:rev_xs) rest) >> eval x

            ------ Structs ------
            -- base case: all fields evaluated
            StructCont acc k [] ->
                popCont >> provide (StructVal $ Map.insert k val acc)
            -- recursive case: insert provided value and evaluate another field
            StructCont acc key ((k, v):rest) ->
                let acc' = Map.insert key val acc
                in swapCont (StructCont acc' k rest) >> eval v

            ------ Recursive Data Existence Test ------
            ExistsCont (Field x:route) -> case val of
                StructVal kvs -> case Map.lookup x kvs of
            -- base case 1: provide 1 if field exists, 0 if not
                    Nothing -> popCont >> provide (IntVal 0)
                    Just subVal | null route ->
                        popCont >> provide (IntVal 1)
            -- recursive case 1: continue along route if current field exists
                    Just subVal ->
                        swapCont (ExistsCont route) >> provide subVal
            -- in case of type error, field does not exist
                _ -> popCont >> provide (IntVal 0)
            -- intermediary case: remember provided value, but for now just calculate index
            ExistsCont (Index i:route) ->
                swapCont (ExistsIndexCont val route) >> eval i
            ExistsIndexCont e route -> case (e, val) of
                (ListVal xs, IntVal preN) -> do
                    popCont
                    case undefined of
            -- base case 2: provide 1 if index inside bounds, 0 if not
                        _ | fromIntegral (length xs) <= preN -> provide (IntVal 0)
                        _ | preN < negate (fromIntegral (length xs)) -> provide (IntVal 0)
                        _ | null route -> provide (IntVal 1)
            -- recursive case 2: continue along route if index in bounds
                        _ -> do
                            let n = if preN >= 0 then fromIntegral preN else length xs + fromIntegral preN
                            wind (ExistsCont route) >> provide (xs !! n)
            -- in case of type error, field does not exist
                _ -> popCont >> provide (IntVal 0)

            ------ Recursive Data Access ------
            AccessCont (Field x:route) -> case val of
                StructVal kvs -> case Map.lookup x kvs of
            -- base case 1: fail when a requested field does not exist
                    Nothing -> SFCC . left $ FieldError val x
                    --TODO custom getattr
            -- base case 2: when at end of route, provide requested field
                    Just subVal | null route ->
                        popCont >> provide subVal
            -- recursive case 1: continue along route if field exists
                    Just subVal ->
                        swapCont (AccessCont route) >> provide subVal
                -- base case 1
                _ -> SFCC . left $ FieldError val x
            -- intermediary case: remember provided value, but for now just calculate index
            AccessCont (Index i:route) ->
                swapCont (AccessIndexCont val route) >> eval i
            AccessIndexCont e route -> case (e, val) of
                (ListVal xs, IntVal preN) -> do
                    n <- SFCC . hoistEither $ normIx val (ListVal xs)
            -- base case 1: fail when a requested index does not exist
                    when (n < 0 || length xs <= n) $ SFCC . left $ IndexError (ListVal xs) val
                    popCont
            -- recursive case 2: continue along route if index in bounds
            -- base case 3: provide requested data when route end reached
                    unless (null route) $ wind (AccessCont route)
                    provide $ xs !! n
                -- base case 1
                _ -> SFCC . left $ IndexError e val

            ------ Recursive Data Update and Delete ------
            SlotCont [] Nothing -> error "the syntax should have stopped you from deleting from a list"
            -- base case 1 (update): move on to evaluating the replacement expression
            --                       the continuation will update enclosing data structures
            SlotCont [] (Just e') -> popCont >> eval e'
            SlotCont (Field x:[]) m_e' -> case (val, m_e') of
            -- base case 2 (delete): remove the field from the struct
            -- if the delete was deep, then the continuation will include updates
                (StructVal kvs, Nothing) ->
                    popCont >> provide (StructVal $ Map.delete x kvs)
            -- base case 3 (update): prepare to update, then move on to evaluating the replacement
                (StructVal kvs, Just e') -> do
                    swapCont (UpdateCont val (Field x)) >> eval e'
            -- base case 4: fail when the requested field or index does not exist
                _ -> SFCC . left $ FieldError val x
            SlotCont (Field x:route) e' -> case val of
                StructVal kvs -> case Map.lookup x kvs of
            -- base case 4
                    Nothing -> SFCC . left $ FieldError val x
                    --TODO custom getattr
            -- recursive case 1: prepare to update, then continue along route
                    Just subVal -> do
                        swapCont $ UpdateCont val (Field x)
                        wind $ SlotCont route e'
                        provide subVal
            -- base case 4
                _ -> SFCC . left $ FieldError val x
            -- intermediary case: remember provided value, but for now just calculate index
            SlotCont (Index i:route) e' ->
                swapCont (SlotIndexCont val route e') >> eval i
            SlotIndexCont val0 route e' -> do
                case (val0, val) of
                    (ListVal xs, IntVal preN) -> do
                        n <- SFCC . hoistEither $ normIx val val0
            -- base case 4
                        when (n < 0 || length xs <= n) $ SFCC . left $ IndexError val0 val
            -- recursive case 2: prepare to update, then continue along route
                        swapCont $ UpdateCont val0 (Index (IntVal $ fromIntegral n)) -- pre-normalize the index
                        wind $ SlotCont route e'
                        provide $ xs !! n
                    _ -> SFCC . left $ IndexError val0 val
            -- unwinding case 1: update the value at the requested field
            -- if the update/delete was deep, there will be more updates in the continuation
            UpdateCont (StructVal val0) (Field x) ->
                    popCont >> provide (StructVal $ Map.insert x val val0)
            -- unwinding case 2: update the index at the requested field
            -- if the update/delete was deep, there will be more updates in the continuation
            UpdateCont (ListVal val0) (Index (IntVal n)) -> do  -- expecting already-normalized index
                    let (pre,_:post) = splitAt (fromIntegral n) val0
                    popCont >> provide (ListVal $ pre ++ [val] ++ post)
            -- NOTE: update continuations should be fully checked before pushing to the continuation
            UpdateCont _ _ -> error "precondition failed when providing value to UpdateCont"
            ------ Combination ------
            CombinatorCont args -> do
                case (val, args) of
                    -- base case 1: execute callable without arguments
                    (Closure _ _ _, []) ->
                        popCont >> apply val []
                    -- recursive case: move to eagerly evaluate next argument
                    (Closure _ _ _, arg:args) ->
                        swapCont (EagerApplyCont val [] args) >> eval arg
                    -- base case 2: apply unevaluated arguments to callable
                    (LazyClosure _ _ _, args) ->
                        popCont >> apply val args
                    -- base case 1
                    (Prim _, []) ->
                        popCont >> apply val []
                    -- recursive case
                    (Prim _, arg:args) ->
                        swapCont (EagerApplyCont val [] args) >> eval arg
                    -- base case 1
                    (SysPrim _, []) ->
                        popCont >> apply val []
                    -- recursive case
                    (SysPrim _, arg:args) -> do
                        swapCont (EagerApplyCont val [] args) >> eval arg
                    -- base case 2
                    (Form _, args) ->
                        popCont >> apply val args
                    -- base case 3: fail when applicand is not callable
                    _ -> SFCC . left $ CombinationError val
            -- base case: apply evaluated arguments to remembered callable
            EagerApplyCont f rev_args [] ->
                popCont >> apply f (reverse (val:rev_args))
            -- recursive case: 
            EagerApplyCont f rev_args (arg:args) -> do
                swapCont (EagerApplyCont f (val:rev_args) args) >> eval arg
            ------ Special Form Continuations ------
            SeqCont [] -> popCont >> provide val
            SeqCont (next:rest) -> do
                popCont >> wind (SeqCont rest)
                eval next
            CondCont thisBranch [] elseBranch -> do
                truthy <- isTruthy val
                if truthy
                    then popCont >> eval thisBranch
                    else popCont >> eval elseBranch
            CondCont thisBranch ((nextPred, nextBranch):restBranches) elseBranch -> do
                truthy <- isTruthy val
                if truthy
                    then popCont >> eval thisBranch
                    else popCont >> wind (CondCont nextBranch restBranches elseBranch) >> eval nextPred
            DefCont x -> do
                popCont
                env <- SFCC . lift $ gets currentEnv
                liftIO $ env `setAttr` x $ val
                provide NilVal

isTruthy (IntVal 0) = pure False
isTruthy (IntVal _) = pure True
isTruthy v = SFCC . left $ TypeError [v]


popCont :: SFCC ()
popCont = SFCC . lift $ do
    State env metaCont <- get
    case metaCont of
        _ | atHalt metaCont -> pure ()
        (Cont [] : metaCont) -> put $ State env metaCont
        (Cont (_:cont) : metaCont) -> put $ State env (Cont cont:metaCont)

swapCont :: ContItem -> SFCC ()
swapCont cont = popCont >> wind cont