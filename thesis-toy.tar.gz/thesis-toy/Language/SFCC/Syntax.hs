module Language.SFCC.Syntax where

import qualified Data.Map as Map

import Text.Luthor
import Text.Luthor.Syntax
import Language.SFCC.Support


type Parser a = Parsec String () a

parseExpr :: FilePath -> String -> Either ParseError Expr
parseExpr = parse (between2 (optional_ ws) expr <* endOfInput)

parseFile :: FilePath -> String -> Either ParseError Expr
parseFile = parse (file <* endOfInput)

file :: Parser Expr
file = Combine (Form Local) <$> (expr `sepAroundBy` ws)

expr :: Parser Expr
expr = plainExpr >>= subData
    where
    plainExpr = choice [
          atom
        , compound
        , combination
        ]

atom :: Parser Expr
atom = expect "atom" $
    choice [
          NilVal <$ string "()"
        , IntVal <$> integer
        --TODO other atomic data types
        , Symbol <$> symbol
        ]

{-
Conventions are:
    use dash to separate words in a multi-word identifer
    use ! at the end of an itentifier to signal that it is not referentially transparent (if the effects are encapsulated, it doesn't count)
    use ? at the end of an identifier to signal that it is a predicate (e.g. gt? bool?) (no need to but an `is` prefix, so: `foo?` in lieu of `isFoo?`)
    use ? at the beginning of an identifier to signal that it might be a good value but it might be an error signal
    use $ at the beginning of an identifier to signal that it is assignable (reference cell, fluidvar, mutable array, mutable eobject, &c)
    use / to separate an identifier from its arity, provided arity is significant
    use underscores at the begining or end of an identifier to signal visibility/magic:
        one leading underscore for private
        two leading and trailing underscores for magic
    variations of functions have funcname_flags. for example, if `cp` copies a single file no clobber, `cp_f` copies a single file with clobber, `cp_r` copies a tree no clobber, `cp_rf` copies a tree with clobber
-}
symbol :: Parser Symbol
symbol = expect "symbol" $
    charClass "a-zA-Z_0-9$!?/-" `many1Not` charClass "0-9-"

compound :: Parser Expr
compound = choice [emptyList, listExpr, emptyStruct, structExpr]
    where
    emptyList = ListVal [] <$ inBrackets (optional_ ws)
    listExpr = List <$> inBrackets (expr `sepAroundBy` ws)
    emptyStruct = StructVal (Map.empty) <$ inBraces (optional_ ws)
    structExpr = Struct <$> inBraces (kvPair `sepAroundBy` ws)
    kvPair = symbol <* (colon >> ws) <$$> (,) <*> expr


subData :: Expr -> Parser Expr
subData e0 = do
    route <- many $ attr <||> index
    if null route
        then pure e0
        else
        let tester = Test e0 route <$ case last route of
                (Field _) ->  string ":?"
                (Index _) -> string "?"
            updater = Update e0 route <$> (char '=' *> expr)
            deleter = case last route of
                (Field _ ) -> Delete e0 route <$ char '='
                (Index _) -> parserZero
            accessor = pure $ Access e0 route
        in choice [tester, updater, deleter, accessor]
    where
    attr = Field <$ dot <*> symbol
    index = Index <$> inBrackets expr

combination :: Parser Expr
combination = do
    (f:args) <- inParens $ expr `sepAroundBy1` ws
    pure $ Combine f args
--TODO allow for passing kwargs e.g. (f x y z kwarg1: (f 3) blah: 9)
--TODO allow for a fixed set of infixes (+, -, *, /, %, **, &, |, =, ^, &&, ||, ->, :=, ::, where, \def)
--btw, `->` means "send": take the eval'd first arg, look up the attr, then call the attr with the first arg and the rest
--also, `:=` means assign, usable on reference cells, fluid, channels, &c
--btw, `::` means "assert type", which performs a dynamic type check. definitely usable in function definitions
    -- e.g. (def (foo (a :: nat?) (b :: list? int?) :: int?) (b[a]))
    -- foo takes a natural number, a list of ints, and returns an int
    -- like other lang's asserts, they can be turned off in production

ws :: Parser ()
ws = many1_ $ expect "whitespace" $ choice [
      void lws
    , newline
    , void $ nestingComment "#(" ")#"
    , void $ lineComment "#"
    ]
