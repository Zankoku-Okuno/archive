module Language.SFCC.SpecialForms where

import Control.Applicative
import Control.Monad
import Language.SFCC.Support


defForm :: [Expr] -> Either Error (Symbol, Either Expr ([Symbol], Expr))
defForm [] = Left $ SpecialFormError "malformed def"
defForm [_] = Left $ SpecialFormError "malformed def"
defForm (Symbol x : exprs) = Right (x, Left $ implicitBegin exprs)
defForm ((Combine (Symbol x) m_params) : exprs) = do
    params <- mapM aParam m_params
    Right (x, Right (params, implicitBegin exprs))

lambdaForm :: [Expr] -> Either Error ([Symbol], Expr)
lambdaForm [] = Left $ SpecialFormError "malformed abstraction"
lambdaForm [params, body] = do
    params <- paramList params
    pure $ (params, body)
lambdaForm (params:body) = do
    params <- paramList params
    pure $ (params, Combine (Form Begin) body)

paramList :: Expr -> Either Error [Symbol]
--FIXME make sure the same param is not defined twice
paramList NilVal = Right []
paramList x@(Symbol _) = (:[]) <$> aParam x
paramList (Combine arg args) = mapM aParam (arg:args)
paramList _ = Left $ SpecialFormError "bad param list"

aParam :: Expr -> Either Error Symbol
aParam (Symbol x) = Right x
aParam _ = Left $ SpecialFormError "bad param"


condForm :: [Expr] -> Either Error ([(Expr, Expr)], Expr)
condForm [] = Left $ SpecialFormError "malformed cond"
condForm [elseBranch] = Right ([], elseBranch)
condForm branches = do
    mainBranches <- mapM condCase (init branches)
    Right (mainBranches, last branches)

condCase :: Expr -> Either Error (Expr, Expr)
condCase (Combine predicate [action]) = Right (predicate, action)
condCase _ = Left $ SpecialFormError "malformed cond case"

implicitBegin :: [Expr] -> Expr
implicitBegin [] = error "implicit begin of zero exprs"
implicitBegin [expr] = expr
implicitBegin exprs = Combine (Form Begin) exprs