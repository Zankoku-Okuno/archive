thesis-toy
==========

Toy language illustrating the ideas in my master's thesis "On Secure First-Class Control"
