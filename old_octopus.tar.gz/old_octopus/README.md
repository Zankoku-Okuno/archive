Octopus
=======

A programming language inspired by Python and Kernel.

"A language called octopus? Heheh..."

No, I am not wanking off about github. In fact, octopuses are well known for their 
curiosity, intellegence, and dexterity, so it seems perfectly apt to associate a 
language like this after such a creature. Not to mention they are one of my favorite 
animals; I would probably keep one as a pet if it weren't so high-maintenence.

Features
--------

There are several things I want to do with this language. All in all, they should 
add up to a simple but powerful dynamic language with relatively strong reliability 
guarantees.

* Dynamic Manifest Typing: variables have types that are assigned and checked at 
runtime. For the most part, types will simply be strong, but I may investigate explicit 
structural typing as well (like Java interfaces, but interface implementation is 
inferred).
* First-Class Environments: If you've read about it, then you know how powerful 
the Kernel programming language is. It's the ultimate in high-level general-purpose 
programming languages (among those that make you write the parse tree by hand), and 
it's all due to it's first-class environments and the $vau primitive. I'm not sure 
those constructs will be as front-and-center as in Kernel, but the'll be there for 
when you need them.
* Everything is an Environment: Everything has bindings to track state. This is 
essentially everything is an object, but in the Ruby (good) way, not the Java (bad >.<) 
way.
* Decoupled and Introspective Stack: Even function activations are environments. 
I plan on keeping a fairly stack-frame-based layout, since I would like to investigate 
decoupled stacks in performance-oriented languages, but there are bigger immediate 
benefits: dynamic scope, continuations, introspection, and tail calls, to name a 
few, can all be implemented within Octopus itself.
* Cleanup Python: Some things about Python just annoy me. A lot. And I can elucidate 
each language design flaw in excruciating detail, so don't get me started. Perhaps 
I'll provide a link to Python, though, so I can leverage the excellent libraries.

Status
------

<del>Ho hum, nothing to see, move along.</del>
 
<del>Okay, now it's a calculator. One where you can make your own environments and 
set variables in them, but really still little more than a calculator. Also, 
there are exceptions, but no way to catch and handle them.</del>

With the introduction of `if` and `loop`, Octopus is now Turing-complete! Annoyingly, 
most real features are out of reach: user-defined functions, most data types...