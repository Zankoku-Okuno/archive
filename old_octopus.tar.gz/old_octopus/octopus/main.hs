import Prelude hiding (catch)
import System.Environment
import System.Console.GetOpt
import System.Exit
import qualified Control.Exception as E
import Control.Exception ( SomeException(..)
                         , AsyncException(..) )
import System.Console.Haskeline hiding (catch, handle)
import qualified System.Console.Haskeline as Hl

import Octopus.Common

import Octopus.Syntax
import Octi.Data
import Octi.Eval
import Octi.Eval.Monad
import Octi.Display
import Octi.Builtin

import Octi.Repl


progVersion = "Version 0.01"

main :: IO ()
main = do
        (actions, args, errors) <- return . getOpt Permute options =<< getArgs
        when (errors /= []) $ do
            mapM putErrLn errors
            exitFailure
        Options { optVerbose  = verbose
                , optBatch    = batch
                , optInput    = command
                , optInteract = interactive
                } <- foldl (>>=) (return startOptions) actions
        let enterREPL = if verbose then friendlyREPL else repl
        machine <- startMachine
        case (batch, args, interactive || command == Nothing) of
            (True, [], _) -> do 
                putErrLn "No input files. Executing from stdin..."
                batchExec machine "cmdline" =<< getContents
                return ()
            (True, _, _) -> do
                    --TODO if there's a slash in the arg, it's a filename, else its a modulename
                    contents <- mapM readFile args
                    loop machine (zip args contents)
                    when interactive $ enterREPL machine
            (False, _, interactive) -> do
                --FIXME just import modules/files from args, don't execute here
                contents <- mapM readFile args
                loop machine (zip args contents)
                case command of
                    Nothing -> return ()
                    Just input -> batchExec machine "cmdline" input
                when interactive $ enterREPL machine
    where loop machine [] = return ()
          loop machine ((fname,contents):xs) = do
            batchExec machine fname contents
            loop machine xs

batchExec :: OctMachine -> FilePath -> String -> IO ()
batchExec machine filename input = case octParser filename input of
    Left err -> putErrLn ("Syntax Error: " ++ show err) >> exitFailure
    Right ast -> do
        evald <- evalOctopusT machine $ eval ast
        case evald of
            Right _ -> return ()
            Left ex -> putErrLn (showException ex) >> exitFailure


-- The following architecture is taken from http://www.haskell.org/haskellwiki/High-level_option_handling_with_GetOpt

startOptions :: Options
startOptions = Options  { optVerbose    = True
                        , optInteract   = False
                        , optBatch      = False
                        , optInput      = Nothing
                        }

data Options = Options  { optVerbose    :: Bool
                        , optInteract   :: Bool
                        , optBatch      :: Bool
                        , optInput      :: Maybe String
                        }

options :: [OptDescr (Options -> IO Options)]
options =
    [ Option "i" ["interact"]
        (NoArg
            (\opt -> if optBatch opt
                       then putErrLn "Cannot use `-i` with `-x`." >> exitFailure
                       else return opt { optInteract = True }))
        "Enter the interactive REPL. This action is default if neither `-x` nor `-c` are given.\n\
If file or module names are given, these are imported first (but before any `-c` command)."
    ,  Option "x" ["execute"]
        (NoArg
            (\opt -> if optInteract opt
                       then putErrLn "Cannot use `-x` with `-i`." >> exitFailure
                       else return opt { optBatch = True }))
        "Execute code from a file. If no file given, execute from stdin. Cannot be used with `-i`."
    , Option "c" ["command"]
        (ReqArg
            (\arg opt -> return opt { optInput = Just arg })
            "code")
        "Execute passed code. If `-i` is passed also, then enter the REPL afterwards."
    , Option "q" ["quiet"]
        (NoArg
            (\opt -> return opt { optVerbose = False }))
        "Disable verbose messages"
    , Option "v" ["verbose"]
        (NoArg
            (\opt -> return opt { optVerbose = True }))
        "Enable verbose messages"
    , Option "V" ["version"]
        (NoArg
            (\_ -> do
                hPutStrLn stderr progVersion
                exitWith ExitSuccess))
        "Print version"
    , Option "h" ["help"]
        (NoArg
            (\_ -> do
                prg <- getProgName
                putErrLn "Interpreter for the Octopus language."
                putErrLn "This interpretrer is licensed under GPLv3."
                putErrLn (usageInfo (prg ++ " [options]") options)
                exitWith ExitSuccess))
        "Show help"
    ]

