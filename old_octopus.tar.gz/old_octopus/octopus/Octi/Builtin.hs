module Octi.Builtin 
    ( nullEnv
    , dispatchBuiltin
    , throwBuiltin
    , startMachine
    , BasicException(..)
    ) where

import Octopus.Common
--MAYBE I can get rid of this dependency
import qualified Octopus.AST as AST
import Octopus.AST (Node, ParamQualifier (StrictParam, LazyNameParam, LazyNeedParam) )
import Octi.Data
import Octi.Eval.Monad

startMachine :: IO OctMachine
startMachine = do
  prelude <- preludeEnv
  newMachine prelude

nullEnv :: IO Value
nullEnv = return . Environment . Env =<< newIORef ([], [])




preludeEnv :: IO Env
preludeEnv = do
        emptyEnv <- liftIO nullEnv
        __new_environment__        <- pack emptyEnv [] MakeEnv
        __current_environment__    <- pack emptyEnv [] CurrEnv
        __add_parent_environment__ <- pack emptyEnv [one, two] AddParentEnv
        __integer_environment__    <- pack emptyEnv [] IntEnv
        let prelude = [ (intern "__new_environment__", __new_environment__)
                      , (intern "__current_environment__", __current_environment__)
                      , (intern "__add_parent_environment__", __add_parent_environment__)
                      , (intern "__integer_environment__", __integer_environment__)
                      ]
        return . Env =<< newIORef (prelude, [])
    where pack env parms func = newIORef $ Strict $ Builtin func (Params env parms)
          param str = (intern ("arg" ++ str), StrictParam, Nothing)
          one = param "0"
          two = param "1"


instance Show OctBuiltin where
    show x = "<builtin: " ++ case x of
            CurrEnv -> "__current_environment__"
            MakeEnv -> "__new_environment__"
            AddParentEnv -> "__add_parent_environment__"
        ++ ">"

__current_environment__ :: Octopus Value
__current_environment__ = return =<< getEnv

__new_environment__ :: Octopus Value
__new_environment__ = return =<< (liftIO nullEnv)
--TODO error on other args
--new Environment(parents...) as part of a library

__add_parent_environment__ :: Arguments -> Octopus Value
__add_parent_environment__ [a,b] = case (a,b) of
    ((_, Strict (Environment child)), (_, Strict (Environment parent))) -> do
        liftIO $ child `addParentEnv` parent
        return Void
    _ -> throwBuiltin TypeError


dispatchBuiltin :: Value -> Octopus Value
dispatchBuiltin (Application (CallBuiltin func) _ args) = case func of
    CurrEnv -> __current_environment__
    MakeEnv -> __new_environment__
    AddParentEnv -> __add_parent_environment__ args
    IntEnv -> return . Environment =<< intClass

throwBuiltin :: (Monad m) => BasicException -> OctopusT m a
--FIXME create an object of the appropriate class
throwBuiltin t = do
    env <- getEnv
    expr <- getExpr
    throw $ IFE dispatch env expr Nothing Nothing
    where dispatch = case t of
            Unbound     -> (OctString "Unbound identifier.")
            TypeError   -> (OctString "Type error.")
            Unbindable  -> (OctString "Variable cannot be bound.")
            MissingArg  -> (OctString "Missing positional argument(s).")
            TooManyArgs -> (OctString "Too many positional arguments.")
            DivZeroExc  -> (OctString "Divide by zero.")

data BasicException = Unbound | TypeError | Unbindable | MissingArg | TooManyArgs | DivZeroExc
--TODO transmit more info
