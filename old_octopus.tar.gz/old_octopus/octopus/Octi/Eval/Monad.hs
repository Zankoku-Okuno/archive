module Octi.Eval.Monad
    ( Octopus
    , OctopusT
    , OctMachine
    , newMachine
    , evalOctopusT
    , getEnv, inEnv
    , getExpr, inExpr
    , intClass
    , throw, attempt
    ) where

import Octopus.Common

import Control.Monad.IO.Class
import Control.Monad.Trans.Class

import qualified Octopus.AST as AST
import Octopus.AST (Node)
import Octi.Data

type Octopus = OctopusT IO

newtype OctopusT m a = OctopusT { runOctopusT :: OctMachine -> m (Either IFE a, OctMachine) }
-- WARNING: so as not to export `runOctopusT`, only IORefs and things you can throw away should go in here
data OctMachine = OctMachine {
    currentEnvironment :: Env
  , currentExpression :: Node
  , _intClass :: Env
}

instance (Monad m) => Monad (OctopusT m) where
    return a = OctopusT $ \s -> return (Right a, s)
    (OctopusT x) >>= f = OctopusT $ \s -> do 
        (result, s') <- x s
        case result of
            Left  err -> return (Left err, s')
            Right val -> runOctopusT (f val) s'

instance MonadTrans OctopusT where
    lift c = OctopusT $ \s -> (c >>= \x -> return (Right x, s))

instance (MonadIO m) => MonadIO (OctopusT m) where
    liftIO = lift . liftIO


newMachine :: Env -> IO OctMachine
newMachine preludeEnv = do
    intEnv <- nullEnv
    return OctMachine {
        currentEnvironment = preludeEnv
      , currentExpression = AST.Void
      , _intClass = intEnv
    }

nullEnv :: IO Env
nullEnv = return . Env =<< newIORef ([], [])

evalOctopusT :: (Monad m) => OctMachine -> OctopusT m a -> m (Either IFE a)
evalOctopusT s c = do
    (result, _) <- runOctopusT c s
    return result


{- Accessors -}

getEnv :: (Monad m) => OctopusT m ExpectEnv
getEnv = OctopusT $ \s -> return (pack $ currentEnvironment s, s)
    where pack e = Right (Environment e)
putEnv :: (Monad m) => ExpectEnv -> OctopusT m ()
putEnv (Environment env) = OctopusT $ \s -> return (Right (), s {currentEnvironment = env})

inEnv :: (Monad m) => ExpectEnv -> OctopusT m a -> OctopusT m a
inEnv env' f = do
    env <- getEnv
    putEnv env'
    result <- f
    putEnv env
    return result


getExpr :: (Monad m) => OctopusT m Node
getExpr = OctopusT $ \s -> return (Right $ currentExpression s, s)
putExpr :: (Monad m) => Node -> OctopusT m ()
putExpr node = OctopusT $ \s -> return (Right (), s {currentExpression = node})

inExpr :: (Monad m) => Node -> OctopusT m a -> OctopusT m a
inExpr node' f = do
    node <- getExpr
    putExpr node'
    result <- f
    putExpr node
    return result


{- Builtin Classes -}
intClass :: Octopus Env
intClass = OctopusT $ \s -> return (Right $ _intClass s, s)


{- Exception Handling -}

throw :: (Monad m) => IFE -> OctopusT m a
throw exc = OctopusT $ \s -> return (Left exc, s)

attempt :: (Monad m) => OctopusT m a -> (IFE -> OctopusT m b) -> (a -> OctopusT m b) -> OctopusT m b
attempt (OctopusT try) handler k = OctopusT $ \s -> do
    (result, s') <- try s
    case result of
        Right val -> runOctopusT (k val) s'
        Left err  -> case doubleException err of
            -- If a double exception has been encountered, don't attempt recovery: unroll to top
            Just _  -> return (Left err, s')
            Nothing -> do
                (result', s'') <- runOctopusT (handler err) s'
                case result' of
                    Right val' -> return (Right val', s'')
                    -- An exception has escaped the handler: double exception
                    Left err'  -> return (Left err { doubleException = Just err' }, s'')

