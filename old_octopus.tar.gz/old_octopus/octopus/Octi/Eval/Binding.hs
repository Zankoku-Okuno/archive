{- Memory Model -}
defVar :: Value -> Symbol -> OctopusVariable -> Octopus Value
defVar (Environment env) name val = do
    x <- liftIO $ newIORef val
    liftIO $ env `appendEnv` (name, x)
    return $ Reference $ Right x
defVar obj name val = throwBuiltin Unbindable

getVar, getVar' :: Value -> Symbol -> Octopus Value
getVar  = _Env_getVar False
getVar' = _Env_getVar True

getRef, getRef' :: Value -> Symbol -> Octopus Value
getRef  = _Env_getRef False
getRef' = _Env_getRef True

setVar :: Value -> OctopusVariable -> Octopus Value
--TODO type checking
setVar (Reference (Left (env,name))) val = defVar env name val
setVar ref@(Reference (Right loc)) val       = (liftIO $ loc `writeIORef` val) >> return ref

ref2var :: Value -> Octopus Value
ref2var (Reference (Right ref)) = _accessVar ref
ref2var (Reference (Left (_, name))) = throwBuiltin Unbound


{- Lookup Procedures -}

directLookup :: Value -> Symbol -> Octopus (Maybe (IORef OctopusVariable))
directLookup (Environment (Env env)) name = do
    (bindings, _) <- liftIO (readIORef env)
    directLookup' bindings name
directLookup val name = throwBuiltin Unbindable

normalLookup :: Value -> Symbol -> Octopus (Maybe (IORef OctopusVariable))
normalLookup (Environment env) name = normalLookup' env name
normalLookup val name = throwBuiltin Unbindable

memberLookup :: Value -> Symbol -> Octopus (Maybe (IORef OctopusVariable))
memberLookup obj@(Environment env) name = do
        --TODO lookup in builtin types
        --TODO call dot
        result <- normalLookup' env name
        result <- maybe typeLookup (return . return) result
        maybe missingLookup (return . return) result
    where
    typeLookup = do
        __type__ <- normalLookup' env (intern "__type__")
        case __type__ of
            Nothing -> return Nothing
            Just x -> attempt (_accessVar x) (return $ return Nothing) (classicalLookup obj name . (:[]))
    missingLookup | name `elem` bypass = return Nothing
                  | otherwise          = return Nothing --STUB
    bypass = [intern "__dot__", intern "__missing__"]
memberLookup obj name = do
    cls <- case obj of
        OctInt _ -> intClass
        --TODO more primitives
    maybe (throwBuiltin Unbound) (return . return) =<< normalLookup' cls name

{- Helpers -}

classicalLookup :: Value -> Symbol -> [ExpectEnv] -> Octopus (Maybe (IORef OctopusVariable))
classicalLookup obj name (Environment cls:mro) = do
        result <- normalLookup' cls name
        case result of
            Nothing -> do
                __supers__ <- inherit
                classicalLookup obj name $ mro ++ __supers__
            Just x -> instantiate x
        --TODO
    --            if callable, partial bind the instance
    --            elsewise, simply return as usual
    where
        --instantiate (Builtin params func) = return . return --FIXME apply the obj
        instantiate x = return $ return x
        inherit = do
            __supers__ <- normalLookup' cls (intern "__supers__") --FIXME shuold probably not be a normal lookup
            --TODO try to access supers and turn it into a haskell list. If it's not an octopus list, then that's a type error
            return [] --STUB
classicalLookup obj name [] = return Nothing

directLookup' :: [Binding] -> Symbol -> Octopus (Maybe (IORef OctopusVariable))
directLookup' bindings name = maybe (return Nothing) (return . Just) (lookup name bindings)

normalLookup' :: Env -> Symbol -> Octopus (Maybe (IORef OctopusVariable))
normalLookup' (Env env) name = do
        (bindings, parents) <- liftIO (readIORef env)
        result <- directLookup' bindings name
        maybe (recurse parents) (return . return) result
    where recurse [] = return Nothing
          recurse (p:ps) = do
            result <- normalLookup' p name
            maybe (recurse ps) (return . return) result

_Env_getVar :: Bool -> Value -> Symbol -> Octopus Value
_Env_getVar direct env name = maybe badpack goodpack =<< lookup env name
    where badpack = throwBuiltin Unbound
          goodpack = _accessVar
          lookup = if direct then directLookup else memberLookup

_Env_getRef :: Bool -> Value -> Symbol -> Octopus Value
_Env_getRef direct env name = do
        result <- lookup env name
        case result of
            Just ref -> pack $ Right ref
            Nothing -> pack $ Left (env, name)
    where lookup = if direct then directLookup else normalLookup
          pack = return . Reference

_accessVar :: IORef OctopusVariable -> Octopus Value
_accessVar ref = do
    val <- liftIO $ readIORef ref
    case val of
        Strict val -> return val
        LazyNeed env' val -> return =<< inEnv env' (rvalue val)
        LazyName env' val -> do
            val' <- inEnv env' (rvalue val)
            liftIO $ ref `writeIORef` (Strict val')
            return val'