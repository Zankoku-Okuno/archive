{- Arithmetic Operations -}
arithmetic :: Value -> BinOp -> Value -> Octopus Value
arithmetic a op b = do
        case (a,b) of
            (OctInt a,    OctInt b)    -> evalIntInt       a op b
            (OctInt a,    OctReal b)  -> evalIntFloat     a op b
            (OctReal a,   OctInt b)    -> evalFloatInt     a op b
            (OctReal a,   OctReal b)  -> evalFloatFloat   a op b
            (OctChar a,   OctChar b)   -> evalCharChar     a op b
            (OctString a, OctString b) -> evalStringString a op b
            (OctString a, OctInt b)    -> evalStringInt    a op b
            (OctInt a,    OctString b) -> evalStringInt    b op a
    where    
    evalIntInt a op b = case op of
        OpPlus      ->               return $ OctInt  $ a+b
        OpMinus     ->               return $ OctInt  $ a-b
        OpMultiply  ->               return $ OctInt  $ a*b
        OpDivide    -> checkZero b $ return $ OctReal $ (fromIntegral a)/(fromIntegral b)
        OpQuotient  -> checkZero b $ return $ OctInt  $ div a b
        OpRemainder -> checkZero b $ return $ OctInt  $ mod a b
        --OpDivmod  -> checkZero b $ ??? (quotRem) a b --TODO returns two integers
        OpExponent  | b >= 0    ->   return $ OctInt  $ a^b
                    | otherwise ->   return $ OctReal $ (fromIntegral a)**(fromIntegral b)
        --TODO error on other cases
    evalIntFloat a op b = case op of
        OpPlus     ->               return $ OctReal $ (fromIntegral a)+b
        OpMinus    ->               return $ OctReal $ (fromIntegral a)-b
        OpMultiply ->               return $ OctReal $ (fromIntegral a)*b
        OpDivide   -> checkZero b $ return $ OctReal $ (fromIntegral a)/b
        OpExponent ->               return $ OctReal $ (fromIntegral a)**b
        --TODO error on other cases
    evalFloatInt a op b = case op of
        OpPlus     ->               return $ OctReal $ a+(fromIntegral b)
        OpMinus    ->               return $ OctReal $ a-(fromIntegral b)
        OpMultiply ->               return $ OctReal $ a*(fromIntegral b)
        OpDivide   -> checkZero b $ return $ OctReal $ a/(fromIntegral b)
        OpExponent ->               return $ OctReal $ a**(fromIntegral b)
        --TODO error on other cases
    evalFloatFloat a op b = case op of
        OpPlus     ->               return $ OctReal $ a+b
        OpMinus    ->               return $ OctReal $ a-b
        OpMultiply ->               return $ OctReal $ a*b
        OpDivide   -> checkZero b $ return $ OctReal $ a/b
        OpExponent ->   return $ OctReal $ a**b
        --TODO error on other cases
    evalCharChar a op b = case op of
        OpPlus  -> return $ OctChar $ chr $ (ord a) + (ord b)
        OpMinus -> return $ OctChar $ chr $ (ord a) - (ord b)
        --TODO error on other cases
    evalStringString a op b = case op of
        OpPlus -> return $ OctString $ a ++ b
        --TODO error on other cases
    evalStringInt a op b = case op of
        OpMultiply -> return $ OctString $ concat $ take (fromInteger b) $ repeat a
        --TODO error on other cases
    
    checkZero val k = case val of
        0 -> throwBuiltin DivZeroExc
        _ -> k
