{- Parameter Passing -}
bindArgs :: Callable -> Parameters -> Node -> Octopus Value
bindArgs func params args@(AST.Args _) = do
        Application func remaining applied <- bindPartial func params args
        return . uncurry (Application func) =<< applyDefaults remaining applied
    where
        applyDefaults params@(Params _     []   ) args = return $ (params, args)
        applyDefaults (Params pEnv (p:ps)) args = do
            arg <- case p of
                (name, StrictParam,   Just expr) -> return . ((,) name) . Strict   =<< inEnv pEnv (rvalue expr)
                (name, LazyNameParam, Just expr) -> return       (name,   LazyName           pEnv expr)
                (name, LazyNeedParam, Just expr) -> return       (name,   LazyNeed           pEnv expr)
                (_,    _,             Nothing  ) -> throwBuiltin MissingArg
            applyDefaults (Params pEnv ps) (arg:args)

bindPartial :: Callable -> Parameters -> Node -> Octopus Value
bindPartial func params (AST.Args args) = apply params [] args
    where
        apply  params                      bound  []        = return $ Application func params bound
        apply (Params pEnv  [])            bound  args      = throwBuiltin TooManyArgs
        apply (Params pEnv (param:params)) bound (arg:args) = do
            env <- getEnv
            binding <- case param of
                (name, StrictParam,   _) -> return . ((,) name) . Strict   =<< rvalue arg
                (name, LazyNameParam, _) -> return       (name,   LazyName        env arg)
                (name, LazyNeedParam, _) -> return       (name,   LazyNeed        env arg)
            apply (Params pEnv params) (bound++[binding]) args

bindMethod :: Value -> Value -> Octopus Value
bindMethod (Builtin func (Params _ [])) obj = throwBuiltin TooManyArgs
bindMethod (Builtin func (Params pEnv ((pName, _, _):ps))) obj = do
    return $ Application (CallBuiltin func) (Params pEnv ps) [(pName, Strict obj)]
--TODO for functions and properties also