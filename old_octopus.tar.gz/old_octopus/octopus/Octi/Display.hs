module Octi.Display where

import Octopus.Common
import Octi.Data
import Octi.Builtin ()

instance Show Value where
    show  Void         = "void"
    show  Nil          = "nil"
    show (OctBool b)   = if b then "true" else "false"
    show (OctInt  n)   = show n
    show (OctReal n)   = show n

    show (OctChar '\'')                           = "'''"
    show (OctChar '\\')                           = "'\\'"
    show (OctChar c) | c `elem` specials          = quote escape
                     | isControl c && ord c < 256 = quote ('\\':hex c)
                     --TODO notation for non-printing characters > 0xff
                     | otherwise                  = ('\'':c:"'")
        where hex c     = map toUpper $ showHex (ord c) ""
              quote x   = "'" ++ x ++ "'"
              escape    = fromJust $ lookup c $ zipWith (,) specials semantics
              specials  = "\a\b\f\n\r\t\v"
              semantics = ["\\a","\\b","\\f","\\n","\\r","\\t","\\v"]
    
    show (OctString s) = "\"" ++ s ++ "\"" -- TODO escape char encoding

    show (Builtin func _) = show func

    show (Environment _) = "<environment>"


showException (IFE val env expr prev k) = prefix ++ loc ++ "\n"
                                       ++ node expr     ++ "\n"
                                       ++ (show val)    ++ "\n"
                                       ++ tb env
  where prefix = "Unhandled Exception:"
        loc    = " at `" ++ "TODO" ++ "' line " ++ "TODO"
        node   = ("    in: " ++) . show
        tb env = "Traceback:\n" ++ "TODO"