module Octi.Eval (
      eval
    ) where

import Octopus.Common
import qualified Octopus.AST as AST
import Octopus.AST (
      Node (Name, Unary, Binary)
    , ParamQualifier (StrictParam, LazyNameParam, LazyNeedParam)
    , UnOp (..), BinOp (..)
    )
import Octi.Eval.Monad
import Octi.Data
import Octi.Builtin (dispatchBuiltin, throwBuiltin, BasicException(..))

eval   = _eval VValue
lvalue = _eval LValue
rvalue = _eval RValue

data EvalContext = RValue | LValue | VValue
    deriving (Eq)

_eval :: EvalContext -> Node -> Octopus Value

{- Primitives -}
_eval _  AST.Void            = return   Void
_eval _  AST.Nil             = return   Nil
_eval _ (AST.OctBool   atom) = return $ OctBool   atom
_eval _ (AST.OctInt    atom) = return $ OctInt    atom
_eval _ (AST.OctReal   atom) = return $ OctReal   atom
_eval _ (AST.OctChar   atom) = return $ OctChar   atom
_eval _ (AST.OctString atom) = return $ OctString atom

{- Binding Manipulation -}
_eval LValue                  (Name name)  =               getEnv >>= flip getRef  name
_eval _                       (Name name)  =               getEnv >>= flip getVar  name
_eval LValue node@(Unary OpMy (Name name)) = inExpr node $ getEnv >>= flip getRef' name
_eval _      node@(Unary OpMy (Name name)) = inExpr node $ getEnv >>= flip getVar' name

_eval deref node@(Binary OpMember x (Name name)) = inExpr node $ do
    env' <- rvalue x
    let access = if deref == LValue then getRef else getVar
    access env' name

_eval deref expr@(Binary OpAssign lhs rhs) = inExpr expr $ do
    val <- rvalue rhs
    ref <- lvalue lhs
    assign deref ref val

_eval deref expr@(Binary (OpImmediate op) lhs rhs) = inExpr expr $ do
    rval <- rvalue rhs
    ref  <- lvalue lhs
    --TODO look up __iop__
    --TODO? defaults for int, float, string, collections
    lval <- ref2var ref
    val' <- arithmetic lval op rval
    assign deref ref val'


{- Control Structures -}
_eval deref (AST.Block statements) = impl statements
    where impl (x:[]) = _eval deref x
          impl (x:xs) = do
            result <- _eval deref x
            case result of
                Fallthrough -> return Fallthrough
                Break       -> return Break
                Continue    -> return Continue
                _           -> impl xs

_eval _ (AST.Fallthrough) = return Fallthrough
_eval _ (AST.Break)       = return Break
_eval _ (AST.Continue)    = return Continue
_eval _ (AST.LoopDone)    = return LoopDone

_eval deref (AST.Check b test exec) = do
    (OctBool val) <- truthy =<< rvalue test
    if val == b
        then _eval deref exec
        else return GuardFailure

_eval deref (AST.IfChain chain) = impl chain
    where impl (x:[]) = _eval deref x
          impl (x:xs) = do
            result <- _eval deref x
            case result of
                GuardFailure -> impl xs
                Fallthrough  -> impl xs
                _ ->           return result

_eval deref (AST.Loop b test body lThen lElse) = do
        exit <- impl
        case exit of
            LoopDone -> maybe (return Void) (_eval deref) lThen
            Break    -> maybe (return Void) (_eval deref) lElse
    where impl = do
            (OctBool val) <- truthy =<< rvalue test
            if val == b
              then do
                result <- _eval deref body 
                case result of 
                    LoopDone -> return LoopDone
                    Break    -> return Break
                    Continue -> impl
                    _        -> impl
              else              return LoopDone


{- Function Calling -}
_eval _ node@(Binary OpCall x args@(AST.Args _)) = inExpr node $ do
    callable <- rvalue x
    case callable of
        Builtin func params -> dispatchBuiltin =<< bindArgs (CallBuiltin func) params args
        --TODO OctFunc
            --here, once we have the Arguments, we need to create an env for them,
            --that's the first parent of the stack frame env
            --somewhere we need to add the function's static environment
            --finally, evaluate teh function's code in the env just constructed
        --TODO try __call__
        --TODO error cases


{- Arithmetic -}
_eval deref expr@(Unary op x) = inExpr expr $ do
    a <- rvalue x
    case op of
        OpNegate -> case a of
            OctInt  a -> return $ OctInt  (-a)
            OctReal a -> return $ OctReal (-a)
            --TODO lookup __neg__
            --TODO errors
        OpNot -> do
            (OctBool a) <- truthy a
            return $ OctBool (not a)

_eval _ expr@(Binary op a b) = inExpr expr $
        case op of
            OpAnd     -> logic  (==False) return return a b
            OpOr      -> logic  (==True)  return return a b
            OpNand    -> logic  (==False) octNot octNot a b
            OpNor     -> logic  (==True)  octNot octNot a b
            OpImplies -> logic  (==False) octNot return a b
            _         -> do 
                            a <- rvalue a
                            b <- rvalue b
                            arithmetic a op b
    where
    logic short shortOp longOp a b = do
        a'@(OctBool a) <- truthy =<< rvalue a
        if short a
             then shortOp a'
             else longOp =<< truthy =<< rvalue b
    octNot (OctBool t) = return $ OctBool (not t)


{- Assignment -}
assign :: EvalContext -> Value -> Value -> Octopus Value
assign side ref val = case ref of
    (Reference _) -> do
        ref' <- setVar ref (Strict val)
        return $ if side == LValue then ref' else val
        --TODO chase member and index chains
        --TODO error if not an lvalue

{- Other -}

truthy :: Value -> Octopus Value
truthy  Void           = throwBuiltin Unbound
truthy  Nil            = return $ OctBool False
truthy val@(OctBool _) = return   val
truthy (OctInt val)    = return $ OctBool (val /= 0)
truthy (OctReal val)   = return $ OctBool (val /= 0)
truthy (OctChar val)   = return $ OctBool (val /= '\0')
truthy (OctString val) = return $ OctBool (length val /= 0)
--TODO error on functions?
--TODO environments get __bool__ called on them, or else return true


#include "Octi/Eval/Binding.hs"
#include "Octi/Eval/Application.hs"
#include "Octi/Eval/Arithmetic.hs"