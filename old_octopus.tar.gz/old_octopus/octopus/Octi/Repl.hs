module Octi.Repl where

import System.Exit
import qualified Control.Exception as E
import Control.Exception ( SomeException(..)
                         , AsyncException(..) )
import System.Console.Haskeline hiding (catch, handle)
import qualified System.Console.Haskeline as Hl

import Octopus.Common

import Octopus.Syntax
import Octi.Data
import Octi.Eval
import Octi.Eval.Monad
import Octi.Display



friendlyREPL :: OctMachine -> IO ()
friendlyREPL machine = E.handle handler $ do
        greet
        repl machine
        farewell
    where greet = do
            putStrLn "Mesdames, messieures, bon soir."
            putStrLn "Welcome to Octi, the Octopus interpreter."
            putStrLn "This interpreter is licensed under GPLv3."
            putStrLn "Type ``:help'' for help or ``:quit'' to exit."
          farewell = putStrLn "Namarië."
          handler (SomeException e) = do
            farewell >> E.throw e

repl :: OctMachine -> IO ()
repl machine = runInputT defaultSettings (loop machine)
    where loop machine = do
            input <- getLines
            case input of
                "" -> loop machine
                (':':it) -> liftIO $ runCommand it
                _        -> liftIO (interactiveExec machine input)
            loop machine


interactiveExec :: OctMachine -> String -> IO ()
interactiveExec machine input = case octParser "interpreter" input of
    Left err -> putStrLn ("Syntax Error: " ++ show err)
    Right ast -> do
        evald <- evalOctopusT machine $ eval ast
        case evald of
            Right val -> putStrLn (show val)
            Left ex   -> putStrLn (showException ex)

runCommand :: String -> IO ()
--TODO parse the command, don't rely on nicely formatted input
--TODO prefix commands are also allowed
runCommand command = maybe noCanDo id $ lookup command cmds 
    where
        cmds = [ ("quit", exitSuccess)
               , ("help", displayHelp)
               --TODO more commands
               ]
        displayHelp = do
            putErrLn "This is Octi, the Octopus interpreter."
            putErrLn "  At the prompt, you may enter Octopus code. Input is read until a blank line, then executed. Alternatively, if the first line of input ends in a semicolon, the line is executed immediately."
            putErrLn "  In addition to normal Octopus code, you may also input any of the following commands, or their unique prefixes:"
            putErrLn ""
            putErrLn "    :quit      -- Quit Octi."
            putErrLn "    :save      -- TODO Output history to a file (successful history only)."
            putErrLn "    :edit name -- TODO Edit the contents of a file."
            putErrLn "    :load name -- TODO Imports or re-imports the file or module."
            putErrLn "                  If the name contains a slash, it is a filename, otherwise it's a module name."
            putErrLn "    :help      -- Display this message."
        noCanDo = putErrLn "I'm afraid I can't do that, Dave."


getLines :: InputT IO String
getLines = impl ("鮹: ":repeat "... ") [] `Hl.catch` \UserInterrupt -> getLines
    where
        impl (p:ps) xs = getInputLine p >>= decideLine ps xs

        decideLine ps xs  Nothing                             = return ":quit"
        decideLine ps xs (Just "")                            = return $ (unlines . reverse) xs
        decideLine ps xs (Just x) | xs == [] && head x == ':' = return x
                                  | xs == [] && last x == ';' = return $ ((++"\n") . init) x
                                  | otherwise                 = impl ps (x:xs)
