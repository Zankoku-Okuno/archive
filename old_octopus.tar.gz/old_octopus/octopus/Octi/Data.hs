module Octi.Data where

import Octopus.Common
import qualified Octopus.AST as AST
import Octopus.AST (Node(..), ParamQualifier)

type OctopusResult = EitherT IFE IO Value

-- In-flight exception:
data IFE = IFE {
    thrown          :: Value,
    thrownFrom      :: ExpectEnv,
    thrownDuring    :: Node,
    doubleException :: Maybe IFE, -- This field is the exception that escaped the handler for this (the first) exception
    restart         :: ExceptionCont
}
type ExceptionCont = Maybe (OctopusResult -> Cont OctopusResult OctopusResult)

data Value = Void
           | Nil
           
           | GuardFailure | Fallthrough | LoopDone | Break | Continue

           | OctBool     Bool
           | OctInt      Integer
           | OctReal     Double

           | OctChar     Char
           | OctString   String

           | Builtin     OctBuiltin Parameters
           --TODO Function Parameters Env
           --TODO Property Function
           | Application Callable Parameters Arguments

           | Reference  (Either (ExpectEnv, Symbol) (IORef OctopusVariable) )
           | Environment Env
           | Type        Type

{- Types -}

data Type = Concrete    ExpectEnv
          | Abstract    ExpectEnv [Type]
          | Structure   [Type] --TODO more than positional types
          | Union       [Type]
          | NonNillable Type
          | Unresolved
          | Any


{- Environments -}

type ExpectEnv = Value

newtype Env = Env (IORef ([Binding], [Env]))
type Binding = (Symbol, IORef OctopusVariable) -- TODO type checking, const correctness, locking, visibility perhaps?
data OctopusVariable = Strict             Value
                     | LazyName ExpectEnv Node
                     | LazyNeed ExpectEnv Node

appendEnv :: Env -> Binding -> IO ()
appendEnv (Env env) binding = do
    (bindings, parents) <- readIORef env
    env `writeIORef` ((binding:bindings), parents)

addParentEnv :: Env -> Env -> IO ()
addParentEnv (Env child) parent = do
    (bindings, parents) <- readIORef child
    child `writeIORef` (bindings, parents++[parent])

{- Callables -}

data Callable = CallBuiltin OctBuiltin | CallFunction | CallProperty

data Parameters = Params Value [Param]
type Param = (Symbol, ParamQualifier, Maybe Node)

type Arguments = [(Symbol, OctopusVariable)]


{- Builtin Data Values -}

data OctBuiltin = CurrEnv | MakeEnv | AddParentEnv | IntEnv --TODO more builtins

{- Helpers -}

-- |Strict version of 'modifyIORef'
modifyIORef' :: IORef a -> (a -> a) -> IO ()
modifyIORef' ref f = do
    x <- readIORef ref
    let x' = f x
    x' `seq` writeIORef ref x'



