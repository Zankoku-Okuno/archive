{-
    Token Parsing

    The idea in this module is to provide an api that consumes tokens.
    `lexOctopus' provides a perilogue to ensure consistency. Every parseXXX
    function should use it to wrap delegations to various lexXXX functions,
    which themselves assume 1) no leading whitespace 2) no need to backtrack 3) 
    no need to report expected symbols.
-}

--FIXME tokens have positions at their ends: put them at their beginnings
module Octopus.Token
    ( Parser
    , startState
    , parseIdentifier
    , parseAtom
    , inFile
    , parseKeyword
    , parseOperator
    , parseBlock
    , parseNextline
    , parsePunctuation
    ) where

import Octopus.Common
import Octopus.AST

{- Data Structures -}

type Parser = Parsec String [WhitespaceMode]

data WhitespaceMode = Curly | Indent Int | StringWeave

data Lexeme = Identifier String | Operator String | Keyword String | Punctuation String
            | EOF
    deriving (Show)

startState :: [WhitespaceMode]
startState = [Indent 0]

getWM :: Parser WhitespaceMode
getWM = return . head =<< getState
setWM :: WhitespaceMode -> Parser ()
setWM x = setState . (x:) =<< getState
popWM :: Parser ()
popWM = setState . tail =<< getState


{- Token Parsers -}

inFile :: Parser a -> Parser a
inFile = between startFile endFile
    where startFile = do
            many lexBlankline
            leading <- liftM length $ many (char ' ') << notFollowedBy space
            setState [Indent leading]
          endFile = many lexBlankline >> eof <?> "end of input"

parseIdentifier :: Parser Node
parseIdentifier = lexOctopus "identifier" $ do
    name <- lexAlphanum
    case name of
        Identifier name -> return $ Name (intern name)
        _ -> fail ""

parseAtom :: Parser Node
parseAtom = lexOctopus "atom" $ lexLiteral <|> parseIdentifier

parseKeyword :: String -> Parser ()
parseKeyword cmp = lexOctopus cmp $ do
    kw <- lexAlphanum
    case kw of
        Keyword kw | kw == cmp -> return ()
        _ -> fail ""

parseOperator :: String -> Parser ()
parseOperator cmp = lexOctopus "operator" $ do
    op <- lexSymbol
    case op of
        op | op == cmp -> return ()
        _              -> fail ""

parsePunctuation :: Char -> Parser ()
parsePunctuation cmp = lexOctopus (cmp:"") $ lexPunctuation cmp


parseNextline :: Parser ()
parseNextline = do
    mode <- getWM
    let expected = case mode of
            Indent _    -> "newline"
            Curly       -> ";"
            StringWeave -> "end of string"
    lexOctopus expected lexNextline

parseBlock :: Parser a -> Parser a
parseBlock p = parseIndent >> p << parseDedent

{- Parser Helpers -}

lexOctopus :: String -> Parser a -> Parser a
lexOctopus s p = expect s (try p << lexLinespace)

parseIndent :: Parser ()
parseIndent = do
    mode <- getWM
    let expected = case mode of
            Indent _    -> "indent"
            Curly       -> "{"
            StringWeave -> "end of string"
    lexOctopus expected lexIndent

parseDedent :: Parser ()
parseDedent = do
    mode <- getWM
    let expected = case mode of
            Indent _    -> "dedent"
            Curly       -> "}"
            StringWeave -> "end of string"
    lexOctopus expected lexDedent

{- Raw Lexers -}

lexAlphanum :: Parser Lexeme
lexAlphanum = do
        name <- (liftM2 (:) first (many rest)) << notFollowedBy (char '"')
        return $ case (name `elem` keywords) of
                True  -> Keyword name
                --FIXME disallow pure underscores as names
                False -> Identifier name
    where first = letter   <|> char '_'
          rest  = alphaNum <|> char '_'
          --FIXME add more reserved words
          keywords = [ "nil", "true", "false"
                     , "my"
                     , "pass"
                     , "if", "then", "elif", "else", "when", "unless"
                     , "loop", "while", "until"
                     , "fallthrough", "break", "continue"
                     ]

lexSymbol :: Parser String
--FIXME unicode symbols, too
lexSymbol = many1 (oneOf "+-*/%<>=!&|^?@~")

lexPunctuation :: Char -> Parser ()
lexPunctuation c = do
        result <- char c
        case result of
            _ | result `elem` openPunctuation  -> setWM Curly
              | result `elem` closePunctuation -> popWM
              | result `elem` otherPunctuation -> return ()
            _ -> fail ""
    where openPunctuation  = "([{"
          closePunctuation = ")]}"
          otherPunctuation = ",.;:"

lexLiteral :: Parser Node
lexLiteral = expect "literal" $ (literalReal <|> literalInt <|> literalChar)
    where
        --WARNING '15a' does not parse as '15' 'a', which may be unexpected and give bad diagnostics
        literalInt = ((try nonDecPrefix >> (hex <|> oct <|> bin)) <|> dec)
                                         << expectInsteadOf alphaNum "space before variable"
            where
            bin = oneOf "bB" >> many1 (oneOf "01") >>= return . OctInt . strToInteger 2
            oct = oneOf "oO" >> many1 octDigit     >>= return . OctInt . strToInteger 8
            dec =               many1 digit        >>= return . OctInt . strToInteger 10
            hex = oneOf "xX" >> many1 hexDigit     >>= return . OctInt . strToInteger 16
            nonDecPrefix = char '0' >> lookAhead (oneOf "xXoObB")
        --WARNING floats must be digit+.digit+, instead of digit+.digit*, since 1.times is allowed
        literalReal = mzero -- TODO
        literalChar = (escape <|> anyChar) `surroundedBy` (char '\'') >>= return . OctChar
            where escape = backslash chrEscape

backslash p = try (char '\\') >> p
chrEscape = specialEscapes <|> asciiEscape <|> shortUnicodeEscape <|> unicodeEscape
    where asciiEscape = count 2 hexDigit >>= return . chr . fromInteger . (strToInteger 16)
          shortUnicodeEscape = oneOf "uU" >> count 4 hexDigit
                               >>= return . chr . fromInteger . (strToInteger 16)
          unicodeEscape = oneOf "xX" >> (five <|> six)
                          >>= return . chr . fromInteger . (strToInteger 16)
              where five = liftM2 (:)  (char '0')    (count 5 hexDigit) 
                    six =  liftM2 (++) (string "10") (count 4 hexDigit) 
          specialEscapes = oneOf specials >>= return . fromJust . trans
              where trans = flip lookup $ zipWith (,) specials semantics
                    specials = "abfnrtv"
                    semantics = "\a\b\f\n\r\t\v"

----TODO ' for char, " for string, ` for raw string (double backticks to escape them); all prefixable

lexIndent :: Parser ()
lexIndent = do
    mode <- getWM
    case mode of
        Indent depth -> try whitespaceBlock <|> lexPunctuation '{'
            where
            whitespaceBlock = do
                lexNewline
                leading <- leadingWhitespace
                case leading of
                    _ | leading > depth -> lexLinespace >> setWM (Indent leading)
                    _                   -> fail "expected indent"
        Curly                           -> lexPunctuation '{'
        StringWeave                     -> fail "expected end of string"

lexNextline :: Parser ()
lexNextline = do
    mode <- getWM
    case mode of
        Indent depth -> do
            optional $ parsePunctuation ';'
            lexNewline
            leading <- leadingWhitespace
            case leading of
                _ | leading <  depth -> fail "unexpected dedent"
                  | leading == depth -> lexLinespace
                  | leading >  depth -> fail "unexpected indent"
        Curly       -> lexPunctuation ';'
        StringWeave -> fail "expected end of string"

lexDedent :: Parser ()
lexDedent = do
    mode <- getWM
    case mode of
        Indent depth -> do
            lexNewline
            leading <- leadingWhitespace
            case leading of
                _ | leading <  depth -> popWM
                  | leading == depth -> lexLinespace >> popWM
                  | leading >  depth -> fail "dedent has no matching indent"
        Curly                        -> lexPunctuation '}'
        StringWeave                  -> fail "expected end of string"
 
leadingWhitespace = expect "space" $ do
    leading <- lookAhead (many (char ' ') << notFollowedBy space)
    return $ length leading
lexNewline = expect "end of line" $ do
    newline <|> (eof >> return '\n')
    skipMany lexBlankline

{- Whitespace Consumers -}

lexBlankline :: Parser ()
lexBlankline = try (lexLinespace >> newline) >> return ()

lexLinespace :: Parser ()
lexLinespace = do
    mode <- getWM
    case mode of
        Indent _    -> skipMany (oneOf " \t")
        StringWeave -> skipMany (oneOf " \t")
        Curly       -> skipMany space
    expect "" $ optional $ char '#' >> skipMany (noneOf "\r\n")
    case mode of
        Indent _    -> return ()
        StringWeave -> skipMany lexBlankline
        Curly       -> return () --skipMany lexBlankline

{- Helpers -}

expect = flip (<?>)

expectInsteadOf p err = notFollowedBy p <?> err
p `surroundedBy` x = between x x p

-- WARNING This function has unchecked preconditions:
-- 1) If the digits do not match the base, the function will appear to succeed, but produce incorrect results
-- e.g. strToInteger 2 "f" === 15
-- 2) the function happily accepts radix <= 0, but this is clearly mathemamtically meaningless
-- 3) base 1 works, but note that the digit used is '1', rather than '0'. This breaks with the pattern of digit selection for other radices, but keeps with traditional base-1 notation
-- e.g. strToInteger 1 "1111" === 4, but strToInteger 1 "0000" === 0
-- There are also checked preconditions because of digitToInt:
-- 1) no radix > 16 is supported
-- 2) only characters [0-9a-fA-F] appear in the input string
strToInteger :: Integer -> String -> Integer
strToInteger radix input = impl 0 input
  where impl acc "" = acc
        impl acc (x:xs) = impl (radix * acc + (toInteger . digitToInt) x) xs


-- === HERE THERE BE DRAGONS ===

        --literalString = (many (noneOf "\\\"" <|> escape)) `surroundedBy` (char '"')  >>= return . OctString
        --    where escape = backslash (char '\\' <|> char '"' <|> chrEscape)
        ---- WARNING: NUL character is escaped like "\00" as opposed to "\0"
        --chrEscape = specialEscapes <|> asciiEscape <|> shortUnicodeEscape <|> unicodeEscape
        --    where
        --    asciiEscape = count 2 hexDigit >>= return . chr . fromInteger . (strToInteger 16)
        --    shortUnicodeEscape = oneOf "uU" >> count 4 hexDigit
        --                         >>= return . chr . fromInteger . (strToInteger 16)
        --    unicodeEscape = oneOf "xX" >> (five <|> six)
        --                    >>= return . chr . fromInteger . (strToInteger 16)
        --        where five = liftM2 (:)  (char '0')    (count 5 hexDigit) 
        --              six =  liftM2 (++) (string "10") (count 4 hexDigit) 
        --    specialEscapes = oneOf specials >>= return . fromJust . trans
        --        where trans = flip lookup $ zipWith (,) specials semantics
        --              specials = "abfnrtv"
        --              semantics = "\a\b\f\n\r\t\v"
        --backslash p = try $ char '\\' >> p
        ----TODO collection literals, environment (object?) literals

