module Octopus.AST where

import Octopus.Common

data Node = Name Symbol
                
          | Void
          | Placeholder --for partial application literals that skip a positional arg

          | Fallthrough | LoopDone | Break | Continue
          
          | Nil
          | OctBool   Bool
          | OctInt    Integer
          | OctReal   Double
          --TODO byte and byteString types
          | OctChar   Char
          | OctString String

          | Unary  UnOp  Node
          | Binary BinOp Node Node

          | Multi [Node] -- STUB
          | Block [Node] -- STUB
          
          | Check Bool Node Node
          | IfChain [Node]
          | Loop Bool Node Node (Maybe Node) (Maybe Node)

            -- TODO OctFunction, OctProperty and OctBoundFunction
          | Params [Param]
          | Args   [Node]
    deriving (Show)


data UnOp = OpMy | OpNegate | OpNot
    deriving (Show)
data BinOp = OpPlus | OpMinus
           | OpMultiply | OpDivide | OpQuotient | OpRemainder | OpDivmod
           | OpExponent
           | OpAnd | OpNand | OpImplies
           | OpOr | OpNor
           | OpMember | OpCall | OpIndex
           | OpAssign
           | OpImmediate BinOp
    deriving (Show)

type Param = (Symbol, ParamQualifier, Maybe Node)
data ParamQualifier = StrictParam | LazyNameParam | LazyNeedParam
    deriving (Show)

{- MAYBE I should just use deriving, but I'm not sure.
    For now, let's leave deriving for testing purposes
    If I do write a custom Show instance, put it in Display.AST, and move Display to Display.Value

{- Display -}

instance Show (Node) where
    show (Name name) = show name
    show  Void = "Void"
    show (OctBool b) = if b then "True" else "False"
    show (OctInt n) = show n
    show (OctReal n) = show n
    show (OctChar '\'') = "'''"

    show (OctChar '\\') = "'\\'"
    show (OctChar c) | c `elem` specials = quote $ fromJust $ lookup c $ zipWith (,) specials semantics
                     | isControl c && ord c < 256 = quote ('\\':hex c)
                     | otherwise = ('\'':c:"'") --TODO notation for non-printing characters > 0xff
        where hex c = map toUpper $ showHex (ord c) ""
              quote x = "'" ++ x ++ "'"
              specials = "\a\b\f\n\r\t\v"
              semantics = ["\\a","\\b","\\f","\\n","\\r","\\t","\\v"]
    show (OctString s) = show s -- TODO escape char encoding
    show  Nil = "Nil"
    show (Args args) = foldr (++) "" $ map ((++", ") . show) args
    show (Unary op a) = "(" ++ show op ++ show a ++ ")"
    show (Binary OpMember a b) = "(" ++ show a ++ ")." ++ show b 
    show (Binary OpCall a b) = "(" ++ show a ++ ")(" ++ show b ++ ")"
    show (Binary OpIndex a b) = "(" ++ show a ++ ")[" ++ show b ++ "]"
    show (Binary op a b) = "(" ++ show a ++ show op ++ show b ++ ")"

instance Show UnOp where
    show OpNegate = "-"
instance Show BinOp where
    show OpPlus = "+"
    show OpMinus = "-"
    show OpMultiply = "*"
    show OpDivide = "/"
    show OpQuotient = "//"
    show OpRemainder = "%"
    show OpDivmod = "/%"
    show OpExponent = "**"
    show OpAssign = "="

-}