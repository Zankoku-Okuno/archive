module Octopus.Syntax
    ( octParser
    ) where

import Octopus.Common
import Octopus.Token
import Octopus.AST as AST

octParser :: String -> String -> Either ParseError Node
octParser filename input = case runParser parseOctopus startState filename input of
        Right vals -> return $ Block vals
        Left err   -> Left err
    where parseOctopus = inFile statements


statements :: Parser [Node]
statements = statement `sepEndBy` parseNextline

statement :: Parser Node
statement = specialStatement <|> parseExpr

specialStatement :: Parser Node
specialStatement =  (parseKeyword "pass"        >> return Void)
                <|> (parseKeyword "fallthrough" >> return Fallthrough)
                <|> (parseKeyword "break"       >> return Break)
                <|> (parseKeyword "continue"    >> return Continue)
                <|> (finishGuard  "while" False)
                <|> (finishGuard  "until" True)
    where finishGuard kw positive = do
            test <- (parseKeyword kw) >> statement
            return $ Check positive test LoopDone

{- Main Parsers -}

parseUnit :: Parser Node
parseUnit = do
        begin <- atom <|> parens parseExpr <|> parseControl
        follow <- many (dot <|> call <|> index)
        return $ foldr (\(op,x) acc -> Binary op acc x) begin (reverse follow)
    where
    -- TODO new operator
    atom   = parseAtom <|> myName
    dot    = liftM ((,) OpMember) $ parsePunctuation '.' >> parseIdentifier
    index  = liftM ((,) OpIndex)  $ brackets                parseArgs
    call   = liftM ((,) OpCall)   $ parens                  parseArgs
    myName = liftM (Unary OpMy)   $ parseKeyword    "my" >> parseIdentifier

parseControl :: Parser Node
parseControl =  whenGuard
          <|> unlessGuard
          <|> ifChain
          <|> loop
    where 
    ifChain = do
        first <-                   (guard "if" True)
        body  <- many           $  (guard "elif" True)
        last  <- kwColon "else" >> compoundExpr
        return $ IfChain $ first:(body ++ (last:[]))
    whenGuard =   guard "when"   True
    unlessGuard = guard "unless" False
    loop = do
            parseKeyword "loop"
            test  <- while <|> return (Loop True $ OctBool True)
            optional $ parsePunctuation ':'
            body  <- compoundExpr
            lThen <- parseThen <|> return Nothing
            lElse <- parseElse <|> return Nothing
            return $ test body lThen lElse
        where
            parseThen = kwColon "then" >> compoundExpr >>= return . Just
            parseElse = kwColon "else" >> compoundExpr >>= return . Just
            while = do
                positive <- (parseKeyword "while" >> return True)
                        <|> (parseKeyword "until" >> return False)
                test <- statement
                return $ Loop positive test
    guard word positive = do
        test <- parseKeyword word >> statement
        optional (parsePunctuation ':' <|> parseKeyword "then")
        exec <- compoundExpr
        return $ Check positive test exec
    kwColon str = parseKeyword str >> optional (parsePunctuation ':')

{- Function Parsers -}

--parseParams = STUB

parseArgs ::Parser Node
parseArgs = return . Args =<< parseExpr `sepEndBy` (parsePunctuation ',')
--TODO default args, kwargs, varargs, varkwargs, block

{- Expression Parsers -}

parseExpr :: Parser Node
parseExpr = assignExpr
--    --TODO casting, type assertions

assignExpr = userExpr `chainr1` op
    where op =  (parseOperator "="   >> return (Binary   OpAssign))
            <|> (parseOperator "+="  >> return (Binary $ OpImmediate OpPlus))
            <|> (parseOperator "-="  >> return (Binary $ OpImmediate OpMinus))
            <|> (parseOperator "*="  >> return (Binary $ OpImmediate OpMultiply))
            <|> (parseOperator "/="  >> return (Binary $ OpImmediate OpDivide))
            <|> (parseOperator "//=" >> return (Binary $ OpImmediate OpQuotient))
            <|> (parseOperator "%="  >> return (Binary $ OpImmediate OpRemainder))
            <|> (parseOperator "**=" >> return (Binary $ OpImmediate OpExponent))

userExpr = logicExpr --STUB
--    --TODO? user-defined operations

--TODO separate logic and short-circuit expressions
logicExpr = relationExpr -- STUB
--    expr50 = try (op >> (expr50) >>= return . (Unary OpNot))
--              <|>                          expr40
--        where op = (parseOperator "!") >> return (Unary OpNot)
--    expr51 = (expr50) `chainl1` op
--        where op =  (parseOperator  "&&" >> return (Binary OpAnd))
--                <|> (parseOperator "!&&" >> return (Binary OpNand))
--                <|> (parseOperator  "->" >> return (Binary OpImplies))
--    expr52 = (expr51) `chainl1` op
--        where op =  (parseOperator  "||" >> return (Binary OpOr))
--                <|> (parseOperator "!||" >> return (Binary OpNor))
relationExpr = bitExpr -- STUB
--    expr40 = expr31 -- TODO (ordering, element and set) relation ops 
--    --TODO? a?b checks if a has b as a member
bitExpr = sequenceExpr -- STUB
--    expr30 = expr21 -- TODO bitwise inversion
--    expr31 = expr30 -- TODO bitwise operations

sequenceExpr = arithExpr --STUB
---- l ~ l,  l <~ a,  a ~> l
---- l ~= l, l <~= a, l ~>= a
--    expr20 = expr13 -- TODO append, prepend
--    expr21 = expr20 -- TODO ranges (-1..4) (-1...4) (-1 to 4) (-1 thru 4); open ranges (1..) === [1,inf), (..4) === (-inf,4)

arithExpr :: Parser Node
arithExpr = addExpr
    where
    addExpr = multExpr `chainl1` op
        where op =  (parseOperator "+" >> return (Binary OpPlus ))
                <|> (parseOperator "-" >> return (Binary OpMinus))
    multExpr = expExpr `chainl1` op
        where op =  (parseOperator "*"  >> return (Binary OpMultiply ))
                <|> (parseOperator "/"  >> return (Binary OpDivide   ))
                <|> (parseOperator "//" >> return (Binary OpQuotient ))
                <|> (parseOperator "%"  >> return (Binary OpRemainder))
                <|> (parseOperator "/%" >> return (Binary OpDivmod   ))
    expExpr = (negExpr) `chainr1` op
        where op = (parseOperator "**" >> return (Binary OpExponent))
    negExpr = (parseOperator "-" >> parseUnit >>= return . (Unary OpNegate))
           <|>                      parseUnit


{- Helpers -}

parens   p = parsePunctuation '(' >> p << parsePunctuation ')'
brackets p = parsePunctuation '[' >> p << parsePunctuation ']'
braces   p = parsePunctuation '{' >> p << parsePunctuation '}'

compoundExpr = try (return . Block =<< parseBlock statements) <|> statement
