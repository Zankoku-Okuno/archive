module Octopus.Common (
      module Numeric
    , module Data.Char
    , module Data.Maybe
    , module Data.Symbol
    , module System.IO
    , module Data.IORef

    , module Control.Monad
    , module Control.Monad.IO.Class
    , module Control.Monad.Trans.Either
    , module Control.Monad.Cont

    , module Text.Parsec
    , module Text.Parsec.Char
    , module Text.Parsec.String

    , (<<)
    , putErrLn
    ) where

import Numeric
import Data.Char
import Data.Maybe
import Data.Symbol
import System.IO
import Data.IORef

import Control.Monad
import Control.Monad.IO.Class
import Control.Monad.Trans.Either
import Control.Monad.Cont

import Text.Parsec
import Text.Parsec.Char
import Text.Parsec.String hiding (Parser)

infixl 1 <<
x << y = do { out <- x; y; return out }

putErrLn = hPutStrLn stderr