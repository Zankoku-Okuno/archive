{-
    Stream Simplification

    This module primarily provides facilities for simplifying token detection. Its
    parsers consume excess whitespace and comments, detect statement separators 
    and block delimiting, all based on a mode of operation, which could be 
    curly-brace style, or whitespace style.
-}

module Stream (
      WhitespaceMode, newWM, curlyWM
    , tokWM, nextline, block
    , startfile, endfile
    ) where

import Common

{- Stream Simplification -}

linespace :: Parser ()
linespace = skipMany (oneOf " \t") --TODO allow more types of whitespace
            <?> "whitespace"

comment :: Parser ()
comment = char '#' >> skipMany (noneOf "\n")
          <?> ""

linefold :: Parser ()
linefold = return () << (blankline <|> (eof >> return '\n')) << skipMany (try blankline)
           <?> "end of line"
    where blankline = linespace >> optional comment >> newline

curlyfold :: Parser ()
curlyfold = linespace >> skipMany (try blankline) >> linespace
    where blankline = linespace >> optional comment >> newline

type WhitespaceMode = (Bool, [Int])

newWM :: WhitespaceMode
newWM = (True, [0])
curlyWM :: WhitespaceMode
curlyWM = (False, [])

tokWM :: WhitespaceMode -> Parser a -> Parser a
tokWM (False,_) p = curlyfold >> p << curlyfold
tokWM (True,_)  p = linespace >> p << linespace
nextline :: WhitespaceMode -> Parser ()
nextline (False,_) = curlyfold >> char ';' >> curlyfold
nextline (True, (n:ns)) = do
    linespace >> optional (char ';') >> linefold
    lookAhead (count n (char ' ') >> notFollowedBy space)
    return ()
block :: WhitespaceMode -> (WhitespaceMode -> Parser a) -> Parser a
block mode@(False,_) p = between (tokWM mode $ char '{') (curlyfold >> char '}') (p mode)
block mode@(True,_) p = try indentation <|> curlies
    where indentation = do
                mode' <- indent mode
                p mode' << dedent mode'
            where
                indent, dedent :: WhitespaceMode -> Parser WhitespaceMode
                indent (True, ns@(n0:_)) = do
                    linespace >> optional (char ';') >> linefold
                    leading <- many (char ' ') << notFollowedBy space
                    let n = length leading
                    if n <= n0
                        then fail "expected indent"
                        else return (True, (n:ns))
                dedent (True, (n0:ns)) = do
                    linespace >> optional (char ';')
                    leading <- lookAhead (linefold >> (many $ char ' ') << notFollowedBy space)
                    case length leading of
                        n | n > n0                -> fail "expected dedent"
                          | n < n0 && n > head ns -> fail "dedent does not match indent"
                          | otherwise             -> return (True, ns)
          curlies = between (tokWM mode' $ char '{') (curlyfold >> char '}') (p mode')
            where mode' = curlyWM


startfile, endfile :: Parser ()
startfile = optional (linefold << notFollowedBy space) << notFollowedBy space
endfile = optional linefold >> eof
          <?> "end of input"