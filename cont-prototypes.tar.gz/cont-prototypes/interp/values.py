class Value:
	pass


class Data(Value):
	def __init__(self, data):
		self.data = data


class Abstraction(Value):
	def __init__(self, ctor):
		self.ctor = ctor
	def apply(self, x):
		assert isinstance(x, Value)
		return self.ctor(x)


class Prompt(Value):
	__q = 0
	def __init__(self):
		self.q = Prompt.__q
		Prompt.__q += 1
	def __equal__(self, other):
		return isinstance(other, Prompt) and self.q == other.q

class SubContinuation(Data):
	pass

