from interp.values import *
from interp.semantics import *

class Code:
	pass


class Context:
	def __init__(self, ctor, next=None):
		self.ctor = ctor
		self.next = next

class Machine:
	__context = None
	__stack = []

	def __init__(self):
		self.e = None

	def eval(self, e):
		self.e = e
		while not self.is_done():
			self.step()
		return self.e

	def step(self):
		if isinstance(self.e, Value):
			if Machine.__context is None:
				context = Machine.__stack.pop()
				if isinstance(context, Prompt):
					pass
				else:
					Machine.__context = context
			else:
				context = Machine.__context
				self.e = context.ctor(self.e)
				Machine.__context = context.next
		elif isinstance(self.e, Code):
			self.e = self.e.eval()
		else: raise Exception("unreachable")
	def is_done(self):
		return (isinstance(self.e, Value)
			and Machine.__context is None
			and len(Machine.__stack) == 0
			)

	@staticmethod
	def augment_context(ctor):
		Machine.__context = Context(ctor, Machine.__context)
	@staticmethod
	def push_prompt(p):
		Machine.__stack.append(Machine.__context)
		Machine.__stack.append(p)
		Machine.__context = None
	@staticmethod
	def capture_subcont(p):
		for i in range(len(Machine.__stack)-1, 0, -1):
			if p == Machine.__stack[i]: break
		else: raise Exception("Prompt not found on stack.")
		subcont = Machine.__stack[i+1:-1]
		subcont.append(Machine.__context)
		Machine.__stack = Machine.__stack[0:i]
		Machine.__context = None
		return SubContinuation(subcont)
	@staticmethod
	def push_subcont(subcont):
		if not isinstance(subcont, SubContinuation): raise TypeError("Attempted to push non-subcontinuation onto control stack.")
		Machine.__stack.append(Machine.__context)
		Machine.__stack = Machine.__stack + subcont.data
		Machine.__context = None




