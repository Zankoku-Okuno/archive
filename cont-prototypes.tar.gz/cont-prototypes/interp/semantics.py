from interp.values import *
from interp.machine import *


class Apply(Code):
	def __init__(self, f, x):
		self.f = f
		self.x = x
	def eval(self):
		if isinstance(self.f, Value):
			if isinstance(self.x, Value):
				return self.f.apply(self.x)
			elif isinstance(self.x, Code):
				Machine.augment_context(lambda x: Apply(self.f, x))
				return self.x
			else: raise Exception("unreachable")
		elif isinstance(self.f, Code):
			Machine.augment_context(lambda x: Apply(x, self.x))
			return self.f
		else: raise Exception("unreachable")

class Branch(Code):
	def __init__(self, p, t, f):
		self.p = p
		self.t = t
		self.f = f
	def eval(self):
		if isinstance(self.p, Value):
			if not isinstance(self.p, Data):
				raise Exception("Cont Type Error: data value required for pred of if")
			if self.p.data == True:
				return self.t
			elif self.p.data == False:
				return self.f
			else:
				raise Exception("Cont Type Error: predicate of if must be boolean value")
		elif isinstance(self.p, Code):
			Machine.augment_context(lambda x: Branch(x, self.t, self.f))
			return self.p
		else: raise Exception("unreachable")

class Primitive(Code):
	def __init__(self, f, args, vals=[]):
		self.f = f
		self.vs = vals
		self.es = args
	def eval(self):
		if len(self.es) == 0:
			return Data(self.f(*{v.data for v in self.vs}))
		elif isinstance(self.es[0], Value):
			return Primitive(self.f, self.es[1:], self.vs + [self.es[0]])
		elif isinstance(self.es[0], Code):
			Machine.augment_context(lambda x: Primitive(self.f, [x] + self.es[1:], self.vs))
			return self.es[0]
		else: raise Exception("unreachable")


class NewPrompt(Code):
	def __init__(self): pass
	def eval(self):
		return Prompt()

class PushPrompt(Code):
	def __init__(self, p, e):
		self.p = p
		self.e = e
	def eval(self):
		if isinstance(self.p, Prompt):
			Machine.push_prompt(self.p)
			return self.e
		elif isinstance(self.p, Value):
			raise Exception("Cont Type Error: PushPrompt requires a prompt")
		elif isinstance(self.p, Code):
			Machine.augment_context(lambda x: PushPrompt(x, self.e))
			return self.p
		else: raise Exception("unreachable")

class WithSubCont(Code):
	def __init__(self, p, e):
		self.p = p
		self.e = e
	def eval(self):
		if isinstance(self.p, Prompt):
			if isinstance(self.e, Value):
				subcont = Machine.capture_subcont(self.p)
				return Apply(self.e, subcont)
			elif isinstance(self.e, Code):
				Machine.augment_context(lambda x: WithSubCont(self.p, x))
				return self.e
			else: raise Exception("unreachable")
		elif isinstance(self.p, Value):
			raise Exception("Cont Type Error: PushPrompt requires a prompt")
		elif isinstance(self.p, Code):
			Machine.augment_context(lambda x: WithSubCont(x, self.e))
			return self.p
		else: raise Exception("unreachable")

class PushSubCont(Code):
	def __init__(self, c, e):
		self.c = c
		self.e = e
	def eval(self):
		if isinstance(self.c, Value):
			Machine.push_subcont(self.c)
			return self.e
		elif isinstance(self.c, Code):
			Machine.augment_context(lambda x: PushSubCont(x, self.e))
			return self.c
		else: raise Exception("unreachable")
