from interp.values import *
from interp.semantics import *
from interp.machine import *

m = Machine()
test = Apply(Abstraction(lambda p: Primitive(lambda x, y: x + y, [Data(2), PushPrompt(p, 
         Branch(WithSubCont(p,
             Abstraction(lambda k: Primitive(lambda x, y: x + y, [
               PushSubCont(k, Data(False)),
               PushSubCont(k, Data(True))
             ]))),
           Data(3),
           Data(4))
       )])), NewPrompt())
