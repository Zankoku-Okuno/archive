module Part1 (
      newChannel
    , producer
    , consumer
    ) where

import ChildThread
import Control.Monad
import Control.Concurrent
import Control.Monad.STM
import Control.Concurrent.STM.TMVar

type DoubleBuffer = (TMVar (Maybe [Int]), TMVar (Maybe [Int]))
data WhichBuffer = BufferA | BufferB
switchBuf :: WhichBuffer -> WhichBuffer
switchBuf BufferA = BufferB
switchBuf BufferB = BufferA
getBuf :: WhichBuffer -> DoubleBuffer -> TMVar (Maybe [Int])
getBuf BufferA chan = fst chan
getBuf BufferB chan = snd chan

newChannel :: IO DoubleBuffer
newChannel = liftM2 (,) newEmptyTMVarIO newEmptyTMVarIO

producer :: DoubleBuffer -> IO ()
producer chan = loop [1..50] BufferA
    where
    loop [] whichBuf = atomically $ putTMVar (getBuf whichBuf chan) Nothing
    loop xs whichBuf = do
        mapM (printNum "Producer") (take 10 xs)
        atomically $ putTMVar (getBuf whichBuf chan) (Just $ take 10 xs)
        loop (drop 10 xs) (switchBuf whichBuf)

consumer :: DoubleBuffer -> IO ()
consumer chan = loop BufferA
    where
    loop whichBuf = do
        xs <- atomically $ takeTMVar (getBuf whichBuf chan) 
        case xs of
            Nothing -> return ()
            Just xs -> do
                mapM (printNum "Consumer") xs
                loop (switchBuf whichBuf)

printNum :: (Show a, Num a) => String -> a -> IO ()
printNum whence n = do
    putStrLn $ whence ++ ": " ++ show n
    threadDelay 1000000
