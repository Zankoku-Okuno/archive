module ChildThread (
	  newChildList
	, forkChild
	, waitForChildren
	) where

import Control.Concurrent
import Control.Concurrent.MVar


-- Child thread architecture inspired by http://www.haskell.org/ghc/docs/7.6.2/html/libraries/base/Control-Concurrent.html

type ChildThreads = MVar [MVar ()]

newChildList :: IO ChildThreads
newChildList = newMVar []

waitForChildren :: ChildThreads -> IO ()
waitForChildren children = do
  cs <- takeMVar children
  case cs of
    []   -> return ()
    m:ms -> do
       putMVar children ms
       takeMVar m
       waitForChildren children

forkChild :: ChildThreads -> IO () -> IO ThreadId
forkChild children io = do
    mvar <- newEmptyMVar
    childs <- takeMVar children
    putMVar children (mvar:childs)
    forkFinally io (\_ -> putMVar mvar ())
