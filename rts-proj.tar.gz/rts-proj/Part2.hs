module Part2 where

import System.CPUTime
import Control.Monad
import Control.Monad.IO.Class
import Control.Concurrent
import Control.Concurrent.STM.TChan


import Agent

newAgents :: [(Point, Point -> Point)] -> IO [Agent]
newAgents starts = do
    chans <- mapM (const newTChanIO) starts
    return $ zipWith3 newAgent starts chans (tail $ cycle chans)
    where
    newAgent (x0, v0) i o = Agent { ichan = i, ochan = o, x = x0, v = v0 }

sleepyLoop :: AgentM () -> Agent -> IO ()
sleepyLoop action agent = runAgentM impl agent
    where
    impl = do
        t0 <- liftIO getCPUTime
        action
        t1 <- liftIO getCPUTime
        let dt =  fromInteger $ (t1 - t0) `div` 1000000
        liftIO $ threadDelay (1000000 - dt)
        impl

agentLoop :: AgentM ()
agentLoop = do
        writeAgentChan =<< updateAgent
        propagate
    where
    propagate :: AgentM ()
    propagate = do
        msg@(Position author _ collisions) <- readAgentChan
        self <- agentSignature
        if author == self
          then mapM_ (liftIO . print) collisions
          else do
            msg' <- checkCollision msg
            writeAgentChan msg'
            propagate

