module Main where

import System.IO
import System.Environment
import System.Exit
import System.Console.GetOpt

import Part2
import ChildThread

progVersion = "0.2.0.0"

main :: IO ()
main = do
    agents <- newAgents [ ((0,0), \(x,y) -> ((x+1) `mod` 8, (y+1) `mod` 7))
                        , ((0,2), \(x,y) -> ((x+1) `mod` 8, 2))
                        , ((3,6), \(x,y) -> (3, (y+1) `mod` 7))
                        ]
    children <- newChildList
    mapM_ (forkChild children . sleepyLoop agentLoop) agents
    waitForChildren children
    exitWith ExitSuccess

-- The following architecture is taken from http://www.haskell.org/haskellwiki/High-level_option_handling_with_GetOpt

data Options = Options  { } deriving (Show)
startOptions = Options  { }

getOptions :: IO (Options, [String])
getOptions = do
    (actions, args, errors) <- return . getOpt Permute options =<< getArgs
    if errors == []
      then do
        opts <- foldl (>>=) (return startOptions) actions
        return (opts, args)
      else do
        mapM (hPutStrLn stderr) errors
        exitFailure

options :: [OptDescr (Options -> IO Options)]
options =
    [ Option "V" ["version"]
        (NoArg
            (\_ -> do
                hPutStrLn stderr progVersion
                exitWith ExitSuccess))
        "Print version"
    , Option "h" ["help"]
        (NoArg
            (\_ -> do
                prg <- getProgName
                hPutStrLn stderr $ "Part one of my project in Real Time Systems, Fall 2013."
                hPutStrLn stderr $ "This program is licensed under the GPLv3."
                hPutStrLn stderr $ usageInfo (prg) options
                exitWith ExitSuccess))
        "Show help"
    ]

