module Agent (
	  Agent(..)
	, AgentM
	, Message(..)
	, Point
	, runAgentM
	, readAgentChan
	, writeAgentChan
	, updateAgent
	, agentSignature
	, checkCollision
	) where

import Control.Monad.IO.Class
import Control.Monad.Trans.State
import Control.Concurrent
import Control.Monad.STM
import Control.Concurrent.STM.TChan


type Point = (Int, Int)
type Collision = (Author, Author, Point)
type Author = ThreadId
data Message = Position Author Point [Collision]


data Agent = Agent { ichan  :: TChan Message
                   , ochan  :: TChan Message
                   , x      :: Point
                   , v      :: Point -> Point
                   }

type AgentM = StateT Agent IO

runAgentM :: AgentM a -> Agent -> IO a
runAgentM action agent = evalStateT action agent

readAgentChan :: AgentM Message
readAgentChan = do
    chan <- gets ichan
    liftIO . atomically $ readTChan chan

writeAgentChan :: Message -> AgentM ()
writeAgentChan msg = do
    chan <- gets ochan
    liftIO . atomically $ writeTChan chan msg

updateAgent :: AgentM Message
updateAgent = do
    agent <- get
    let agent' = agent { x = (v agent) (x agent) }
    put agent'
    author <- agentSignature
    return $ Position author (x agent') []

agentSignature :: AgentM Author
agentSignature = liftIO myThreadId

checkCollision :: Message -> AgentM Message
checkCollision (Position author at prev) = do
    self <- agentSignature
    here <- gets x
    let collisions = if self < author && at == here 
                       then (self, author, at) : prev
                       else prev
    return (Position author at collisions)

