Real-Time Systems Project: Part One
===================================

 - Eric Demko

Full source code can be browsed at https://github.com/Zankoku-Okuno/rts-proj
You can download the code repository with `git clone https://github.com/Zankoku-Okuno/rts-proj.git`


Introduction
============

I decided to use Haskell for this project because it has the best API for software transactional memory (STM). In turn, I decided to use STM because it has the advantage of _composability_. With locks, composition of correct program fragments may result in errors: deadlock, livelock, data corruption, &c. STM avoids all of these common and difficult-to-find/fix multitasking bugs, in addition to having better performance in the large. This multitasking model is also used for most databases for much the same reasons.

A word of warning, Haskell is a lazy, pure-functional language, which means it is superficially very different from your average programming language. When in doubt, the code probably just does what you expect, even if it seems like magic.

Usage
=====

If you want to compile the system, you'll need the Haskell Platform (http://www.haskell.org/platform/). This will install several things, but for our purposes, it will install a compiler (ghc), a package manager (cabal) and the required libraries.

Once you have that, extract the tarball and enter the directory. On the command line, type `cabal configure`, then `cabal build`. This will compile the program, which will be placed in `dist/build/rts-proj/rts-proj`, which you may then run without arguments.

Architecture
============

Rather than use the provided architecture, I decided to spawn one thread for each agent in the world. Each agent stores and updates its own location information.

The agents are connected by a ring of message channels. When an agent updates its position, it generates a message and send it through the system. Each other agent checks for collisions, and if there is one, it signs the message before passing it on. When the message returns to its creator, the list of collisions are extracted from the message and reported.

In order to prevent multiple reports of the same collision, only collisions where the author agent is "less than" the subject agent are recorded, in some sense of "less than". Though it is immaterial to the semantics, in this implementation, authors are ordered by ThreadId.

Haskell Techniques
==================

Haskell, being a lazy language with strong type inference, has some weird idioms, so I'm collecting them here.


Often wrapping/unwrapping functions are needed to match types up. The various `lift` functions, like `liftIO` and `liftM` do just that. They can basically be ignored, unless you want to understand monads and monad transformers.

In `zipWith3 newAgent starts chans (tail $ cycle chans)`, I needed to pass two arrays of chanels A and B, such that A[i] == B[i+1], modulo length of the array. To do this, `cycle` concatenates chans to itself ad infinitum, and `tail` offsets it by one. Though an infinite data structure is involved, it is a lazy structure, and so does not cause infinite regress.


A `TMVar` is a possibly empty piece of transactional memory. If an attempt is made to read from an empty `TMVar`, then the reader thread blocks. Similarly, if an attempt to place data in an already full `TMVar`, the writing thread blocks. When there is contention for a `TMVar`, the system will rollback transactions to ensure atomicity and isolation. All this is handled automatically deep in the libraries and compiler.

No value is allowed to be `null` in Haskell. When we want to signal no result, we instead use the `Maybe` generic type. If there is a result `x`, then we wrap `x` into `Just x`, but when there is no result, we return simply `Nothing`. The type system forces us to unwrap valid results and treat them as distinct from no result, so we cannot make a mistake by using invalid results.

As Haskell is a pure-functional language, the concept of a loop, as it appears in most other languages doesn't really make any sense. Instead, we use tail-recursive functions. Any variables mutated throughout the course of the loop (such as counters) are parameters to the function. The last thing the loop does is either 1) return a value, which represents the end of the loop, or 2) call itself with some updated parameters, representing a `continue` statement.

Tail-recursion allows us to abstract common loop patterns. You'll see `mapM` in my code, which is really just a `map` function, and implements a `foreach` loop. Other common functional programming abstractions include `take`, `drop`, `concat`, `filter` and `fold`. There are good tutorials for all of these online. When in doubt about the meaning of a function, google for `haskell `+function_name, and you'll find documentation on `hackage.haskell.org`.
