import unittest
from okulib import *

from pasta_parser.regex.rxconst import *

class TestConstants(unittest.TestCase):
	def test_is(self):
		kleene_star is kleene_star



if __name__ == '__main__':
	unittest.main()