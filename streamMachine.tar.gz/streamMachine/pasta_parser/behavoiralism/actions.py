class Action:
	def __init__(self, function):
		self.act = function

class LocatedAction(Action):
	def __init__(self, function, function_after):
		super().__init__(function)
		self.act_after = function_after