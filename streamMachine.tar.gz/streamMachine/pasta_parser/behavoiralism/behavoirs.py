class _Stimulus_Response:
	def __init__(self, one, two):
		self._pair = (one, two)
	def stimulus(self): return self._pair[0]
	def response(self): return self._pair[1]

from .actions import *
class Behavoir(_Stimulus_Response):
	def __init__(self, stimulus, response):
		super().__init__(stimulus, Action(response))

class LocatedBehavoir(_Stimulus_Response):
	def __init__(self, stimulus, at, after):
		super().__init__(stimulus, LocatedAction(at, after))