from .meaning import MeaningMachine
class LocationMachine(MeaningMachine):
	def __init__(self, keywords, driver):
		self.keywords = keywords
		self.driver = driver
		self.reset()
	
	def _reset_location(self, line=0, col=0):
		self.line = line
		self.col = col
		self._locations = []
	def reset(self, line=0, col=0):
		self._reset_meaning()
		self._reset_location()
	
	def location(self):
		return (self.line, self.col)
	
	def push_location(self):
		self._locations.append(self.location())
	def pop_location(self):
		loc = self._locations[-1] if self._locations else None
		self._locations = self._locations[:-1] if self._locations else []
		return loc
	
	def _act(self, syntax, action):
		action.act(syntax, self)
		self._update_location(syntax)
		if 'act_after' in action.__dict__:
			action.act_after(syntax, self)
	def _update_location(self, input):
		for item in input:
			if item == '\n': #TODO generalize
				self.line += 1
				self.col = 1
			else:
				self.col += 1