from .mode_path import ModePathMachine
class HookMachine(ModePathMachine):
	def __init__(self, keywords, driver, initial_mode, final_modes,
				 enter=dict(), evolve=dict(), devolve=dict(), exit=dict()):
		self.enter_hooks = enter
		self.evolve_hooks = evolve
		self.devolve_hooks = devolve
		self.exit_hooks = exit
		super().__init__(keywords, driver, initial_mode, final_modes)
	
	def _hook(self, hook_type, syntax):
		if self.mode() in hook_type:
			hook_type[self.mode()](syntax, self)
	
	def _enter_into(self, syntax): self._hook(self.enter_hooks, syntax)
	def _evolve_from(self, syntax): self._hook(self.evolve_hooks, syntax)
	def _devolve_into(self, syntax): self._hook(self.devolve_hooks, syntax)
	def _exit_from(self, syntax): self._hook(self.exit_hooks, syntax)

from okulib import progn
def enter_mode(mode):
	return lambda syntax, state: progn(
			lambda: state._evolve_from(syntax),
			lambda: state.push_mode(mode),
			lambda: state._enter_into(syntax) )
def exit_mode():
	return lambda syntax, state: progn(
		lambda: state._exit_from(syntax),
		lambda: state.pop_mode(),
		lambda: state._devolve_into(syntax) )