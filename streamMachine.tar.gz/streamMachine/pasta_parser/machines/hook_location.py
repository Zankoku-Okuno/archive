from .hook import HookMachine
from .location import LocationMachine
class HookLocationMachine(HookMachine, LocationMachine):
	def __init__(self, keywords, driver, initial_mode, final_modes,
				 enter=dict(), evolve=dict(), devolve=dict(), exit=dict()):
		self.keywords = keywords
		self.driver = driver
		self.final_modes = final_modes
		
		self.enter_hooks = enter
		self.evolve_hooks = evolve
		self.devolve_hooks = devolve
		self.exit_hooks = exit
		
		self.reset(initial_mode)
	
	def reset(self, reinitial_mode, line=0, col=0):
		self._reset_meaning()
		self._reset_location(line, col)
		self._reset_mode(reinitial_mode)

from okulib import progn
def enter_mode(mode):
	return (
		lambda syntax, state: progn(
			lambda: state._evolve_from(syntax),
			lambda: state.push_mode(mode) ),
		lambda syntax, state: state._enter_into(syntax)
		)
def exit_mode():
	return (
		lambda syntax, state: progn(
			lambda: state._exit_from(syntax),
			lambda: state.pop_mode() ),
		lambda syntax, state: state._devolve_into(syntax)
		)