class _RXConst:
	def __init__(self): pass

kleene_star = _RXConst()