# == TOKENIZER == 

spring_section = '_SPRING_'
section_end = '_END_SECTION_'

private_import = '_USING_'
public_import = '_STREAM_'
charstream = '_CHARSTREAM_'
line_continue = '_LINE_CONTINUE_'
tabsize = '_TABSIZE_'
ignore_empty_lines = '_IGNORE_EMPTY_LINES_'
detect_indentation = '_DETECT_INDENTATION_'
collapse_whitespace = '_COLLAPSE_WHITESPACE_'
discard_whitespace = '_DISCARD_WHITESPACE_'
phoneme = '_PHONEME_'
keyword = '_KEYWORD_'
opword = '_OPWORD_'
pattern = '_PATTERN_'
delimiter = '_DELIMITER_'

delim_begin = '_DELIMITER_BEGIN_'
delim_end = '_DELIMITER_END_'
delim_escape = '_DELIMITER_ESCAPE_'
delim_weave = '_DELIMITER_WEAVE_'
delim_unweave = '_DELIMITER_UNWEAVE_'
delim_recurse = '_RECURSIVE_DELIMITER_'

end_spring_statement = '_SPRING_STATEMENT_'


spring_detect_opwords = {
    spring_section,
    section_end
}
spring_opwords = {
    private_import,
    public_import,
    charstream,
    line_continue,
    tabsize,
    ignore_empty_lines,
    detect_indentation,
    collapse_whitespace,
    discard_whitespace,
    phoneme,
    keyword,
    opword,
    pattern,
    delimiter
}
delimiter_opwords = {
    delim_begin,
    delim_end,
    delim_escape,
    delim_weave,
    delim_unweave,
    delim_recurse
}





# == COMPILER ==

cpragma = "_C_PRAGMA_"
rpragma = "_R_PRAGMA_"

locative = "_LOCATIVE_"     #at
inessive = "_INESSIVE_"     #in
essive = "_ESSIVE_"         #as
antessive = "_ANTESSIVE_"   #before
postessive = "_POSTESSIVE_" #after
begin_pragma = "_END_PRAGMA_HEADER_"

call_pragma = "_CALL_PRAGMA_"


header_opwords = {
    locative,
    inessive,
    essive,
    antessive,
    postessive,
    begin_pragma
}
section_opwords = {
    cpragma,
    rpragma,
    #STUB anything that can start a D-pragma
    section_end
}

cpragma_opwords = {
    call_pragma
}
#TODO more individual section opwords
#to add more categories:
    #1) create the category here as a set and populate it with strings
    #2) go to waterworks.context and add the category (if new) into its data structure
    #3) go to InitialContext.__init__ and add the pair (<category>, <data
    #   structure>) in the for loop
    #4) go to sed.opword and adjust __init__ OpwordSed.transitions





# == LIL ==
#TODO
lil_opwords = {
    #STUB
}