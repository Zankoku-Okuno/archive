from ..reserved import *
from ..predef import *

from waterworks.context import Context
class InitialContext(Context):
    def __init__(self):
        super().__init__()
        def load(category, target):
            for key in category:
                target[key] = key
        for pair in [
            (spring_detect_opwords, self.opwords.spring_detect),
            (spring_opwords, self.opwords.spring),
            (delimiter_opwords, self.opwords.delimiter),
            (whitespace_opwords, self.opwords.whitespace),
            (section_opwords, self.opwords.section),
            (header_opwords, self.opwords.header),
            (cpragma_opwords, self.opwords.cpragma)
        ]:
            load(*pair)
        self.tokenizer.charstream = False
        self.tokenizer.tabsize = 0
        self.tokenizer.ignore_empty_lines = True
        self.tokenizer.detect_indentation = False
        self.tokenizer.collapse_whitespace = False
        self.tokenizer.discard_whitespace = True
        from stovokor.local import Phoneme
        self.tokenizer.phonemes.append(Phoneme(separator_phoneme, ' \t\n'))