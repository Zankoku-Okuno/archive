import re
from facilities.unicode import unicode_escapes
from ..exceptions import LotusCompilerError

class BaseSubcompiler:
    def __init__(self, context, token1, token2=None):
        from ..predef import whitespace_opwords
        self.whitespace = {context.opwords.whitespace(x): whitespace_opwords[x]
                           for x in context.opwords.whitespace}
        self.location = token1.location
        if token2 is not None:
            self.location.end = token2.location.end
    
    def append(self, token):
        self.location.end = token.location.end

class BaseUnaryCompiler(BaseSubcompiler):
    def __init__(self, context, verb, token):
        super().__init__(context, verb, token)
    
    def append(self, token):
        raise LotusCompilerError("Expected end of statement.", token)

class BaseBooleanCompiler(BaseUnaryCompiler):
    def __init__(self, context, verb, token):
        super().__init__(context, verb, token)
        self.setting = self.secure(token)
    
    def secure(self, token):
        if token.text in {'0', '1'}:
            return token.text == '1'
        else:
            raise LotusCompilerError("Expected single bit.", token)
    
    def compile(self):
        return self.setting

class BaseKeywordCompiler(BaseSubcompiler):
    def append(self, token):
        super().append(token)
        text = unicode_escapes(token.text)
        if text in self.whitespace:
            text = self.whitespace[text]
        return text


class OpwordStatement(BaseKeywordCompiler):
    def __init__(self, context, token, verb):
        super().__init__(context, token, verb)
        self.foreign = ""
        self.native = token
        self.secure_native()
    
    def secure_native(self):
        from .initial import InitialContext
        try:
            InitialContext().opwords[self.native.text] = self
        except KeyError as ex:
            raise LotusCompilerError("Cannot define {0} opword.".format(ex), self.native) #TESTME
        self.native = self.native.text
    
    #TODO lets improve the security architecture
    #have the 'reserved' module be able to classify opwords, so we needn't use a try/catch
    #at the same time, this will allow us to set a flag for 'allow whitespace', and subsequently secure definitional tokens as they come
    
    def append(self, token):
        self.foreign += super().append(token)
    
    def compile(self):
        return self.foreign
    
    def insert_into(self, context):
        context.opwords[self.native] = self

class CharStreamStatement(BaseBooleanCompiler):
    def insert_into(self, context):
        context.tokenizer.set_charstream(self)

class LineContinueStatement(BaseKeywordCompiler):
    def __init__(self, context, verb, token):
        super().__init__(context, verb, token)
        self.definition = ''
        self.append(token)
    
    def append(self, token):
        self.definition += self.secure(super().append(token))
    
    def secure(self, text):
        return text #STUB
        #pass the definition through the sequence normalizer, as if it were being massaged
        #although, since the whole file is run through... but there are things like _SPACE_
    
    def compile(self):
        return self.definition
    
    def insert_into(self, context):
        context.tokenizer.set_line_continue(self)

class TabSizeStatement(BaseUnaryCompiler):
    def __init__(self, context, verb, token):
        super().__init__(context, verb, token)
        self.tabsize = self.secure(token)
    
    def secure(self, token):
        for char in token.text:
            if char not in "0123456789":
                raise LotusCompilerError("Expected positive integer.", token)
        return int(token.text)
    
    def compile(self):
        return self.tabsize
    
    def insert_into(self, context):
        context.tokenizer.set_tabsize(self)

class IgnoreEmptyLinesStatement(BaseBooleanCompiler):
    def insert_into(self, context):
        context.tokenizer.set_ignore_empty_lines(self)

class DetectIndentationStatement(BaseBooleanCompiler):
    def insert_into(self, context):
        context.tokenizer.set_detect_indentation(self)

class CollapseWhitespaceStatement(BaseBooleanCompiler):
    def insert_into(self, context):
        context.tokenizer.set_collapse_whitespace(self)

class DiscardWhitespaceStatement(BaseBooleanCompiler):
    def insert_into(self, context):
        context.tokenizer.set_discard_whitespace(self)

from stovokor.local import Phoneme
class PhonemeStatement(BaseSubcompiler):
    def __init__(self, context, token, verb):
        super().__init__(context, token, verb)
        self.phoneme = Phoneme(token.text) #no need for security
        self.original = []
    
    def append(self, token):
        super().append(token)
        self.original.append(token.text)
        text = unicode_escapes(token.text) #no need for security
        if len(text) == 3 and text[1] == '-':
            c1, c2 = text[0], text[2]
            if ord(c2) < ord(c1):
                c1, c2 = c2, c1
            self.phoneme.add_range(c1, c2)
        else:
            if text in self.whitespace:
                text = self.whitespace[text]
            self.phoneme.add_all(text)
    
    def compile(self):
        return self.phoneme
    
    def insert_into(self, context):
        context.tokenizer.add_phoneme(self)

class KeywordStatement(BaseKeywordCompiler):
    def __init__(self, context, verb, token):
        super().__init__(context, verb, token)
        self.definition = ''
        self.append(token)
    
    def append(self, token):
        self.definition += self.secure(super().append(token))
    
    def secure(self, text):
        return text #STUB
        #pass the definition through the sequence normalizer, as if it were being massaged
        #although, since the whole file is run through... but there are things like _SPACE_
    
    def compile(self):
        from stovokor.quantum import Keyword
        return Keyword(self.definition)
    
    def insert_into(self, context):
        context.tokenizer.add_keyword(self)

class PatternStatement(BaseKeywordCompiler):
    def __init__(self, context, token, verb):
        super().__init__(context, token, verb)
        self.name = token.text
        self.pattern = ''
    
    def append(self, token):
        self.pattern += self.secure(super().append(token))

    def secure(self, text):
        return text #STUB
        #pass the definition through the sequence normalizer, as if it were being massaged
        #TODO figure that out, given that the pattern is encoded itself
    
    def compile(self):
        from stovokor.quantum import Pattern
        #FIXME throw a LotusCompilerError if the pattern can't be compiled
        return Pattern(self.name, self.pattern)
    
    def insert_into(self, context):
        context.tokenizer.add_pattern(self)

from ..reserved import delim_begin, delim_end, delim_escape, \
                       delim_weave, delim_unweave, delim_recurse
class DelimiterStatement(BaseSubcompiler):
    def __init__(self, context, token, verb):
        super().__init__(context, token, verb)
        self.paramwords = context.opwords.delimiter
        self.mode = 0
        self.positional = [token]
        self.kwargs = {delim_begin: '', delim_end: '', delim_escape: '',
                       delim_weave: '', delim_unweave: '', delim_recurse: False}
    
    def append(self, token):
        super().append(token)
        text = token.text
        if self.paramwords.has(text):
            text = self.paramwords[text]
        if text in DelimiterStatement.keyword_to_mode:
            self.mode = DelimiterStatement.keyword_to_mode[text]
            if text == delim_recurse:
                if self.kwargs[delim_recurse]:
                    raise LotusCompilerError("Cannot set recursive twice.", token) #TESTME
                self.kwargs[delim_recurse] = True
        else:
            if text in self.whitespace:
                text = self.whitespace[text]
            text = unicode_escapes(text)
            if self.mode == 0:
                token.text = text
                self.positional.append(token)
            elif self.mode == -1: #TESTME
                raise LotusCompilerError("Expected keyword argument or end of statement.", token)
            else:
                self.kwargs[DelimiterStatement.mode_to_keyword[self.mode]] += text
    
    mode_to_keyword = {
        1: delim_begin,
        2: delim_end,
        3: delim_escape,
        4: delim_weave,
        5: delim_unweave,
    }
    keyword_to_mode = {
        delim_begin: 1,
        delim_end: 2,
        delim_escape: 3,
        delim_weave: 4,
        delim_unweave: 5,
        delim_recurse: -1
    }
    
    def compile(self):
        if not self.kwargs[delim_begin]:
            if len(self.positional) < 2: #TESTME
                raise LotusCompilerError("Delimiters need at least start and end sequences.", self)
            self.kwargs[delim_begin] = self.positional[1].text
        if not self.kwargs[delim_end]:
            if len(self.positional) < 3: #TESTME
                raise LotusCompilerError("Delimiters need at least start and end sequences.", self)
            self.kwargs[delim_end] = self.positional[2].text
        if not self.kwargs[delim_escape] and len(self.positional) > 3:
            self.kwargs[delim_escape] = self.positional[3].text
        if not self.kwargs[delim_weave] and len(self.positional) > 4:
            self.kwargs[delim_weave] = self.positional[4].text
        if not self.kwargs[delim_unweave] and len(self.positional) > 5:
            self.kwargs[delim_unweave] = self.positional[5].text
        if len(self.positional) > 6: #TESTME
            raise LotusCompilerError("Too many positional aguments.", self.input[6])
        try:
            from stovokor.quantum import Delimiter
            return Delimiter(self.positional[0].text,
                             self.kwargs[delim_begin],
                             self.kwargs[delim_end],
                             self.kwargs[delim_escape],
                             self.kwargs[delim_weave],
                             self.kwargs[delim_unweave],
                             self.kwargs[delim_recurse])
        except ValueError as ex:
            raise LotusCompilerError(ex, self)
    
    def insert_into(self, context):
        context.tokenizer.add_delimiter(self)
        
class _ModuleConnectionCompiler(BaseSubcompiler):
    def __init__(self, context, verb, first_token):
        super().__init__(context, verb, first_token)
        self.modules = [first_token]
    
    def append(self, token):
        self.modules.append(token)
    
    def secure(self):
        pass #STUB validate path syntax
    
    def insert_into(self, context):
        self.secure()
        for token in self.modules:
            self._insert_helper(context, token)

class ImportExportStatement(_ModuleConnectionCompiler):
    def _insert_helper(self, context, token):
        context.modules.add_stream(token)

class ImportStatement(_ModuleConnectionCompiler):
    def _insert_helper(self, context, token):
        context.modules.add_using(token)