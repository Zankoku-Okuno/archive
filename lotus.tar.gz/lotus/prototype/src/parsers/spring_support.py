from .. import reserved
from stovokor.local import FriendlyAlphabet, RichAlphabet, Phoneme
class SpringAlphabet(RichAlphabet, FriendlyAlphabet):
    pass
spring_alphabet = SpringAlphabet()
spring_alphabet[SpringAlphabet.separator] = " \t\n\r"
statement_phoneme = Phoneme(reserved.end_spring_statement, "\n\r")
spring_alphabet[reserved.end_spring_statement] = statement_phoneme
from stovokor.quantum import Keyword
spring_line_continue = Keyword("\\lc\n") #TODO make it a pattern for more flexibility


from .spring_subparsers import *
intransitive = {
    reserved.charstream: CharStreamStatement,
    reserved.line_continue: LineContinueStatement,
    reserved.ignore_empty_lines: IgnoreEmptyLinesStatement,
    reserved.detect_indentation: DetectIndentationStatement,
    reserved.collapse_whitespace: CollapseWhitespaceStatement,
    reserved.discard_whitespace: DiscardWhitespaceStatement,
    reserved.tabsize: TabSizeStatement,
    reserved.keyword: KeywordStatement,
    reserved.public_import: ImportExportStatement,
    reserved.private_import: ImportStatement,
}
transitive = {
    reserved.phoneme: PhonemeStatement,
    reserved.pattern: PatternStatement,
    reserved.delimiter: DelimiterStatement
}