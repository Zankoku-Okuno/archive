from ..reserved import *

from .spring_support import *

from stovokor.sed import AnnotatingReader
class SpringReader(AnnotatingReader):
    def __init__(self, output):
        from stovokor.matcher import Driver
        super().__init__(Driver(spring_alphabet, {spring_line_continue}, set(), set()), output)

class SpringParser:
    def __init__(self, output):
        self.output = output
    
    def append(self, token):
        from stovokor.token import MatchedByKeyword
        if isinstance(token.matcher, MatchedByKeyword):
            token = None
        elif statement_phoneme in token.matcher.matcher:
            token.text = end_spring_statement
        elif spring_alphabet.separator_phoneme in token.matcher.matcher:
            token = None
        else:
            pass
        if token:
            self.output.append(token)
    
    def eof(self):
        try:
            self.output.eof()
        except AttributeError:
            pass

class BaseSpringCompiler:
    def __init__(self, context):
        self.context = context
        from waterworks.flow import Flow
        self.flow = Flow()
        self.subcompiler = None
        self.lookahead_buffer = None
    
    def _in_the_market(self, token):
        text, la_text = token.text, self.lookahead_buffer.text
        if text == self.context.opwords.spring(opword):
            self._create_subcompiler(token, OpwordStatement)
        elif la_text == self.context.opwords.spring_detect(section_end):
            raise EndSectionException(self.lookahead_buffer.location)
        else:
            try:
                self._create_subcompiler(token,
                        intransitive[self.context.opwords.spring[la_text]])
                return
            except KeyError:
                try:
                    self._create_subcompiler(token,
                            transitive[self.context.opwords.spring[text]])
                    return
                except KeyError:
                    raise Exception(la_text + " " + text) #TODO
    
    def append(self, token):
        if self.subcompiler is None:
            if self.lookahead_buffer is None:
                self.lookahead_buffer = token
            else:
                self._in_the_market(token)
        elif token.text == end_spring_statement:
            self._end_statement()
        else:
            self.subcompiler.append(token)
    
    def eof(self):
        self._end_statement()
        if self.lookahead_buffer.text == self.context.opwords.spring_detect(section_end):
            raise EndSectionException(self.lookahead_buffer.location)
        #TODO more checks in case of improper stuff at eof
    
    def _create_subcompiler(self, token, compiler):
        self.subcompiler = compiler(self.context, self.lookahead_buffer, token)
        self.lookahead_buffer = None
    

class EndSectionException(Exception):
    def __init__(self, location):
        self.location = location.end.line+1



class SpringCompiler(BaseSpringCompiler):
    def _end_statement(self):
        if self.subcompiler is None:
            return
        if isinstance(self.subcompiler, OpwordStatement):
            self.subcompiler.insert_into(self.context)
        self.subcompiler.insert_into(self.flow)
        self.subcompiler = None




