class LotusCompilerError(Exception):
    def __init__(self, message, location=None):
        super().__init__(message)
        self.msg = str(self)
        self.where = location