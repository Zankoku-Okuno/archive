space = '_space_'
tab = '_tab_'
linebreak = '_linebreak_'
whitespace_opwords = {
    space: ' ',
    tab: '\t',
    linebreak: '\n'
}

default_phoneme = '_default_'
separator_phoneme = '_separator_'
loner_phoneme = '_loner_'