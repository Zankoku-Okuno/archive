from ..reserved import *
class OpwordSed:
    def __init__(self, context, output):
        self.output = output
        self.mode, self.next_mode = 'normal', None
        
        self.opwords = { #for use in translating opwords
            'normal': {context.opwords.section},
            'header': {context.opwords.header},
            'cpragma': {context.opwords.section,
                        context.opwords.cpragma}
            #STUB
        }
        from stovokor.quantum import Keyword
        self.keyword_sets = dict() #for use in swapping the matcher's keywords
        #here, we only set up where everyday keywords are applicable
        for mode in {'normal', 'cpragma'}: #TODO figure out all modes where keywords apply
            self.keyword_sets[mode] = context.tokenizer.keywords
        #here, we merge in the appropriate opwords using previous knowledge about translations
        for mode in self.opwords:
            if mode not in self.keyword_sets: #malloc
                self.keyword_sets[mode] = set()
            for S in self.opwords[mode]:
                self.keyword_sets[mode] |= {Keyword(x) for x in S.values()}
    
    def link_input(self, input):
        self.input = input
        self.switch_mode('normal')
    
    def switch_mode(self, mode, next_mode=None):
        self.mode = mode if mode else self.next_mode
        self.next_mode = next_mode
        self.input.matcher.keyword_matcher.source = self.keyword_sets[self.mode]
        
    
    def append(self, token):
        if token.matcher.type == 'keyword':
            if self.lookup(token.text):
                token.text = self.lookup(token.text)
                token.matcher.type = 'opword'
                self.maintain_mode(token.text)
        self.output.append(token)

    def lookup(self, text):
        for isomorph in self.opwords[self.mode]:
            if isomorph.has(text):
                return isomorph[text]
        else:
            return False

    def maintain_mode(self, text):
        if text in OpwordSed.transitions[self.mode]:
            self.switch_mode(*OpwordSed.transitions[self.mode][text])

    transitions = { #basically, this is a stack machine with a max stack height of 2
        'normal': {
            cpragma: ('header', 'cpragma')
            #STUB
        },
        'header': {
            begin_pragma: (None, None)
        },
        'cpragma': {
            section_end: ('normal', None)
        }
        #TODO more types of section
    }




