class LineContinueHandler:
    #MAYBE we should also worry about trimming tabs off here
    #that is, plug into the tab detection if _DETECT_INDENTATION_ is on
    #then, trim off the current indentation level if the last line was continued
    #then again, maybe not: some indentation may not be significant to the end-user
    def __init__(self, context, output):
        self.line_continue = context.tokenizer.line_continue
        self.did_continue = False
        self.output = output
    
    def is_continued(self, line):
        if not line:
            return False
        test_line = line[:-1] if line[-1] == '\n' else line
        if len(test_line) < len(self.line_continue):
            return False
        return test_line[-len(self.line_continue):] == self.line_continue
    
    def feed(self, line):
        import re
        if self.did_continue and re.match(r'\s*\Z', line):
            self.output.feed_invisible(line)
        elif self.is_continued(line):
            excess = len(self.line_continue) + (1 if line[-1] == '\n' else 0)
            self.output.feed(line[:-excess])
            if self.output.matcher.delimiter_matcher.active:
                self.output.feed(line[-excess:])
            else:
                self.output.feed_invisible(line[-excess:])
                self.did_continue = True
        else:
            self.output.feed(line)
            self.did_continue = False
    
    def eof(self):
        self.output.eof()




