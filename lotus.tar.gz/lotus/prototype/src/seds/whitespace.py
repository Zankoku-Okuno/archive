from stovokor.token import Token, Location
from ..predef import *
class SeparatorSed:
    def __init__(self, context, output):
        self.tabsize = context.tokenizer.tabsize
        self.ignore_empty_lines = context.tokenizer.ignore_empty_lines
        self.detect_indentation = context.tokenizer.detect_indentation
        self.collapse_whitespace = context.tokenizer.collapse_whitespace
        self.discard_whitespace = context.tokenizer.discard_whitespace
        self.output = output
        
        self.indent_stack = [0]
    
    def append(self, token): #REFAC internally
        if (token.matcher.type == 'alphabet' and
            {x.name for x in token.matcher.matcher} == {separator_phoneme}):
            split, i = [], 0
            for char in token.text:
                split.append((char, (i, i+1)))
                i += 1
            split = self.handle_whitespace(split)
            for item in split:
                line, col = token.location.start.line, token.location.start.column
                for i in range(item[1][0]):
                    if token.text[i] == '\n':
                        line, col = line+1, 0
                    else:
                        col += 1
                start = (line, col)
                for i in range(item[1][0], item[1][1]):
                    if token.text[i] == '\n':
                        line, col = line+1, 0
                    else:
                        col += 1
                end = (line, col)
                self.output.append(Token(item[0],
                                         token.matcher,
                                         Location(token.location.file, start, end)))
        else:
            self.output.append(token)
    
    def handle_whitespace(self, split):
        split = self.handle_tabs(split)
        if self.ignore_empty_lines:
            split = self.empty_empty_lines(split)
        if self.detect_indentation:
            split = self.track_indent(split)
        if self.collapse:
            split = self.collapse(split)
        split = self.discard(split)
        return self.normalize(split)
    

    def handle_tabs(self, split):
        if self.tabsize == 0:
            return split
        elif self.tabsize == 1:
            new_split = []
            for item in split:
                if item[0] == '\t':
                    new_split.append((' ', item[1]))
                else:
                    new_split.append(item)
            return new_split
        else:
            new_split, lookahead = [], []
            for item in split:
                lookahead.append(item)
                if item[0] == ' ':
                    if len(lookahead) == self.tabsize:
                        new_split.append(('\t', (lookahead[0][1][0], lookahead[-1][1][1])))
                        lookahead = []
                else:
                    new_split += lookahead
                    lookahead = []
            return new_split + lookahead
    
    def empty_empty_lines(self, split):
        newline = False
        new_split, lookahead = [], []
        for item in split:
            if newline:
                if item[0] == '\n':
                    new_split.append( ('\n', (lookahead[0][1][0], lookahead[-1][1][1])) )
                    lookahead = [item]
                else:
                    lookahead.append(item)
                    if item[0] not in ' \t':
                        new_split += lookahead
                        newline, lookahead = False, []
            else:
                if item[0] == '\n':
                    newline = True
                    lookahead.append(item)
                else:
                    new_split.append(item)
        return new_split + lookahead
    
    def track_indent(self, split):
        new_split, lookahead = [], []
        linestart = False
        for item in split:
            if linestart:
                if (self.ignore_empty_lines
                    and not lookahead
                    and item[0] == '\n'):
                    new_split.append(item)
                else:
                    if item[0] == '\t':
                        lookahead.append(item)
                    else:
                        new_split += self.tab_significance(lookahead, new_split[-1][1][1])
                        lookahead, linestart = [], item[0] == '\n'
                        new_split.append(item)
            else:
                if item[0] == '\n':
                    linestart = True
                new_split.append(item)
        return new_split + self.tab_significance(lookahead, new_split[-1][1][1])
    
    def tab_significance(self, lookahead, last_loc):
        out = []
        if len(lookahead) > self.indent_stack[-1]:
            out.append( ('_indent_', (lookahead[0][1][0], lookahead[-1][1][1])) )
            self.indent_stack.append(len(lookahead))
        else:
            while len(lookahead) < self.indent_stack[-1] and \
                  len(lookahead) <= self.indent_stack[-2]:
                out.append( ('_dedent_',
                                   (last_loc,
                                    lookahead[-1][1][1] if lookahead else last_loc)) )
                self.indent_stack.pop()
        return out
    
    def collapse(self, split):
        new_split, lookahead = [], []
        for item in split:
            if lookahead:
                if item[0] == lookahead[-1][0]:
                    lookahead.append(item)
                else:
                    new_split.append( (lookahead[0][0][0], (lookahead[0][1][0], lookahead[-1][1][1])) )
                    lookahead = []
            if item[0] in ' \t':
                lookahead.append(item)
            else:
                new_split.append(item)
        return new_split + lookahead
    
    def discard(self, split):
        keepset = {'_indent_', '_dedent_'}
        if not self.discard_whitespace:
            keepset |= {' ', '\t', '\n'}
        new_split = []
        for item in split:
            if item[0] in keepset:
                new_split.append(item)
        return new_split
    
    def normalize(self, split):
        new_split = []
        for item in split:
            if item[0] == ' ':
                new_split.append((space, item[1]))
            elif item[0] == '\t':
                new_split.append((tab, item[1]))
            elif item[0] == '\n':
                new_split.append((linebreak, item[1]))
            else:
                new_split.append(item)
        return new_split