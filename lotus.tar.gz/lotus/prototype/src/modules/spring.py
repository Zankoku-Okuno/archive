import os
from os import path
from .spring_detector import handle_spring

def build_spring(modpath):
    basis = get_upstream(modpath)
    flow, body = get_spring(modpath, build_context(basis))
    basis += get_imports(modpath, flow.modules.stream)
    basis += get_imports(modpath, flow.modules.using)
    return build_context(basis + [flow]), body

def build_watershed(modpath, traversed_modules=None):
    """Given a module, return the linearized list of flows which the module
    exports."""
    traversed_modules =_update_traversed(modpath, traversed_modules)
    basis = get_upstream(modpath, traversed_modules)
    flow, body = get_spring(modpath, build_context(basis))
    basis += get_imports(modpath, flow.modules.stream, traversed_modules)
    #TODO linearize: remove all but the last modpath for those that appear more than once
    return basis + [flow]
def _update_traversed(modpath, modules):
    return {modpath} if modules is None else modules|{modpath}

def get_spring(modpath, context):
    """Given a path to a module, return the flow defined in that module."""
    if path.exists(modpath) and path.isdir(modpath):
        filepath = path.join(modpath, '_petal_.lotus')
    else:
        filepath = modpath+'.lotus'
    if path.exists(filepath):
        flow, body = handle_spring(filepath, context)
        return flow, body
    else:
        raise Exception(filepath) #TODO

def get_upstream(modpath, traversed_modules=None):
    """Given a module, return a list of flows constituting that module's
    upstream."""
    if traversed_modules is None:
        traversed_modules = set()
    if has_supermodule(modpath):
        return build_watershed(path.split(modpath)[0], traversed_modules)
    else:
        return []

def get_imports(modpath, sources, traversed_modules=None):
    if traversed_modules is None:
        traversed_modules = set()
    out = []
    for source in sources:
        absolute = path.join(path.split(modpath)[0], source.text)
        #TODO if it doesn't exist, look elsewhere
        if absolute in traversed_modules:
            raise Exception() #TODO
        out += build_watershed(absolute, traversed_modules)
    #TODO linearize: remove all but the last modpath for those that appear more than once
    return out

def has_supermodule(modpath):
    if modpath == '/':
        return False
    return path.exists(path.join(path.split(modpath)[0], '_petal_.lotus'))

def build_context(flows):
    from ..parsers.initial import InitialContext
    context = InitialContext()
    for flow in flows:
        context.layer(flow)
    return context.finalize()


