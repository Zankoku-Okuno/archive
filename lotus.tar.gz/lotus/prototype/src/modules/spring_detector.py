import re
from ..parsers.spring import *
from waterworks.flow import Flow

def handle_spring(filepath, context):
    """Given a file path, uses the context to detect and parse spring sections.
    A flow object is returned along with a the lineno where the file's body
    begins. If no such section is detected, then an empty flow is returned. If
    there is a flow, but there is no body (an unterminated spring section), the
    returned line number is -1."""
    file, first_line = detect_spring(filepath, context)
    if not file:
        return Flow(), 0
    parser, flow = get_spring_parser(context, filepath, first_line)
    try:
        while True:
            try:
                text = file.readline()
                if not text: #end of file
                    parser.eof()
                    return flow, -1
                parser.feed(text)
            except EndSectionException as end:
                return flow, end.location
    finally:
        file.close()

def detect_spring(filepath, context):
    """Checks if the file at the path has a spring section. If so, it returns an
    open file object and the number of lines into the file where the spring
    statement begins (its interior, not the spring section flag itself). If
    there is no such section, returns (None, 0)."""
    file = open(filepath)
    text, line = file.readline(), 1 #start at one because we have already read line zero
    while re.match(r'\s*\Z', text):
        text, line = file.readline(), line+1
        if not text: #end of file
            file.close()
            return None, 0
    canary = context.opwords.spring_detect('_SPRING_')
    extract = re.match(r'\s*([^\s]*)\s*\Z', text).groups()[0]
    if canary == extract:
        return file, line
    else:
        file.close()
        return None, 0

def get_spring_parser(context, filepath, line):
    """Initializes a parser, returning it along with its output Flow object."""
    compiler = SpringCompiler(context)
    parser = SpringReader(SpringParser(compiler))
    parser.file, parser.lineno = filepath, line
    return parser, compiler.flow
    