from os import path
from .modules.spring import build_spring

#TODO handle passing delimited tokens to their subcompiler
#str _SUBCOMPILER_ lib/str

#TODO build something that can search over the tree, picking out woven delimited tokens and unewaving them
#this will occur perforce, before the compiler entry-point
#this will also need to extract delimiter escapes, since they must be extracted
#only on leaf nodes in order to keep better track of location

def tokenize(modpath):
    #assert: given an absolute filepath
    context, body = build_spring(modpath)
    filepath = _get_filepath(modpath)
    reader, tree = _get_sed(context, filepath, body)
    file = open(filepath)
    for line in range(body):
        file.readline()
    while True:
        text = file.readline()
        if not text: #end of file
            reader.eof()
            break
        reader.feed(text)
    file.close()
    return tree, context
        #the context may be needed later to handle complex delimited tokens

def _get_filepath(modpath):
    if path.isdir(modpath):
        modpath = path.join(modpath, '_petal_')
    modpath += '.lotus'
    return modpath

from stovokor.matcher import Driver
from .seds.line_continue import LineContinueHandler
from stovokor.sed import AnnotatingReader
from .seds.whitespace import SeparatorSed
from .seds.opword import OpwordSed
from arboreum.tree import TreeBuilder as Tree
def _get_sed(context, file, starting_line):
    driver = Driver(context.tokenizer.alphabet,
                    context.tokenizer.keywords,
                    context.tokenizer.patterns,
                    context.tokenizer.delimiters)
    tree = Tree()
    separator = SeparatorSed(context, tree)
    opworder = OpwordSed(context, separator)
    reader = AnnotatingReader(driver, opworder)
    opworder.link_input(reader)
    reader.file, reader.lineno = file, starting_line
    if context.tokenizer.line_continue is not None:
        reader = LineContinueHandler(context, reader)
    return reader, tree




