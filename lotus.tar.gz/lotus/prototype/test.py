#! /usr/bin/python3

import unittest

from test.parsers.spring_subcompilers import *
from test.parsers.spring_parser import *
from test.parsers.opword_sed import *
from test.tokenizing import *

unittest.main()
