import unittest
import os
from os import path

from src.modules.spring import *
class TestSpringModules(unittest.TestCase):
    def test_supermodule(self):
        p = path.join(os.getcwd(), 'test/test_module')
        self.assertFalse(has_supermodule(p))
        p = path.join(p, 'test_submodule')
        self.assertTrue(has_supermodule(p))
    def test_upstream(self):
        p = path.join(os.getcwd(), 'test/test_module')
        self.assertEqual([], get_upstream(p, set()))
        p = path.join(p, 'A')
        f = get_upstream(p, set())
        self.assertEqual(len(f), 1)
        self.assertEqual(f[0].opwords.new_opwords['_TABSIZE_'].compile(), 'tab:')
    def test_streaming(self):
        p = path.join(os.getcwd(), 'test/test_module/test_submodule/sA')
        flows = build_watershed(p)
        context = build_context(flows)
        self.assertEqual(context.tokenizer.tabsize, 2)

from src.tokenizer import SeparatorSed
from src.parsers.initial import InitialContext
class TestSettingsSed(unittest.TestCase): #TESTME for token location as well
    def split(self, text):
        s, i = [], 0
        for char in text:
            if char in {'i', 'd'}:
                char = {'i': '_indent_', 'd': '_dedent_'}[char]
            s.append((char, (i, i+1)))
            i += 1
        return s
    def setUp(self):
        self.c = InitialContext()
    def test_charstream(self):
        context = InitialContext()
        context.tokenizer.charstream = True
        context.finalize()
        from src.tokenizer import _get_sed
        reader, tree = _get_sed(context, None, 0)
        reader.feed('split me')
        reader.eof()
        self.assertEqual(['s', 'p', 'l', 'i', 't', 'm', 'e'], [x.text for x in tree])
    def test_zero_tab_handling(self):
        s = self.split('\t   \t\t')
        self.c.tokenizer.tabsize = 0
        sed = SeparatorSed(self.c, None)
        new = sed.handle_tabs(s)
        self.assertEqual(s, new)
    def test_one_tab_handling(self):
        s = self.split('\t   \t\t')
        self.c.tokenizer.tabsize = 1
        sed = SeparatorSed(self.c, None)
        new = sed.handle_tabs(s)
        self.assertEqual(''.join([x[0] for x in new]), '      ')
    def test_two_tab_handling(self):
        s = self.split('\t   \t\t')
        self.c.tokenizer.tabsize = 2
        sed = SeparatorSed(self.c, None)
        new = sed.handle_tabs(s)
        self.assertEqual(''.join([x[0] for x in new]), '\t\t \t\t')
    def test_three_tab_handling(self):
        s = self.split('\t   \t\t')
        self.c.tokenizer.tabsize = 3
        sed = SeparatorSed(self.c, None)
        new = sed.handle_tabs(s)
        self.assertEqual(''.join([x[0] for x in new]), '\t\t\t\t')
    def test_empty_lines(self):
        s = self.split('  \n  \n  |\t\n\t\t\n')
        self.c.tokenizer.ignore_empty_lines = True
        sed = SeparatorSed(self.c, None)
        new = sed.empty_empty_lines(s)
        self.assertEqual(''.join([x[0] for x in new]), '  \n\n  |\t\n\n')
    def test_detect_indentation(self):
        s1 = self.split('\n\t\n\t\t\n\t\n\n\t\t\t\n\t\t\t\n\t\t|  \n|\n\t\t')
        self.c.tokenizer.detect_indentation = True
        self.c.tokenizer.ignore_empty_lines = True
        sed = SeparatorSed(self.c, None)
        new1 = sed.track_indent(s1)
        new1 = ['i' if x=='_indent_' else 'd' if x=='_dedent_' else x for x in [y[0] for y in new1]]
        self.assertEqual(''.join(new1), '\ni\ni\nd\n\ni\n\n|  \ndd|\ni')
    def test_indentation_dont_ignore_empty_lines(self):
        s1, s2 = self.split('\n\t\n\t\t\n\t\n\n'), \
                 self.split('\n  \n\t\t\n\t\n\t\t|  \n|\n\t\t')
        self.c.tokenizer.detect_indentation = True
        self.c.tokenizer.ignore_empty_lines = False
        sed = SeparatorSed(self.c, None)
        new1 = sed.track_indent(s1)
        new2 = sed.track_indent(s2)
        new1 = ['i' if x=='_indent_' else 'd' if x=='_dedent_' else x for x in [y[0] for y in new1]]
        new2 = ['i' if x=='_indent_' else 'd' if x=='_dedent_' else x for x in [y[0] for y in new2]]
        self.assertEqual(''.join(new1), '\ni\ni\nd\nd\n')
        self.assertEqual(''.join(new2), '\n  \ni\n\n|  \nd|\ni')
    def test_collapse(self):
        s = self.split('  \t\t\t || \t|\n\n \n ')
        self.c.tokenizer.collapse_whitespace = True
        sed = SeparatorSed(self.c, None)
        new = sed.collapse(s)
        self.assertEqual(''.join([x[0] for x in new]), ' \t || \t|\n\n \n ')
    def test_discard_all(self):
        s = self.split('\t i | \n d')
        self.c.tokenizer.discard_whitespace = True
        sed = SeparatorSed(self.c, None)
        new = sed.discard(s)
        self.assertEqual(''.join([x[0] for x in new]), '_indent__dedent_')
    def test_discard_extraneous(self):
        s = self.split('\t i | \n d')
        self.c.tokenizer.discard_whitespace = False
        sed = SeparatorSed(self.c, None)
        new = sed.discard(s)
        self.assertEqual(''.join([x[0] for x in new]), '\t _indent_  \n _dedent_')


from src.tokenizer import tokenize
class TestTokenizer(unittest.TestCase):
    def setUp(self):
        self.root = path.join(os.getcwd(), 'test/test_tokenizer')
    def test_line_continues(self):
        p = path.join(self.root, 'line_continue')
        tree, context = tokenize(p)
        self.assertEqual(4, len(tree))
        self.assertEqual(tree[0].text, '(* <_V\n(* recursive comment *)\n*)')
        self.assertEqual(tree[0].location.start.to_tuple(), (4,0))
        self.assertEqual(tree[0].location.end.to_tuple(), (6,2))
        self.assertEqual(tree[1].text, 'line-continue')
        self.assertEqual(tree[1].location.start.to_tuple(), (8,0))
        self.assertEqual(tree[1].location.end.to_tuple(), (11,9))
        self.assertEqual(tree[2].text, 'split')
        self.assertEqual(tree[2].location.start.to_tuple(), (13,0))
        self.assertEqual(tree[2].location.end.to_tuple(), (13,5))
        self.assertEqual(tree[3].text, '(*token*)')
        self.assertEqual(tree[3].location.start.to_tuple(), (14,0))
        self.assertEqual(tree[3].location.end.to_tuple(), (14,9))
    def test_lml_like(self):
        p = path.join(self.root, 'lml')
        tree, context = tokenize(p)
        self.assertEqual(tree[0].text, 'a')
        self.assertEqual(tree[0].location.start.to_tuple(), (7,0))
        self.assertEqual(tree[0].location.end.to_tuple(), (7,1))
        self.assertEqual(tree[1].text, ' ')
        self.assertEqual(tree[1].location.start.to_tuple(), (7,1))
        self.assertEqual(tree[1].location.end.to_tuple(), (7,2))
        self.assertEqual(tree[2].text, 't')
        self.assertEqual(tree[2].location.start.to_tuple(), (7,2))
        self.assertEqual(tree[2].location.end.to_tuple(), (7,3))
        self.assertEqual(tree[6].text, '[^')
        self.assertEqual(tree[6].location.start.to_tuple(), (7,6))
        self.assertEqual(tree[6].location.end.to_tuple(), (7,8))
        self.assertEqual(tree[14].text, '_linebreak_')
        self.assertEqual(tree[14].location.start.to_tuple(), (7,15))
        self.assertEqual(tree[14].location.end.to_tuple(), (8,0))
        self.assertEqual(tree[15].text, '_linebreak_')
        self.assertEqual(tree[15].location.start.to_tuple(), (8,0))
        self.assertEqual(tree[15].location.end.to_tuple(), (9,0))
        self.assertEqual(tree[16].text, 'n')
        self.assertEqual(tree[16].location.start.to_tuple(), (9,0))
        self.assertEqual(tree[16].location.end.to_tuple(), (9,1))
    def test_numbers_and_indents(self):
        p = path.join(self.root, 'indented_numbers')
        tree, context = tokenize(p)
        self.assertEqual(10, len(tree))
        self.assertEqual(tree[0].text, '24.8e+16')
        self.assertEqual(tree[0].location.start.to_tuple(), (7,0))
        self.assertEqual(tree[0].location.end.to_tuple(), (7,8))
        self.assertEqual(tree[1].text, '_indent_')
        self.assertEqual(tree[1].location.start.to_tuple(), (8,0))
        self.assertEqual(tree[1].location.end.to_tuple(), (8,2))
        self.assertEqual(tree[2].text, '133')
        self.assertEqual(tree[2].location.start.to_tuple(), (8,2))
        self.assertEqual(tree[2].location.end.to_tuple(), (8,5))
        self.assertEqual(tree[3].text, '+')
        self.assertEqual(tree[3].location.start.to_tuple(), (8,5))
        self.assertEqual(tree[3].location.end.to_tuple(), (8,6))
        self.assertEqual(tree[4].text, '4')
        self.assertEqual(tree[4].location.start.to_tuple(), (8,6))
        self.assertEqual(tree[4].location.end.to_tuple(), (8,7))
        self.assertEqual(tree[5].text, '7.1')
        self.assertEqual(tree[5].location.start.to_tuple(), (9,8))
        self.assertEqual(tree[5].location.end.to_tuple(), (9,11))
        self.assertEqual(tree[6].text, '3.14e-1')
        self.assertEqual(tree[6].location.start.to_tuple(), (10,1))
        self.assertEqual(tree[6].location.end.to_tuple(), (10,8))
        self.assertEqual(tree[7].text, '_dedent_')
        self.assertEqual(tree[7].location.start.to_tuple(), (11,0))
        self.assertEqual(tree[7].location.end.to_tuple(), (11,0))
        self.assertEqual(tree[8].text, '42')
        self.assertEqual(tree[8].location.start.to_tuple(), (11,0))
        self.assertEqual(tree[8].location.end.to_tuple(), (11,2))
        self.assertEqual(tree[9].text, '.1')
        self.assertEqual(tree[9].location.start.to_tuple(), (12,0))
        self.assertEqual(tree[9].location.end.to_tuple(), (12,2))
        
        