import unittest

from src.parsers.spring import *


class ParserTester(unittest.TestCase):
    def setUp(self):
        self.o = []
        self.p = SpringParser(self.o)
        self.r = SpringReader(self.p)
    def test_one_line(self):
        self.r.feed("_SEPARATOR _PHONEME\t_SPACE  _TAB _NEWLINE \n\r")
        self.r.eof()
        cmp = [x.text for x in self.o]
        self.assertEqual(cmp, ["_SEPARATOR", "_PHONEME", "_SPACE", "_TAB", "_NEWLINE", "_SPRING_STATEMENT_"])
    def test_many_lines(self):
        self.r.feed("""_OPWORD _OPWORD opword
                            _SPRING opword spring: _NEWLINE
                       _END_SECTION opword :;
                       """)
        self.r.eof()
        cmp = [x.text for x in self.o]
        self.assertEqual(cmp, ["_OPWORD", "_OPWORD", "opword", "_SPRING_STATEMENT_",
                               "_SPRING", "opword", "spring:", "_NEWLINE", "_SPRING_STATEMENT_",
                               "_END_SECTION", "opword", ":;", "_SPRING_STATEMENT_"])
    def test_continued_line(self):
        self.r.feed(r"""stream aaa \lc
                            \lc
                    bbb""")
        self.r.eof()
        cmp = [x.text for x in self.o]
        self.assertEqual(cmp, ['stream', 'aaa', 'bbb'])

from src.parsers.initial import InitialContext
class CompilerTester(unittest.TestCase):
    def setUp(self):
        self.c = SpringCompiler(InitialContext())
        self.flow = self.c.flow
        self.context = self.c.context
        self.p = SpringParser(self.c)
        self.r = SpringReader(self.p)
    def test_intransitives(self):
        self.r.feed("_CHARSTREAM_ 1\n")
        self.r.feed("_LINE_CONTINUE_ _space_ <_V\n")
        self.r.feed("_IGNORE_EMPTY_LINES_ 1\n")
        self.r.feed("_DETECT_INDENTATION_ 1\n")
        self.r.feed("_COLLAPSE_WHITESPACE_ 1\n")
        self.r.feed("_DISCARD_WHITESPACE_ 1\n")
        self.r.feed("_TABSIZE_ 2\n")
        self.r.feed("_KEYWORD_ mememe\n")
        self.r.feed("_STREAM_ aaa\n")
        self.r.feed("_USING_ bbb\n")
        self.r.eof()
        self.assertTrue(self.flow.tokenizer.charstream is True)
        self.assertEqual(self.flow.tokenizer.line_continue, ' <_V')
        self.assertTrue(self.flow.tokenizer.ignore_empty_lines is True)
        self.assertTrue(self.flow.tokenizer.detect_indentation is True)
        self.assertTrue(self.flow.tokenizer.collapse_whitespace is True)
        self.assertTrue(self.flow.tokenizer.discard_whitespace is True)
        self.assertEqual(self.flow.tokenizer.tabsize, 2)
        self.assertEqual({x.compile().pattern for x in self.flow.tokenizer.keywords}, {"mememe"})
        self.assertSetEqual({x.text for x in self.flow.modules.stream}, {'aaa'})
        self.assertSetEqual({x.text for x in self.flow.modules.using}, {'bbb'})
    def test_phoneme(self):
        self.r.feed("""1 _PHONEME_ a
                    2 _PHONEME_ c-e
                    3 _PHONEME_ A SDF
                    4 _PHONEME_ G-HJ
                    """)
        self.r.eof()
        a_stuff = self.flow.tokenizer.phonemes
        from stovokor.local import BaseAlphabet
        a = BaseAlphabet()
        for statement in a_stuff:
            a[None] = statement.phoneme
        self.assertEqual(set(map(lambda x: x.name, a['a'])), {'1'})
        self.assertEqual(set(map(lambda x: x.name, a['c'])), {'2'})
        self.assertEqual(set(map(lambda x: x.name, a['d'])), {'2'})
        self.assertEqual(set(map(lambda x: x.name, a['e'])), {'2'})
        self.assertEqual(set(map(lambda x: x.name, a['A'])), {'3'})
        self.assertEqual(set(map(lambda x: x.name, a['S'])), {'3'})
        self.assertEqual(set(map(lambda x: x.name, a['D'])), {'3'})
        self.assertEqual(set(map(lambda x: x.name, a['F'])), {'3'})
        self.assertEqual(set(map(lambda x: x.name, a['G'])), {'4'})
        self.assertEqual(set(map(lambda x: x.name, a['-'])), {'4'})
        self.assertEqual(set(map(lambda x: x.name, a['H'])), {'4'})
        self.assertEqual(set(map(lambda x: x.name, a['J'])), {'4'})
    def test_opword(self):
        self.r.feed("""_OPWORD_ _OPWORD_ opword
                    _PHONEME_ opword phoneme
                    1 phoneme a
                    """)
        self.r.eof()
        a_stuff, o = self.flow.tokenizer.phonemes, self.flow.opwords.new_opwords
        from stovokor.local import BaseAlphabet
        a = BaseAlphabet()
        for statement in a_stuff:
            a[None] = statement.phoneme
        self.assertEqual(set(map(lambda x: x.name, a['a'])), {'1'})
        self.assertEqual(o['_OPWORD_'].compile(), 'opword')
        self.assertEqual(o['_PHONEME_'].compile(), 'phoneme')
    def test_pattern(self):
        self.r.feed("""_PATTERN_ _OPWORD_ pattern
                    4 pattern 4th _space_ priority
                    """)
        self.r.eof()
        self.assertSetEqual({p.pattern for p in self.flow.tokenizer.patterns}, {"4th priority"})
        self.assertSetEqual({p.name for p in self.flow.tokenizer.patterns}, {"4"})
    def test_delimiter(self):
        self.r.feed(r"""test _DELIMITER_ " " \
                    """)
        self.r.eof()
        self.assertEqual(1, len(self.flow.tokenizer.delimiters))
        d = self.flow.tokenizer.delimiters.pop().compile()
        self.assertEqual(d.begin, '"')
        self.assertEqual(d.end, '"')
        self.assertEqual(d.not_end, '\\"')
    def test_end_section_before_code(self):
        self.r.feed("_OPWORD_ _OPWORD_ opword\n")
        self.r.feed("_SPRING_ opword spring:\n")
        self.r.feed("_END_SECTION_ opword :;\n")
        with self.assertRaises(EndSectionException) as e:
            self.r.feed(":;\n")
            self.r.feed("code")
        self.assertEqual(e.exception.location, 4)
    def test_end_section_before_eof(self):
        self.r.feed("_OPWORD_ _OPWORD_ opword\n")
        self.r.feed("_SPRING_ opword spring:\n")
        self.r.feed("_END_SECTION_ opword :;\n")
        with self.assertRaises(EndSectionException) as e:
            self.r.feed(":;\n")
            self.r.eof()
        self.assertEqual(e.exception.location, 4)
    def test_reassign_whitespace(self):
        self.r.feed("_space_ _OPWORD_ \\w\n")
        self.r.feed("_KEYWORD_ for \\w sooth\n")
        self.r.eof()
        self.assertEqual(self.context.opwords.whitespace['\\w'], '_space_')
        self.assertEqual(self.flow.opwords.new_opwords['_space_'].compile(), '\\w')

from src.modules.spring_detector import *
class TestSpringDetection(unittest.TestCase):
    def setUp(self):
        import os
        from os import path
        self.path = path.join(os.getcwd(), 'test', 'test_module/_petal_.lotus')
        self.fail = path.join(os.getcwd(), 'test', 'test_module/fail')
    def test_detect_success(self):
        file, loc = detect_spring(self.path, InitialContext())
        self.assertEqual(loc, 3)
        self.assertEqual('_OPWORD_ _OPWORD_ opword\n', file.readline())
        self.assertEqual('\n', file.readline())
        file.close()
    def test_detect_fail(self):
        file, loc = detect_spring(self.fail+'A', InitialContext())
        self.assertFalse(file)
        file, loc = detect_spring(self.fail+'B', InitialContext())
        self.assertFalse(file)
    def test_init_parser(self):
        context = InitialContext()
        file, loc = detect_spring(self.path, context)
        parser, flow = get_spring_parser(context, self.path, loc)
        file.close()
        self.assertEqual(parser.output.output.context.opwords.spring_detect['_SPRING_'], '_SPRING_')
        self.assertEqual(parser.file, self.path)
        self.assertEqual(parser.lineno, 3)
        self.assertEqual(parser.column, 0)
    def test_total_parse(self):
        flow, last_loc = handle_spring(self.path, InitialContext())
        self.assertEqual(last_loc, 14)
        self.assertEqual(flow.opwords.new_opwords['_SPRING_'].compile(), 'spring:')
        self.assertEqual(flow.opwords.new_opwords['_OPWORD_'].compile(), 'opword')
        self.assertEqual(flow.opwords.new_opwords['_END_SECTION_'].compile(), ':;')
        self.assertEqual(flow.opwords.new_opwords['_space_'].compile(), r'\s')
        self.assertEqual(flow.opwords.new_opwords['_tab_'].compile(), r'\t')
        self.assertEqual(flow.opwords.new_opwords['_linebreak_'].compile(), r'\n')
        self.assertEqual(flow.opwords.new_opwords['_TABSIZE_'].compile(), 'tab:')