import unittest
from src.parsers.spring_subparsers import *
from src.parsers.spring import *
from waterworks.context import *
from src.parsers.initial import InitialContext

class Token:
    class Point:
        def __init__(self, arg1, arg2):
            self.line = arg1
            self.column = arg2
    class Loc:
        def __init__(self, arg1, arg2):
            self.start = Token.Point(arg1[0], arg1[1])
            self.end = Token.Point(arg2[0], arg2[1])
    def __init__(self, arg1, arg2=None):
        self.text = arg1
        if arg2 is not None:
            self.location = Token.Loc(*arg2)
        else:
            self.location = Token.Loc((0,0),(0,0))

class TestOpwordStatement(unittest.TestCase):
    def setUp(self):
        self.supercompiler = SpringCompiler(InitialContext())
        self.flow = self.supercompiler.flow
        self.context = self.supercompiler.context
    def test_one_token(self):
        c = OpwordStatement(self.supercompiler.context, Token('_PHONEME_'), Token('_OPWORD_'))
        c.append(Token('phoneme'))
        c.insert_into(self.flow)
        c.insert_into(self.context)
        self.assertEqual(1, len(self.flow.opwords.new_opwords))
        self.assertEqual(self.flow.opwords.new_opwords['_PHONEME_'].compile(), 'phoneme')
        self.assertEqual(self.context.opwords.spring["phoneme"], '_PHONEME_')
    def test_two_tokens(self):
        c = OpwordStatement(self.supercompiler.context, Token('_PHONEME_'), Token('_OPWORD_'))
        c.append(Token('phon'))
        c.append(Token('eme'))
        c.insert_into(self.flow)
        c.insert_into(self.context)
        self.assertEqual(1, len(self.flow.opwords.new_opwords))
        self.assertEqual(self.flow.opwords.new_opwords['_PHONEME_'].compile(), 'phoneme')
        self.assertEqual(self.context.opwords.spring["phoneme"], '_PHONEME_')
    def test_special_tokens(self):
        c = OpwordStatement(self.supercompiler.context, Token('_SPRING_'), Token('_OPWORD_'))
        c.append(Token('spring:'))
        c.append(Token('_linebreak_'))
        c.insert_into(self.flow)
        c.insert_into(self.context)
        self.assertEqual(1, len(self.flow.opwords.new_opwords))
        self.assertEqual(self.flow.opwords.new_opwords['_SPRING_'].compile(), 'spring:\n')
        self.assertEqual(self.context.opwords.spring_detect["spring:\n"], '_SPRING_')
    def test_exceptions(self):
        pass #TESTME

class TestIntransitiveCompilers(unittest.TestCase):
    def setUp(self):
        self.supercompiler = SpringCompiler(Context())
        self.context = self.supercompiler.flow
    def test_charstream(self):
        c = CharStreamStatement(self.supercompiler.context, Token('_CHARSTREAM_'), Token('0'))
        c.insert_into(self.context)
        self.assertTrue(self.context.tokenizer.charstream is False)
        c = CharStreamStatement(self.supercompiler.context, Token('_CHARSTREAM_'), Token('1'))
        c.insert_into(self.context)
        self.assertTrue(self.context.tokenizer.charstream is True)
    def test_tabsize(self):
        c = TabSizeStatement(self.supercompiler.context, Token('_TABSIZE_'), Token('33'))
        c.insert_into(self.context)
        self.assertEqual(33, self.context.tokenizer.tabsize)
        c = TabSizeStatement(self.supercompiler.context, Token('_TABSIZE_'), Token('2'))
        c.insert_into(self.context)
        self.assertEqual(2, self.context.tokenizer.tabsize)
    def test_stream(self):
        c = ImportExportStatement(self.supercompiler.context, Token('_STREAM_'), Token('file/path'))
        c.append(Token('file'))
        c.append(Token('file/path'))
        c.insert_into(self.context)
        self.assertListEqual(['file', 'file/path'], [x.text for x in self.context.modules.stream])
        self.assertListEqual([], self.context.modules.using)
    def test_using(self):
        c = ImportStatement(self.supercompiler.context, Token('_USING_'), Token('file/path'))
        c.append(Token('file'))
        c.append(Token('file/path'))
        c.insert_into(self.context)
        self.assertListEqual(['file', 'file/path'], [x.text for x in self.context.modules.using])
        self.assertListEqual([], self.context.modules.stream)
    def test_exceptions(self):
        with self.assertRaises(LotusCompilerError):
            TabSizeStatement(self.supercompiler.context, Token('_TABSIZE_'), Token('33')).append('3')
        with self.assertRaises(LotusCompilerError):
            TabSizeStatement(self.supercompiler.context, Token('_TABSIZE_'), Token('ab')).secure()

class TestPhonemeStatement(unittest.TestCase):
    def setUp(self):
        self.supercompiler = SpringCompiler(InitialContext())
        self.context = self.supercompiler.flow
    def test_single(self):
        a_stuff = self.context.tokenizer.phonemes
        c = PhonemeStatement(self.supercompiler.context, Token('1'), Token("_PHONEME_"))
        c.append(Token('a'))
        c.insert_into(self.context)
        c = PhonemeStatement(self.supercompiler.context, Token('2'), Token("_PHONEME_"))
        c.append(Token("c-e"))
        c.insert_into(self.context)
        c = PhonemeStatement(self.supercompiler.context, Token('3'), Token("_PHONEME_"))
        c.append(Token('A'))
        c.append(Token('SDF'))
        c.insert_into(self.context)
        c = PhonemeStatement(self.supercompiler.context, Token('4'), Token("_PHONEME_"))
        c.append(Token('G-HJ'))
        c.insert_into(self.context)
        from stovokor.local import BaseAlphabet
        a = BaseAlphabet()
        for statement in a_stuff:
            a[None] = statement.phoneme
        self.assertEqual(set(map(lambda x: x.name, a['a'])), {'1'})
        self.assertEqual(set(map(lambda x: x.name, a['c'])), {'2'})
        self.assertEqual(set(map(lambda x: x.name, a['d'])), {'2'})
        self.assertEqual(set(map(lambda x: x.name, a['e'])), {'2'})
        self.assertEqual(set(map(lambda x: x.name, a['A'])), {'3'})
        self.assertEqual(set(map(lambda x: x.name, a['S'])), {'3'})
        self.assertEqual(set(map(lambda x: x.name, a['D'])), {'3'})
        self.assertEqual(set(map(lambda x: x.name, a['F'])), {'3'})
        self.assertEqual(set(map(lambda x: x.name, a['G'])), {'4'})
        self.assertEqual(set(map(lambda x: x.name, a['-'])), {'4'})
        self.assertEqual(set(map(lambda x: x.name, a['H'])), {'4'})
        self.assertEqual(set(map(lambda x: x.name, a['J'])), {'4'})
    def test_keywords(self):
        a_stuff = self.context.tokenizer.phonemes
        c = PhonemeStatement(self.supercompiler.context, Token('1'), Token("_PHONEME_"))
        c.append(Token("_space_"))
        c.insert_into(self.context)
        c = PhonemeStatement(self.supercompiler.context, Token('2'), Token("_PHONEME_"))
        c.append(Token("_tab_"))
        c.insert_into(self.context)
        c = PhonemeStatement(self.supercompiler.context, Token('3'), Token("_PHONEME_"))
        c.append(Token('_linebreak_'))
        c.insert_into(self.context)
        from stovokor.local import BaseAlphabet
        a = BaseAlphabet()
        for statement in a_stuff:
            a[None] = statement.phoneme
        self.assertEqual(set(map(lambda x: x.name, a[' '])), {'1'})
        self.assertEqual(set(map(lambda x: x.name, a['\t'])), {'2'})
        self.assertEqual(set(map(lambda x: x.name, a['\n'])), {'3'})
    def test_multiple(self):
        a_stuff = self.context.tokenizer.phonemes
        c = PhonemeStatement(self.supercompiler.context, Token('a'), Token("_PHONEME_"))
        c.append(Token('a'))
        c.append(Token('A-Z'))
        c.append(Token('_space_'))
        c.insert_into(self.context)
        from stovokor.local import BaseAlphabet
        a = BaseAlphabet()
        for statement in a_stuff:
            a[None] = statement.phoneme
        for char in 'aQWERTYUIOPASDFGHJKLZXCVBNM ':
            self.assertEqual({'a'}, set(map(lambda x: x.name, a[char])))
        for char in 'qwertyuiopsdfghjklzxcvbnm\t':
            self.assertFalse('a' in set(map(lambda x: x.name, a[char])))
    def test_unicode(self):
        a = self.context.tokenizer.phonemes
        c = PhonemeStatement(self.supercompiler.context, Token('u'), Token("_PHONEME_"))
        c.append(Token(r'\u255;-\u256;'))
        c.append(Token(r'\u56;'))
        c.insert_into(self.context)
        self.assertEqual(a[0].phoneme.name, 'u')
        self.assertTrue(chr(0x255) in a[0].phoneme)
        self.assertTrue('V' in a[0].phoneme)
        self.assertTrue(chr(0x256) in a[0].phoneme)

from stovokor.quantum import Keyword
class TestKeywordStatement(unittest.TestCase):
    def setUp(self):
        self.supercompiler = SpringCompiler(InitialContext())
        self.context = self.supercompiler.flow
    def test_one_token(self):
        o = self.context.tokenizer.keywords
        c = KeywordStatement(self.supercompiler.context, Token('_KEYWORD_'), Token('for'))
        c.insert_into(self.context)
        self.assertListEqual([x.compile() for x in o], [Keyword('for')])
    def test_multiple_tokens(self):
        context = Context()
        o = self.context.tokenizer.keywords
        c = KeywordStatement(self.supercompiler.context, Token('_KEYWORD_'), Token('for'))
        c.append(Token('tuna'))
        c.insert_into(self.context)
        self.assertListEqual([x.compile() for x in o], [Keyword('fortuna')])
    def test_special_tokens(self):
        o = self.context.tokenizer.keywords
        c = KeywordStatement(self.supercompiler.context, Token('_KEYWORD_'), Token(';'))
        c.append(Token('_linebreak_'))
        c.insert_into(self.context)
        self.assertListEqual([x.compile() for x in o], [Keyword(';\n')])

class TestPatternStatement(unittest.TestCase):
    def setUp(self):
        self.supercompiler = SpringCompiler(InitialContext())
        self.context = self.supercompiler.flow
        self.p = self.context.tokenizer.patterns
    def test_simple(self):
        c = PatternStatement(self.supercompiler.context, Token('0'), Token('_PATTERN_'))
        c.append(Token('[^a-z]'))
        c.insert_into(self.context)
        self.assertSetEqual({p.pattern for p in self.p}, {'[^a-z]'})
    def test_multi_part(self):
        c = PatternStatement(self.supercompiler.context, Token('0'), Token('_PATTERN_'))
        c.append(Token('[^a-z]'))
        c.append(Token('[a-z]'))
        c.insert_into(self.context)
        self.assertSetEqual({p.pattern for p in self.p}, {'[^a-z][a-z]'})
    def test_specials(self):
        c = PatternStatement(self.supercompiler.context, Token('0'), Token('_PATTERN_'))
        c.append(Token('_space_'))
        c.append(Token('='))
        c.append(Token('_space_'))
        c.insert_into(self.context)
        self.assertSetEqual({p.pattern for p in self.p}, {' = '})
    def test_overwrite(self):
        c = PatternStatement(self.supercompiler.context, Token('0'), Token('_PATTERN_'))
        c.append(Token('1'))
        c.insert_into(self.context)
        self.assertSetEqual({p.pattern for p in self.p}, {'1'})
        c = PatternStatement(self.supercompiler.context, Token('0'), Token('_PATTERN_'))
        c.append(Token('2'))
        c.insert_into(self.context)
        self.assertSetEqual({p.pattern for p in self.p}, {'2'})

from stovokor.quantum import Delimiter
class TestDelimiterStatement(unittest.TestCase):
    def setUp(self):
        self.supercompiler = SpringCompiler(InitialContext())
        self.context = self.supercompiler.flow
    def test_one(self):
        c = DelimiterStatement(self.supercompiler.context, Token('one'), Token('_DELIMITER_'))
        for item in ['"', '"']:
            c.append(Token(item))
        c.insert_into(self.context)
        self.assertEqual(1, len(self.context.tokenizer.delimiters))
        d = list(self.context.tokenizer.delimiters)[0].compile()
        self.assertEqual(d.name, 'one')
        self.assertEqual(d.begin, '"')
        self.assertEqual(d.end, '"')
        self.assertFalse(d.not_end)
        self.assertFalse(d.weave)
        self.assertFalse(d.unweave)
        self.assertFalse(d.recursive)
    def test_two(self):
        c = DelimiterStatement(self.supercompiler.context, Token('two'), Token('_DELIMITER_'))
        for item in ['"', '"', '\\']:
            c.append(Token(item))
        c.insert_into(self.context)
        self.assertEqual(1, len(self.context.tokenizer.delimiters))
        d = list(self.context.tokenizer.delimiters)[0].compile()
        self.assertEqual(d.name, 'two')
        self.assertEqual(d.begin, '"')
        self.assertEqual(d.end, '"')
        self.assertEqual(d.not_end, '\\"')
        self.assertFalse(d.weave)
        self.assertFalse(d.unweave)
        self.assertFalse(d.recursive)
    def test_three(self):
        c = DelimiterStatement(self.supercompiler.context, Token('three'), Token('_DELIMITER_'))
        for item in ['"', '"', '\\', '\\{', '}']:
            c.append(Token(item))
        c.insert_into(self.context)
        self.assertEqual(1, len(self.context.tokenizer.delimiters))
        d = list(self.context.tokenizer.delimiters)[0].compile()
        self.assertEqual(d.name, 'three')
        self.assertEqual(d.begin, '"')
        self.assertEqual(d.end, '"')
        self.assertEqual(d.not_end, '\\"')
        self.assertEqual(d.weave, '\\{')
        self.assertEqual(d.unweave, '}')
        self.assertFalse(d.recursive)
    def test_kwargs(self):
        c = DelimiterStatement(self.supercompiler.context, Token('three'), Token('_DELIMITER_'))
        for item in ['_DELIMITER_BEGIN_', '"',
                     '_DELIMITER_END_', '"',
                     '_DELIMITER_ESCAPE_', '\\',
                     '_DELIMITER_WEAVE_', '\\{',
                     '_DELIMITER_UNWEAVE_', '}']:
            c.append(Token(item))
        c.insert_into(self.context)
        self.assertEqual(1, len(self.context.tokenizer.delimiters))
        d = list(self.context.tokenizer.delimiters)[0].compile()
        self.assertEqual(d.name, 'three')
        self.assertEqual(d.begin, '"')
        self.assertEqual(d.end, '"')
        self.assertEqual(d.not_end, '\\"')
        self.assertEqual(d.weave, '\\{')
        self.assertEqual(d.unweave, '}')
        self.assertFalse(d.recursive)
    def test_recursion(self):
        c = DelimiterStatement(self.supercompiler.context, Token('ml-com'), Token('_DELIMITER_'))
        for item in ['(*', '*)', '_RECURSIVE_DELIMITER_']:
            c.append(Token(item))
        c.insert_into(self.context)
        self.assertEqual(1, len(self.context.tokenizer.delimiters))
        d = list(self.context.tokenizer.delimiters)[0].compile()
        self.assertEqual(d.name, 'ml-com')
        self.assertEqual(d.begin, '(*')
        self.assertEqual(d.end, '*)')
        self.assertFalse(d.not_end)
        self.assertFalse(d.weave)
        self.assertFalse(d.unweave)
        self.assertTrue(d.recursive)
    def test_multi_part_arg(self):
        c = DelimiterStatement(self.supercompiler.context, Token('multiarg'), Token('_DELIMITER_'))
        for item in ['"', '_DELIMITER_END_', '"', '_space_', '"']:
            c.append(Token(item))
        c.insert_into(self.context)
        self.assertEqual(1, len(self.context.tokenizer.delimiters))
        d = list(self.context.tokenizer.delimiters)[0].compile()
        self.assertEqual(d.name, 'multiarg')
        self.assertEqual(d.begin, '"')
        self.assertEqual(d.end, '" "')
        self.assertFalse(d.not_end)
        self.assertFalse(d.weave)
        self.assertFalse(d.unweave)
        self.assertFalse(d.recursive)


