import unittest
from src.seds.opword import OpwordSed
from stovokor.matcher import Driver
from stovokor.sed import AnnotatingReader
from src.parsers.initial import InitialContext
from stovokor.quantum import Keyword
from waterworks.flow import Flow

class Dummy:
    def __init__(self, data):
        self.compile = lambda: data
class T:
    def __init__(self, text, matcher_type):
        self.text = text
        self.matcher = M(matcher_type)
class M:
    def __init__(self, type):
        self.type = type

class TestOpwordSed(unittest.TestCase):
    def setUp(self):
        flow = Flow()
        flow.tokenizer.add_keyword(Dummy(Keyword('for')))
        flow.opwords['_ESSIVE_'] = Dummy('as')
        flow.opwords['_END_PRAGMA_HEADER_'] = Dummy(':')
        context = InitialContext()
        context.layer(flow)
        context.finalize()
        self.o = []
        self.d = Driver(context.tokenizer.alphabet,
                    context.tokenizer.keywords,
                    context.tokenizer.patterns,
                    context.tokenizer.delimiters)
        self.sed = OpwordSed(context, self.o)
        self.r = AnnotatingReader(self.d, None)
        self.sed.link_input(self.r)
    def test_nothing(self):
        self.assertIn(Keyword('for'), self.r.matcher.keyword_matcher.source)
        self.assertIn(Keyword('_C_PRAGMA_'), self.r.matcher.keyword_matcher.source)
        self.assertNotIn(Keyword(':'), self.r.matcher.keyword_matcher.source)
        self.sed.append(T('nope', 'alphabet'))
        self.sed.append(T('for', 'keyword'))
        self.sed.append(T('as', 'keyword'))
        self.assertEqual(self.sed.mode, 'normal')
        self.assertEqual(3, len(self.o))
        self.assertEqual(self.o[0].text, 'nope')
        self.assertEqual(self.o[0].matcher.type, 'alphabet')
        self.assertEqual(self.o[1].text, 'for')
        self.assertEqual(self.o[1].matcher.type, 'keyword')
        self.assertEqual(self.o[2].text, 'as')
        self.assertEqual(self.o[2].matcher.type, 'keyword')
    def test_mode_switch(self):
        self.sed.append(T('_C_PRAGMA_', 'keyword'))
        self.assertEqual(1, len(self.o))
        self.assertEqual(self.o[0].text, '_C_PRAGMA_')
        self.assertEqual(self.o[0].matcher.type, 'opword')
        self.assertEqual(self.sed.mode, 'header')
        self.assertEqual(self.sed.next_mode, 'cpragma')
        self.assertIn(Keyword('as'), self.r.matcher.keyword_matcher.source)
        self.assertIn(Keyword(':'), self.r.matcher.keyword_matcher.source)
        self.sed.append(T('as', 'keyword'))
        self.assertEqual(2, len(self.o))
        self.assertEqual(self.o[1].text, '_ESSIVE_')
        self.assertEqual(self.o[1].matcher.type, 'opword')
        self.sed.append(T(':', 'keyword'))
        self.assertEqual(3, len(self.o))
        self.assertEqual(self.o[2].text, '_END_PRAGMA_HEADER_')
        self.assertEqual(self.o[2].matcher.type, 'opword')
        self.assertEqual(self.sed.mode, 'cpragma')
    #def test_cpragma_mode(self):
    #    pass #TESTME
        