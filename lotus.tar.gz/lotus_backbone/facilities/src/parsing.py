from .reserved import *

def section_opwords():
    return {
        spring_section: None,
        section_end: None
    }

def spring_opwords():
    return {
        public_import: None,
        private_import: None,
        tabsize: None,
        phoneme: None,
        keyword: None,
        opword: None,
        pattern: None,
        delimiter: None
    }

from .predef import *

def whitespace_opwords():
    return {
        whitespace: None,
        indent: None,
        dedent: None,
        linebreak: None
    }