def unicode_escapes(input):
    import re
    match = re.search(r'\\u([\dA-Fa-f]+);', input)
    while match:
        replace = match.groups()[0]
        input = re.sub(r'\\u{0};'.format(replace), chr(int(replace, 16)), input)
        match = re.search(r'\\u([\dA-Fa-f]+);', input)
    #TODO now that replacements have been made, merge equivalent sequences
    #really, equivalent sequences should be easily expandable, but not really by the user
    #that way, parsing remains fairly constant
    return input