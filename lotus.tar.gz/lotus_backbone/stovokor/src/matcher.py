class Driver:
    def __init__(self, alphabet, set_of_keywords, set_of_patterns, set_of_delimiters):
        self.alphabet = alphabet
        self.keywords = set_of_keywords
        self.patterns = set_of_patterns
        self.delimiters = set_of_delimiters

from .submatcher import *
from .token import *

class Matcher:
    def __init__(self, driver):
        self.alphabet_matcher = AlphabetMatcher(driver.alphabet)
        self.keyword_matcher = ImmediateKeywordMatcher(driver.keywords)
        self.pattern_matcher = ImmediatePatternMatcher(driver.patterns)
        self.delimiter_matcher = DelimiterMatcher(driver.delimiters)
        self.reset()
    
    def could_be(self, input):
        delims = self.delimiter_matcher.could_be(input)
        if not delims and self.delimiter_matcher.active:
            return delims
        phones = self.alphabet_matcher.could_be(input)
        kws = self.keyword_matcher.could_be(input)
        pats = self.pattern_matcher.could_be(input)
        return phones + kws + pats + delims
    
    def match(self, input):
        delim = self.delimiter_matcher.match(input)
        if delim != (0, None):
            return delim[0], MatchedByDelimiter(delim[1])
        phone = self.alphabet_matcher.match(input)
        kw = self.keyword_matcher.match(input)
        pat = self.pattern_matcher.match(input)
        max_len = max(map(lambda x: x[0], [phone, kw, pat]))
        if kw[0] == max_len:
            return kw[0], MatchedByKeyword(kw[1])
        if pat[0] == max_len:
            return pat[0], MatchedByPattern(pat[1])
        if phone[0] == max_len:
            return phone[0], MatchedByAlphabet(phone[1])
    
    def eof(self, input):
        self.alphabet_matcher.eof()
        self.keyword_matcher.eof()
        self.pattern_matcher.eof()
        self.delimiter_matcher.eof(input)
    
    def reset(self):
        self.alphabet_matcher.reset()
        self.keyword_matcher.reset()
        self.pattern_matcher.reset()
        self.delimiter_matcher.reset()




