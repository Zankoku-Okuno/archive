class Token:
    def __init__(self, text, matched_by, location):
        self.text = text
        self.matcher = matched_by
        self.location = location

class Location:
    def __init__(self, file, start, end):
        self.file = file
        self.start = _LocPoint(*start)
        self.end = _LocPoint(*end)
class _LocPoint:
    def __init__(self, line, column):
        self.line = line
        self.column = column
    
    def __str__(self):
        return "({0}, {1})".format(self.line, self.column)
    def to_tuple(self):
        return self.line, self.column

class _MatchedBy:
    def __init__(self, matcher):
        self.matcher = matcher
    def __eq__(self, other):
        return self.matcher == other.matcher
    def __hash__(self):
        return hash(self.matcher)

class MatchedByAlphabet(_MatchedBy):
    type = 'alphabet'
    def __hash__(self):
        out = 0
        for phoneme in self.matcher:
            out += hash(phoneme)
        return hash(out)

class MatchedByKeyword(_MatchedBy):
    type = 'keyword'
class MatchedByPattern(_MatchedBy):
    type = 'pattern'
class MatchedByDelimiter(_MatchedBy):
    type = 'delimiter'
