"""A number of matchers devoted to matching particular sorts of tokens.

These sub-matchers, like the main matcher itself, must be fed characters
one-at-a-time, calling the could_be() method with progressively longer input
strings."""

from functools import reduce

class AlphabetMatcher:
    def __init__(self, alphabet):
        self.alphabet = alphabet
        self.compatible = self.alphabet.compatible
        self.reset()
    
    def could_be(self, input):
        """Returns the number of distinct tokens that this matcher could
        possibly detect at the start of the input string. Tokens that have
        already been detected are not included in this number."""
        if len(input) != 1 + self.max_length:
            return 0
        elif len(input) == 1 or self.compatible(input[-2], input[-1]):
            self.max_length += 1
            return 1
        else:
            return 0
    
    def eof(self):
        """Notifies the matcher that the end of the input has arrived. If there
        is a possible match, then it must be _the_ match."""
        pass
    
    def match(self, input):
        """Returns the length of the token which this matcher has detected and
        the phonemes involved in the match.
        
        Should not be called until either could_be() returns 0 on the same input
        string, or the end of input has been reached."""
        phonemes = reduce(lambda x,y: x|self.alphabet[y], input[:self.max_length], set())
        return (self.max_length, phonemes)
    
    def reset(self):
        """Reinitializes this matcher so that it may look for matches in a
        different location. Must be called after a token has matched in the
        input stream (regardles of whether the match was from this matcher)."""
        self.max_length = 0


from .base_matcher import *
class KeywordMatcher(IncompatibilityMatcher):
    def __init__(self, keywords, alphabet):
        super().__init__(ImmediateKeywordMatcher(keywords), alphabet)

class ImmediateKeywordMatcher(BaseMatcher):    
    def get_all(self):
        return self.source
    def get_none(self):
        return None
    
    def could_be(self, input):
        candidates = {kw for kw in self.possible if kw.match(input)}
        if candidates:
            self.best_yet = candidates.pop()
        self.possible = {kw for kw in self.possible if kw.could_be(input)}
        return len(self.possible)
    
    def result(self, input):
        return len(self.best_yet.pattern), self.best_yet


class PatternMatcher(IncompatibilityMatcher):
    def __init__(self, patterns, alphabet):
        super().__init__(ImmediatePatternMatcher(patterns), alphabet)

class ImmediatePatternMatcher(BaseMatcher): #TODO
    #what should be done about ambiguity here? since we may have agents of the
    #same length with differing backreferences. I suppose we can take the one
    #with the most backreferences, but what if, say, two agents differ only in
    #the fact that one of the backreference names is different (but the
    #contained data is the same and all othe rbackreferences and lengths are the
    #same)
    #MAYBE I should raise an error when the ambiguity cannot be solved
    
    #choose the 'simplest' regex: the one with the fewest states, likely
    #alternatively, choose the most 'specific': w/ the most states
    #or, finally, give each pattern a priority
    #if there's still a tie, choose the agent with the most b/rs
    def __init__(self, patterns):
        super().__init__({pat.graph: pat for pat in patterns})
    
    def get_all(self):
        return {machine.fork(): self.source[machine] for machine in self.source}
    def get_none(self):
        return set()
    
    def could_be(self, input):
        candidates = set()
        for engine in self.possible:
            engine.step(input[-1])
            candidates |= { (agent, self.possible[engine])
                            for agent in engine.terminal() }
        if candidates:
            self.best_yet = candidates
        self.possible = {x: self.possible[x] for x in self.possible if x.potential()}
        return len(self.possible)
    
    def result(self, input):
        #TODO figure out how to resolve ambiguity. I might prefer returning all
        #agent/pattern pairs, then letting the client fight it out, since the
        #client might have something to say about which it prefers
        if len(self.best_yet) != 1:
            specificity = min(map(lambda x: x[1].generality(), self.best_yet))
            self.best_yet = {x for x in self.best_yet if x[1].generality()==specificity}
            if len(self.best_yet) != 1:
                raise Exception() #TODO figure out the definitional order
        agent, pattern = self.best_yet.pop()
        return (agent.bounds.end, pattern)
    
    def reset(self):
        super().reset()
        for automaton in self.possible:
            automaton.flush()
            automaton.spawn()


class DelimiterMatcher:
    def __init__(self, delimiters):
        self._delimiters = delimiters
        self.reset()
    
    def could_be(self, input):
        """Returns the number of distinct tokens that this matcher could
        possibly detect at the start of the input string. Tokens that have
        already been detected are not included in this number."""
        candidates = {d for d in self.possible if d.match(input)}
        if candidates:
            self.active = {x: (1, 0, 0, False) for x in candidates}
            self.lookaheads = {x: input[len(x.begin):] for x in candidates}
        self.possible = {d for d in self.possible if d.could_be(input)}
        removes = set()
        for delim in self.active:
            state, lookahead = self.active[delim], self.lookaheads[delim]
            if not candidates:
                lookahead += input[-1]
            state, lookahead = delim.count( *(state+(lookahead,)) )
            self.active[delim], self.lookaheads[delim] = state, lookahead
            if state[0] == 0:
                self.best_possible = (len(input)-len(lookahead), delim) #HAX I need to ensure elsewhere that delimiters never have the same start&end char sequences
                removes.add(delim)
        for delim in removes:
            self.active.pop(delim)
            self.lookaheads.pop(delim)
        return len(self.possible) + len(self.active)
    
    def eof(self, input):
        """Notifies the matcher that the end of the input has arived. If there
        is a possible match, then it must be _the_ match."""
        self.possible = set()
        for delim in self.active:
            state, lookahead = self.active[delim], self.lookaheads[delim]
            state, lookahead = delim.count( *(state+(lookahead,True)) )
            if state[0] == 0:
                length = len(input)-len(lookahead)
                if length > self.best_possible[0]:
                    self.best_possible = (length, delim)
        self.active = set()
    
    def match(self, input):
        """Returns a pair. The first element is the length of the token which
        this matcher has detected. The second is the delimiter that made the
        match. If no match has been detected, returns (0, None).
        
        Should not be called until either could_be() returns 0 on the same input
        string, or the end of input has been reached."""
        return self.best_possible
    
    def reset(self):
        """Reinitializes this matcher so that it may look for matches in a
        different location. Must be called after a token has matched in the
        input stream (regardles of whether the match was from this matcher)."""
        self.possible = self._delimiters
        self.active = dict()
        self.lookaheads = dict()
        self.best_possible = (0, None)

def _num(possible, best_possible):
    return len(possible) + (1 if best_possible is not None else 0)




