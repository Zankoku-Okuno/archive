from .matcher import *

class Reader:
    def __init__(self, driver, output):
        self.matcher = Matcher(driver)
        self.token_lookahead_buffer = ''
        self.output = output
    
    def feed(self, input):
        if len(input) != 1:
            for char in input:
                self.feed(char)
        else:
            self.buffer(input)
            if not self.matcher.could_be(self.token_lookahead_buffer):
                self.flush()
    
    def buffer(self, char):
        self.last_char_read = char
        self.token_lookahead_buffer += char
    
    def flush(self):
        token_length, token_matcher = self.matcher.match(self.token_lookahead_buffer)
        token_string = self.token_lookahead_buffer[:token_length]
        self.token_lookahead_buffer = self.token_lookahead_buffer[token_length:]
        self.output.append(self.create_token(token_string, token_matcher))
        self.matcher.reset()
        self.refeed()
    
    def refeed(self):
        leftovers = self.token_lookahead_buffer
        self.token_lookahead_buffer = ''
        self.feed(leftovers)
    
    def create_token(self, token_string, token_matcher):
        return token_string
    
    def eof(self):
        while self.token_lookahead_buffer:
            self.matcher.eof(self.token_lookahead_buffer)
            self.flush()
        if hasattr(self.output, 'eof'):
            self.output.eof()

#REFAC keeping track of location into a mixin for the challenge
class AnnotatingReader(Reader):
    def __init__(self, driver, output):
        super().__init__(driver, output)
        self.file = None
        self.column = 0
        self.lineno = 0
        self.invisible = []
    
    def create_token(self, token_string, token_matcher):
        from .token import Token, Location
        #TODO here, if there's an invisible bit between tokens, we should discard it completely
        if self.invisible and (self.lineno, self.column) == self.invisible[0][0]:
            self.lineno, self.column = add_locs((self.lineno, self.column), self.invisible[0][1])
            self.invisible = self.invisible[1:]
        start_loc = (self.lineno, self.column)
        self._update_location(token_string)
        end_loc = (self.lineno, self.column)
        return Token(token_string, token_matcher,
                    Location(self.file, start_loc, end_loc))
    
    def feed_invisible(self, string):
        insert = add_locs((self.lineno, self.column),
                          count_location(self.token_lookahead_buffer))
        if self.invisible and self.invisible[-1][0] == insert:
            self.invisible[-1] = (self.invisible[-1][0],
                                  add_locs(self.invisible[-1][1], count_location(string)))
        else:
            self.invisible.append( (insert, count_location(string)) )
    
    def _update_location(self, token_string):
        if self.invisible:
            self._update_invisible(token_string)
        else:
            self.lineno, self.column = add_locs((self.lineno, self.column),
                                                count_location(token_string))
    def _update_invisible(self, token_string):
        predict = add_locs((self.lineno, self.column),
                           count_location(token_string))
        if predict[0] < self.invisible[0][0][0] or (
           predict[0] == self.invisible[0][0][0] and predict[1] < self.invisible[0][0][1]):
            self.lineno, self.column = predict
            return #TESTME this optimization: from the top of the method
        while token_string and self.invisible:
            insert_line, insert_col = self.invisible[0][0]
            if self.lineno == insert_line and self.column == insert_col:
                self.lineno, self.column = add_locs((self.lineno, self.column),
                                                    self.invisible[0][1])
                self.invisible = self.invisible[1:]
            else:
                self.lineno, self.column = add_locs((self.lineno, self.column),
                                                    count_location(token_string[0]))
                token_string = token_string[1:]
        self.lineno, self.column = add_locs((self.lineno, self.column),
                                            count_location(token_string))

def count_location(string):
    lines, columns = 0, 0
    for char in string:
        if char == '\n': #WARNING, the assumption is that all linebreaks have been processed down already
            lines, columns = lines+1, 0
        else:
            columns += 1
    return lines, columns

def add_locs(loc1, loc2):
    if loc2[0]:
        return (loc1[0]+loc2[0], loc2[1])
    return (loc1[0], loc1[1]+loc2[1])
