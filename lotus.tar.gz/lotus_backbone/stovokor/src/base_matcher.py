"""The idea behind a matcher is to eliminate the impossible, leaving behind the
goal, no matter how improbable. To do this, input is fed in, one character at a
time. slowly, the matcher winnows these down while holding onto the longest
(read: best) possibilities, occasionally replacing them with newer, better options.

Thus, the workflow is to call could_be with progressively longer samples of
input until it returns zero (no further possibilities for expansion). If the
input runs out before possibilities reach zero, then call eof. At this point,
call match, which will return pertinent information (see below), and (after
storing the result of match), call reset if the matcher is to be used again.

The pertinitent information is a pair containing 1) the length of the best
possible match on the input from the start and 2) whatever drivers, be they
phonemes/keywords/whatever, actually performed the match. The second part is a
bit more lenient with regards data type, just as long as the semantics are
useful to the Lotus user."""

class BaseMatcher:
    """Provides an interface and some common functionality for all matchers.
    
    Specifically, it defines source, possible and best_yet. It furthermore
    provides some basic reset code and does a check+handles having no match.
    
    Other than defining could_be, eof, match like you would any other
    matcher, you must also provide get_all, get_none and result. If there is no
    special eof code, then it need not be provided."""
    def __init__(self, source):
        self.source = source
        self.reset()
    
    def get_all(self):
        """Helper that returns all of the (stateless) structures that might
        match on any possible input. Assume that the result will be modified."""
        raise NotImplementedError()
    def get_none(self):
        """Helper that returns a data structure representing no
        possibilities. Should evaluate as false."""
        raise NotImplementedError()
    
    def could_be(self, input): #REFAC rename
        """Returns the number of distinct tokens that this matcher could
        possibly detect at the start of the input string. Tokens that have
        already been detected are not included in this number."""
        raise NotImplementedError()
    
    def eof(self):
        """Notifies the matcher that the end of the input has arived. If there
        is a possible match, then it must be _the_ match."""
        pass
    
    def match(self, input): #REFAC rename
        """Returns a pair. The first element is the length of the token which
        this matcher has detected. The second is the specific user-structure
        that made the match. If no match has been detected, returns (0, None).
        
        Should not be called until either could_be() returns 0 on the same input
        string, or the end of input has been reached."""
        if not self.best_yet:
            return (0, None)
        else:
            return self.result(input)
    def result(self, input):
        """Helper that build a return value for the match() method from the
        currently stored result."""
        raise NotImplementedError()
    
    def reset(self):
        """Reinitializes this matcher so that it may look for matches in a
        different location. Must be called after a token has matched in the
        input stream (regardles of whether the match was from this matcher)."""
        self.best_yet = self.get_none()
        self.possible = self.get_all()

class IncompatibilityMatcher(BaseMatcher):
    """Provides a framework that helps ensure that matched items (as from
    keywords and patterns) are not parts of a larger token. That is, it checks
    to make sure that the potential token is not surrounded by compatible
    characters.
    
    Specifically, it does not check in front of the potential token (since that
    has already be tokenized). It simply receives results from an immediate
    matcher, then keeps them on hold for one more character of input. If the
    next input character is not compatible, then the immediate match was
    accurate and remembered in best_yet like any other matcher, but is thrown
    away otherwise.
    
    To use, simply inherit from this class, then create a new constructor. It
    should call its superconstructor along with a 'submatcher' which actually
    looks for the matches themselves. An alphabet must also be supplied to check
    for compatibility."""
    def __init__(self, delegate, alphabet):
        self.delegate = delegate
        self.compatible = alphabet.compatible
        self.old_candidate, self.candidate, self.best_yet = None, None, None
        self.result = self.delegate.result
    
    def could_be(self, input):
        num = self.delegate.could_be(input)
        if self.candidate:
            if not self.compatible(input[-2], input[-1]):
                self.best_yet = self.candidate
            self.old_candidate, self.candidate = self.candidate, None
        if self.delegate.best_yet != self.old_candidate:
            self.candidate = self.delegate.best_yet
        return num + (1 if self.candidate else 0)
    
    def eof(self):
        if self.candidate:
            self.best_yet = self.candidate
    
    def reset(self):
        self.delegate.reset()
        self.old_candidate, self.candidate, self.best_yet = None, None, None




