"""Provides utilities that help define and detect nonlocal structures.

Nonlocal structures are: keywords, regex patterns and delimited sublanguages.
They are nonlocal because relations between characters in distant parts of the
string can influence whether the structure is valid. E.g. the string "1.34.0e4"
is not a valid number because it contains two periods in the base. Note that the
two periods do not neighbor each other, so a local structure does not suffice to
discriminate between the above invalid string and the valid "1.340e4.".

In case you don't know much about how python relates quantum mechanics, quantum
mechanics (the proper stuff) is a nonlocal theory. In python, 'nonlocal' is a
reserved word, so I can't name my module 'nonlocal'. Thus: quantum (i.e.
nonlocal) structures vs. local structures. (aside: you know, Scala allows
backticks around a name to un-keywordize it; and C# allows the @-prefix)

"""

from functools import reduce

def _partial(standard, input):
    return len(input) < len(standard) and \
           input == standard[:len(input)]
def _full(standard, input):
    return len(standard) <= len(input) and \
           standard == input[:len(standard)]

class Keyword:
    def __init__(self, string):
        self.pattern = string
        self.name = string
    
    def could_be(self, input):
        """Returns whether the input might eventually begin with this keyword's
        pattern."""
        return _partial(self.pattern, input)
    
    def match(self, input):
        """Returns whether the input begins with this keyword's pattern."""
        return _full(self.pattern, input)
    
    def __eq__(self, other):
        return isinstance(other, Keyword) and self.pattern == other.pattern
    def __hash__(self):
        return hash(self.pattern)

class Pattern:
    def __init__(self, name, regex):
        from genregex.textex import textex
        self.graph = textex.compile(regex)
        self.pattern = regex
        self.name = name
    
    def could_be(self, input):
        """Returns whether the input might eventually begin with this keyword's
        pattern."""
        pass #STUB
    
    def generality(self):
        #FIXME for now, I'm assuming that longer patterns are more specific, not
        #a good assumption
        return len(self.pattern)
    
    def match(self, input):
        """Returns whether the input begins with this keyword's pattern."""
        pass #STUB
    
    def __eq__(self, other):
        return isinstance(other, Pattern) and self.name == other.name
    def __hash__(self):
        return hash(self.name)

class Delimiter:
    def __init__(self, name, begin, end, escape='', weave='', unweave='', recursive=False): #MAYBE expand this interface with overrides for not_X and not_not_X
        if weave and not unweave:
            raise ValueError("Must specify unweave symbol whenever weave symbol is specified.")
        if recursive:
            if begin == end:
                raise ValueError("Recursive delimiters cannot have identical begin and end symbols.")
            if weave and begin == weave:
                raise ValueError("Recursive delimiters cannot have identical begin and weave symbols.")
        if weave and weave == end:
            raise ValueError("The symbol to start weaving cannot be identical to the symbol to end the delimiter.")
        if unweave and begin == unweave:
            raise ValueError("The symbol to start the delimiter cannot be identical to the symbol to end weaving.")
        
        self.name = name
        self.recursive = recursive
        
        self.begin = begin
        self.end = end
        self.weave = weave
        self.unweave = unweave
        
        if escape:
            self.not_end = escape + end[0]
            self.not_escape = escape + escape[0]
            self.not_weave = escape + weave[0] if weave else None
            self.not_unweave = escape + unweave[0] if unweave else None
        else:
            self.not_end, self.not_escape, self.not_weave, self.not_unweave = None, None, None, None
        
        self._summary = [self.begin, self.end, self.not_end, self.not_escape,
                         self.weave, self.not_weave, self.unweave, self.not_unweave]
        self._summary = [x for x in self._summary if x]
        
    def could_be(self, input):
        """Returns whether the input might eventually begin with the start
        sequence for this delimiter."""
        return _partial(self.begin, input)
    def match(self, input):
        """Returns whether the input begins with the start sequence for this
        delimiter."""
        return _full(self.begin, input)
    
    def count(self, starts, weaves, depth, is_weaving, lookahead, eof=False):
        """Returns a pair (state, remainder). The remainder is the string that
        could not or should not be counted. The state is the quadruple (starts,
        weaves, depth, is_weaving), just as input into the function, but
        modified according to the lookahead.
        
        If eof is set to True, then counting continues even when there could be
        (on further input, which obviously does not exist) a better counting
        match.
        
        If starts ever reduces to zero, counting stops immediately. The
        lookahead should not contain the characters which initiated the
        delimiter match. Doing so may cause problems if begin is aliased.
        Between these two factors, it should be clear that, when beginning to
        count a delimited string, always set starts to one to take proper
        account of the first begin char sequence.
        """
        while starts and self._can_decide(lookahead, eof):
            decision = self._decide(lookahead)
            if not is_weaving:
                if self.recursive and decision == self.begin:
                    starts += 1
                    depth += 1
                elif decision == self.end:
                    starts -= 1
                    if depth: depth -=1
                    else: is_weaving = True
                elif decision == self.weave:
                    weaves += 1
                    is_weaving = True
            else:
                if decision == self.begin:
                    starts += 1
                    is_weaving = False
                elif decision == self.unweave:
                    weaves -= 1
                    is_weaving = False
            lookahead = lookahead[len(decision):]
        return (starts, weaves, depth, is_weaving), lookahead
    
    def __eq__(self, other): #WARNING
        return (isinstance(other, Delimiter) and
                self.name == other.name #and
                #self.begin == other.begin and
                #self.end == other.end and
                #self.weave == other.weave and
                #self.unweave == other.unweave and
                #self.not_end == other.not_end and
                #self.not_weave == other.not_weave and
                #self.not_unweave == other.not_unweave #and
                #self.not_escape == other.not_escape
               )
    def __hash__(self): #WARNING
        return hash(self.name)
        out = 0
        for item in self._summary:
            out += hash(item)
        return hash(out)
    
    def _can_decide(self, input, eof=False):
        if not input:
            return False
        if eof:
            return True
        for i in self._summary:
            if _partial(i, input):
                return False
        else:
            return True
    def _decide(self, input):
        possible = {x for x in self._summary if _full(x, input)}
        if not possible:
            return input[0]
        out = max(possible, key=lambda x: len(x))
        return out if out else input[0]




