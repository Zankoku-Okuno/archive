from src.local import FriendlyAlphabet, RichAlphabet

class Alphabet(RichAlphabet, FriendlyAlphabet):
    def __init__(self):
        super().__init__()
        self[Alphabet.separator] = ' \t\n\r'