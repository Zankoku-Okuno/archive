import unittest

from src.quantum import Delimiter

class TestDelimiter(unittest.TestCase):
    def setUp(self):
        self.d = Delimiter('str', '"""', '"""', '\\', '\\{', '}')
        self.r = Delimiter('str', '(*', '*)', None, None, None, True) #TESTME
    def test_init(self):
        self.assertEqual(self.d.not_end, '\\"')
        self.assertEqual(self.d.not_weave, '\\\\')
        self.assertEqual(self.d.not_unweave, '\\}')
    def test_could_be_match(self):
        self.assertTrue(self.d.could_be('"'))
        self.assertTrue(self.d.could_be('""'))
        self.assertFalse(self.d.could_be('"""'))
        self.assertTrue(self.d.match('"""'))
    def test_can_decide(self):
        self.assertFalse(self.d._can_decide(''))
        self.assertTrue(self.d._can_decide('abc""'))
        self.assertFalse(self.d._can_decide('"'))
        self.assertFalse(self.d._can_decide('""'))
        self.assertTrue(self.d._can_decide('""a'))
        self.assertTrue(self.d._can_decide('"""'))
        self.assertFalse(self.d._can_decide('\\'))
        self.assertTrue(self.d._can_decide('\\\\'))
        self.assertTrue(self.d._can_decide('\\"'))
        self.assertTrue(self.d._can_decide('\\{'))
    def test_decide(self):
        self.assertEqual('"', self.d._decide('""a'))
        self.assertEqual('a', self.d._decide('abc""'))
        self.assertEqual('"""', self.d._decide('"""'))
        self.assertEqual('\\\\', self.d._decide('\\\\'))
        self.assertEqual('\\{', self.d._decide('\\{'))
        self.assertEqual('\\"', self.d._decide('\\"'))
    def test_counting(self):
        self.assertEqual(((0,0,0,True),''), self.d.count(1,0,0,False,r'hello, world!"""'))
        self.assertEqual(((0,0,0,True),''), self.d.count(1,0,0,False,r'hello, world!\""""'))
        self.assertEqual(((1,0,0,False),''), self.d.count(1,0,0,False,r'hello'))
        self.assertEqual(((1,0,0,False),'""'), self.d.count(1,0,0,False,r'hello\"""'))
        self.assertEqual(((1,1,0,True),''), self.d.count(1,0,0,False,r'hello, \{name'))
        self.assertEqual(((1,0,0,False),''), self.d.count(1,0,0,False,r'hello, \{name}'))
        self.assertEqual(((0,0,0,True),''), self.d.count(1,0,0,False,r'hello, \{name}"""'))
        self.assertEqual(((2,1,0,False),''), self.d.count(1,0,0,False,r'hello, \{name"""'))
        self.assertEqual(((0,0,0,True),''), self.d.count(1,0,0,False,r'hello, \{name + """!"""\{}"""'))
        self.assertEqual(((2,0,1,False),'*'), self.r.count(1,0,0,False,r'comment(*recursion*'))
        self.assertEqual(((0,0,0,True),''), self.r.count(1,0,0,False,r'comment(*recursion*)*)'))
    def test_eof(self):
        d = Delimiter('name', '"', '"', '\\', '"""', '"""')
        self.assertEqual(((0,0,0,True),'"'), d.count(1,0,0,False,r'omg, contrived""', True))

from src.submatcher import DelimiterMatcher
class TestDelimMatcher(unittest.TestCase):
    def setUp(self):
        self.d1 =  Delimiter('str', '"', '"', '\\', '\\{', '}')
        self.d2 =  Delimiter('ml-str', '"""', '"""', '\\', '\\{', '}')
        self.d3 = Delimiter('cont', '?a', '?')
        self.d4 = Delimiter('rive', '?a', 'a')
        self.m = DelimiterMatcher({self.d1, self.d2, self.d3, self.d4})
    def test_no_match(self):
        self.assertEqual(0, self.m.could_be('h'))
    def test_one_match(self):
        self.assertEqual(2, self.m.could_be('"'))
        self.assertEqual(1, self.m.could_be('"h'))
        self.assertTrue(self.m.active)
        self.assertEqual({self.d1}, set(self.m.active.keys()))
        self.assertEqual(0, self.m.could_be('"h"'))
        self.assertEqual((3,self.d1), self.m.match('"h"'))
    def test_eof(self):
        self.assertEqual(2, self.m.could_be('?'))
        self.assertEqual(2, self.m.could_be('?a'))
        self.m.could_be('?a?')
        #self.assertEqual(1, self.m.could_be('?a?')) #TESTME really, getting this test passing means building a weaving-contextual can_decide: sugar
        self.m.eof('?a?')
        self.assertEqual((3, self.d3), self.m.match('?a?'))
    def test_triple(self):
        self.assertEqual(2, self.m.could_be('"'))
        self.assertEqual(1, self.m.could_be('""'))
        self.assertEqual((2, self.d1), self.m.best_possible)
        self.assertEqual(1, self.m.could_be('"""'))
        self.assertTrue(self.m.active)
        self.assertSetEqual({self.d2}, set(self.m.active.keys()))
        for i in range(3, len('"""hello"world""')):
            self.assertEqual(1, self.m.could_be('"""hello"world""'[:i+1]))
        self.assertEqual(0, self.m.could_be('"""hello"world"""'))
        self.assertEqual((len('"""hello"world"""'),self.d2), self.m.match('"""hello"world"""'))
    def test_weaving(self):
        input = '"Hello, \{name if name is not None else "world"}!"'
        for i in range(len(input)-1):
            self.assertTrue(0 < self.m.could_be(input[:i]))
        self.assertTrue(self.m.active)
        self.assertSetEqual({self.d1}, set(self.m.active.keys()))
        self.assertEqual(0, self.m.could_be(input))
        self.assertEqual((len(input), self.d1), self.m.match(input))
    def test_not_not_end(self):
        input = '"\\\\"'
        self.assertEqual(2, self.m.could_be(input[:1]))
        self.assertEqual(1, self.m.could_be(input[:2]))
        self.assertEqual(1, self.m.could_be(input[:3]))
        self.assertEqual(0, self.m.could_be(input[:4]))
        self.assertEqual((4,self.d1), self.m.match(input))
        
        
    