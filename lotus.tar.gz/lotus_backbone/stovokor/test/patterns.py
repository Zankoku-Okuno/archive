import unittest

from .rich_friend import Alphabet
from src.quantum import Pattern

from src.submatcher import PatternMatcher

class TestPatternmatcher(unittest.TestCase):
    def setUp(self):
        self.p1 = Pattern('integer', '[0-9]+')
        self.p2 = Pattern('rational', '[0-9]+(.[0-9]*)?')
        self.p3 = Pattern('test method', 'test_[a-z][a-z0-9]*')
        self.m = PatternMatcher({self.p1, self.p2, self.p3}, Alphabet())
    def test_none(self):
        self.assertEqual(0, self.m.could_be('A'))
        self.assertEqual((0,None), self.m.match('A'))
        self.m.reset()
        self.assertEqual(1, self.m.could_be('t'))
        self.assertEqual(0, self.m.could_be('to'))
        self.assertEqual((0,None), self.m.match('to'))
    def test_test_pattern(self):
        for i in range(1, len('test_')+1):
            self.assertEqual(1, self.m.could_be('test_'[:i]))
        self.assertEqual(2, self.m.could_be('test_m'))
        self.assertEqual(2, self.m.could_be('test_me'))
        self.assertEqual(0, self.m.could_be('test_me\n'))
        self.assertEqual((7, self.p3), self.m.match('test_me\n'))
        self.m.reset()
        for i in range(1, len('test_')+1):
            self.assertEqual(1, self.m.could_be('test_'[:i]))
        self.assertEqual(2, self.m.could_be('test_m'))
        self.assertEqual(2, self.m.could_be('test_me'))
        self.assertEqual(2, self.m.could_be('test_me1'))
        self.assertEqual(0, self.m.could_be('test_me1\n'))
        self.assertEqual((8, self.p3), self.m.match('test_me1\n'))
    def test_no_test_pattern(self):
        for i in range(1, len('test_')+1):
            self.assertEqual(1, self.m.could_be('test_'[:i]))
        self.assertEqual(2, self.m.could_be('test_m'))
        self.assertEqual(2, self.m.could_be('test_me'))
        self.assertEqual(0, self.m.could_be('test_meA'))
        self.assertEqual((0, None), self.m.match('test_meA'))
    def test_integer(self):
        for i in range(1, len('123')+1):
            self.assertEqual(3, self.m.could_be('123'[:i]))
        self.assertEqual(0, self.m.could_be('123 '))
        self.assertEqual((3, self.p1), self.m.match('123 '))
        self.m.reset()
        for i in range(1, len('123')+1):
            self.assertEqual(3, self.m.could_be('123'[:i]))
        self.m.eof()
        self.assertEqual((3, self.p1), self.m.match('123'))
    def test_rational(self):
        for i in range(1, len('123')+1):
            self.assertEqual(3, self.m.could_be('123'[:i]))
        for i in range(len('123')+1, len('123.456')+1):
            self.assertEqual(2, self.m.could_be('123.456'[:i]))
        self.m.eof()
        self.assertEqual((7, self.p2), self.m.match('123.456'))