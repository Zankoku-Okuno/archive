import unittest

from .rich_friend import Alphabet
from src.quantum import Keyword

class TestKeyword(unittest.TestCase):
    def setUp(self):
        self.kw = Keyword('for')
    def test_could_be(self):
        self.assertTrue(self.kw.could_be('f'))
        self.assertTrue(self.kw.could_be('fo'))
        self.assertFalse(self.kw.could_be('for'))
        self.assertFalse(self.kw.could_be('fort'))
        self.assertFalse(self.kw.could_be('forth'))
        self.assertFalse(self.kw.could_be('for '))
    def test_match(self):
        self.assertFalse(self.kw.match('f'))
        self.assertFalse(self.kw.match('fo'))
        self.assertTrue(self.kw.match('for'))
        self.assertTrue(self.kw.match('fort'))
        self.assertTrue(self.kw.match('forth'))
        self.assertTrue(self.kw.match('for '))

from src.submatcher import KeywordMatcher

class TestKWMatcher(unittest.TestCase):
    def setUp(self):
        self.k1 = Keyword('for')
        self.k2 = Keyword('forth')
        self.m = KeywordMatcher({self.k1, self.k2}, Alphabet())
    def test_none(self):
        self.assertEqual(0, self.m.could_be('a'))
        self.assertEqual((0,None), self.m.match('a'))
        self.m.reset()
        self.assertEqual(2, self.m.could_be('f'))
        self.assertEqual(0, self.m.could_be('fr'))
        self.assertEqual((0,None), self.m.match('fr'))
    def test_too_connected(self):
        self.assertEqual(2, self.m.could_be('f'))
        self.assertEqual(2, self.m.could_be('fo'))
        self.assertEqual(2, self.m.could_be('for'))
        self.assertEqual(0, self.m.could_be('form'))
        self.assertEqual((0,None), self.m.match('form'))
    def test_for(self):
        self.assertEqual(2, self.m.could_be('f'))
        self.assertEqual(2, self.m.could_be('fo'))
        self.assertEqual(2, self.m.could_be('for'))
        self.assertEqual(0, self.m.could_be('for '))
        self.assertEqual((3,self.k1), self.m.match('for '))
    def test_forth(self):
        self.assertEqual(2, self.m.could_be('f'))
        self.assertEqual(2, self.m.could_be('fo'))
        self.assertEqual(2, self.m.could_be('for'))
        self.assertEqual(1, self.m.could_be('fort'))
        self.assertEqual(1, self.m.could_be('forth'))
        self.assertEqual(0, self.m.could_be('forth '))
        self.assertEqual((5,self.k2), self.m.match('forth '))
    def test_eof(self):
        self.assertEqual(2, self.m.could_be('f'))
        self.assertEqual(2, self.m.could_be('fo'))
        self.assertEqual(2, self.m.could_be('for'))
        self.m.eof()
        self.assertEqual((3,self.k1), self.m.match('for'))
        self.m.reset()
        self.assertEqual(2, self.m.could_be('f'))
        self.assertEqual(2, self.m.could_be('fo'))
        self.assertEqual(2, self.m.could_be('for'))
        self.assertEqual(1, self.m.could_be('fort'))
        self.assertEqual(1, self.m.could_be('forth'))
        self.m.eof()
        self.assertEqual((5,self.k2), self.m.match('forth'))
    
    
    
    
    