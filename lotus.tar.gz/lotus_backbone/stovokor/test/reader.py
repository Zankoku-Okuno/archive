import unittest

from src.local import *
from src.quantum import *
from src.matcher import *
from src.sed import *

from .rich_friend import Alphabet

tab_length = 3 #TODO make customizable REFAC into the library proper
class WhitespaceParsingSed:
    def __init__(self, output):
        self.output = output
    def append(self, token):
        for char in token:
            if char not in ' \t\n\r':
                is_whitespace = False
                break
        else:
            is_whitespace = True
        if is_whitespace:
            import re
            if tab_length:
                token = re.sub(' '*tab_length, '\t', token)
            token = re.sub('\r\n', '\n', token)
            token = re.sub('\r', '\n', token)
            token = re.sub(' ', '', token)
            for char in token:
                self.output.append(char)
        else:
            self.output.append(token)

class TestAlphabetReading(unittest.TestCase):
    def setUp(self):
        a = Alphabet()
        p = Phoneme('noname')
        p.add_range("a", "z")
        p.add_range("0", "9")
        p.add("_")
        a['alphanumeric'] = p
        a['numeric'] = "0123456789"
        a['symbol'] = "~@#$%&%*|+=-/:<>"
        a['punctuation'] = ".,;!?"
        a[Alphabet.loner] = "()[]{}"
        d = Driver(a, set(), set(), set())
        self.o = []
        self.sed = Reader(d, WhitespaceParsingSed(self.o))
    def test_one(self):
        self.sed.feed("2+2=4")
        self.sed.eof()
        self.assertEqual(['2','+','2','=','4'], self.o)
    def test_two(self):
        cmp = "ghlasfnk2653kjsfbk295"
        self.sed.feed(cmp)
        self.sed.eof()
        self.assertEqual([cmp], self.o)
    def test_three(self):
        self.sed.feed("2*((3+5)+4)")
        self.sed.eof()
        self.assertEqual([c for c in "2*((3+5)+4)"], self.o)
    def test_whitespace(self):
        self.sed.feed("   \t \n\r\n\r")
        self.sed.eof()
        self.assertEqual([c for c in "\t\t\n\n\n"], self.o)
    def test_four(self):
        cmp = "ghlasfnk2 653 kjsfbk29 5"
        self.sed.feed(cmp)
        self.sed.eof()
        self.assertEqual(['ghlasfnk2', '653', 'kjsfbk29', '5'], self.o)
    def test_five(self):
        self.sed.feed('obj.method(5+2, !alpha);\nstring~=regex')
        self.sed.eof()
        self.assertEqual(['obj','.','method','(','5','+','2',',','!','alpha',')',';',
                          '\n', 'string', '~=', 'regex'], self.o)
    def test_six(self):
        self.sed.feed('A(B)CD')
        self.sed.eof()
        self.assertEqual(['A', '(', 'B', ')', 'CD'], self.o)

class TestKeywordReading(unittest.TestCase):
    def setUp(self):
        a = Alphabet()
        p = Phoneme('noname')
        p.add_range("a", "z")
        p.add_range("A", "Z")
        p.add("_")
        a['alphanumeric'] = p
        a['numeric'] = "0123456789"
        a['symbol'] = "~@#$%&%*|+=-/:<>"
        a['punctuation'] = ".,;!?"
        a['_LONERS_PHONEME'] = "()[]{}"
        d = Driver(a, {Keyword('for'), Keyword('from'), Keyword('for1thing'), Keyword('to')}, set(), set())
        self.o = []
        self.sed = Reader(d, WhitespaceParsingSed(self.o))
    def test_basics(self):
        self.sed.feed("for from1")
        self.sed.eof()
        self.assertEqual(["for", "from", "1"], self.o)
    def test_end(self):
        self.sed.feed("for1")
        self.sed.eof()
        self.assertEqual(['for', '1'], self.o)
    def test_combo(self):
        self.sed.feed("for i from1to10\n\tgo forth;\n")
        self.assertEqual(['for', 'i', 'from', '1', 'to', '10', '\n', '\t', 'go', 'forth', ';'], self.o)
    def test_kw_at_end(self):
        self.sed.feed('10 for')
        self.sed.eof()
        self.assertEqual(['10', 'for'], self.o)

class AnnotationSplittingSed:
    def __init__(self, a, b, c):
        self.text = a
        self.name = b
        self.loc = c
    
    def append(self, item):
        self.text.append(item[0])
        self.name.append(item[1])
        self.loc.append(item[2])
class WhitespaceSplitableSed:
    def __init__(self, output):
        self.output = output
    def append(self, input):
        token = input[0]
        if is_whitespace(token):
            line, col = input[2]
            while token:
                if token[0] == '\n':
                    self.output.append((token[0], '\n', (line,col)))
                    line += 1
                    col = 1
                if token[0] == '\t':
                    self.output.append((token[0], '\t', (line,col)))
                    col += 1
                if token[0] == ' ':
                    col += 1
                token = token[1:]
        else:
            self.output.append(input)

class TestDelimiterReading(unittest.TestCase):
    def setUp(self):
        a = Alphabet()
        p = Phoneme('noname')
        p.add_range("a", "z")
        p.add_range("A", "Z")
        p.add("_")
        a['alphanumeric'] = p
        a['numeric'] = "0123456789"
        a['symbol'] = "~@#$%&%*|+=-/:<>"
        a['punctuation'] = ".,;!?"
        a['_LONERS_PHONEME'] = "()[]{}"
        d = Driver(a,
                   {Keyword('for'), Keyword('from'), Keyword('to')},
                   set(),
                   {Delimiter('str','"','"','\\','\\{','}'),
                      Delimiter('literal','`','`'),
                      Delimiter('ml-str','"""','"""','\\'),
                      Delimiter('r-str','r"','"','\\')})
        self.o = []
        self.sed = Reader(d, WhitespaceParsingSed(self.o))
    def test_one(self):
        self.sed.feed('print "Hello, world!"')
        self.sed.eof()
        self.assertEqual(['print', '"Hello, world!"'], self.o)
    def test_two(self):
        self.sed.feed(r'print "Hello, \{name if !(name == null) else "world"}!"')
        self.sed.eof()
        self.assertEqual(['print', r'"Hello, \{name if !(name == null) else "world"}!"'], self.o)
    def test_three(self):
        self.sed.feed(r'name if !(name == null) else "world"')
        self.sed.eof()
        self.assertEqual(['name', 'if', '!', '(', 'name', '==', 'null', ')', 'else', '"world"'], self.o)

class TestPatternReading(unittest.TestCase):
    def setUp(self):
        a = Alphabet()
        p = Phoneme('noname')
        p.add_range("a", "z")
        p.add_range("A", "Z")
        a['alphanumeric'] = p
        a['numeric'] = "0123456789"
        a['symbol'] = "~@#$%&%*|+=-/:<>_"
        a['punctuation'] = ".,;!?"
        a['_LONERS_PHONEME'] = "()[]{}"
        d = Driver(a,
                   {Keyword('for'), Keyword('from'), Keyword('to')},
                   {Pattern('tester method', 'test_[a-z][a-z0-9]*'), Pattern('integer', '0x[0-9A-F]+|[0-9]+'), Pattern('rational', '[0-9]+.[0-9]+(e(\+|-)?[0-9]+)?')},
                   {Delimiter('str','"','"','\\','\\{','}'),
                      Delimiter('literal','`','`'),
                      Delimiter('ml-str','"""','"""','\\'),
                      Delimiter('r-str','r"','"','\\')})
        self.o = []
        self.sed = Reader(d, WhitespaceParsingSed(self.o))
    def test_one(self):
        self.sed.feed(r'1+2=3')
        self.sed.eof()
        self.assertEqual(self.o, ['1', '+', '2', '=', '3'])
    def test_two_a(self):
        self.sed.feed(r'donttest_me')
        self.sed.eof()
        self.assertEqual(self.o, ['donttest', '_', 'me'])
    def test_two_b(self):
        self.sed.feed(r'test_me')
        self.sed.eof()
        self.assertEqual(self.o, ['test_me'])
    def test_three(self):
        self.sed.feed(r'"Pi: " + str(3.14159e+9)')
        self.sed.eof()
        self.assertEqual(self.o, ['"Pi: "', '+', 'str', '(', '3.14159e+9', ')'])
    def test_four_a(self):
        self.sed.feed(r'3.14 e 1.41')
        self.sed.eof()
        self.assertEqual(self.o, ['3.14', 'e', '1.41'])
    def test_four_b(self):
        self.sed.feed(r'3.14e1.41')
        self.sed.eof()
        self.assertEqual(self.o, ['3.14e1', '.', '41'])
    def test_five(self):
        self.sed.feed(r'for30times: print "Hellow!"')
        self.sed.eof()
        self.assertEqual(self.o, ['for', '30', 'times', ':', 'print', '"Hellow!"'])




