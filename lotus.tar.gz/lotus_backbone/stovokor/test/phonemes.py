import unittest

from Lotus import predef
from src.local import *

class Alphabet(RichAlphabet, FriendlyAlphabet): pass

class TestPhoneme(unittest.TestCase):
    def setUp(self):
        self.p1, self.p2 = Phoneme('1', "hello"), Phoneme('2', "world")
    def test_add(self):
        p = Phoneme('p')
        p.add('\0')
        self.assertEqual(0, len(p._chars))
        p.add('a')
        self.assertEqual(1, len(p._chars))
        p.add(ord('a'))
        self.assertEqual(1, len(p._chars))
        p.add('A')
        self.assertEqual(2, len(p._chars))
    def test_in(self):
        for char in "lo":
            self.assertIn(char, self.p1)
            self.assertIn(char, self.p2)
        for char in "he":
            self.assertIn(char, self.p1)
            self.assertNotIn(char, self.p2)
        for char in "wrd":
            self.assertIn(char, self.p2)
            self.assertNotIn(char, self.p1)
    def test_add_range(self):
        self.p1.add_range("A", "Z")
        self.assertIn("G", self.p1)
        self.assertNotIn("g", self.p1)
    def test_add_all(self):
        self.p2.add_all("hello")
        for char in "helloworld":
            self.assertIn(char, self.p2)

class TestBasicAlphabets(unittest.TestCase):
    def test_get(self):
        a = BaseAlphabet()
        a._phonemes = {Phoneme('h', "hello"), Phoneme('w', "world")}
        self.assertSetEqual({a.default_phoneme}, a[' '])
        self.assertSetEqual({'h'}, set(map(lambda x: x.name, a['e'])))
        self.assertSetEqual({'h', 'w'}, set(map(lambda x: x.name, a[ord('o')])))
        self.assertSetEqual({a.default_phoneme}, a['z'])
        with self.assertRaises(ValueError): a['']
        with self.assertRaises(ValueError): a['az']
        with self.assertRaises(ValueError): a[a]
    def test_set(self):
        a = BaseAlphabet()
        a['h'] = Phoneme('h', "hello")
        a['w'] = 'world'
        self.assertSetEqual({a.default_phoneme}, a[' '])
        self.assertSetEqual({'h'}, set(map(lambda x: x.name, a['e'])))
        self.assertSetEqual({'h', 'w'}, set(map(lambda x: x.name, a['o'])))
        self.assertSetEqual({a.default_phoneme}, a['z'])
    def test_compatibility(self):
        with self.assertRaises(NotImplementedError):
            BaseAlphabet().compatible('a', 'b')
    def test_wrappers(self):
        p = Phoneme('p', "hello")
        a = BaseAlphabet()
        a._phonemes = {p}
        for char in [chr(i) for i in range(ord('a'), ord('z')+1)]:
            if char in "hello": self.assertTrue(char in p)
            else: self.assertFalse(char in p)
            if char in "hello": self.assertEqual({'p'}, set(map(lambda x: x.name, a[char])))
            else: self.assertEqual({a.default_phoneme}, a[char])
        a.add('p', 'z')
        for char in [chr(i) for i in range(ord('a'), ord('z')+1)]:
            if char in "helloz": self.assertTrue(char in p)
            else: self.assertFalse(char in p)
            if char in "helloz": self.assertEqual({'p'}, set(map(lambda x: x.name, a[char])))
            else: self.assertEqual({a.default_phoneme}, a[char])
        a.add_all('p', 'sna')
        for char in [chr(i) for i in range(ord('a'), ord('z')+1)]:
            if char in "hellozans": self.assertTrue(char in p)
            else: self.assertFalse(char in p)
            if char in "hellozans": self.assertEqual({'p'}, set(map(lambda x: x.name, a[char])))
            else: self.assertEqual({a.default_phoneme}, a[char])
        a.add_range('p', 'a', 'z')
        for char in [chr(i) for i in range(ord('a'), ord('z')+1)]:
            self.assertTrue(char in p)
            self.assertEqual({'p'}, set(map(lambda x: x.name, a[char])))
    def test_default_semantics(self):
        a = BaseAlphabet()
        a['test'] = 'test'
        a[a.default_phoneme.name] = 't'
        self.assertTrue('test' in {x.name for x in a['e']})
        self.assertTrue('test' in {x.name for x in a['s']})
        self.assertFalse('test' in {x.name for x in a['t']})
    def test_friendly(self):
        a = FriendlyAlphabet()
        self.assertTrue(a.compatible('g', '!'))
    def test_disjoint(self):
        a = DisjointAlphabet()
        self.assertFalse(a.compatible('g', '!'))

class TestAlphabet(unittest.TestCase):
    def test_get(self):
        a = Alphabet()
        a._phonemes = {Phoneme('h', "hello"), Phoneme('w', "world"), Phoneme(Alphabet.separator, ' \t\n\r')}
        self.assertSetEqual({a.separator_phoneme}, a[' '])
        self.assertSetEqual({'h'}, set(map(lambda x: x.name, a['e'])))
        self.assertSetEqual({'h', 'w'}, set(map(lambda x: x.name, a[ord('o')])))
        self.assertSetEqual({a.default_phoneme}, a['z'])
        with self.assertRaises(ValueError): a['']
        with self.assertRaises(ValueError): a['az']
        with self.assertRaises(ValueError): a[a]
    def test_set(self):
        a = Alphabet()
        a[Alphabet.separator] = ' \t\n\r'
        a['h'] = Phoneme('h', "hello")
        a['w'] = 'world'
        self.assertSetEqual({a.separator_phoneme}, a[' '])
        self.assertSetEqual({'h'}, set(map(lambda x: x.name, a['e'])))
        self.assertSetEqual({'h', 'w'}, set(map(lambda x: x.name, a['o'])))
        self.assertSetEqual({a.default_phoneme}, a['z'])
    def test_compatibility(self):
        ab = Alphabet()
        ab['h'] = "hello"
        ab['w'] = 'world'
        ab[Alphabet.loner] = '()'
        ab[Alphabet.separator] = ' \t'
        for a in 'hello':
            for b in 'lo':
                self.assertTrue(ab.compatible(a,b))
        for a in 'rwd':
            for b in 'world':
                self.assertTrue(ab.compatible(a,b))
        for a in 'rwd':
            for b in 'he':
                self.assertFalse(ab.compatible(a,b))
        for a in 'WORLD':
            for b in "hello,world!":
                if not ab.compatible(a,b):
                    print(ab[a], ab[b].pop().name)
                self.assertTrue(ab.compatible(a,b))
        for a in '( )':
            for b in 'HELLOworld()':
                self.assertFalse(ab.compatible(a,b))
        self.assertFalse(ab.compatible('f', ' '))
        self.assertTrue(ab.compatible(' ', '\t'))

from src.submatcher import AlphabetMatcher

class TestAlphabetMatcher(unittest.TestCase):
    def setUp(self):
        a = Alphabet()
        a[Alphabet.separator] = ' \t\n\r'
        p = Phoneme('noname')
        p.add_range("a", "z")
        p.add_range("0", "9")
        p.add("_")
        a['alphanumeric'] = p
        a['numeric'] = "0123456789"
        a['symbol'] = "~@#$%&%*|+=-/:<>"
        a['punctuation'] = ".,;:!?"
        a[Alphabet.loner] = "()[]{}"
        self.m = AlphabetMatcher(a)
    def test_one(self):
        for i in range(len("abcd")):
            self.assertEqual(1, self.m.could_be("abcd"[:i+1]))
        self.assertEqual(0, self.m.could_be("abcd "))
        self.assertEqual(4, self.m.match("abcd ")[0])
    def test_two(self):
        for i in range(len("abcd")):
            self.assertEqual(1, self.m.could_be("ab1d"[:i+1]))
        self.assertEqual(0, self.m.could_be("ab1d "))
        self.assertEqual(4, self.m.match("ab1d ")[0])
    def test_three(self):
        for i in range(len("abcd")):
            self.assertEqual(1, self.m.could_be("abcd+"[:i+1]))
        self.assertEqual(0, self.m.could_be("abcd+"))
        self.assertEqual(4, self.m.match("abcd+")[0])
    def test_four(self):
        for i in range(len("+<=")):
            self.assertEqual(1, self.m.could_be("+<="[:i+1]))
        self.assertEqual(0, self.m.could_be("+<=1"))
        self.assertEqual(3, self.m.match("+<=1")[0])
    def test_loners(self):
        self.assertEqual(1, self.m.could_be("("))
        self.assertEqual(0, self.m.could_be("(("))
        self.assertEqual(1, self.m.match("((")[0])
        self.m.reset()
        self.assertEqual(1, self.m.could_be("a"))
        self.assertEqual(0, self.m.could_be("a("))
        m = self.m.match("a(")
        self.assertEqual(1, m[0])
        self.m.reset()
        self.assertEqual(1, self.m.could_be("("))
        self.assertEqual(0, self.m.could_be("(a"))
        self.assertEqual(1, self.m.match("(a")[0])
    def test_eof(self):
        for i in range(len("?:")):
            self.assertEqual(1, self.m.could_be("?:"[:i+1]))
        self.m.eof()
        self.assertEqual(2, self.m.match("?:")[0])

