#! /usr/bin/python3

import unittest

from test.phonemes import *
from test.keywords import *
from test.patterns import *
from test.delimiters import *

from test.reader import *

unittest.main()