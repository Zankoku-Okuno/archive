from functools import reduce

class Agent:
    def __init__(self, start_loc=0, end_loc=None):
        if end_loc is None:
            end_loc = start_loc
        self.bounds = Bounds(start_loc, end_loc)
        self.stack = []
        self.groups = Groups()
        self.backreferences = dict() #String: br_name to Machine
        
        self.groups_builder = GroupsBuilder()
        self.replay_builder = ReplayBuilder()
    
    def create(self, vertex):
        """Returns a set of agents based on their start vertex. Each returned
        agent is independent of the others, but not necessarily from self."""
        return {a.push(vertex) for a in vertex.on_enter(self)}
    def birth(self, arc, symbol):
        """Returns a set of new agents (possibly, and probably modified) based
        on the input symbol. All the new agents are structurally independant of
        the input agent."""
        agent = self.copy()
        agent.replay_builder += arc.replayer(agent, symbol) #has to be up here, since the replayer might use some of the agent's state
        agent.groups_builder.glomb(symbol)
        agent.bounds.glomb(symbol)
        return agent.create(arc.dest)
    
    def begin_capture(self, name):
        self.replay_builder.malloc(name)
        self.begin_reference(name)
    def begin_reference(self, name):
        self.groups_builder.malloc(name, self.bounds.end)
    
    def end_capture(self, name):
        if name not in self.backreferences:
            from .engine import Machine
            self.backreferences[name] = Machine(self.replay_builder.finish(name))
        else:
            self.backreferences[name].graph += self.replay_builder.finish(name)
        self.end_reference(name)
    def end_reference(self, name):
        self.groups[name] = self.groups_builder.finish(name)
    
    def compile(self, input):
        return self #STUB
        #return CompiledAgent(self, input)
    
    def peek(self):
        return self.stack[-1]
    def pop(self):
        return self.stack.pop()
    def push(self, state):
        self.stack.append(state)
        return self
    def __len__(self):
        return len(self.stack)

    def copy(self):
        "Performs a deep copy on all of the agent's data."
        from .engine import Machine
        out = Agent()
        out.bounds = self.bounds.copy()
        out.stack = self.stack[:]
        out.groups = self.groups.copy()
        out.backreferences = {x: Machine(self.backreferences[x].graph.copy()) for x in self.backreferences}
        out.groups_builder = self.groups_builder.copy()
        out.replay_builder = self.replay_builder.copy()
        return out
    def __eq__(self, other):
        if other is self: return True
        if not isinstance(other, Agent): return False
        return (self.bounds == other.bounds
                and self.stack == other.stack
                and self.groups == other.groups
               )
        #TESTME I don't need to check the backreferences or replay/groups builders, since they are one-to-one with boundsXstackXgroups
    def __hash__(self):
        return (5*hash(self.bounds)
                + 3*reduce(lambda x,y: x+hash(y), self.stack, 0)
                + 2*hash(self.groups)
               )
    def __str__(self):
        return "<Agent: in {2} {0} {1}>".format(self.bounds, self.groups, self.stack)
    def __repr__(self):
        return str(self)



class CompiledAgent: #TODO revisit usage
    def __init__(self, agent, input):
        self.match = input[agent.bounds.begin : agent.bounds.end]
        self.groups = {key:
                [input[group.begin : group.end] for group in agent.groups[key]]
            for key in agent.groups}

class Bounds:
    """Manages match location for an agent.
    
    For efficiency, it does not hold the input sequence itself: two bounds
    objects are equal iff their match start and end are equal."""
    def __init__(self, begin, end):
        self.begin = begin
        self.end = end
    def copy(self):
        return Bounds(self.begin, self.end)
    def glomb(self, symbol):
        """Increase the length of the match, unless the input symbol was
        'epsilon', the zero-length symbol."""
        from .rxconst import epsilon
        if symbol is not epsilon:
            self.end += 1
    def __len__(self):
        return self.end - self.begin
    def __eq__(self, other):
        return isinstance(other, Bounds) and (
            self.begin == other.begin and self.end == other.end )
    def __hash__(self):
        return self.begin ^ self.end
    def __str__(self):
        return "<Bounds {0}-{1}>".format(self.begin, self.end)
    def __repr__(self):
        return str(self)

class Groups:
    """Manages record-keeping of backreferences for an agent. Because
    backreference-matchers can be re-entered, a group actually maintains a
    sorted list of backreferences for each backreferenced name.
    
    For efficiency, it does not hold the backreference sequence itself: two
    groups objects are equal iff the contain the same bounds objects."""
    def __init__(self):
        self._data = dict() #from group name to list of Bounds
    #DOC names are _flat_: b/r name scope is always global to the match
    
    def __contains__(self, group):
        return group in self._data
    def __len__(self):
        return len(self._data)
    def __getitem__(self, group):
        """Call to retrieve an already matched group.
        
        Since groups may have match multiple matches associated, a list of all
        matches is returned. If there is no match for the group, then the empty
        list is returned."""
        return self._data[group] if group in self else []
    def __setitem__(self, group, bounds):
        """Call when a new group needs to be tracked.
        
        group = the name of the group to be tracked
        bounds = the location of the match (Bounds object)"""
        if group not in self:
            self._data[group] = []
        self._data[group].append(bounds)
    
    def copy(self):
        copy = Groups()
        copy._data = {key: self._data[key][:] for key in self._data}
        return copy
    
    def __eq__(self, other):
        if not isinstance(other, Groups):
            return False
        if len(self._data) != len(other._data):
            return False
        for key in self._data:
            if key not in other._data:
                return False
            if self._data[key] != other._data[key]:
                return False
        else:
            return True
    def __hash__(self):
        hashdict = 0
        for key in self._data:
            hashdict += hash(key)
            for item in self._data[key]:
                hashdict += hash(item)
            hashdict %= 2**20
        return 5*len(self._data) + hashdict
    def __str__(self):
        return "<Groups {0}>".format(self._data)
    def __repr__(self):
        return str(self)


class GroupsBuilder:
    def __init__(self):
        self.in_progress = dict()
    
    def malloc(self, name, start):
        assert name not in self.in_progress, name
        self.in_progress[name] = Bounds(start, start)
    
    def glomb(self, symbol):
        for name in self.in_progress:
            self.in_progress[name].glomb(symbol)
    
    def finish(self, name):
        return self.in_progress.pop(name).copy()
    
    def copy(self):
        out = GroupsBuilder()
        out.in_progress = {x: self.in_progress[x].copy() for x in self.in_progress}
        return out

class ReplayBuilder:
    """Assembles replayers (possibly many at one time) for later use in
    backreferences. These replayers are really just simple, linear machines.
    Each replayer is indexed by a name, and only one replayer may be built for a
    given name at one time (though obviously, the Replaybuilder is subordinate
    to the Agent, so many agents might have wildly varying replayers being
    built."""
    def __init__(self):
        self.in_progress = dict()
    
    def malloc(self, name):
        assert name not in self.in_progress, name
        self.in_progress[name] = _ReplayBuilderHelper()
    
    def __iadd__(self, gate):
        for name in self.in_progress:
            self.in_progress[name] += gate
        return self
    
    def finish(self, name):
        return self.in_progress.pop(name).finish()
    
    def copy(self):
        out = ReplayBuilder()
        out.in_progress = {x: self.in_progress[x].copy() for x in self.in_progress}
        return out

from .graph import Graph
from .struct import BaseVertex
class _ReplayBuilderHelper:
    def __init__(self):
        self.graph = Graph()
        self.last_state = BaseVertex()
        self.graph.add_initial(self.last_state)
    
    def __iadd__(self, gate):
        nu = BaseVertex()
        self.graph.add_arc(self.last_state, gate, nu)
        self.last_state = nu
        return self
    
    def finish(self):
        self.graph.add_final(self.last_state)
        return self.graph.copy()
    
    def copy(self):
        out = _ReplayBuilderHelper()
        out.graph = self.graph.copy()
        out.last_state = self.last_state
        return out



