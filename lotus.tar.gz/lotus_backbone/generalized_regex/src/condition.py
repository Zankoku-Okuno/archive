from .rxconst import epsilon, epsilon_transition

class BaseCondition:
    def __call__(self, agent, symbol):
        return symbol is not epsilon and self.test(agent, symbol)
    def replayer(self, agent, symbol): #SPIFFY
        assert self(agent, symbol)
        return RecursingCondition(self.replay_test(agent, symbol))
    
    def test(self, agent, symbol):
        raise NotImplementedError()
    def replay_test(self, agent, symbol):
        raise NotImplementedError()

class SimpleCondition(BaseCondition):
    def __init__(self, expr):
        self._test = expr
    
    def test(self, agent, symbol):
        return self._test(agent, symbol)
    def replay_test(self, agent, symbol):
        return lambda a,s: s == symbol
    
    def __neg__(self):
        return SimpleCondition(lambda a,x: not self._test(a,x))
    def __and__(self, other):
        return SimpleCondition(lambda a,x: self._test(a,x) and other._test(a,x))
    def __or__(self, other):
        return SimpleCondition(lambda a,x: self._test(a,x) or other._test(a,x))

class RecursingCondition(SimpleCondition):
    """Because when conditions that are in a backreference need to be
    backreferenced, they should continue replaying just as before, not generate
    a new replay condition."""
    def replay_test(self, agent, symbol):
        return self._test

def iscondition(obj):
    return obj is epsilon_transition or isinstance(obj, BaseCondition)