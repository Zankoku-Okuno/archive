"""Provides the logic for state updates in an automaton.
 
 DOC the new plan is just to have an engine, no wrapper
 
An engine is able to spawn new agents, collect information on living and
accepted agents and to manage the flow of agents through the automaton. It
essentially provides the execution semantics of an epsilon-nondeterministic
finite automaton; however, because transitions may activate based on the
properties of an agent and agents may include arbitrary state information, the
expressive power is probably equivalent to a Turing machine. The non-masochistic
user will decide to use the engine's environment only for problems which are
either nearly or completely within the scope of an e-NFA.

DOC The algorithmic complexity is probably in O(n^k) on the number of transition
functions, since the number of agents is related to their spawn/die ratio, which
in turn is determined by the number and nature of transitions. I bet it hovers
near O(n) amortized for many applications, since the spawn/die ratio is likely
to be <= 1. On the other hand, even one poorly designed loop in the graph (not
to mention nested loops) could seriously slow it down.

The Automaton class is meant to provide a neat, all-in-one-place, simple
interface to 80% of the utility of the engine. It's the nice bodywork that
conceals the twin turbo-chargers."""

from .agent import Agent
from .graph import Graph
from .rxconst import epsilon


class Machine:
    def __init__(self, graph):
        self.graph = graph
    
    def spawn(self, prototype):
        out = set()
        for vertex in self.graph.initial:
            out |= prototype.copy().create(vertex)
        return self.__epsilon_close(out)
    
    def step(self, agents, symbol):
        if not isinstance(agents, set):
            agents = {agents}
        return self.__epsilon_close(self.__step(agents, symbol))
    
    def potential(self, agents):
        out = set()
        for agent in agents:
            assert len(agent)
            if len(agent) > 1:
                out.add(agent)
            if self.graph[agent.peek()]:
                out.add(agent)
        return out
    def terminal(self, agents):
        out = set()
        for agent in agents:
            assert len(agent)
            if len(agent) == 1:
                if agent.peek() in self.graph.final:
                    out.add(agent)
        return out
    
    def __epsilon_close(self, agents):
        activeAgents = {x.copy() for x in agents}
        nuActiveAgents = self.__step(activeAgents, epsilon) - agents
        while nuActiveAgents:
            agents |= nuActiveAgents
            activeAgents = {x.copy() for x in nuActiveAgents}
            nuActiveAgents = self.__step(activeAgents, epsilon) - agents
        return agents
    
    def __step(self, agents, symbol):
        out = set()
        for agent in agents:
            out |= agent.pop().update(agent, symbol, self.graph)
        return out


class Engine:
    def __init__(self, graph):
        self.machine = Machine(graph)
        self.agents = set()
        self._input = []
    
    def spawn(self, prototype=None):
        if prototype is None:
            prototype = Agent(len(self._input))
        self.agents |= self.machine.spawn(prototype)

    def step(self, symbol):
        self.agents = self.machine.step(self.agents, symbol)
        self._input.append(symbol)
    
    def alive(self):
        return self.agents
    def potential(self):
        return self.machine.potential(self.agents)
    def terminal(self):
        return self.machine.terminal(self.agents)
    
    def extract(self):
        out = set()
        for agent in self.machine.terminal(self.agents):
            nuAgent = agent.copy()
            nuAgent.pop()
            out.add(nuAgent)
        return {x.compile(self._input) for x in out}
    
    def flush(self):
        self.agents = set()




    