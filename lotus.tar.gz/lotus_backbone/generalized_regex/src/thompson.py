from .struct import BaseVertex, MultiplicativeVertex
from .rxconst import *
from .graph import Graph
from .condition import *


def compile(stream):
    return _NetworkBuilder().build(
            _SubnetworkDetector().detect(
                flatten(deepen(stream))))

def deepen(stream):
    out = [[]]
    for item in stream:
        if item is expr:
            out.append([])
        elif item is end:
            if len(out) < 2:
                raise Exception("Unopened subexpression.") #TODO more specific
            out[-2].append(out.pop())
        else:
            out[-1].append(item)
    if len(out) != 1:
        raise Exception("Unclosed subexpression.") #TODO more specific
    return out[-1]

def flatten(tree):
    for child in tree:
        if isinstance(child, list):
            yield compile(child)
        elif child is epsilon:
            yield epsilon_transition
        elif child is anything:
            yield SimpleCondition(lambda a,x: True)
        else:
            assert iscondition(child) or isinstance(child, RXConst), child
            yield child

class _SubnetworkDetector:
    def __init__(self):
        self.LAB = None
        self.mode = None
    
    def detect(self, stream):
        for item in stream:
            it = self.decode(item)
            if it is not None:
                yield it
        if self.mode is not None:
            raise Exception('Unbound prefix.') #TODO more specific
        if self.LAB is not None:
            yield self.LAB
    
    def decode(self, item):
        if self.mode is not None:
            assert self.LAB is None
            return self.__prefix(item)
        elif isinstance(item, RXVar):
            if item.name == 'capture':
                self.mode = (CapturingVertex, item.var)
                item = None #fallthrough
            elif item.name == 'multiply':
                return self.__multiplicative(item)
            #else: fallthrough
        if self.LAB is None:
            self.LAB = item
        else:
            out, self.LAB = self.LAB, item
            return out
    
    def __prefix(self, item):
        #STUB
        #create the submachine
        self.mode = None
        return something
    def __multiplicative(self, item):
        if self.LAB is None:
            raise Exception('Unbound suffix.') #TODO more specific
        if not isinstance(self.LAB, Graph):
            self.LAB = compile([self.LAB])
        subgraph, self.LAB = self.LAB, None
        return MultiplicativeVertex(subgraph, *item.var)


class _NetworkBuilder:
    def __init__(self):
        self.graph = Graph()
        self.last_i, self.last_f = set(), set()
        #last_i is what transisions connect to in a feedback scenario (genreally second-last created vertex)
        #last_f is where new transitions should start (generally last created vertex)
        self.reset_last()
    
    def build(self, stream):
        self.add_initial(self.last_f)
        for item in stream:
            self.dispatch(item)
        self.add_final(self.last_f)
        return self.graph
    
    def dispatch(self, item):
        if isinstance(item, Graph):
            self.expression(item)
        elif isinstance(item, BaseVertex):
            self.subgraph(item)
        
        elif item is alternator:
            self.alternate()
        elif item is option_mark:
            self.optionate()
        elif item is kleene_star:
            self.star()
        elif item is kleene_plus:
            self.plus()
        elif item is lazy_star:
            assert False
        elif item is lazy_plus:
            assert False
            
            
        else:
            assert item is epsilon_transition or iscondition(item)
            self.condition(item)
    
    def condition(self, condition):
        nu = {BaseVertex()}
        self.add_arcs(self.last_f, condition, nu)
        self.advance(nu)
    def expression(self, subgraph):
        self.add_subgraph(subgraph)
        self.add_arcs(self.last_f, epsilon_transition, subgraph.initial)
        self.last_i, self.last_f = subgraph.initial, subgraph.final
    def subgraph(self, subgraph):
        self.add_arcs(self.last_f, epsilon_transition, {subgraph})
        self.last_i, self.last_f = ({subgraph},)*2
    
    def alternate(self):
        self.add_final(self.last_f)
        self.reset_last()
        self.add_initial(self.last_f)
    def optionate(self):
        if not self.last_i:
            raise Exception() #TODO more specific
        self.last_f |= self.last_i
    def star(self):
        if not self.last_i:
            raise Exception() #TODO more specific
        nu = {BaseVertex()}
        self.add_arcs(self.last_f, epsilon_transition, self.last_i)
        self.add_arcs(self.last_i, epsilon_transition, nu)
        self.last_i, self.last_f = set(), nu
    def plus(self):
        if not self.last_i:
            raise Exception() #TODO more specific
        self.add_arcs(self.last_f, epsilon_transition, self.last_i)
        self.last_i = set()
    def lazy_star(self):
        assert False
    def lazy_plus(self):
        assert False
    
    def reset_last(self):
        self.last_i, self.last_f = set(), {BaseVertex()}
    def advance(self, vertices):
        self.last_i, self.last_f = self.last_f, vertices
    def add_initial(self, vertices):
        for vertex in vertices:
            self.graph.add_initial(vertex)
    def add_final(self, vertices):
        for vertex in vertices:
            self.graph.add_final(vertex)
    def add_subgraph(self, subgraph):
        for vertex in subgraph.vertices:
            self.graph.add_vertex(vertex)
            self.graph.vertices[vertex] |= subgraph.vertices[vertex]
    def add_arcs(self, sources, gate, destinations):
        for source in sources:
            for destination in destinations:
                self.graph.add_arc(source, gate, destination)


