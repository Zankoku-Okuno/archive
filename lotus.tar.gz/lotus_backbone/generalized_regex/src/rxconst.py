"""Provides some constants which are used throughout the system, though
generally not explicitly by the user.

Most importantly, it provides epsilon and epsilon_transition as constants.
epsilon is the only zero-length symbol. epsilon_transition is a transition
function independent of agent which is active only when the input is epsilon. DO
NOT use any other objects for these purposes, as the system is specially
designed to handle these two.

Furthermore, a number of constants are provided that are of great help in using
the thompson construction. Essentially, a string that is to be fed to thompson
should consist purely of Condition and _RXConst objects. The conditions will
determine the content of arcs in the machine and the _RXConsts will determine
structure."""

class RXConst:
	def __init__(self, name):
		self.name = name
	def __repr__(self):
		return self.name
class RXVar(RXConst):
	def __init__(self, name, var):
		super().__init__(name)
		self.var = var
	def __repr__(self):
		return "{0}({1})".format(self.name, self.var)
class RXDynamic(RXVar):
	pass
class _EpsilonCondition:
    def __call__(self, agent, symbol):
        return symbol is epsilon
    def replayer(self, agent, symbol):
        return self


epsilon = RXConst('epsilon')
epsilon_transition = _EpsilonCondition()

expr = RXConst('expr')						# (
end = RXConst('end expr')					# )
alternator = RXConst('alternator')			# X|Y
kleene_star = RXConst('kleene star')		# X*
kleene_plus = RXConst('kleene plus')		# X+
option_mark = RXConst('optional')			# X?
lazy_star = RXConst('lazy star')			# X*?
lazy_plus = RXConst('lazy plus')			# X+?

anything = RXConst('anything')				# .
begin_stream = RXConst('begin stream')		# \A ^
end_stream = RXConst('end stream')			# \Z $
#TODO lookbehind (only at start of regex) and lookahead (only at end of regex)
#TODO \b-like things, perhaps
	#okay, okay:
	#agents get set of lookahead machines.
	#if any machine ever fails (dies), the agent dies
	#if a machine is terminal, the agent must spawn w/o that machine (become a real boy!)
	#if multiple machines are terminal, all combinations must spawn
	#for negative lookaround: swap terminal and nonterminal states
	
	#(it might be possible to do something similar for lookbehind)
	#in fact, it seems like this should be useable for both lookahead and
	#lookbehind, the difference between the two is just a matter of what to
	#increase
	
	
def multiplier(low, high):					# X{N} X{N+} X{-N} X{N,M}
	assert (low is not None
			or high is not None)
	if low is None:
		low = 0
	return RXVar('multiply', (low, high))
def late_bound(*names):						# "NAME" "NAME1&NAME2" 
	return RXDynamic('late bound', names)
def capture(br_name):						# `NAME,X `(
	return RXVar('capture', br_name)
def reference(br_name):
	return RXVar('reference', br_name)		# `NAME, \N

#TODO more features
