"""This module provides the basic elements of strucutre for a state machine.
Namely, Verteces and Arcs (states and transitions).

#DOC states better
#DOC arcs better
"""
from functools import reduce

from .rxconst import epsilon
class Arc:
    def __init__(self, gate, destination):
        self.gate, self.dest = gate, destination
    
    def test(self, agent, symbol):
        return self.gate(agent, symbol)
    def replayer(self, agent, symbol):
        return self.gate.replayer(agent, symbol)
    
    def __repr__(self):
        return "<Arc to " + str(self.dest) + ">"

class BaseVertex:
    """A state with a very simple update. An epsilon-nondeterministic finite
    automaton would be built entirely out of these states."""
    def on_enter(self, agent):
        """One unmolested child."""
        return {agent}
    def update(self, agent, symbol, engine):
        """Looks in the machine for arcs along which the agent may travel given
        the input symbol. Returns a set of descendants, all of which are
        independent of the input agent."""
        out = set()
        for arc in engine[self]:
            if arc.test(agent, symbol):
                out |= agent.birth(arc, symbol)
        return out


class SubmachineVertex(BaseVertex):
    def __init__(self, subgraph):
        from .engine import Machine
        self.submachine = Machine(subgraph)
    
    def update(self, agent, symbol, engine):
        if not agent.stack:
            return super().update(agent, symbol, engine)
        elif symbol is epsilon:
            #to avoid infinite recursion during the supermachine's epsilon
            #closure calculation --
            #if the upper limit is None, and epsilon creates a terminal from one
            #of the newly exiting agents, we will create yet another new agent
            #that has been through the machine an extra time
            return {agent.push(self)}
        else:
            return {x.push(self) for x in self.step(agent, symbol)}

    def step(self, agent, symbol):
        raise NotImplementedError()

def _pop_all(iterable):
    for item in iterable:
        item.pop()
    return iterable


class MultiplicativeVertex(SubmachineVertex):
    def __init__(self, subgraph, low, high):
        assert low is not None
        assert high is None or low <= high
        super().__init__(subgraph)
        self.lower_limit, self.upper_limit = low, high
    
    def on_enter(self, agent):
        """Push how many times (0) the agent has matched in the submachine."""
        nu = self.submachine.spawn(agent)
        immediate_exit = {agent.copy()} if self.lower_limit == 0 or self.submachine.terminal(nu) else set()
        return {x.push(0) for x in nu} | immediate_exit
    def step(self, agent, symbol):
        times = agent.pop()
        would_be_times = times+1
        nuAgents = self.submachine.step(agent, symbol)
        return (  self.loop_agents(would_be_times, nuAgents)
                | self.exit_agents(would_be_times, nuAgents)
                | self.empty_loop_exiters(would_be_times, nuAgents)
                | {x.push(times) for x in self.submachine.potential(nuAgents)} #don't need to copy here, but must be at the bottom
               )
    
    def loop_agents(self, would_be_times, nuAgents):
        """Given a set of agents in the submachine, creates appropriate agents
        representing those same agents after looping from a terminal state back
        to initial states."""
        if self.upper_limit is not None and self.upper_limit <= would_be_times:
            return set()
        return reduce(lambda acc,x: acc | {looped.push(would_be_times) for looped in self.submachine.spawn(x)},
                        _pop_all(self.terminal_copies(nuAgents)), set())
    def exit_agents(self, would_be_times, nuAgents):
        """Given a set of agents in the submachine, creates agents exited from
        the submachine from the terminal agents of the submachine."""
        return _pop_all(self.terminal_copies(nuAgents)) if (
                self.lower_limit <= would_be_times) else set()
        
    def empty_loop_exiters(self, would_be_times, nuAgents):
        """Find looping agents that would exit given enough epsilons. Create
        agents from those exiting agents."""
        if self.lower_limit <= would_be_times:
            return set() #we've already exited what we need, further exits will simply be discarded later
        candidates = reduce(lambda acc,x: acc | self.submachine.spawn(x),
                                _pop_all(self.terminal_copies(nuAgents)), set())
        return _pop_all(self.submachine.terminal(candidates))
    
    def terminal_copies(self, nuAgents):
        return {x.copy() for x in self.submachine.terminal(nuAgents)}

class GroupsVertex(SubmachineVertex):
    def __init__(self, subgraph, name):
        super().__init__(subgraph)
        self.name = name
    
    def current_submachine(self, agent):
        raise NotImplementedError()
    
    def on_enter(self, agent):
        #MAYBE I should copy the agent, malloc immediately, then spawn and check immediate exit (which would have the backreference removed)
        #I'm just worried about the number of empty backreferences that could crop up in the case of, say, `(a)*
        #since I'm saving each backreference instead of just one, I'd need to avoid infinite loop-ness
        #(although, perhaps I could modify the agent such that it only accepts one consecutive empty group)
        submachine = self.current_submachine(agent)
        nuAgents = self.begin_all(submachine.spawn(agent))
        immediate_exit = {agent.copy()} if submachine.terminal(nuAgents) else set()
        return submachine.potential(nuAgents) | immediate_exit
    def begin_all(self, agents):
        raise NotImplementedError()
    
    def step(self, agent, symbol):
        submachine = self.current_submachine(agent)
        nuAgents = submachine.step(agent, symbol)
        exiters = _pop_all({x.copy() for x in self.current_submachine(agent).terminal(nuAgents)})
        self.end_all(exiters)
        return submachine.potential(nuAgents) | exiters
    def end_all(self, agents):
        raise NotImplementedError()
    
    def terminal_copies(self, nuAgents, baseAgent):
        return {x.copy() for x in self.current_submachine(baseAgent).terminal(nuAgents)}

class CapturingVertex(GroupsVertex):
    
    def current_submachine(self, agent):
        return self.submachine
    
    def begin_all(self, agents):
        for agent in agents:
            agent.begin_capture(self.name)
        return agents
    
    def end_all(self, agents):
        for agent in agents:
            agent.end_capture(self.name)
        return agents

class ReferencingVertex(GroupsVertex):
    def __init__(self, name):
        self.name = name
    
    def current_submachine(self, agent):
        return agent.backreferences[self.name]
    
    def begin_all(self, agents):
        for agent in agents:
            agent.begin_reference(self.name)
        return agents
    
    def end_all(self, agents):
        for agent in agents:
            agent.end_reference(self.name)
        return agents
    
    #on entrance, if the agent does not have the backreference, then simply return {the agent}
    #if the backreference does exist, then we spawn using the agent's backreference machine for my name
    #we also begin_reference
    
    # on the step:
    #so, oh! no... the agent can only be in one b/r at a time, since the b/r machines aare full of only BaseVertex
    
    #on exit, we simply end_reference




