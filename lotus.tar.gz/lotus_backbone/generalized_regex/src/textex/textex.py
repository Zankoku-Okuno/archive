
# ==============
# == Compiler ==
# ==============

from .. import thompson
from ..rxconst import RXDynamic
def compile(input, binder=None):
    return thompson.compile(_link(_parse(_preprocess(input)), binder))

def _preprocess(input): #REFAC this is used in the waterworks, too
    import re
    match = re.search(r'\\u([\dA-Fa-f]+);', input)
    while match:
        replace = match.groups()[0]
        input = re.sub(r'\\u{0};'.format(replace), chr(int(replace, 16)), input)
        match = re.search(r'\\u([\dA-Fa-f]+);', input)
    return input

def _parse(input):
    from . import expression
    from stovokor.sed import AnnotatingReader
    parse = expression.MainParser()
    tokenizer = AnnotatingReader(expression.tokenizer, parse)
    tokenizer.feed(input)
    tokenizer.eof()
    return parse.out

from ..condition import SimpleCondition
def _link(input, binder):
    if binder is None:
        return input
    out = []
    for token in input:
        if isinstance(token, RXDynamic):
            if token.name == 'late bound':
                if not token.var:
                    raise Exception() #TODO more specific
                linked = SimpleCondition(binder.bind(token.var[0]))
                for i in range(1, len(token.var)):
                    linked = linked & SimpleCondition(binder.bind(token.var[i]))
                out.append(linked)
            else:
                assert False
        else:
            out.append(token)
    return out



