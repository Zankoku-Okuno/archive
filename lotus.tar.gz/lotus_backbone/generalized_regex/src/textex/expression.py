from .const import *

# == Tokenizer Setup ==

from stovokor.local import DisjointAlphabet
from stovokor.matcher import Driver
tokenizer = Driver(DisjointAlphabet(), keywords | escapes, patterns, delimiters)

# == Parser ==

from ..condition import SimpleCondition
from . import char_class
class MainParser:
    def __init__(self):
        self.out = []
    
    def append(self, token):
        string, type = token.text, token.matcher.type
        if type == 'keyword':
            if string in kw_lookup:
                self.out.append(kw_lookup[string])
            elif len(string) == 2 and string[0] == '\\':
                self.out.append(SimpleCondition(lambda agent, symbol : symbol == string[1]))
            else:
                assert False
        elif type == 'pattern':
            pattern = token.matcher.matcher
            if pattern.name == 'exact multiplier':
                self.out.append(multiplier( *(pattern.parse(string),)*2 ))
            elif pattern.name == 'at least multiplier':
                self.out.append(multiplier(pattern.parse(string), None))
            elif pattern.name == 'up to multiplier':
                self.out.append(multiplier(0, pattern.parse(string)))
            elif pattern.name == 'between multiplier':
                self.out.append(multiplier(*pattern.parse(string)))
            else:
                assert False
        elif type == 'delimiter':
            delimiter = token.matcher.matcher
            if delimiter.name in {'charclass', 'anticlass'}:
                self.out.append(char_class.compile(string))
            elif delimiter.name == 'phoneme':
                self.out.append(late_bound(*char_class.var_names(string)))
            else:
                assert False, delimiter.name
        else:
            self.out.append(SimpleCondition(lambda agent, symbol: symbol == string))