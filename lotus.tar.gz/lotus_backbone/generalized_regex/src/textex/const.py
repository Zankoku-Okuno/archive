from stovokor.local import DisjointAlphabet
from stovokor.quantum import Keyword, Pattern, Delimiter
from stovokor.matcher import Driver

# == Support ==

from .. import thompson
class _HandCompiledPattern(Pattern):
    def __init__(self, name, fake_pattern, stream, parser):
        self.graph = thompson.compile(stream)
        self.pattern = fake_pattern
        self.name = name
        self.parse = parser

# == Constants ==

from ..rxconst import *
from ..condition import SimpleCondition
kw_lookup = {
    '(': expr,
    ')': end,
    '|': alternator,
    '?': option_mark,
    '*': kleene_star,
    '+': kleene_plus,
    '*?': lazy_star,
    '+?': lazy_plus,
    r'\d': SimpleCondition(lambda a,x: ord('0')<=ord(x)<=ord('9'))
}

keywords = {Keyword(s) for s in kw_lookup}

patterns = {
    _HandCompiledPattern('exact multiplier', r'{\d+}',
                         [SimpleCondition(lambda a,x: x == '{'),
                          kw_lookup['\d'],
                          kleene_plus,
                          SimpleCondition(lambda a,x: x == '}')],
                         lambda s: int(s[1:-1])),
    _HandCompiledPattern('at least multiplier', r'{\d+\+}',
                         [SimpleCondition(lambda a,x: x == '{'),
                          kw_lookup['\d'],
                          kleene_plus,
                          SimpleCondition(lambda a,x: x == '+'),
                          SimpleCondition(lambda a,x: x == '}')],
                         lambda s: int(s[1:-2])),
    _HandCompiledPattern('up to multiplier', r'{-\d+}',
                         [SimpleCondition(lambda a,x: x == '{'),
                          SimpleCondition(lambda a,x: x == '-'),
                          kw_lookup['\d'],
                          kleene_plus,
                          SimpleCondition(lambda a,x: x == '}')],
                         lambda s: int(s[2:-1])),
    _HandCompiledPattern('between multiplier', r'{\d+,\d+}',
                         [SimpleCondition(lambda a,x: x == '{'),
                          kw_lookup['\d'],
                          kleene_plus,
                          SimpleCondition(lambda a,x: x == ','),
                          kw_lookup['\d'],
                          kleene_plus,
                          SimpleCondition(lambda a,x: x == '}')],
                         lambda s: (int(x) for x in s[1:-1].split(',')))
}

delimiters = {
    Delimiter('charclass', '[', ']', '\\'),
    Delimiter('anticlass', '[^', ']', '\\'),
    Delimiter('phoneme', '"', '"', '\\')
}

escapes = {Keyword('\\' + char) for char in
           {kw.pattern[0] for kw in keywords} |
           {delim.begin[0] for delim in delimiters} |
           {'{', '\\'}}


