"""Provides a way to manage networks of states without any execution logic."""

from .rxconst import epsilon, epsilon_transition
from .struct import Arc

class Graph:
    """Provides the logic to create and query a state network.
    
    The functionality focused on here is the determination of active transitions
    and accumulation of actively connected states.
    
    Other classes will implement the logic: if a transition to a state q from
    state p is active for a given agent on a given input symbol, then that
    agent, if it is currently on p, should migrate (move/spawn) to state q when
    that input symbol is consumed."""
    
    def __init__(self):
        self.vertices, self.initial, self.final = dict(), set(), set()
    def fork(self):
        from .engine import Engine
        return Engine(self.copy())
    
    def add_vertex(self, vertex):
        if vertex not in self.vertices:
            self.vertices[vertex] = set()
    def add_initial(self, vertex):
        self.add_vertex(vertex)
        self.initial.add(vertex)
    def add_final(self, vertex):
        self.add_vertex(vertex)
        self.final.add(vertex)
    def add_arc(self, source, gate, destination):
        """Creates a connection from source to destination, active only when
        the gate returns true."""
        self.add_vertex(source)
        self.add_vertex(destination)
        self.vertices[source].add(Arc(gate, destination))
    
    def __set_helper(self, vertex, yn, method, S):
        if yn:
            method(vertex)
        else:
            try: S.remove(vertex)
            except KeyError: pass
    def set_initial(self, vertex, yn=True):
        self.__set_helper(vertex, yn, self.add_initial, self.initial)
    def set_final(self, vertex, yn=True):
        self.__set_helper(vertex, yn, self.add_final, self.final)
    
    def __getitem__(self, source):
        """Returns the arcs which originate at the source."""
        return self.vertices[source]
    
    def __or__(self, other):
        out = self.copy()
        out |= other
        return out
    def __add__(self, other):
        out = self.copy()
        out += other
        return out
    def __mult__(self, other):
        out = self.copy()
        out *= other
        return out
    
    def __ior__(self, other):
        pass #STUB
        return self
    def __iadd__(self, other):
        for vertex in other.vertices:
            self.add_vertex(vertex)
            self.vertices[vertex] |= other.vertices[vertex]
            if vertex in other.initial:
                self.set_initial(vertex)
            if vertex in other.final:
                self.set_final(vertex)
        return self
    def __imul__(self, other):
        pass #STUB
        return self
    
    def copy(self):
        out = Graph()
        out.vertices = {k: {Arc(arc.gate, arc.dest) for arc in self.vertices[k]}
            for k in self.vertices}
        out.initial = {x for x in self.initial}
        out.final = {x for x in self.final}
        return out


