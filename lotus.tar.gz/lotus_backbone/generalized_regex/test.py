#! /usr/bin/python3

import unittest

from tests.test_constants import *
from tests.test_conditions import *
from tests.test_agents import *
from tests.test_structs import *

from tests.test_graphs import *
from tests.test_engine import *
from tests.test_services import *

from tests.test_construction import *
from tests.test_textex import *


unittest.main()