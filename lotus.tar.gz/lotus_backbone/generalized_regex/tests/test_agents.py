import unittest

from src.agent import Bounds
from src.rxconst import epsilon
from src.struct import *

class TestBounds(unittest.TestCase):
    def setUp(self):
        self.b1 = Bounds(0, 5)
        self.b2 = Bounds(0, 3)
        self.b3 = Bounds(3, 8)
        self.b4 = Bounds(0, 5)
        self.bs = [self.b1, self.b2, self.b3, self.b4]
    def test_eq(self):
        for i in range(4):
            for j in range(4):
                if i != j:
                    self.assertFalse(self.bs[i] is self.bs[j])
                    if i in {0, 3} and j in {0, 3}:
                        self.assertEqual(self.bs[i], self.bs[j])
                    else:
                        self.assertNotEqual(self.bs[i], self.bs[j])
                else:
                    self.assertTrue(self.bs[i] is self.bs[j])
                    self.assertEqual(self.bs[i], self.bs[j])
    def test_glomb(self):
        b, e = self.b1.begin, self.b1.end
        self.b1.glomb(epsilon)
        self.assertEqual(b, self.b1.begin)
        self.assertEqual(e, self.b1.end)
        self.b1.glomb("a")
        self.assertEqual(b, self.b1.begin)
        self.assertEqual(e+1, self.b1.end)
    def test_copy(self):
        c = self.b1.copy()
        self.assertFalse(c is self.b1)
        self.assertEqual(c, self.b1)
        c.glomb("a")
        self.assertNotEqual(c, self.b1)
        self.assertEqual(c, Bounds(0, 6))
        self.assertEqual(self.b1, Bounds(0, 5))


from src.agent import Groups
class TestGroups(unittest.TestCase):
    def setUp(self):
        self.g = Groups()
        self.g._data['exists'] = [Bounds(3,3),Bounds(5,5)]
    def test_contains(self):
        self.assertFalse('dne' in self.g)
        self.assertTrue('exists' in self.g)
    def test_get(self):
        self.assertEqual([], self.g['dne'])
        self.assertTrue([Bounds(3,3),Bounds(5,5)], self.g['exists'])
    def test_set(_):
        _.g['exists'] = Bounds(7,9)
        _.assertEqual(_.g['exists'], [Bounds(3,3),Bounds(5,5),Bounds(7,9)])
        _.g['dne'] = Bounds(4,4)
        _.assertEqual([Bounds(4,4)], _.g['dne'])
    def test_equal(self):
        g = Groups()
        self.assertNotEqual(g, self.g)
        g['exists'] = Bounds(3,3)
        g['exists'] = Bounds(5,5)
        self.assertEqual(g, self.g)
    def test_copy(self):
        old_groups = [b.copy() for b in self.g['exists']]
        new_group = self.g.copy()
        self.assertEqual(new_group, self.g)
        self.assertFalse(new_group is self.g)
        new_group['exists'] = Bounds(6,6)
        new_group['new'] = Bounds(6,6)
        self.assertNotEqual(self.g, new_group)
        self.assertEqual(old_groups, self.g['exists'])

from src.agent import ReplayBuilder
from src.condition import SimpleCondition
class TestReplay(unittest.TestCase):
    def setUp(self):
        self.rb = ReplayBuilder()
    def test_single(self):
        self.rb.malloc('t')
        self.rb += SimpleCondition(lambda a,x: x in 'abc').replayer(None, 'c')
        self.rb += SimpleCondition(lambda a,x: x in 'abc').replayer(None, 'b')
        self.rb += SimpleCondition(lambda a,x: x in 'abc').replayer(None, 'a')
        e = self.rb.finish('t').fork()
        self.assertFalse(self.rb.in_progress)
        e.spawn()
        for i in 'cba':
            e.step(i)
            self.assertTrue(e.alive())
        self.assertTrue(e.terminal())
        self.assertFalse(e.potential())
        for i in 'abd':
            e.spawn()
            self.assertTrue(e.alive())
            e.step(i)
            self.assertFalse(e.alive())
    def test_nested(self):
        # `([ab]`[ab])\2\1  matches  abbab
        self.rb.malloc(1)
        self.rb += SimpleCondition(lambda a,x: x in 'ab').replayer(None, 'a')
        self.rb.malloc(2)
        self.rb += SimpleCondition(lambda a,x: x in 'ab').replayer(None, 'b')
        e1 = self.rb.finish(1).fork()
        e2 = self.rb.finish(2).fork()
        self.assertFalse(self.rb.in_progress)
        e2.spawn()
        e2.step('b')
        self.assertTrue(e2.terminal())
        self.assertFalse(e2.potential())
        e1.spawn()
        e1.step('a')
        e1.step('b')
        self.assertTrue(e2.terminal())
        self.assertFalse(e2.potential())

from src.agent import Agent
class TestAgent(unittest.TestCase):
    def test_copy(self):
        a1 = Agent()
        a1.bounds = Bounds(4, 6)
        a1.push(3)
        g = Groups()
        g['exists'] = Bounds(5, 6)
        a1.groups = g
        a2 = a1.copy()
        self.assertTrue(a1 == a2)
        self.assertFalse(a1 is a2)
        a2.bounds.glomb('a')
        a2.groups['exists'] = Bounds(6,7)
        self.assertNotEqual(a1, a2)
        self.assertEqual(Bounds(4,6), a1.bounds)
        self.assertEqual(g, a1.groups)
        self.assertFalse(a1.backreferences is a2.backreferences)
        self.assertFalse(a1.groups_builder is a2.groups_builder)
        self.assertFalse(a1.replay_builder is a2.replay_builder)
    def test_birth(self):
        v = BaseVertex()
        arc = Arc(SimpleCondition(lambda a,s: 3<=s<=5), v)
        a = Agent()
        res = a.birth(arc, 5)
        self.assertEqual(1, len(res))
        res = res.pop()
        self.assertFalse(a is res)
        self.assertFalse(a == res)
        self.assertEqual(res.peek(), v)
    def test_replayment(self):
        # `([ab]`[ab]*)\2\1\2  matches  abaaabab (also: abbbabbb but not abbaabbb)
        a = Agent()
        a.begin_capture(1)
        self.assertEqual(a.bounds, Bounds(0,0))
        self.assertEqual(a.groups_builder.in_progress[1], Bounds(0,0))
        nu = a.birth(Arc(SimpleCondition(lambda a,x: x in 'ab'), BaseVertex()), 'a')
        self.assertEqual(len(nu), 1)
        a = nu.pop()
        a.begin_capture(2)
        nu = a.birth(Arc(SimpleCondition(lambda a,x: x in 'ab'), BaseVertex()), 'b')
        self.assertEqual(len(nu), 1)
        a = nu.pop()
        a.end_capture(2)
        self.assertEqual(len(a.groups[2]), 1)
        self.assertEqual(Bounds(1,2), a.groups[2][0])
        a.begin_capture(2)
        nu = a.birth(Arc(SimpleCondition(lambda a,x: x in 'ab'), BaseVertex()), 'a')
        self.assertEqual(len(nu), 1)
        a = nu.pop()
        a.end_capture(2)
        self.assertEqual(len(a.groups[2]), 2)
        self.assertEqual(Bounds(2,3), a.groups[2][1])
        a.end_capture(1)
        self.assertEqual(len(a.groups[1]), 1)
        self.assertEqual(Bounds(0,3), a.groups[1][0])
        #interlude to test the machines work properly
        e = a.backreferences[1].graph.fork()
        e.spawn()
        e.step('a')
        self.assertFalse(e.terminal())
        self.assertTrue(e.potential())
        e.step('b')
        self.assertFalse(e.terminal())
        self.assertTrue(e.potential())
        e.step('a')
        self.assertTrue(e.terminal())
        self.assertFalse(e.potential())
        for i in 'ab':
            e = a.backreferences[2].graph.fork()
            e.spawn()
            e.step(i)
            self.assertTrue(e.terminal())
            self.assertFalse(e.potential())
        #end of interlude
        a.begin_reference(2)
        nu = a.birth(Arc(SimpleCondition(lambda a,x: x in 'ab'), BaseVertex()), 'a')
        self.assertEqual(len(nu), 1)
        a = nu.pop()
        a.end_reference(2)
        a.begin_reference(1)
        nu = a.birth(Arc(SimpleCondition(lambda a,x: x in 'ab'), BaseVertex()), 'a')
        self.assertEqual(len(nu), 1)
        a = nu.pop()
        nu = a.birth(Arc(SimpleCondition(lambda a,x: x in 'ab'), BaseVertex()), 'b')
        self.assertEqual(len(nu), 1)
        a = nu.pop()
        nu = a.birth(Arc(SimpleCondition(lambda a,x: x in 'ab'), BaseVertex()), 'a')
        self.assertEqual(len(nu), 1)
        a = nu.pop()
        a.end_reference(1)
        a.begin_reference(2)
        nu = a.birth(Arc(SimpleCondition(lambda a,x: x in 'ab'), BaseVertex()), 'b')
        self.assertEqual(len(nu), 1)
        a = nu.pop()
        a.end_reference(2)
        self.assertEqual(len(a.groups[1]), 2)
        self.assertEqual(a.groups[1][1], Bounds(4,7))
        self.assertEqual(len(a.groups[2]), 4)
        self.assertEqual(a.groups[2][2], Bounds(3,4))
        self.assertEqual(a.groups[2][3], Bounds(7,8))
