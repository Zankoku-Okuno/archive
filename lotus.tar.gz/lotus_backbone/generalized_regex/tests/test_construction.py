import unittest

from src.condition import SimpleCondition
from src.engine import Engine
from src import thompson
from src.rxconst import *

def convert(regex):
    for i in range(len(regex)):
        if isinstance(regex[i], list):
            regex[i] = convert(regex[i])
        elif isinstance(regex[i], RXConst):
            pass
        else:
            regex[i] = SimpleCondition(regex[i])
    return regex
def match(regex, input):
    rx = thompson.compile(regex)
    a = Engine(rx)
    a.spawn()
    for item in input:
        a.step(item)
    return a.terminal()
class TestConstruction(unittest.TestCase):
    def test_basics(self):
        rx = thompson.compile(convert([lambda x,y:y=='a',
                                       lambda x,y:y=='b',
                                       lambda x,y:y=='c']))
        a = rx.fork()
        a.spawn()
        for item in 'abc':
            self.assertFalse(a.terminal())
            a.step(item)
            self.assertEqual(1, len(a.agents))
        self.assertTrue(a.terminal())
    def test_literals(self):
        rx = convert([lambda x,y:y=='a',
                      lambda x,y:y=='b',
                      lambda x,y:y=='c'])
        self.assertTrue(match(rx, 'abc'))
        self.assertFalse(match(rx, 'aaa'))
    def test_classes(self):
        rx = convert([lambda x,y: y in 'abc'])
        for char in 'abc':
            self.assertTrue(match(rx, char))
        for char in 'ABC':
            self.assertFalse(match(rx, char))
        self.assertFalse(match(convert([lambda a,x: len(x)==1 and 'a' <= x <= 'z']), 'ab'))
    def test_anti_classes(self):
        rx = convert([lambda x,y: y not in 'abc'])
        for char in 'abc':
            self.assertFalse(match(rx, char))
        for char in 'ABC':
            self.assertTrue(match(rx, char))
    def test_anything(self):
        rx = convert([lambda a,x: x=='(',
                      anything,
                      lambda a,x: x==')'])
        self.assertFalse(match(rx, '('))
        self.assertFalse(match(rx, '()'))
        self.assertTrue(match(rx, '(h)'))
        self.assertTrue(match(rx, '(i)'))
        self.assertFalse(match(rx, '(hi)'))
    def test_alternator(self):
        rx = convert([lambda a,x: x=='a',
                      alternator,
                      lambda a,x: x=='v'])
        self.assertTrue(match(rx, 'a'))
        self.assertTrue(match(rx, 'v'))
        self.assertFalse(match(rx, 'b'))
        self.assertFalse(match(rx, 'av'))
        
        rx1 = convert([alternator,
                      lambda a,x: x=='F',
                      lambda a,x: x=='F',
                      lambda a,x: x=='F',
                      alternator,
                      lambda a,x: x=='f',
                      lambda a,x: x=='f',
                      lambda a,x: x=='f'])
        rx2 = convert([lambda a,x: x=='f',
                      lambda a,x: x=='f',
                      lambda a,x: x=='f',
                      alternator,
                      lambda a,x: x=='F',
                      lambda a,x: x=='F',
                      lambda a,x: x=='F',
                      alternator])
        for string in ['', 'FFF', 'fff']:
            self.assertTrue(match(rx1, string))
            self.assertTrue(match(rx2, string))
        
        rx = convert([lambda a,x: x=='a',
                      alternator,
                      lambda a,x: x=='a',
                      lambda a,x: x=='a'])
        self.assertTrue(match(rx, 'a'))
        self.assertTrue(match(rx, 'aa'))
        self.assertFalse(match(rx, 'aaa'))
        
        rx = convert([lambda a,x: len(x)==1 and 'a'<=x<='z',
                      alternator,
                      lambda a,x: x=='a',
                      lambda a,x: x=='b',
                      lambda a,x: x=='c'])
        self.assertFalse(match(rx, 'dabc'))
        self.assertTrue(match(rx, 'abc'))
        self.assertTrue(match(rx, 'a'))
        self.assertTrue(match(rx, 'b'))
        self.assertTrue(match(rx, 'c'))
        self.assertTrue(match(rx, 'd'))
    def test_star(self):
        rx = convert([lambda a,x:x=='a',
                      kleene_star])
        rx1 = convert([lambda a,x:x=='b',
                       lambda a,x:x=='a',
                      kleene_star])
        for i in range(10):
            self.assertTrue(match(rx, 'a'*i))
            self.assertTrue(match(rx1, 'b'+'a'*i))
            self.assertFalse(match(rx, 'b'+'a'*i))
        
        rx = convert([lambda a,x:'a'<=x<='z',
                      kleene_star,
                      lambda a,x:'A'<=x<='Z',
                      kleene_star])
        test = 'jafdhjkfl'
        for i in range(10):
            self.assertTrue(match(rx, test[:i]))
            self.assertTrue(match(rx, test.upper()[:i]))
            self.assertTrue(match(rx, test[:i]+test.upper()[:i]))
        
        rx = convert([lambda a,x:x=='t',
                      lambda a,x:x=='e',
                      lambda a,x:x=='s',
                      lambda a,x:x=='t',
                      lambda a,x:x=='_',
                      lambda a,x:'a'<=x<='z',
                      lambda a,x:'a'<=x<='z' or '0'<=x<='9',
                      kleene_star])
        self.assertTrue(match(rx, 'test_me'))
    def test_plus(self):
        rx = convert([lambda a,x:x=='a',
                      kleene_plus])
        rx1 = convert([lambda a,x:x=='b',
                       lambda a,x:x=='a',
                      kleene_plus])
        self.assertFalse(match(rx, ''))
        self.assertFalse(match(rx1, 'b'))
        self.assertFalse(match(rx, 'b'))
        for i in range(1,10):
            self.assertTrue(match(rx, 'a'*i))
            self.assertTrue(match(rx1, 'b'+'a'*i))
            self.assertFalse(match(rx, 'b'+'a'*i))
        
        rx = convert([lambda a,x:'a'<=x<='z',
                      kleene_plus,
                      lambda a,x:'A'<=x<='Z',
                      kleene_plus])
        test = 'jafdhjkfl'
        for i in range(1,10):
            self.assertFalse(match(rx, test[:i]))
            self.assertFalse(match(rx, test.upper()[:i]))
            self.assertTrue(match(rx, test[:i]+test.upper()[:i]))
    def test_expr(self):
        rx = convert([lambda a,x:x=='a',
                      expr,
                      lambda a,x:x=='b',
                      alternator,
                      lambda a,x:x=='!',
                      end,
                      lambda a,x:x=='c'])
        self.assertTrue(match(rx, 'abc'))
        self.assertTrue(match(rx, 'a!c'))
        self.assertFalse(match(rx, 'ab!'))
        
        rx = convert([expr,
                      lambda a,x:x=='a',
                      lambda a,x:x=='b',
                      end,
                      kleene_star])
        for i in range(10):
            self.assertTrue(match(rx, 'ab'*i))
        
        rx = convert([expr,
                      lambda a,x:x=='a',
                      alternator,
                      lambda a,x:x=='b',
                      end,
                      kleene_star,
                      lambda a,x:x=='c'])
        self.assertTrue(match(rx, 'abbabaaababac'))
        self.assertFalse(match(rx, 'abbabaaababa'))
        self.assertFalse(match(rx, 'abbabaacababa'))
    def test_optional(self):
        rx = convert([lambda a,x: x=='a',
                      option_mark])
        self.assertTrue(match(rx, 'a'))
        self.assertTrue(match(rx, ''))
        self.assertFalse(match(rx, 'b'))
        self.assertFalse(match(rx, 'aa'))
    def test_multiply(self):
        rx = convert([expr,
                      lambda a,x:x=='a',
                      lambda a,x:x=='b',
                      end,
                      multiplier(3,5)])
        for i in [0,1,2]:
            self.assertFalse(match(rx, 'ab'*i))
        for i in [3,4,5]:
            self.assertTrue(match(rx, 'ab'*i))
        self.assertFalse(match(rx, 'ab'*6))
        self.assertFalse(match(rx, 'abba'))
    def test_multiply_immediate_exit(self):
        rx = convert([expr,
                      lambda a,x:x=='a',
                      kleene_star,
                      end,
                      multiplier(4, None)])
        for i in range(6):
            self.assertTrue(match(rx, 'a'*i))
    def test_lazy(self):
        return #TESTME
        rx = convert([expr,
                      anything,
                      lazy_plus,
                      lambda a,x:x==',',
                      end,
                      kleene_star,
                      anything,
                      lazy_star,
                      lambda a,x: x=='='])
        # (.+?,)*.*?=
        self.assertTrue(match(rx, 'a,fht,b='))
        self.assertTrue(match(rx, 'a,fht,='))
        self.assertTrue(match(rx, 'b='))
        self.assertFalse(match(rx, ',fht,b='))
    
    
    
    
    
    
    def test_numerical_detection(self):
        return #TESTME
        rx = textex.compile('[0-9]+(.[0-9]+(e(\+|-)?[0-9]+)?)?')
        a = Automaton(rx)
        a.spawn()
        self.assertFalse(a.terminal())
        for c in "123": a.input(c)
        self.assertTrue(a.terminal())
        self.assertTrue(a.potential())
        a.input('.')
        self.assertFalse(a.terminal())
        self.assertTrue(a.potential())
        for c in "456": a.input(c)
        self.assertTrue(a.terminal())
        self.assertTrue(a.potential())
        for c in 'e+':
            a.input(c)
            self.assertFalse(a.terminal())
            self.assertTrue(a.potential())
        for c in "7890": a.input(c)
        self.assertTrue(a.terminal())
        self.assertTrue(a.potential())
        a.input('e')
        self.assertFalse(a.terminal())
        self.assertFalse(a.potential())
    




