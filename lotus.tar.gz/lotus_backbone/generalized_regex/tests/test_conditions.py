import unittest
from src.condition import *
from src.rxconst import *

class TestSimpleCondition(unittest.TestCase):
    def test_tester(self):
        c = SimpleCondition(lambda a,s: s in 'abc')
        self.assertFalse(c(None, 'd'))
        for char in 'abc':
            self.assertTrue(c(None, char))
            r = c.replayer(None, char)
            for char2 in 'abcd':
                self.assertEqual(char==char2, r(None, char2))
    def test_epsilon(self):
        c = SimpleCondition(lambda a,s: s not in ['a', 'b', 'c'])
        self.assertFalse(c(None, epsilon))
        self.assertTrue(c(None, None))
        self.assertTrue(epsilon_transition(None, epsilon))
        self.assertFalse(epsilon_transition(None, 'a'))
    def test_neg(self):
        c = SimpleCondition(lambda a,s: s not in ['a', 'b', 'c'])
        c = -c
        self.assertFalse(c(None, epsilon))
        self.assertFalse(c(None, None))
        self.assertTrue(c(None, 'a'))
    def test_and(self):
        c1 = SimpleCondition(lambda a,s: len(s)==1 and 'a'<=s<='z')
        c2 = SimpleCondition(lambda a,s: s not in ['a', 'e', 'i', 'o', 'u'])
        c = c1 & c2
        self.assertFalse(c(None, 'a'))
        self.assertTrue(c(None, 'b'))
        self.assertTrue(c(None, 'c'))
        self.assertTrue(c(None, 'd'))
        self.assertFalse(c(None, 'a'))
        self.assertTrue(c(None, 'f'))
    def test_or(self):
        c1 = SimpleCondition(lambda a,s: len(s)==1 and 'a'<=s<='e')
        c2 = SimpleCondition(lambda a,s: len(s)==1 and '0'<=s<='9')
        c = c1 | c2
        self.assertTrue(c(None, 'b'))
        self.assertTrue(c(None, 'c'))
        self.assertTrue(c(None, 'd'))
        self.assertTrue(c(None, '1'))
        self.assertTrue(c(None, '4'))
        self.assertTrue(c(None, '7'))
        self.assertFalse(c(None, '['))
        self.assertFalse(c(None, 'f'))
        self.assertFalse(c(None, epsilon))
        
        