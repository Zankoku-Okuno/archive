import unittest

from src.rxconst import *

class TestConstants(unittest.TestCase):
    def setUp(self):
        self.consts = [epsilon, kleene_star, alternator, expr, end, capture]
    def test_is(self):
        for i in range(len(self.consts)):
            for j in range(len(self.consts)):
                if i == j:
                    self.assertIs(self.consts[i], self.consts[j])
                else:
                    self.assertIsNot(self.consts[i], self.consts[j])
    def test_eq(self):
        for i in range(len(self.consts)):
            for j in range(len(self.consts)):
                if i == j:
                    self.assertEqual(self.consts[i], self.consts[j])
                else:
                    self.assertNotEqual(self.consts[i], self.consts[j])
    def test_transition(self):
        for i in range(7):
            for j in range(7):
                self.assertFalse(epsilon_transition(i,j))
            self.assertTrue(epsilon_transition.replayer(i,j) is epsilon_transition)