import unittest

from src.graph import Graph
from src.struct import BaseVertex
from src.condition import SimpleCondition


class TestGraph(unittest.TestCase):
    def setUp(self):
        self.g = Graph()
        for i in [1,3]:
            self.g.add_vertex(i)
        self.g.add_initial(1)
        self.g.set_final(4)
        self.g.add_arc(1, lambda a,x: x == 10, 2)
        self.g.add_arc(1, lambda a,x: x == 20, 3)
        self.g.add_arc(2, lambda a,x: x == 10, 1)
        self.g.add_arc(2, lambda a,x: x == 10, 2)
        self.g.add_arc(3, lambda a,x: 0 <= x < 10, 4)
        self.g.add_arc(2, lambda a,x: 0 <= x < 10, 4)
        self.g.add_arc(1, lambda a,x: 0 <= x < 10, 4)
    def test_sets(self):
        self.assertSetEqual(set(self.g.vertices.keys()), {1,2,3,4})
        self.assertSetEqual(self.g.initial, {1})
        self.assertSetEqual(self.g.final, {4})
    def test_arcs(self):
        self.assertEqual(len(self.g[2]), 3)
        self.assertSetEqual({1,2}, {x.dest for x in self.g[2] if x.test(None, 10)})
        self.assertSetEqual({4}, {x.dest for x in self.g[2] if x.test(None, 7)})

class TestGraphArithmetic(unittest.TestCase):
    def setUp(self):
        self.a = Graph()
        self.b = Graph()
        s = {0:BaseVertex(),1:BaseVertex(),2:BaseVertex(),3:BaseVertex()}
        
        self.a.add_arc(s[0], SimpleCondition(lambda a,x:x==0), s[1])
        self.a.add_arc(s[1], SimpleCondition(lambda a,x:x==1), s[0])
        self.a.add_initial(s[0])
        self.a.add_final(s[1])
        
        self.b.add_arc(s[2], SimpleCondition(lambda a,x:x==1), s[3])
        self.b.add_arc(s[3], SimpleCondition(lambda a,x:x==0), s[2])
        self.b.add_initial(s[2])
        self.b.add_final(s[3])
    def test_setUp(self):
        e = self.a.fork()
        e.spawn()
        self.assertFalse(e.terminal())
        e.step(0)
        self.assertTrue(e.terminal())
        e.step(1)
        self.assertFalse(e.terminal())
        e.step(1)
        self.assertFalse(e.alive())
        e.step(0)
        self.assertFalse(e.alive())
        e = self.b.fork()
        e.spawn()
        self.assertFalse(e.terminal())
        e.step(1)
        self.assertTrue(e.terminal())
        e.step(0)
        self.assertFalse(e.terminal())
        e.step(0)
        self.assertFalse(e.alive())
        e.step(1)
        self.assertFalse(e.alive())
    def test_add(self):
        c = self.a + self.b
        self.assertEqual(len(c.initial), len(c.final), 2)
        e = c.fork()
        e.spawn()
        for i,s in [(0,0),(1,1),(2,1)]:
            self.assertEqual(bool(e.terminal()), [False, True, False][i])
            e.step(s)
        self.assertFalse(e.alive())
        e.spawn()
        for i,s in [(0,1),(1,0),(2,0)]:
            self.assertEqual(bool(e.terminal()), [False, True, False][i])
            e.step(s)
        self.assertFalse(e.alive())
    def test_wrapped_add(self):
        from src.engine import Machine
        m = Machine(self.a)
        m.graph += self.b
        e = Graph().fork()
        e.machine = m
        e.spawn()
        for i,s in [(0,0),(1,1),(2,1)]:
            self.assertEqual(bool(e.terminal()), [False, True, False][i])
            e.step(s)
        self.assertFalse(e.alive())
        e.spawn()
        for i,s in [(0,1),(1,0),(2,0)]:
            self.assertEqual(bool(e.terminal()), [False, True, False][i])
            e.step(s)
        self.assertFalse(e.alive())
        




