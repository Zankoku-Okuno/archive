import unittest

from src.graph import Graph
from src.struct import *
from src.agent import *
from src.rxconst import *
from src.condition import *

from functools import reduce
class PimpedTestCase(unittest.TestCase):
    def assertStateIs(self, expected, engine=None):
        if engine is None: engine = self.e
        res = engine.agents
        self.assertEqual(len(res), reduce(lambda x,y:x+len(expected[y]), expected, 0))
        self.assertSetEqual({x.peek() for x in res}, set(expected.keys()))
        for loc in expected.keys():
            self.assertSetEqual({x.bounds for x in res if x.peek() is loc},
                                {x.bounds for x in expected[loc]})

class TestDFA(PimpedTestCase):
    def setUp(self):
        self.s1 = BaseVertex()
        self.s2 = BaseVertex()
        self.s3 = BaseVertex()
        self.g = Graph()
        self.g.add_arc(self.s1, SimpleCondition(lambda a,x : x == 0), self.s1)
        self.g.add_arc(self.s1, SimpleCondition(lambda a,x : x == 1), self.s2)
        self.g.add_arc(self.s2, SimpleCondition(lambda a,x : x == 0), self.s3)
        self.g.add_arc(self.s2, SimpleCondition(lambda a,x : x == 1), self.s2)
        self.g.add_arc(self.s3, SimpleCondition(lambda a,x : x == 0), self.s1)
        self.g.add_arc(self.s3, SimpleCondition(lambda a,x : x == 1), self.s1)
        self.g.set_initial(self.s1)
        self.g.set_final(self.s3)
        self.e = self.g.fork()
    def test_spawn(self):
        self.e.spawn()
        self.assertSetEqual({self.s1}, {a.peek() for a in self.e.agents})
        self.assertSetEqual({Bounds(0,0)}, {a.bounds for a in self.e.agents})
        self.e.spawn(Agent(3,5))
        self.assertSetEqual({self.s1}, {a.peek() for a in self.e.agents})
        self.assertSetEqual({Bounds(0,0), Bounds(3,5)}, {a.bounds for a in self.e.agents})
    def test_step(self):
        self.e.spawn()
        self.e.step(0)
        self.assertStateIs({self.s1: {Agent(0,1)}})
        self.e.step(1)
        self.assertStateIs({self.s2: {Agent(0,2)}})
        nu = Agent(2)
        nu.push(self.s1)
        self.e.agents.add(nu)
        agents = self.e.step(0)
        self.assertStateIs({self.s1: {Agent(2,3)}, self.s3: {Agent(0,3)}})
        nu1, nu2 = Agent(2), Agent(0,2)
        nu1.push(self.s1)
        nu2.push(self.s2)
        self.e.agents = {nu1, nu2}
        agents = self.e.step(1)
        self.assertStateIs({self.s2: {Agent(2,3), Agent(0,3)}})

class TestNFA(PimpedTestCase):
    def setUp(self):
        self.s1 = BaseVertex()
        self.s2 = BaseVertex()
        self.s3 = BaseVertex()
        self.g = Graph()
        self.g.add_arc(self.s1, SimpleCondition(lambda a,x : x == 0), self.s1)
        self.g.add_arc(self.s1, SimpleCondition(lambda a,x : x == 1), self.s1)
        self.g.add_arc(self.s1, SimpleCondition(lambda a,x : x == 1), self.s2)
        self.g.add_arc(self.s2, SimpleCondition(lambda a,x : x == 0), self.s3)
        self.g.add_initial(self.s1)
        self.g.add_final(self.s3)
        self.e = self.g.fork()
    def test_update(self):
        self.e.spawn()
        self.e.step(0)
        self.assertStateIs({self.s1: {Agent(0,1)}})
        self.e.step(1)
        self.assertStateIs({self.s1: {Agent(0,2)}, self.s2: {Agent(0,2)}})
        agents = self.e.step(1)
        agents = self.e.step(1)
        self.assertStateIs({self.s1: {Agent(0,4)}, self.s2: {Agent(0,4)}})
        agents = self.e.step(0)
        self.assertStateIs({self.s1: {Agent(0,5)}, self.s3: {Agent(0,5)}})

class TestENFA(PimpedTestCase):
    def test_spawn(self):
        s1, s2 = BaseVertex(), BaseVertex()
        g = Graph()
        g.add_arc(s1, epsilon_transition, s2)
        g.add_arc(s2, epsilon_transition, s2)
        g.set_initial(s1)
        e = g.fork()
        e.spawn()
        self.assertStateIs({s1: {Agent()}, s2: {Agent()}}, e)
    def test_update(self):
        s1, s2, s3, s4 = BaseVertex(), BaseVertex(), BaseVertex(), BaseVertex()
        g = Graph()
        g.add_arc(s1, SimpleCondition(lambda a,x: x == 0), s2)
        g.add_arc(s3, SimpleCondition(lambda a,x: x == 1), s4)
        g.add_arc(s1, epsilon_transition, s3)
        g.add_arc(s2, epsilon_transition, s1)
        g.add_arc(s2, epsilon_transition, s3)
        g.add_initial(s1)
        self.e = g.fork()
        self.e.spawn()
        self.assertStateIs({s1: {Agent()}, s3: {Agent()}})
        self.e.step(1)
        self.assertStateIs({s4: {Agent(0,1)}})
        self.e.step('hello!')
        self.assertStateIs(dict())
        self.e.spawn(Agent())
        self.assertStateIs({s1: {Agent()}, s3: {Agent()}})
        self.e.step(0)
        self.assertStateIs({s1: {Agent(0,1)}, s2: {Agent(0,1)}, s3: {Agent(0,1)}})
        self.e.step(0)
        self.assertStateIs({s1: {Agent(0,2)}, s2: {Agent(0,2)}, s3: {Agent(0,2)}})
        self.e.step(1)
        self.assertStateIs({s4: {Agent(0,3)}})

class TestMultiplicativeFA(PimpedTestCase):
    def test_simple(self):
        ss1, ss2 = BaseVertex(), BaseVertex()
        sg = Graph()
        for i in [0,1]: [sg.add_initial, sg.add_final][i]([ss1, ss2][i])
        sg.add_arc(ss1, lambda a,x: x=='a', ss2)
        s1,s2 = MultiplicativeVertex(sg, 3,5), BaseVertex()
        g = Graph()
        for i in [0,1]: [g.add_initial, g.add_final][i]([s1, s2][i])
        g.add_arc(s1, lambda a,x:x=='b', s2)
        e = g.fork()
        e.spawn()
        self.assertTrue(e.alive())
        self.assertFalse(e.terminal())
        self.assertSetEqual({3}, {len(x) for x in e.agents})
    def setUp(self):
        ss1, ss2, ss3, ss4, ss5 = BaseVertex(), BaseVertex(), BaseVertex(), BaseVertex(), BaseVertex()
        sg = Graph()
        sg.add_initial(ss1)
        for v in [ss3,ss5]: sg.add_final(v)
        sg.add_arc(ss1, SimpleCondition(lambda a,x:x==0), ss2)
        sg.add_arc(ss2, SimpleCondition(lambda a,x:x==1), ss3)
        sg.add_arc(ss3, epsilon_transition, ss2)
        sg.add_arc(ss1, SimpleCondition(lambda a,x:x==1), ss4)
        sg.add_arc(ss4, SimpleCondition(lambda a,x:x==0), ss5)
        sg.add_arc(ss5, epsilon_transition, ss4)
        s1, s2, s3 = BaseVertex(), MultiplicativeVertex(sg, 2, None), MultiplicativeVertex(sg, 0, 3)
        g = Graph()
        g.add_arc(s1, SimpleCondition(lambda a,x:x==2), s2)
        g.add_arc(s2, SimpleCondition(lambda a,x:x==2), s3)
        for i in [0,1]: [g.add_initial, g.add_final][i]([s1, s3][i])
        self.e = g.fork()
        self.e.spawn()
    def test_unbasic(self):
        for i in [2,0,1,1,1,0,1,2,1,0]:
            #print(i)
            self.e.step(i)
            #print(i, '::', [x.stack for x in e.agents])
            #print()
            self.assertTrue(self.e.alive())
    def test_atleast(self):
        for i in [2,0,1,1,1]:
            self.e.step(i)
            self.assertTrue(self.e.alive())
        self.e.step(2)
        self.assertFalse(self.e.alive())
    def test_upto(self):
        for i in [2,0,1,0,1,2]:
            self.e.step(i)
            self.assertTrue(self.e.alive())
        self.assertTrue(self.e.terminal())
        for i in [0,1,0,1,0,1,1]:
            self.e.step(i)
            self.assertTrue(self.e.alive())
        self.e.step(0)
        self.assertFalse(self.e.alive())
    def test_exactly(self):
        ss1, ss2 = BaseVertex(), BaseVertex()
        sg = Graph()
        for i in [0,1]: [sg.add_initial, sg.add_final][i]([ss1, ss2][i])
        sg.add_arc(ss1, SimpleCondition(lambda a,x: x=='a'), ss2)
        s1 = MultiplicativeVertex(sg, 5,5)
        g = Graph()
        for i in [0,1]: [g.add_initial, g.add_final][i](s1)
        e = g.fork()
        e.spawn()
        for i in range(5):
            self.assertTrue(e.alive())
            self.assertFalse(e.terminal())
            e.step('a')
        self.assertTrue(e.terminal())
        e.step('a')
        self.assertFalse(e.alive())
        self.assertFalse(e.terminal())

class TestCFA(PimpedTestCase):
    def setUp(self):
        ss1, ss2 = BaseVertex(), BaseVertex()
        sg = Graph()
        sg.add_initial(ss1)
        sg.add_final(ss2)
        sg.add_arc(ss1, SimpleCondition(lambda a,x: x in {2,3,5,7,9}), ss2)
        s1, s2, s3 = BaseVertex(), CapturingVertex(sg, 'cap'), BaseVertex()
        g = Graph()
        #g.add_arc(s1, SimpleCondition(lambda a,x:x==0), s1)
        for i in [0,1,2]: g.add_arc([s1,s2,s1][i], SimpleCondition(lambda a,x: x == 0), [s2,s3,s1][i])
        for i in [0,1]: [g.add_initial, g.add_final][i]([s1,s3][i])
        self.e = g.fork()
    def test_one(self):
        e = self.e
        e.spawn()
        e.step(0)
        e.step(0)
        e.step(0)
        self.assertTrue(e.alive())
        self.assertEqual({0, 1}, {len(x.groups_builder.in_progress) for x in e.alive()})
        self.assertEqual({0}, {len(x.groups_builder.in_progress['cap']) for x in e.alive()
                               if len(x.groups_builder.in_progress)==1})
        e.step(7)
        self.assertTrue(e.alive())
        self.assertEqual({0}, {len(x.groups_builder.in_progress) for x in e.alive()})
        self.assertEqual({1}, {len(x.groups._data['cap']) for x in e.alive()
                               if len(x.groups_builder.in_progress)==0})
        e.step(0)
        self.assertTrue(e.terminal())
        self.assertFalse(e.potential())
        self.assertEqual(1, len(e.terminal()))
        a = e.terminal().pop()
        self.assertEqual(len(a.groups), 1)
        self.assertEqual(len(a.groups['cap']), 1)
        self.assertEqual(a.groups['cap'][0], Bounds(3,4))
        br = a.backreferences['cap'].graph.fork()
        for i in range(10):
            br.spawn()
            br.step(i)
            if i == 7:
                self.assertTrue(br.terminal())
                self.assertFalse(br.potential())
            else:
                self.assertFalse(br.alive())
        

class TestBRFA(PimpedTestCase):
    def setUp(self):
        # `([ab]`[ab]*)\2\1\2  matches  abaaabab (also: abbbabbb but not abbaabbb)
        sss1, sss2 = BaseVertex(), BaseVertex()
        ssg = Graph()
        ssg.add_arc(sss1, SimpleCondition(lambda a,x:x in 'ab'), sss2)
        for i in [0,1]: [ssg.add_initial, ssg.add_final][i]([sss1, sss2][i])
        ss1, ss2 = BaseVertex(), CapturingVertex(ssg, 2)
        sg = Graph()
        sg.add_arc(ss1, SimpleCondition(lambda a,x:x in 'ab'), ss2)
        sg.add_arc(ss2, epsilon_transition, ss2)
        for i in [0,1]: [sg.add_initial, sg.add_final][i]([ss1, ss2][i])
        s1, s2, s3, s4 = CapturingVertex(sg, 1), ReferencingVertex(2), ReferencingVertex(1), ReferencingVertex(2)
        g = Graph()
        for i in [0,1,2]: g.add_arc([s1,s2,s3][i], epsilon_transition, [s2,s3,s4][i])
        for i in [0,1]: [g.add_initial, g.add_final][i]([s1, s4][i])
        self.e = g.fork()
    def test_empty(self):
        #matches aa = (a())()(a())()
        e = self.e
        e.spawn()
        e.step('a')
        e.step('a')
        self.assertTrue(e.alive())
        self.assertFalse(e.terminal())
        e.step('a')
        self.assertFalse(e.terminal())
    def test_one(self):
        #matches abbabb = (a(b))(b)(a(b))(b)
        e = self.e
        e.spawn()
        e.step('a')
        e.step('b')
        self.assertTrue(e.alive())
        self.assertFalse(e.terminal())
        # == interlude
        a = {a for a in e.alive() if len(a.groups)==2}.pop()
        se = a.backreferences[2].graph.fork()
        se.spawn()
        se.step('b')
        self.assertTrue(se.terminal())
        self.assertFalse(se.potential())
        se = a.backreferences[1].graph.fork()
        se.spawn()
        se.step('a')
        self.assertTrue(se.alive())
        self.assertFalse(se.terminal())
        se.spawn()
        se.step('b')
        self.assertTrue(se.terminal())
        self.assertFalse(se.potential())
        # == edulretni
        self.assertEqual
        e.step('b')
        e.step('a')
        e.step('b')
        self.assertTrue(e.alive())
        self.assertFalse(e.terminal())
        e.step('b')
        self.assertTrue(e.terminal())
    def test_two(self):
        #matches abaaabab = (a(b|a))(a)(a(ba))(b), not abaaababa
        e = self.e
        e.spawn()
        e.step('a')
        e.step('b')
        e.step('a')
        self.assertTrue(e.alive())
        self.assertFalse(e.terminal())
        self.assertTrue({a for a in e.alive() if len(a.groups)==2})
        e.step('a')
        e.step('a')
        e.step('b')
        e.step('a')
        e.step('b')
        self.assertTrue(e.terminal())
        self.assertTrue(e.potential())
        e.step('a')
        self.assertFalse(e.terminal())
    