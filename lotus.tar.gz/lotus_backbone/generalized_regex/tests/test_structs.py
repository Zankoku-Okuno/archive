import unittest

from src.condition import *
from src.struct import *
from src.agent import Agent, Bounds
from src.graph import Graph

class TestArcAlsoStateID(unittest.TestCase):
    def setUp(self):
        self.s1, self.s2 = BaseVertex(), BaseVertex()
        self.a = Arc(SimpleCondition(lambda a,s: 3<s<=5), self.s2)
    def test_test(self):
        self.assertFalse(self.a.test(None, 3))
        self.assertTrue(self.a.test(None, 4))
        self.assertTrue(self.a.test(None, 5))
        self.assertFalse(self.a.test(None, 6))
    def test_replay(self):
        for i in [4,5]:
            r = self.a.replayer(None, i)
            for j in [3,4,5,6]:
                self.assertEqual(i==j, r(None, j))
    def test_dest(self):
        self.assertTrue(self.s2 is self.a.dest)
        self.assertTrue(self.s2 == self.a.dest)
        self.assertFalse(self.s1 is self.a.dest)
        self.assertFalse(self.s1 == self.a.dest)

class TestBasicStateTransition(unittest.TestCase):
    def setUp(self):
        self.s1 = BaseVertex()
        self.s2 = BaseVertex()
        self.s3 = BaseVertex()
        
        self.t = Graph()
        self.t.add_arc(self.s1, SimpleCondition(lambda a,x : x == 1), self.s2)
        self.t.add_arc(self.s1, SimpleCondition(lambda a,x : x == 2), self.s3)
        self.t.add_arc(self.s2, SimpleCondition(lambda a,x : x == 1), self.s2)
        self.t.add_arc(self.s2, SimpleCondition(lambda a,x : x == 1), self.s1)
    
    def test_entrance(self):
        a = Agent()
        self.assertEqual(BaseVertex().on_enter(a), {a})
    
    def test_transition1(self):
        a = Agent()
        res = self.s1.update(a, 1, self.t)
        self.assertEqual(1, len(res))
        nuA = res.pop()
        self.assertEqual(self.s2, nuA.stack[-1])
        self.assertNotEqual(a, nuA)
        self.assertFalse(a is nuA)
        self.assertEqual(Bounds(0,1), nuA.bounds)
    def test_transition2(self):
        a = Agent()
        res = self.s1.update(a, 2, self.t)
        self.assertEqual(1, len(res))
        res = res.pop()
        self.assertEqual(self.s3, res.stack[-1])
        self.assertNotEqual(a, res)
        self.assertFalse(a is res)
        self.assertEqual(a.groups, res.groups)
        self.assertEqual(Bounds(0,1), res.bounds)
    def test_transition3_4(self):
        a = Agent()
        a.bounds = Bounds(0,1)
        res = list(self.s2.update(a, 1, self.t))
        self.assertEqual(2, len(res))
        self.assertSetEqual({self.s1, self.s2}, {nuA.stack[-1] for nuA in res})
        for nuA in res:
            self.assertEqual(Bounds(0,2), nuA.bounds)
    def test_transitions_merge(self):
        a1 = Agent()
        a2 = Agent()
        res = self.s1.update(a1, 2, self.t) | self.s1.update(a2, 2, self.t)
        self.assertEqual(1, len(res))
        res = res.pop()
        self.assertEqual(self.s3, res.stack[-1])
    def test_transitions_kill(self):
        res = self.s2.update(Agent(), 2, self.t)
        self.assertEqual(0, len(res))
        