import unittest

from src.rxconst import epsilon_transition
from src.struct import BaseVertex
from src.agent import Agent
from src.graph import Graph
from src.condition import SimpleCondition

from src.engine import Engine
class TestLowLevelAutomaton(unittest.TestCase):
    def setUp(self):
        self.s1, self.s2, self.s3, self.s4, self.s5, self.s6 = BaseVertex(), BaseVertex(), BaseVertex(), BaseVertex(), BaseVertex(), BaseVertex()
        self.g = Graph()
        self.g.add_arc(self.s1, SimpleCondition(lambda a,s: s == 0), self.s2)
        self.g.add_arc(self.s2, SimpleCondition(lambda a,s: s == 1), self.s3)
        self.g.add_arc(self.s3, SimpleCondition(lambda a,s: s == 0), self.s4)
        self.g.add_arc(self.s4, epsilon_transition, self.s2)
        self.g.add_arc(self.s2, epsilon_transition, self.s5)
        self.g.add_arc(self.s5, SimpleCondition(lambda a,s: s == 1), self.s6)
        self.g.add_initial(self.s1)
        self.g.add_initial(self.s2)
        self.g.add_final(self.s5)
        self.g.add_final(self.s6)
        self.a = self.g.fork()
    def test_spawn(self):
        self.assertFalse(self.a.alive())
        self.assertFalse(self.a.potential())
        self.assertFalse(self.a.terminal())
        self.a.spawn()
        self.assertTrue(self.a.alive())
        self.assertTrue(self.a.potential())
        self.assertTrue(self.a.terminal())
    def test_refuse_input(self):
        self.a.spawn()
        self.assertSetEqual({self.s1, self.s2, self.s5}, {x.peek() for x in self.a.agents})
        self.a.step(0)
        self.assertEqual(self.a._input, [0])
        self.assertTrue(self.a.alive())
        self.assertTrue(self.a.potential())
        self.assertTrue(self.a.terminal())
        self.a.step(1)
        self.assertEqual(self.a._input, [0, 1])
        self.assertTrue(self.a.alive())
        self.assertTrue(self.a.potential())
        self.assertTrue(self.a.terminal())
        self.a.step(1)
        self.assertEqual(self.a._input, [0, 1, 1])
        self.assertFalse(self.a.alive())
        self.assertFalse(self.a.potential())
        self.assertFalse(self.a.terminal())
    def test_accept_input(self):
        self.a.spawn()
        for i in [0,1,0,1,0,1,0]:
            self.a.step(i)
        self.assertTrue(self.a.alive())
        self.assertTrue(self.a.potential())
        self.assertTrue(self.a.terminal())
        self.assertSetEqual({Agent(0,7)}, self.a.extract())
        self.a.spawn()
        for i in [1,0]:
            self.a.step(i)
        self.assertEqual(self.a._input, [0,1,0,1,0,1,0,1,0])
        self.assertTrue(self.a.alive())
        self.assertTrue(self.a.potential())
        self.assertTrue(self.a.terminal())
        self.assertSetEqual({Agent(0,9), Agent(7,9)}, self.a.extract())
    def test_flush(self):
        self.a.spawn()
        for i in [1,0,1,0]:
            self.a.step(i)
            self.assertTrue(self.a.alive())
        self.assertEqual(4, len(self.a._input))
        self.a.flush()
        self.assertFalse(self.a.alive())
        self.assertEqual(4, len(self.a._input))




