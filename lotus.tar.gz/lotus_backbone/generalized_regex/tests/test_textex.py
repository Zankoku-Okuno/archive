import unittest

from stovokor.sed import Reader, AnnotatingReader
from src.textex import char_class as cc

class TestClassCompiler(unittest.TestCase):
    def setUp(self):
        self.c = cc.ClassParser()
        self.r = Reader(cc.tokenizer, self.c)
    def test_tokenizing1(self):
        o = []
        r = Reader(cc.tokenizer, o)
        r.feed(r'a-zD-Z')
        r.eof()
        self.assertEqual(['a','-','z','D','-','Z'], o)
    def test_tokenizing2(self):
        o = []
        r = Reader(cc.tokenizer, o)
        r.feed(r'\[^\]a-z')
        r.eof()
        self.assertEqual(['\\','[','^','\\]','a','-','z'], o)
    def test_one(self):
        self.r.feed(r'55a-zD-Z-')
        self.r.eof()
        o = self.c.compile()
        for i in range(ord('a'), ord('z')):
            self.assertTrue(o(None, chr(i)))
        for i in range(ord('A'), ord('C')):
            self.assertFalse(o(None, chr(i)))
        for i in range(ord('D'), ord('Z')):
            self.assertTrue(o(None, chr(i)))
        for char in '0123456789':
            if char == '5':
                self.assertTrue(o(None, char))
            else:
                self.assertFalse(None, o(None, char))
        self.assertTrue(o(None, '-'))
    def test_two(self):
        self.r.feed(r'^-\]')
        self.r.eof()
        o = self.c.compile()
        for i in range(ord(']'), ord('^')):
            self.assertTrue(o(None, chr(i)))
    def test_anti(self):
        self.r.feed(r'55a-zD-Z-')
        self.r.eof()
        o = self.c.compile(False)
        for i in range(ord('a'), ord('z')):
            self.assertFalse(o(None, chr(i)))
        for i in range(ord('A'), ord('C')):
            self.assertTrue(o(None, chr(i)))
        for i in range(ord('D'), ord('Z')):
            self.assertFalse(o(None, chr(i)))
        for char in '0123456789':
            if char == '5':
                self.assertFalse(o(None, char))
            else:
                self.assertTrue(o(None, char))
        self.assertFalse(o(None, '-'))
    def test_holistic_api(self):
        p1 = cc.compile('[^a-z-]')
        p2 = cc.compile('[a-z-]')
        for i in range(ord('a'), ord('z')):
            self.assertFalse(p1(None, chr(i)))
            self.assertTrue(p2(None, chr(i)))
        for i in range(ord('A'), ord('Z')):
            self.assertTrue(p1(None, chr(i)))
            self.assertFalse(p2(None, chr(i)))
        self.assertFalse(p1(None, '-'))
        self.assertTrue(p2(None, '-'))

class TestQuoteCompiler(unittest.TestCase):
    def test_one(self):
        
        self.assertSetEqual({'name'}, set(cc.var_names('"name"')))
    def test_two(self):
        self.assertSetEqual({'name','stuff'}, set(cc.var_names('"name&stuff"')))
    def test_three(self):
        self.assertSetEqual({'name&stuff'}, set(cc.var_names(r'"name\&stuff"')))
    def test_four(self):
        self.assertSetEqual({'name\\','stuff'}, set(cc.var_names(r'"name\\&stuff"')))

from src.textex import const
from src.rxconst import *
from src.textex import expression as ex
class ToyInterpreter:
    def __init__(self, output):
        self.output = output
    def append(self, token):
        if token in const.kw_lookup:
            self.output.append(const.kw_lookup[token])
        elif len(token) == 2 and token[0] == '\\':
            self.output.append(token[1])
        else:
            self.output.append(token)
class TestMainTokenizer(unittest.TestCase):
    def setUp(self):
        self.o = []
        self.r = Reader(ex.tokenizer, ToyInterpreter(self.o))
    def test_one(self):
        self.r.feed(r"abc")
        self.r.eof()
        self.assertEqual(['a','b','c'], self.o)
    def test_two(self):
        self.r.feed(r"a(b\dc)+")
        self.r.eof()
        self.assertEqual(['a',expr,'b',const.kw_lookup['\d'], 'c',end,kleene_plus], self.o)
    def test_three(self):
        self.r.feed(r'((\(+)0|1)*')
        self.r.eof()
        self.assertEqual([expr,expr,'(',kleene_plus,end,'0',alternator,'1',end,kleene_star], self.o)
    def test_four(self):
        self.r.feed(r'\\\(\)\[]\+\*\a')
        self.r.eof()
        self.assertEqual(['\\', '(',')','[',']','+','*','\\', 'a'], self.o)
    def test_five(self):
        self.r.feed(r'a[^\[^\]]1')
        self.r.eof()
        self.assertEqual(['a', r'[^\[^\]]', '1'], self.o)

class TestMainParser(unittest.TestCase):
    def setUp(self):
        self.p = ex.MainParser()
        self.r = AnnotatingReader(ex.tokenizer, self.p)
    def test_basic(self):
        self.r.feed(r'abc')
        self.r.eof()
        self.assertEqual(len(self.p.out), 3)
        for i in range(3):
            for j in range(3):
                if i == j:
                    self.assertTrue(self.p.out[i](None, 'abc'[j]))
                else:
                    self.assertFalse(self.p.out[i](None, 'abc'[j]))
    def test_escapes(self):
        self.r.feed(r'\(\[\*')
        self.r.eof()
        self.assertEqual(len(self.p.out), 3)
        for i in range(3):
            for j in range(3):
                if i == j:
                    self.assertTrue(self.p.out[i](None, '([*'[j]))
                else:
                    self.assertFalse(self.p.out[i](None, '([*'[j]))
    def test_keywords(self):
        self.r.feed(r'*|+')
        self.r.eof()
        self.assertEqual(len(self.p.out), 3)
        for i in range(3):
            self.assertEqual([kleene_star,alternator,kleene_plus][i], self.p.out[i])
    def test_branching(self):
        from arboreum.tree import Tree
        self.r.feed(r'a(777)*c')
        self.r.eof()
        self.assertEqual(len(self.p.out), 8)
        self.assertTrue(self.p.out[1] is expr)
        st = self.p.out[2:5]
        for i in range(3):
            self.assertTrue(st[i](None, '7'))
            self.assertFalse(st[i](None, '8'))
            self.assertFalse(st[i](None, '6'))
    def test_classes(self):
        self.r.feed(r'[&*|][^abc]')
        self.r.eof()
        self.assertEqual(2, len(self.p.out))
        for i in range(3):
            self.assertTrue(self.p.out[0](None, '&*|'[i]))
            self.assertTrue(self.p.out[1](None, '&*|'[i]))
            self.assertFalse(self.p.out[0](None, 'abc'[i]))
            self.assertFalse(self.p.out[1](None, 'abc'[i]))

from src.textex.textex import compile
class TestMainCompiler(unittest.TestCase):
    def test_literal(self):
        rx = compile(r'abc')
        e = rx.fork()
        e.spawn()
        e.step('a')
        self.assertFalse(e.terminal())
        e.step('b')
        self.assertFalse(e.terminal())
        e.step('c')
        self.assertTrue(e.terminal())
        e = rx.fork()
        e.spawn()
        self.assertTrue(e.alive())
        e.step('A')
        self.assertFalse(e.alive())
    def test_digit(self):
        rx = compile(r'{\d\d}')
        e = rx.fork()
        e.spawn()
        for i in ['{', '3', '0', '}']:
            self.assertTrue(e.alive())
            self.assertFalse(e.terminal())
            e.step(i)
        self.assertTrue(e.terminal())
    def test_exact_multiple(self):
        s = r'a{3}'
        o = []
        r = Reader(ex.tokenizer, o)
        r.feed(r'a{3}')
        r.eof()
        self.assertEqual(['a','{3}'], o)
        
        rx = compile(s)
        e = rx.fork()
        e.spawn()
        for i in range(3):
            self.assertFalse(e.terminal())
            e.step('a')
        self.assertTrue(e.terminal())
        e.step('a')
        self.assertFalse(e.alive())
    def test_atleast_multiple(self):
        rx = compile(r'a{3+}')
        e = rx.fork()
        e.spawn()
        for i in range(3):
            self.assertFalse(e.terminal())
            e.step('a')
        for i in range(3):
            self.assertTrue(e.terminal())
            e.step('a')
        self.assertTrue(e.potential())
    def test_upto_multiple(self):
        rx = compile(r'a{-3}')
        e = rx.fork()
        e.spawn()
        for i in range(4):
            self.assertTrue(e.terminal())
            e.step('a')
        self.assertFalse(e.alive())
    def test_between_mutiple(self):
        rx = compile(r'a{2,8}')
        e = rx.fork()
        e.spawn()
        e.step('a')
        self.assertTrue(e.alive())
        self.assertFalse(e.terminal())
        for i in range(7):
            e.step('a')
            self.assertTrue(e.terminal())
        self.assertFalse(e.potential())
    def test_escape_brace(self):
        rx = compile(r'a\{3}')
        e = rx.fork()
        e.spawn()
        e.step('a')
        e.step('a')
        self.assertFalse(e.alive())
        e = rx.fork()
        e.spawn()
        for i in ['a', '{', '3', '}']:
            e.step(i)
        self.assertTrue(e.terminal())
        self.assertFalse(e.potential())
    def test_escaped_quote(self):
        rx = compile(r'a\"3}')
        e = rx.fork()
        e.spawn()
        for i in ['a', '"', '3', '}']:
            e.step(i)
        self.assertTrue(e.terminal())
        self.assertFalse(e.potential())
    def test_late_binding(self):
        from stovokor.local import BaseAlphabet
        a = BaseAlphabet()
        a.add_range('alpha', 'a', 'z')
        a.add_all('Vowel', 'aeiouAEIOU')
        with self.assertRaises(Exception):
            a.bind('dne')
        
        rx = compile(r'"alpha"', a)
        e = rx.fork()
        t1 = [True, True, True, False, False]
        for i in range(5):
            e.spawn()
            e.step('akqAQ'[i])
            self.assertEqual(t1[i], bool(e.terminal()))
            self.assertFalse(e.potential())
        
        rx = compile(r'"Vowel"', a)
        e = rx.fork()
        t2 = [True, False, False, True, False]
        for i in range(5):
            e.spawn()
            e.step('akqAQ'[i])
            self.assertEqual(t2[i], bool(e.terminal()))
            self.assertFalse(e.potential())
        
        rx = compile(r'"Vowel&alpha"', a)
        e = rx.fork()
        for i in range(5):
            e.spawn()
            e.step('akqAQ'[i])
            self.assertEqual(t1[i] & t2[i], bool(e.terminal()))
            self.assertFalse(e.potential())

#TESTME paren matching




