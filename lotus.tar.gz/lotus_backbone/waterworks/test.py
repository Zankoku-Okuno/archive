#! /usr/bin/python3

import unittest

from test.structs import *
from test.merging import *

unittest.main()