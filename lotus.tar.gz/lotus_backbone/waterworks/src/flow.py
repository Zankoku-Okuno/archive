"""A flow is not sufficient for tokenizing a file; instead, it is used to modify
existing contexts."""

class TokenizerFlow:
    def __init__(self):
        self.charstream = None
        self.line_continue = None
        self.tabsize = None
        self.ignore_empty_lines = None
        self.detect_indentation = None
        self.collapse_whitespace = None
        self.discard_whitespace = None
        self.phonemes = []
        self.keywords = set()
        self.patterns = set()
        self.delimiters = set()

    def set_charstream(self, source):
        self.charstream = source.compile()
    def set_line_continue(self, source):
        self.line_continue = source.compile()
    def set_tabsize(self, source):
        self.tabsize = source.compile()
    def set_ignore_empty_lines(self, source):
        self.ignore_empty_lines = source.compile()
    def set_detect_indentation(self, source):
        self.detect_indentation = source.compile()
    def set_collapse_whitespace(self, source):
        self.collapse_whitespace = source.compile()
    def set_discard_whitespace(self, source):
        self.discard_whitespace = source.compile()
    def add_phoneme(self, source):
        self.phonemes.append(source)
    def add_keyword(self, source):
        self._add_or_replace(source, self.keywords)
    def add_pattern(self, source):
        self._add_or_replace(source, self.patterns)
    def add_delimiter(self, source):
        self._add_or_replace(source, self.delimiters)
    def _add_or_replace(self, source, S): #TODO turn back into sets, easier to modify
        x, extant = source.compile(), None
        for item in S:
            if item.compile() == x:
                extant = item
                break
        if extant:
            S.remove(extant)
        S.add(source)

class OpwordFlow:
    def __init__(self):
        self.new_opwords = dict()
    
    def __setitem__(self, key, source):
        self.new_opwords[key] = source
    
    #TODO when merging, remember to define a keyword for every opword

class ModuleFlow:
    def __init__(self):
        self.using = []
        self.stream = []
    
    def add_using(self, source):
        self._add_to_list(source, self.using)
    def add_stream(self, source):
        self._add_to_list(source, self.stream)
    def _add_to_list(self, source, list):
        x, out = source.text, []
        for item in list:
            if item.text == x:
                out.append(item)
        while out:
            list.remove(out.pop())
        list.append(source)

class Flow:
    def __init__(self):
        self.tokenizer = TokenizerFlow()
        self.opwords = OpwordFlow()
        self.modules = ModuleFlow()




