"""Contexts hold all the information necessary to tokenize a file, but cannot be
used to modify other contexts."""

from .struct import Isomorphism

class TokenizingContext:
    def __init__(self):
        self.charstream = None
        self.line_continue = None
        self.tabsize = None
        self.ignore_empty_lines = None
        self.detect_indentation = None
        self.collapse_whitespace = None
        self.discard_whitespace = None
        self.phonemes = []
        self.keywords = set()
        self.patterns = set()
        self.delimiters = set()

    def set_charstream(self, source):
        self.charstream = source.compile()
    def set_line_continue(self, source):
        self.line_continue = source.compile()
    def set_tabsize(self, source):
        self.tabsize = source.compile()
    def set_ignore_empty_lines(self, source):
        self.ignore_empty_lines = source.compile()
    def set_detect_indentation(self, source):
        self.detect_indentation = source.compile()
    def set_collapse_whitespace(self, source):
        self.collapse_whitespace = source.compile()
    def set_discard_whitespace(self, source):
        self.discard_whitespace = source.compile()
    def add_phoneme(self, source):
        self.phonemes.append(source.compile())
    def add_keyword(self, source):
        self._add_or_replace(source, self.keywords)
    def add_pattern(self, source):
        self._add_or_replace(source, self.patterns)
    def add_delimiter(self, source):
        self._add_or_replace(source, self.delimiters)
    def _add_or_replace(self, source, S):
        x = source.compile()
        if x in S:
            S.remove(x)
        S.add(x)

class OpwordContext:
    def __init__(self):
        self.spring_detect = Isomorphism()
        self.spring = Isomorphism()
        self.delimiter = Isomorphism()
        self.whitespace = Isomorphism()
        
        self.section = Isomorphism()
        self.header = Isomorphism()
        
        self.cpragma = Isomorphism()
        
        self._summary = [self.spring_detect,
                         self.spring,
                         self.delimiter,
                         self.whitespace,
                         
                         self.section,
                         self.header,
                         self.cpragma]

    def __setitem__(self, key, source):
        for dictionary in self._summary:
            if key in dictionary:
                dictionary[key] = source.compile()
                break
        else:
            raise KeyError(key)

class Context:
    def __init__(self):
        self.tokenizer = TokenizingContext()
        self.opwords = OpwordContext()

    def layer(self, flow):
        """Layers the statements of the passed flow onto this context
        destructively."""
        if flow.tokenizer.charstream is not None:
            self.tokenizer.charstream = flow.tokenizer.charstream
        if flow.tokenizer.line_continue is not None:
            self.tokenizer.line_continue = flow.tokenizer.line_continue
        if flow.tokenizer.tabsize is not None:
            self.tokenizer.tabsize = flow.tokenizer.tabsize
        if flow.tokenizer.ignore_empty_lines is not None:
            self.tokenizer.ignore_empty_lines = flow.tokenizer.ignore_empty_lines
        if flow.tokenizer.detect_indentation is not None:
            self.tokenizer.detect_indentation = flow.tokenizer.detect_indentation
        if flow.tokenizer.collapse_whitespace is not None:
            self.tokenizer.collapse_whitespace = flow.tokenizer.collapse_whitespace
        if flow.tokenizer.discard_whitespace is not None:
            self.tokenizer.discard_whitespace = flow.tokenizer.discard_whitespace
        for phoneme in flow.tokenizer.phonemes:
            self.tokenizer.add_phoneme(phoneme)
        for keyword in flow.tokenizer.keywords:
            self.tokenizer.add_keyword(keyword)
        for pattern in flow.tokenizer.patterns:
            self.tokenizer.add_pattern(pattern)
        for delimiter in flow.tokenizer.delimiters:
            self.tokenizer.add_delimiter(delimiter)
        for native in flow.opwords.new_opwords:
            self.opwords[native] = flow.opwords.new_opwords[native]
    
    def finalize(self):
        from stovokor.local import NormalAlphabet, SedAlphabet
        self.tokenizer.alphabet = SedAlphabet() if self.tokenizer.charstream else NormalAlphabet() #default is Normal, since charstream is None if it is not True/False
        for phoneme in self.tokenizer.phonemes:
            self.tokenizer.alphabet[None] = phoneme #HAX, but requires changes in the Alphbet api
        return self




