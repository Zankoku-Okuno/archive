

class Isomorphism:
    def __init__(self, dictionary=None):
        if dictionary is None:
            dictionary = dict()
        self._data = dictionary
    
    def __getitem__(self, value):
        return self._data[value]
    def __call__(self, key):
        out = []
        for value in self._data:
            if self._data[value] == key:
                out.append(value)
        if not out:
            raise KeyError(key)
        if len(out) > 1:
            raise KeyError(key)
        return out[0]
    def __setitem__(self, key, value):
        remove = set()
        for i in self._data:
            if self._data[i] == key:
                remove.add(i)
        for i in remove:
            del self._data[i]
        self._data[value] = key
    
    def has(self, value):
        return value in self._data
    def __contains__(self, key):
        for i in self._data:
            if self._data[i] == key:
                return True
        else:
            return False
    
    def keys(self):
        return set(self._data.values())
    def values(self):
        return set(self._data.keys())
    
    def __iter__(self):
        return self._data.values().__iter__()

    