import unittest

#okay, so now the flow linearizes within a single spring statement, cool
#anyway, to merge, we first build a dependency graph from those usings/streams
    #this will require finding the absolute paths on the compiling system
#as long as it's a poset, no problem
#now, we discard all usings except those in the root file, and everything now made inaccesible
#finally, linearize the tree:
    #maintain a mutexList, then do a depth-first left-to-right traversal
#we get the downstream context
#we apply all the flows found in linearization to it


#each file is associated with a flow
#determine the absolute file-system path for each stream
#follow those flows' streams to find more files (and get more flows)


#determine all upstream flows, create the linearization
#recursively resolve the streams for the root flow, appending them to the linearization in order, ignoring already-added flows    
#resolve the usings for the root file in order, appending
#append the root file's flow 


#dict from (absolute) filepath to flow
#when a new flow is to be added, resolve all of its streams to absolute paths
#now, use this dictionary as a graph and perform a breadth-first search for loops