import unittest

from src.struct import Isomorphism
class TestIsomorphism(unittest.TestCase):
    def setUp(self):
        self.d = Isomorphism()
    def test_access(self):
        self.d['_OPWORD_'] = 'opword'
        self.assertEqual(self.d['opword'], '_OPWORD_')
        self.assertEqual(self.d('_OPWORD_'), 'opword')
    def test_containment(self):
        self.d['_OPWORD_'] = 'opword'
        self.assertTrue('_OPWORD_' in self.d)

class Dummy:
    def __init__(self, data):
        self.compile = lambda: data

from stovokor.local import Phoneme
from stovokor.quantum import *

from src.context import *
class TestContext(unittest.TestCase):
    def setUp(self):
        self.c = Context()
        self.t = self.c.tokenizer
        self.o = self.c.opwords
    def test_tabsize(self):
        d = Dummy(3)
        self.assertTrue(self.t.tabsize is None)
        self.t.set_tabsize(d)
        self.assertEqual(self.t.tabsize, 3)
    def test_alphabet(self):
        d1 = Dummy(Phoneme('1', 'abc'))
        d2 = Dummy(Phoneme('2', 'cde'))
        self.t.add_phoneme(d1)
        self.t.add_phoneme(d2)
        from stovokor.local import BaseAlphabet
        a = BaseAlphabet()
        for phoneme in self.t.phonemes:
            a[None] = phoneme
        self.assertSetEqual({'1'}, {x.name for x in a['a']})
        self.assertSetEqual({'1'}, {x.name for x in a['b']})
        self.assertSetEqual({'1', '2'}, {x.name for x in a['c']})
        self.assertSetEqual({'2'}, {x.name for x in a['d']})
        self.assertSetEqual({'2'}, {x.name for x in a['e']})
    def test_keywords(self):
        self.t.add_keyword(Dummy(Keyword('helo')))
        self.t.add_keyword(Dummy(Keyword('hello')))
        self.assertSetEqual({x.name for x in self.t.keywords}, {'hello', 'helo'})
    def test_patterns(self):
        self.t.add_pattern(Dummy(Pattern('hello', 'Hello, world!')))
        self.t.add_pattern(Dummy(Pattern('hello', 'Hello, ([A-Z][a-z]*|world)!')))
        self.assertSetEqual({x.name for x in self.t.patterns}, {'hello'})
        self.assertSetEqual({x.pattern for x in self.t.patterns}, {'Hello, ([A-Z][a-z]*|world)!'})
    def test_delimiters(self):
        self.t.add_delimiter(Dummy(Delimiter('str', '"', '"', '\\')))
        self.t.add_delimiter(Dummy(Delimiter('str', '"', '"', '\\', '\\{', '}')))
        self.assertSetEqual({x.name for x in self.t.delimiters}, {'str'})
        self.assertSetEqual({x.weave for x in self.t.delimiters}, {'\\{'})
    def test_opwords(self):
        self.o.whitespace['_TEST_'] = Dummy('test')
        with self.assertRaises(KeyError):
            self.o['_DNE_'] = Dummy('dne')
        self.o['_TEST_'] = Dummy('hi')
        self.assertEqual('_TEST_', self.o.whitespace['hi'])

from src.flow import *
class TestFlow(unittest.TestCase):
    def setUp(self):
        self.c = Flow()
        self.t = self.c.tokenizer
        self.o = self.c.opwords
    def test_tabsize(self):
        d = Dummy(3)
        self.assertTrue(self.t.tabsize is None)
        self.t.set_tabsize(d)
        self.assertEqual(self.t.tabsize, 3)
    def test_alphabet(self):
        d1 = Dummy(Phoneme('1', 'abc'))
        d2 = Dummy(Phoneme('2', 'cde'))
        self.t.add_phoneme(d1)
        self.t.add_phoneme(d2)
        from stovokor.local import BaseAlphabet
        a = BaseAlphabet()
        for statement in self.t.phonemes:
            a[None] = statement.compile()
        self.assertSetEqual({'1'}, {x.name for x in a['a']})
        self.assertSetEqual({'1'}, {x.name for x in a['b']})
        self.assertSetEqual({'1', '2'}, {x.name for x in a['c']})
        self.assertSetEqual({'2'}, {x.name for x in a['d']})
        self.assertSetEqual({'2'}, {x.name for x in a['e']})
    def test_keywords(self):
        self.t.add_keyword(Dummy(Keyword('helo')))
        self.t.add_keyword(Dummy(Keyword('hello')))
        self.assertSetEqual({x.compile().name for x in self.t.keywords}, {'hello', 'helo'})
    def test_patterns(self):
        self.t.add_pattern(Dummy(Pattern('hello', 'Hello, world!')))
        self.t.add_pattern(Dummy(Pattern('hello', 'Hello, ([A-Z][a-z]*|world)!')))
        self.assertSetEqual({x.compile().name for x in self.t.patterns}, {'hello'})
        self.assertSetEqual({x.compile().pattern for x in self.t.patterns}, {'Hello, ([A-Z][a-z]*|world)!'})
    def test_delimiters(self):
        self.t.add_delimiter(Dummy(Delimiter('str', '"', '"', '\\')))
        self.t.add_delimiter(Dummy(Delimiter('str', '"', '"', '\\', '\\{', '}')))
        self.assertSetEqual({x.compile().name for x in self.t.delimiters}, {'str'})
        self.assertSetEqual({x.compile().weave for x in self.t.delimiters}, {'\\{'})
    def test_opwords(self):
        self.o['_TEST_'] = Dummy('hi')
        self.assertEqual('hi', self.o.new_opwords['_TEST_'].compile())

class TestLayering(unittest.TestCase):
    def test_one_layer(self):
        from Lotus.parsers.initial import InitialContext
        context = InitialContext()
        flow = Flow()
        flow.tokenizer.set_tabsize(Dummy(3))
        flow.tokenizer.add_phoneme(Dummy(Phoneme('1', 'a=e')))
        flow.tokenizer.add_keyword(Dummy(Keyword('sna')))
        flow.tokenizer.add_pattern(Dummy(Pattern('sna', '(sna|foo|bar|baz)+')))
        flow.tokenizer.add_delimiter(Dummy(Delimiter('str', "``", "''")))
        flow.opwords['_OPWORD_'] = Dummy('opword')
        context.layer(flow)
        context.finalize()
        self.assertEqual(context.tokenizer.tabsize, flow.tokenizer.tabsize)
        self.assertSetEqual({'1'}, {x.name for x in context.tokenizer.alphabet['a']})
        self.assertSetEqual({'1'}, {x.name for x in context.tokenizer.alphabet['=']})
        self.assertSetEqual({'1'}, {x.name for x in context.tokenizer.alphabet['e']})
        self.assertSetEqual({x.name for x in context.tokenizer.keywords}, {'sna'})
        self.assertSetEqual({x.name for x in context.tokenizer.patterns}, {'sna'})
        self.assertSetEqual({x.pattern for x in context.tokenizer.patterns}, {'(sna|foo|bar|baz)+'})
        self.assertSetEqual({x.name for x in context.tokenizer.delimiters}, {'str'})
        self.assertSetEqual({x.begin for x in context.tokenizer.delimiters}, {"``"})
        self.assertSetEqual({x.end for x in context.tokenizer.delimiters}, {"''"})
        