import unittest

from src.token import *
from src.tree import *

class TestTreeAccess(unittest.TestCase):
    def setUp(self):
        self.t = Tree(Token(type='root'))
        self.t._children.append(Token(type='child'))
        self.t._children.append('a string')
    def test_indexed_access(self):
        self.assertEqual(self.t['type'], 'root')
        self.assertEqual(self.t[0]['type'], 'child')
        self.assertEqual(self.t[-2]['type'], 'child')
        self.assertEqual(self.t['0']['type'], 'child')
        with self.assertRaises(IndexError):
            self.t[2]
        with self.assertRaises(AttributeError):
            self.t['dne']
    def test_dotted_access(self):
        self.assertEqual(self.t.type, 'root')
        self.assertEqual(self.t[0].type, 'child')
        with self.assertRaises(AttributeError):
            self.t.dne
    def test_indexed_set(self):
        self.t[1] = 'a new string'
        self.assertEqual(self.t[1], 'a new string')
        self.t['-1'] = 'the old string'
        self.assertEqual(self.t[1], 'the old string')
        self.t['new attr'] = 'not really'
        self.assertEqual(self.t['new attr'], 'not really')
    def test_dotted_set(self):
        self.assertEqual(self.t.type, 'root')
        self.t.type = 'oops'
        self.assertEqual(self.t.type, 'oops')
    def test_auto_token_construction(self):
        tree = Tree(2)
        self.assertEqual(tree._DATA, 2)
    def test_iteration(self):
        i = 0
        for child in self.t:
            if i == 0:
                self.assertEqual(child.type, 'child')
            elif i == 1:
                self.assertEqual('a string', child)
            i += 1
        self.assertEqual(i, 2)
    #def test_slicing(self): #TESTME

class TestTreeBuilder(unittest.TestCase):
    def setUp(self):
        self.t = TreeBuilder()
    def test_open(self):
        self.t.open()
        self.assertTrue(isinstance(self.t[0], TreeBuilder))
        self.t.open(Token(leaf=True))
        self.assertTrue(isinstance(self.t[0][0], TreeBuilder))
        self.assertEqual(self.t[0][0].leaf, True)
    def test_append(self):
        self.t.open()
        self.assertEqual(len(self.t), 1)
        self.t.append(1)
        self.assertEqual(len(self.t), 1)
        self.assertEqual(len(self.t[0]), 1)
        self.t.open()
        self.t.append(2)
        self.t.append(3)
        self.assertEqual(len(self.t), 1)
        self.assertEqual(len(self.t[0]), 2)
    def test_close(self):
        self.t.open()
        for char in 'abc': self.t.append(char)
        self.t.close()
        self.t.append(1)
        self.assertEqual(len(self.t), 2)
        self.assertEqual(len(self.t[0]), 3)
        self.assertEqual(self.t[1], 1)