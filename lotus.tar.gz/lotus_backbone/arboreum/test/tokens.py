import unittest

from src.token import *

class TestAttr(unittest.TestCase):
    def test_get(self):
        t = Token('aaa', leaf=True)
        self.assertEqual(t._DATA, 'aaa')
        self.assertEqual(t.leaf, True)
        self.assertEqual(t['leaf'], True)
        with self.assertRaises(AttributeError):
            t.dne
        with self.assertRaises(AttributeError):
            t['dne']
        self.assertEqual(t['_DATA'], 'aaa')
        self.assertIs(Token()._DATA, None)
    def test_set(self):
        t = Token()
        with self.assertRaises(AttributeError):
            t.leaf
        t.leaf = False
        self.assertEqual(t.leaf, False)
        with self.assertRaises(AttributeError):
            t.user
        t['user'] = 'input'
        self.assertEqual(t.user, 'input')
    def test_improper_access(self):
        t = Token()
        with self.assertRaises(AttributeError):
            t[1] = 1
        with self.assertRaises(AttributeError):
            t[1]
        with self.assertRaises(ValueError):
            t['']
        with self.assertRaises(ValueError):
            t[''] = 3
        with self.assertRaises(ValueError):
            t['_ATTR']
        with self.assertRaises(ValueError):
            t['_ATTR'] = 3