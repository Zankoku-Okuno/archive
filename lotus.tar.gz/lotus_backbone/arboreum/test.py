#! /usr/bin/python3

import unittest

from test.tokens import *
from test.trees import *

unittest.main()