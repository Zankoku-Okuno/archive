from .primitive import Label
from .memory import DataCell
from .error import LasmBadValue

class ExpressionEngine:
    def __init__(self, memory):
        self.memory = memory
        self.postfix_buffer = []
    
    def quote(self, expr):
        expr = expr.strip(' ')
        if expr[0] == '&': return self.quote(expr[1:])
        prefix, postfix = _isPrefixed(expr), _isPostfixed(expr)
        if prefix:
            address = self.quote(expr[2:])
            self._inc(address, prefix)
            return address
        elif postfix:
            address = self.quote(expr[:-2])
            self.postfix_buffer.append((address, postfix))
            return address
        elif _isPush(expr):
            rest = expr[4:].strip(' ')
            address = self.quote(rest)
            value = address if rest[0] == '&' else self[address]
            self[self.quote('@[++^]')] = value
            return address
        elif '[' in expr:
            acc = Label()
            while '[' in expr:
                start, end, offset = _getLimits(expr)
                acc += self._basecase(expr[:start])
                if offset is None:
                    indirect = self.quote(expr[start+1:end])
                    acc += indirect if indirect.isNumber() else Label(self[indirect])
                else:
                    acc += self._calculateOffset(expr[start+1:offset],
                                                 expr[offset:end])
                expr = expr[end+1:]
            acc += self._basecase(expr)
            return acc
        else:
            return self._basecase(expr)
    
    def dereference(self, expr):
        if expr[0] == '&':
            return self.quote(expr[1:])
        else:
            return self[self.quote(expr)]
    
    def flush(self):
        tmp, self.postfix_buffer = self.postfix_buffer, []
        for label, adjust in tmp:
            self._inc(label, adjust)
        #TODO flush the associated memory here, after postfix incrementation is
        #successfully done
    
    def __getitem__(self, label):
        return self.memory[label]
    def __setitem__(self, label, value):
        self.memory[label] = value
    
    def _basecase(self, expr):
        expr = expr.strip('. ')
        if not expr:
            return Label()
        stack, rest = _isStack(expr)
        if stack:
            depth = 0 if not rest else int(rest)
            if stack == 'peek':
                return Label('@', self[Label('^')] - depth)
            elif stack == 'pop':
                assert not rest or depth #rest implies depth
                if depth: depth -= 1
                address = Label('@', self[Label('^')] - depth)
                self[Label('^')] = self[Label('^')] - depth - 1
                return address
        else:
            parts = expr.split('.')
            for i in range(0, len(parts)):
                if _numeral.match(parts[i]):
                    parts[i] = int(parts[i])
            return Label(*parts)
    
    def _calculateOffset(self, expr, number):
        base = self.dereference(expr)
        if not isinstance(base, int):
            raise LasmBadValue() #TODO better diagnostics
        offset = int(number)
        return Label(base + offset)
    
    def _inc(self, label, amount):
        oldVal = self[label]
        if not isinstance(oldVal, int):
            raise LasmBadValue() #TODO better diagnostics
        self[label] = oldVal + amount
        

import re
_numeral = re.compile(r'^(\+|-)?\d+$')

def _getLimits(expr):
    start = expr.index('[')
    end = _advance(expr, start)
    offset = None
    i = end-1 #TODO why only a minus 1?
    while i > start:
        if expr[i] not in '0123456789':
            break
        i -= 1
    if i != end-1 and expr[i] in '+-':
        offset = i
    #TEST need some asserts
    return start, end, offset

def _advance(expr, start=0):
    depth, active = 0, False
    for i in range(start, len(expr)):
        if expr[i] == '[':
            depth += 1
            active = True
        elif expr[i] == ']':
            depth -= 1
        if active and not depth:
            return i
    assert False

def _isPrefixed(source):
    if len(source) < 2:
        return False
    elif source[:2] == '++':
        return 1
    elif source[:2] == '--':
        return -1
    else:
        return 0
def _isPostfixed(source):
    if len(source) < 2:
        return False
    elif source[-2:] == '++':
        return 1
    elif source[-2:] == '--':
        return -1
    else:
        return 0

def _isPush(expr):
    return len(expr) >= 4 and expr[:4] == 'push'
def _isStack(expr):
    if len(expr) >= 3 and expr[:3] == 'pop':
        return 'pop', expr[3:].strip(' ')
    elif len(expr) >= 4 and expr[:4] == 'peek':
        return 'peek', expr[4:].strip(' ')
    else:
        return None, expr



    