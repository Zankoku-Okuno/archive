class Instruction:
    pass #STUB