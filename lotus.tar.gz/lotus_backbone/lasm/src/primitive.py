from functools import reduce

class Label:
    def __init__(self, *args):
        self._label = list(args)
    def isNumber(self):
        return len(self) == 1 and isinstance(self[0], int)
    def asNumber(self):
        assert self.isNumber()
        return self[0]
    def __len__(self):
        return len(self._label)
    def __getitem__(self, index):
        if isinstance(index, slice):
            return Label(*self._label[index])
        else:
            return self._label[index]
    def __str__(self):
        return '.'.join(map(lambda x: str(x), self._label))
    def __repr__(self): return str(self)
    def __hash__(self):
        return reduce(lambda acc, i: acc ^ hash(i), self._label, 0)
    def __eq__(self, other):
        return isinstance(other, Label) and self._label == other._label
    def __add__(self, other):
        return Label(*(self._label + other._label))
