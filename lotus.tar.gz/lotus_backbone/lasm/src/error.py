class LasmRuntimeError(Exception):
    pass
class LasmSegfault(LasmRuntimeError):
    pass
class LasmDivZero(LasmRuntimeError):
    pass
class LasmBadValue(LasmRuntimeError):
    pass



class LasmSyntaxError(Exception):
    pass

class LasmDoubleNameBindingError(LasmSyntaxError):
    pass