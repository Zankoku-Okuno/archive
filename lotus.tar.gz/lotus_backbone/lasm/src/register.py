from memory import MemoryCell

class Register(MemoryCell):
    pass #STUB