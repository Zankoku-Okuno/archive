from .primitive import Label
from .error import LasmDoubleNameBindingError, LasmSegfault

class DataCell(dict):
    def __init__(self):
        super().__init__()
        self._data = None
    def __getitem__(self, key):
        if isinstance(key, Label):
            if len(key) == 0:
                return self._data
            else:
                return self[key[0]][key[1:]]
        elif key in self:
            return super().__getitem__(key)
        else:
            raise LasmSegfault() #TODO better diagnostics
    def __setitem__(self, key, value):
        if isinstance(key, Label):
            if len(key) == 0:
                self._data = value
            else:
                if key[0] not in self:
                    super().__setitem__(key[0], DataCell())
                self[key[0]][key[1:]] = value
        else: assert False

class InstructionCell(list):
    def __init__(self, *args):
        super().__init__(*args)
        self._labels = dict()
    def __getitem__(self, key):
        if isinstance(key, int):
            if 0 <= key < len(self):
                return super().__getitem__(key)
            else:
                raise LasmSegfault() #TODO better diagnostics
        else:
            if key in self._labels:
                return self[self._labels[key]]
            else:
                raise LasmSegfault() #TODO better diagnostics
    def append(self, value, label=None):
        if isinstance(value, InstructionCell):
            if label is None:
                self._appendUnlabeledSubcell(value)
            else:
                self._appendLabeledSubcell(value, label)
            for instruction in value:
                self.append(instruction)
        else:
            if label is not None:
                self._appendLabel(label, len(self))
            super().append(value)
    
    def _appendLabel(self, label, location):
        if label in self._labels:
            raise LasmDoubleNameBindingError() #TODO better diagnostics
        self._labels[label] = location
    def _appendUnlabeledSubcell(self, value):
        for dumpedLabel in value._labels:
            self._appendLabel(dumpedLabel, len(self) + value._labels[dumpedLabel])
    def _appendLabeledSubcell(self, value, label):
        if label in self._labels:
            raise LasmDoubleNameBindingError() #TODO better diagnostics        
        self._appendLabel(label, len(self))
        for dumpedLabel in value._labels:
            self._appendLabel(label+"."+dumpedLabel, len(self) + value._labels[dumpedLabel])
        self._appendLabel(label+".$", len(self)+len(value))
        