#! /usr/bin/python3

import unittest

from tests.primitives import *
from tests.memory import *
from tests.expressions import *


if __name__ == '__main__':
    unittest.main()