import unittest

from src.memory import *
from src.primitive import *

class TestDataCell(unittest.TestCase):
    def test_integer_access(self):
        m = DataCell()
        m[Label(42)] = 137
        self.assertEqual(m[Label(42)], 137)
        with self.assertRaises(LasmSegfault):
            m[Label(137)]
    def test_label_access(self):
        m = DataCell()
        m[Label('notLabel')] = 42
        m[Label('label')] = 137
        self.assertEqual(m[Label('notLabel')], 42)
        self.assertEqual(m[Label('label')], 137)
    def test_immediate_data(self):
        m = DataCell()
        with self.assertRaises(LasmSegfault):
            val = m[Label('data')]
        m.data = 3
        self.assertEqual(3, m.data)

class TestInstructionCell(unittest.TestCase):
    def setUp(self):
        self.m = InstructionCell([5, 4, 3, 2, 1, 0])
    def test_integer_access(self):
        cmp = [5, 4, 3, 2, 1, 0]
        for i in range(0, 6):
            self.assertEqual(self.m[i], cmp[i])
        with self.assertRaises(LasmSegfault):
            self.m[-1]
        with self.assertRaises(LasmSegfault):
            self.m[8]
    def test_append(self):
        self.m.append(137)
        self.assertEqual(self.m[6], 137)
    def test_label_access(self):
        self.m.append(137, "label")
        self.assertEqual(self.m[6], self.m["label"], 137)
        with self.assertRaises(LasmSegfault):
            self.m["dne"]
    def test_dump_into(self):
        m2 = InstructionCell([10, 11])
        m2.append(12, "thingie")
        self.m.append(m2, "interior")
        self.m.append(20)
        m2 = InstructionCell([61, 62])
        m2.append(63, "label")
        self.m.append(m2)
        self.m.append(40)
        cmp = [5, 4, 3, 2, 1, 0, 10, 11, 12, 20, 61, 62, 63, 40]
        for i in range(0, len(cmp)):
            self.assertEqual(self.m[i], cmp[i])
        self.assertEqual(self.m["interior"], 10)
        self.assertEqual(self.m["label"], 63)
        self.assertEqual(self.m["interior.$"], 20)
        self.assertEqual(self.m["interior.thingie"], 12)
    def test_name_binding_error_detection(self):
        self.m.append(10, "label")
        with self.assertRaises(LasmDoubleNameBindingError):
            self.m.append(11, "label")
        m2 = InstructionCell()
        with self.assertRaises(LasmDoubleNameBindingError):
            self.m.append(m2, "label")
        m2.append(11, "label")
        with self.assertRaises(LasmDoubleNameBindingError):
            self.m.append(m2)




