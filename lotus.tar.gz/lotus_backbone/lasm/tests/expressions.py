import unittest

from src.expression import *
from src.memory import DataCell
from src.error import LasmBadValue, LasmSegfault

class TestExpressions(unittest.TestCase):
    def setUp(self):
        self.m = DataCell()
        self.m[Label('@')] = DataCell()
        #self.m[Label('@')]._subdata = {i: DataCell(5-i) for i in range(0, 6)}
        for i in range(0, 6):
            self.m[Label('@', i)] = 5-i
        self.m[Label('a')] = 70
        self.m[Label('b')] = 71
        self.m[Label('c')] = 2
        self.m[Label('stuff', 1)] = 'a'
        self.m[Label('stuff', 5)] = 'b'
        self.m[Label('sp')] = 5
        self.m[Label('^')] = 5
        self.e = ExpressionEngine(self.m)
    def test_unit_resolution(self):
        self.assertEqual(Label('sp'), self.e.quote('sp'))
        self.assertEqual(5, self.e.dereference('sp'))
    def test_numeral_calculated_resolution(self):
        self.assertEqual(Label('stuff', 1), self.e.quote('stuff[1]'))
        self.assertEqual('a', self.e.dereference('stuff[1]'))
    def test_label_calculated_resolution(self):
        self.assertEqual(Label('@', 5), self.e.quote('@[sp]'))
        self.assertEqual(0, self.e.dereference('@[sp]'))
        self.assertEqual(Label('a'), self.e.quote('[stuff[1]]'))
        self.assertEqual(70, self.e.dereference('[stuff[1]]'))
    def test_nested_resolution(self):
        self.assertEqual(Label('b'), self.e.quote('[stuff[sp]]'))
        self.assertEqual(71, self.e.dereference('[stuff[sp]]'))
    def test_offset_resolution(self):
        self.assertEqual(Label('@', 5), self.e.quote('@[c +3]'))
        self.assertEqual(0, self.e.dereference('@[c +3]'))
        self.assertEqual(Label('@', 2), self.e.quote('@[sp-3]'))
        self.assertEqual(3, self.e.dereference('@[sp -3]'))
        with self.assertRaises(LasmBadValue):
            self.e.quote('[stuff[1] +4]')
    def test_quote_protection(self):
        self.assertEqual(Label('@', 5), self.e.dereference('&@[c +3]'))
        self.assertEqual(Label('b', 5), self.e.dereference('&[stuff[sp]][sp]'))
    def test_prefix_incdec(self):
        self.assertEqual(Label('sp'), self.e.quote('++sp'))
        self.assertEqual(6, self.e.dereference('sp'))
        self.assertEqual(7, self.e.dereference('++sp'))
        self.assertEqual(Label('sp'), self.e.dereference('&++sp'))
        self.assertEqual(8, self.e.dereference('sp'))
        self.assertEqual(Label('sp'), self.e.quote('--sp'))
        self.assertEqual(7, self.e.dereference('sp'))
        self.assertEqual(6, self.e.dereference('--sp'))
        self.assertEqual(Label('sp'), self.e.dereference('&--sp'))
        self.assertEqual(5, self.e.dereference('sp'))
    def test_postfix_incdec(self):
        self.assertEqual(Label('sp'), self.e.quote('sp++'))
        self.assertEqual(5, self.e.dereference('sp'))
        self.assertEqual(5, self.e.dereference('sp++'))
        self.assertEqual(Label('sp'), self.e.dereference('&sp++'))
        self.assertEqual(5, self.e.dereference('sp'))
        self.e.flush()
        self.assertEqual(8, self.e.dereference('sp'))
        self.assertEqual(Label('sp'), self.e.quote('sp--'))
        self.assertEqual(8, self.e.dereference('sp'))
        self.assertEqual(8, self.e.dereference('sp--'))
        self.assertEqual(Label('sp'), self.e.dereference('&sp--'))
        self.assertEqual(8, self.e.dereference('sp'))
        self.e.flush()
        self.assertEqual(5, self.e.dereference('sp'))
    def test_incdec_type_safety(self):
        with self.assertRaises(LasmBadValue):
            self.e.quote('++stuff[1]')
        with self.assertRaises(LasmBadValue):
            self.assertEqual('b', self.e.dereference('stuff[5]--'))
            self.e.flush()
        with self.assertRaises(LasmBadValue):
            self.assertEqual(Label('stuff', 1), self.e.dereference('&stuff[1]++'))
            self.e.flush()
        with self.assertRaises(LasmSegfault):
            self.e.dereference('&--stuff[3]')
        with self.assertRaises(LasmSegfault):
            self.assertEqual(Label('stuff', 3), self.e.quote('stuff[3]--'))
            self.e.flush()
    def test_incdec_offset(self):
        self.assertEqual(3, self.e.dereference('@[sp++-3]'))
        self.assertEqual(0, self.e.dereference('@[sp--]'))
    def test_push(self):
        self.assertEqual(Label('a'), self.e.quote('push a'))
        self.assertEqual(6, self.e.dereference('^'))
        self.assertEqual(70, self.e.dereference('@[^]'))
        self.assertEqual(Label('a'), self.e.quote('push &a'))
        self.assertEqual(7, self.e.dereference('^'))
        self.assertEqual(Label('a'), self.e.dereference('@[^]'))
        self.assertEqual(70, self.e.dereference('push a'))
        self.assertEqual(8, self.e.dereference('^'))
        self.assertEqual(70, self.e.dereference('@[^]'))
        self.assertEqual(Label('a'), self.e.dereference('&push a'))
        self.assertEqual(9, self.e.dereference('^'))
        self.assertEqual(70, self.e.dereference('@[^]'))
        self.assertEqual(Label('a'), self.e.dereference('&push &a'))
        self.assertEqual(10, self.e.dereference('^'))
        self.assertEqual(Label('a'), self.e.dereference('@[^]'))
    def test_peek(self):
        self.assertEqual(Label('@', 5), self.e.quote('peek'))
        self.assertEqual(0, self.e.dereference('peek'))
        for i in range(0, 6):
            self.assertEqual(Label('@', 5-i), self.e.quote('peek {}'.format(i)))
            self.assertEqual(i, self.e.dereference('peek {}'.format(i)))
    def test_pop(self):
        self.assertEqual(Label('@', 5), self.e.quote('pop'))
        self.assertEqual(1, self.e.dereference('pop'))
        self.assertEqual(3, self.e.dereference('pop 2'))
        self.assertEqual(4, self.e.dereference('pop 1'))




