import unittest

from src.primitive import *

def _Label2List(label):
    out = []
    for i in range(0, len(label)):
        out.append(label[i])
    return out

class TestLabel(unittest.TestCase):
    def test_init(self):
        self.assertEqual([], _Label2List(Label()))
        self.assertEqual(['hello'], _Label2List(Label('hello')))
        self.assertEqual(['hi', 7], _Label2List(Label('hi', 7)))
    def test_str(self):
        self.assertEqual('hello', str(Label('hello')))
        self.assertEqual('hi.7', str(Label('hi', 7)))