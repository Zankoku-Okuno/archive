
	

class Process:
	def __init__(self, pid):
		self.id = pid
		self.next = None
	
	def post(self, process):
		self.next = process
	
	def lock(self, from_process):
		self.wake()
	def unlock(self):
		self.next.lock(self)
		
		

class Secretary:
	def __init__(self, monitor):
		self.monitor = monitor
		self.incoming = 0
	
	def wake_monitor(self):
		self.incoming += 1
		self.wake() #TODO find the real name of this
	
	def post(self, pid, type):
		if type == 'r':
			pass #TODO give it, probably
		elif type == 'w':
			pass #TODO put it in the search tree
		elif type == 'u':
			pass #TODO
	
	def run(self):
		while True:
			if self.snagged: self.monitor.unsnag()
			if self.incoming > 0:
				self.monitor.incoming += self.incoming
				self.monitor.wake()
				self.sleep() #TODO find the real name of this

class Monitor:
	def __init__(self, secretary):
		self.secretary
		self.requester_memory = PostNode() #TODO require registration, meaning this should start as None
		#registration can be done like so: posting returns a boolean. If the boolean is True, it means the process has been posted correctly.
		#If False, then there's some registration is in progress, the requester should wait some time, then resend the request
		#when a request comes in, the monitor automatically returns false on all posts and notifies the secretary that some registration has to happen
		#the monitor otherwise continues to operate as normal until both it and the secretary run out of jobs to queue
		#now, the secretary modifies the monitor's tree structure to include the new registrant
		#finally, the operation of posts is returned to normal
		# ----
		# false should also be returned when a process needs to register (though the need for registration should occur automatically)
		# since registration requests write into shared memory, there might be some data loss
		# however, each registrant keeps trying to get in, and only new registrants can write to the shared memory
		# thus, we should usually obtain & deal with all the registrants in one registration cycle
		self.incoming = 0
		self.outgoing = 0
		self.last = self
		self.snag = None
	
	def run(self):
		while True:
			self.incoming -= self.outgoing
			processes = self.requester_memory.search() #TODO
			while processes:
				process = processes.pop()
				process.next = self
				process.wake()
				self.last = process
				if self.snag is not None: self.unsnag()
			self.outgoing += len(processes)
			self.secretary.wake()
			self.sleep()
	
	def lock(self, process):
		self.snag = process
		self.secretary.snagged = True

	def unsnag(self):
		process = self.snag.next
		self.snag = None
		process.wake()

class ReadersConglomerate:
	def __init__(self, num, next):
		self.reading = num
		self.next = next
	
	def lock(self):
		self.reading -= 1
		if not self.reading: self.unlock()
	
	def unlock(self):
		self.next.lock()