import re
from functools import reduce

from .seed_database import define_opword
from .seed_database import seed_keyword_pairs
from .exceptions import ScannerMatchError
from .exceptions import delayedRaise
from .seed_database import comment_and_string_keywords

use_opword = re.compile(r'\s'+define_opword+r'\s')

class Scanner:
	def __init__(self):
		self.detection_set = comment_and_string_keywords
		self.knownMatches = [] #TODO why is this a list instead of a set?
		self.potentialMatch = None
	
	def feed(self, filename, lineno, input):
		"""
		Finds all lines that contain _OPWORD and then tries to explain them.
		If it can't explain them, a delayed error is raised.
		"""
		if re.search(use_opword, input):
			potentialMatch = Match(input, filename, lineno)
			if potentialMatch.valid: #If there are already problems, nothing more can be figured out
				self.digest(potentialMatch)
	
	def digest(self, potentialMatch):
		#Check that it defines an opword that we're currently searching for
		if potentialMatch.operandB not in self.detection_set:
			delayedRaise(ScannerMatchError(potentialMatch, potentialMatch.text.index(define_opword)+len(define_opword)+1,
															 "where '{0}' is meaningless".format(potentialMatch.operandB)))
		#Check that we aren't assigning two meanings to the same opword
		elif reduce(lambda acc, existingMatch: acc or potentialMatch.violates_uniqueness(existingMatch), self.knownMatches, False):
			delayedRaise(ScannerMatchError(potentialMatch, potentialMatch.text.index(potentialMatch.operandA),
															"which assigns a second meaning to {0}".format(potentialMatch.operandA)))
		else:
			#A seed keyword can only be assigned to one lotus keyword at a time,
			#choose the latest if we're overwriting, throw an error if not
			for match in self.knownMatches:
				if potentialMatch.operandB == match.operandB:
					self.knownMatches[self.knownMatches.index(match)] = potentialMatch
					break
			else: #and if all of THAT is in order, carry on!
				self.knownMatches.append(potentialMatch)
	
	def compatible(self, other):
		for s in self.knownMatches:
			for o in other.knownMatches:
				if o.violates_uniqueness(s):
					return False
				elif o.operandB == s.operandB and o.operandA != s.operandA:
					return False
		return True
	
class Match:
	def __init__(self, text, filename, lineno):
		self.file = filename
		self.line = lineno
		self.text = text[:-1] if text else ""
		self.checkValid(text)
		if self.valid:
			self.operandA = self.text[:self.text.index(define_opword)-1]
			self.operandB = self.text[self.text.index(define_opword)+len(define_opword)+1:]
	
	def checkValid(self, text):
		self.valid = True
		#Not in the correct scope
		if re.match('\\s*\t\\s*', re.sub(' {'+'{0}'.format(3)+'}', '\t', text)): #TODO remove the magic number
			delayedRaise(ScannerMatchError(self, 0, "where _OPWORD statement is not in module scope")) #TODO call it module?
			self.valid = False
		words = [ x for x in re.sub(r'\s+', ' ', text).split(' ') if x != "" ]
		#'_OPWORD' appears more than once
		if words.count(define_opword) > 1:
			delayedRaise(ScannerMatchError(self, text.index(define_opword, text.index(define_opword)+1),
												   "where '_OPWORD' operator appears more than once in the statement"))
			self.valid = False
		#Opword statement has more or less than one left argument
		if words[1] != define_opword:
			delayedRaise(ScannerMatchError(self, text.index(words[0]),
												   "exactly one argument required on left side of _OPWORD statement"))
			self.valid = False
		#Opword statement has more or less than one right argument
		if len(words) - words.index(define_opword) != 2:
			delayedRaise(ScannerMatchError(self, text.index(define_opword)+len(define_opword)+1,
												   "exactly one argument required on right side of _OPWORD statement"))
			self.valid = False
	
	def detectable(self, detection_set):
		return self.operandB in detection_set
	
	def violates_uniqueness(self, other):
		return self.operandA == other.operandA and self.operandB != other.operandB and reduce(
			lambda acc, pair: acc and (self.operandB and other.operandB) not in pair, seed_keyword_pairs)
		#MAGIC HACK
		#if self.operandA != other_match.operandA:
		#	return False
		#else:
		#	for overloadableSet in seed_keyword_pairs:
		#		if other_match.operandB in overloadableSet and self.operandB in overloadableSet:
		#			return False
		#	return True

	#
	# Interfacing
	#
	
	def is_already_scanned(self, filename, lineno):
		return lineno == self.line and filename == self.file
	
	def could_eventually_begin(self, input):
		try: return not self.operandA.index(input[:len(self.operandA)])
		except ValueError: return False
	
	def currently_begins(self, input):
		return len(self.operandA) <= len(input) and self.could_eventually_begin(input)
	
	#
	# Support
	#
	
	def __str__(self):
		return self.text

__all__ = ['Scanner']