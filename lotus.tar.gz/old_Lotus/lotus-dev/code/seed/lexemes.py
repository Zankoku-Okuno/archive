#TODO phrasemes are only concerned with their line, but maybe we should have lexemes know their columns as well

class Lexeme:
	def __init__(self, text, filename, lineno):
		self.content = text
		self.filename = filename
		self.lineno = lineno

class ScanPhasePhraseme(Lexeme):
	"""For the phrasemes that get caught in the scan phase of the atomizer."""
	def __init__(self, text, match, filename, lineno):
		super().__init__(text, filename, lineno)
		self.match = match
		self.lexeme_type = "Scan Phase"

class UnexplainedLexeme(Lexeme):
	"""For phrasemes that have not yet been atomized or otherwise explained."""
	def __init__(self, text, filename, lineno):
		super().__init__(text, filename, lineno)
		self.lexeme_type = "Unknown"

class WovenUnexplainedLexeme(UnexplainedLexeme):
	"""For phrasemes that have not yet been atomized or otherwise explained, but which are woven into a string lexeme."""
	def __init__(self, text, filename, lineno, depth):
		super().__init__(text, filename, lineno)
		self.lexeme_type = "Woven {0}".format(depth)

class OpwordLexeme(Lexeme):
	"""For lexemes that have been matched to an operator."""
	def __init__(self, text, filename, lineno):
		super().__init__(text, filename, lineno)
		self.lexeme_type = "Opword"

class StringLiteralLexeme(Lexeme):
	"""For lexemes that have been found to be string literals."""
	def __init__(self, text, filename, lineno):
		super().__init__(text, filename, lineno)
		self.lexeme_type = "String"
	
	