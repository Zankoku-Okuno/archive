from functools import reduce

def delayedRaise(ex):
	delayed.append(ex)
delayed = []
def undelay():
	if len(delayed) == 0:
		pass
	elif len(delayed) == 1:
		raise delayed[0]
	else:
		raise CompoundLotusError(delayed)


class LotusParserError(Exception):
	"""All subclasses should set 'message' and 'info', lest they be replaced with defaults
	Location is a (little-endian) tuple: (file, line column)
	"""#TODO remove the context bit, since it's obviouly derivable from location
	def __init__(self, obj):
		l = obj.now_location()
		self.file = l[0]
		self.line = l[1]
		self.col = l[2]
		
		if not self.message: self.message = "Lotus parser error"
		if not self.info: self.info = " "
	
	def __str__(self):
		where = " in '{0}' line {1}".format(self.file, self.line)
		context = load_context((self.file, self.line, self.col))
		underneath = reduce(lambda x, y: x+y, [ ' ' for x in range(self.col) ], '') + '^'
		return self.message.capitalize() + where + " " + self.info + ':\ncol {0}\t'.format(self.col) + context + '\n \\__>\t' + underneath

class CompoundLotusError(LotusParserError):
	def __init__(self, errs):
		self.errs = errs
		#print(self.errs)
	
	def __str__(self):
		return reduce(lambda x,y: '{0}\n{1}'.format(x,y), self.errs, '')

class TracedLotusError(LotusParserError):
	def __init__(self, obj):
		self.locations = [obj.now_location()]
	def append(self, obj):
		self.locations.append(obj.now_location)
	
	def __str__(self):
		return "TODO"

def load_context(location):
	f = open(location[0])
	for i in range(location[1] - 1): f.readline()
	linetext = f.readline()
	return linetext[:-1] if linetext and linetext[-1] == '\n' else linetext		





#class PondParserError(LotusParserError):
#	def __init__(self, importer):
		#TODO
		#super().__init__(importer)


class ScannerMatchError(LotusParserError):
	def __init__(self, match, col, info):
		self.file = match.file
		self.line = match.line
		self.col = col
		self.message = "Syntax error"
		self.info = info

class EarlyEOL(LotusParserError):
	def __init__(self, extractor):
		self.message = "unexpected end-of-line"
		self.info = "while in {0} Mode".format(extractor.mode)
		super().__init__(extractor)

class EarlyEOF(LotusParserError):
	def __init__(self, extractor):
		self.message = "unexpected end-of-file"
		self.info = "while in {0} Mode".format(extractor.mode_name())
		super().__init__(extractor)

class RestrictedOperator(LotusParserError):
	def __init__(self, extractor): # file, line, operator, mode, context):
		self.message = "operator {0} cannot be used".format(extractor.matchedLotus)
		self.info = "while in {0} Mode".format(extractor.mode_name())
		super().__init__(extractor)
