#!/usr/bin/env python
# -*- coding: utf-8 -*-


import re
import fileinput
import os.path
from functools import reduce

from .seed_database import define_opword
from .seed_database import seed_keyword_pairs
from .lexemes import *
from .exceptions import CompoundLotusError


findOpwordOpword = re.compile(r'\s'+define_opword+r'\s')
opwordOpwordWithSpace = ' '+define_opword+' '
pureWhitespace = re.compile(r'\A\s*\Z')

class Atomizer:
	def __init__(self, inputFile):
		self.inputFile = os.path.join(os.getcwd(), inputFile)
		self.phase = 0
		
		self.scanner = None
		self.extractor = None
		self.indentor = None
		self.itemizer = None
	
	def next_phase(self):
		for i in range(4):
			self.begin_phase(i)
			yield self
			
	#
	# Implementation stuff
	#
	
	def begin_phase(self, i):
		self.phase += 1
		if self.phase is 1:
			self.scan_phase()
		elif self.phase is 2:
			self.extract_phase()
		elif True:
			print(i) #TODO real functionality
		else:
			assert False, "Atomizer segments called in wrong order."
	
	def scan_phase(self):
		assert self.phase == 1, "Now is not the time, scan_phase!"
		from .scanner import Scanner
		self.scanner = Scanner()
		with fileinput.input(files=self.inputFiles) as files:
			for line in files:
				self.scanner.feed(files.filename(), files.lineno(), line)
	
	def extract_phase(self):
		assert self.phase == 2, "Now is not the time, extract_phase!"
		from .extractor import Extractor
		self.extractor = Extractor(self.scanner.knownMatches)
		while True:
			with fileinput.input(files=self.inputFiles) as files:
				for line in files:
					alreadyExplained = self.scanner.has_already_ascertained(files.filename(), files.lineno())
					if alreadyExplained: self.extractor.lexemes.append(
							ScanPhasePhraseme(line[:-1], alreadyExplained[0], files.filename(), files.lineno()))
					else:
						self.extractor.contextualize(files.filename(), files.lineno())
						self.extractor.feed(line)
				self.extractor.contextualize(None, None)
				self.extractor.feed("")
			
			new_knowns = False
			for unknown in self.scanner.unknownMatches[:]:
				print(reduce(lambda x,y: x+y,
										[ u.content for u in self.extractor.lexemes if u.lineno == unknown.line and type(u) is UnexplainedLexeme ], ''))
				new_knowns = self.scanner.feed(unknown.file, unknown.line,
									reduce(lambda x,y: x+y,
										[ u.content for u in self.extractor.lexemes if u.lineno == unknown.line and type(u) is UnexplainedLexeme ], '')) or new_knowns
				#look at all the problem locations, if they have not been resoveld, then attempt to resolve them
				#if one or more are resolved, then we need to re-extract everything
			if not new_knowns: break
		
		
		#then, once it's settled down, let's change the set of right-hand-side operands ro include everything, then run the scan phase a final time
		#if there are even still some problem matches, then we gave the user the benefit of the doubt and there's just an error
		
		if self.scanner.unknownMatches:
			raise CompoundLotusError( {y for x in self.scanner.unknownMatches for y in x.problems} )
	
	def indent_phase(self):
		assert self.phase == 3, "Now is not the time, indent_phase!"
		pass #TODO
	
	def itemize_phase(self):
		assert self.phase == 4, "Now is not the time, itemize_phase!"
		pass #TODO
		
	


### This'll be useful when I get to processing the file proper
#		for line in files:
#			line = re.sub(r' {3}', '\t', line)					#change three spaces into tab
#			
#			firstMeaningful = re.compile(r'\S').search(line)	#count number of leading tabs
#			if firstMeaningful is None:
#				numtabs = 0
#			else: numtabs = len(re.sub(' ', '', line[:firstMeaningful.start()]))
#			
#			line = re.sub(r'\w+', ' ', line[firstMeaningful.start():])				#compress whitespace