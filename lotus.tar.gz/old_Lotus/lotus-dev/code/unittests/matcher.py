import unittest
from okulib import *

from pasta_parser.regex.rxconst import *

class TestConstants(unittest.TestCase):
	def test_is(self):
		self.assertTrue(kleene_star is kleene_star)
		self.assertTrue(expr is expr)
		self.assertTrue(end is end)
		self.assertTrue(alt is alt)
	def test_eq(self):
		self.assertTrue(kleene_star == kleene_star)
		self.assertTrue(expr == expr)
		self.assertTrue(end == end)
		self.assertTrue(alt == alt)
	def test_is_not(self):
		self.assertTrue(kleene_star is not alt)
		self.assertTrue(expr is not kleene_star)
		self.assertTrue(end is not expr)
		self.assertTrue(alt is not end)
	def test_not_eq(self):
		self.assertTrue(kleene_star != alt)
		self.assertTrue(expr != kleene_star)
		self.assertTrue(end != expr)
		self.assertTrue(alt != end)
