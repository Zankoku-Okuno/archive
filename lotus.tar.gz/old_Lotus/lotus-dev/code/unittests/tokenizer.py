import unittest
from tokenizer import phase_one_driver as p1d
from pasta_parser.nested_tokenizer import NestedTokenizer
class Keyword:
	def __init__(self, a, b):
		self.syntax = lambda: a
		self.semantics = lambda: b




from tokenizer._interface import *
class TestInterface(unittest.TestCase):
	def setUp(self):
		self.m = NestedTokenizer(
			keywords = {
				Keyword('\n', '_NEWLINE'),
				Keyword('--', '_LINE_COMMENT')
			},
			driver = make_driver({
				0: (
					mode_changer("_LINE_COMMENT", 'line'),
					default_buffer()
				),
				'line': (
					exit_mode("_NEWLINE"),
					default_nothing()
				)
			}),
			initial_mode = 0,
			final_modes = { 0, 'line' },
			evolve = { 0: flush() },
			exit = { 0: flush() }
		)
	
	def test_prints_right(self):
		self.m.feed('hello')
		self.assertEqual(self.m._storage, 'hello')
		self.m.feed('-- cant see me')
		self.assertEqual(self.m._storage, '')
		self.m.finish()
		self.assertEqual('hello', self.m._output[0].contents())
	def test_parses_right(self):
		self.m.feed('hello--nope\ngoodbye')
		self.m.finish()
		self.assertEqual(self.m._output[0].contents(), 'hello')
		self.assertEqual(self.m._output[1].contents(), '\ngoodbye')