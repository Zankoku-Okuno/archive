from pasta_parser.behavoiralism.behavoirs import *
from pasta_parser.behavoiralism.deciders import *

import unittest
from okulib import *


from pasta_parser.machines.hook_location import HookLocationMachine
from pasta_parser.machines import hook_location as hl
class HookLocationMachineTest(unittest.TestCase):
	def setUp(self):
		self.out = ""
		def pr(x): self.out += str(x)
		
		self.m = HookLocationMachine(
			keywords = {
				Keyword('(', "_OPEN"),
				Keyword(')', "_CLOSE"),
				Keyword('!', "_EEP"),
				Keyword('!', "_OOP"),
				Keyword('yadda', "_YADDA"),
				Keyword('out', "_OUT")
			},
			driver = ModalDecider({
				0: FirstMatchDecider(
					LocatedBehavoir("_OPEN",
									lambda x,y: y.start_to_enter_mode(x, 1),
									lambda x,y: y.finish_entering_mode(x, 1)),
					LocatedBehavoir("_EEP", 
									lambda x,y: y.start_to_enter_mode(x, 'eep'),
									lambda x,y: y.finish_entering_mode(x, 'eep')),
					Behavoir("_EEP", lambda x,y: pr('OOP!')),
					Behavoir("_OUT", lambda x,y: pr('&')),
					LocatedBehavoir("_YADDA", 
									lambda x,y: y.start_to_enter_mode(x, 'y'),
									lambda x,y: y.finish_entering_mode(x, 'y'))
				),
				1: FirstMatchDecider(
					LocatedBehavoir("_CLOSE", 
									lambda x,y: y.start_to_exit_mode(x),
									lambda x,y: y.finish_exiting_mode(x)),
					LocatedBehavoir("_OPEN",
									lambda x,y: y.start_to_enter_mode(x, 1),
									lambda x,y: y.finish_entering_mode(x, 1)),
					Behavoir("_DEFAULT", lambda x,y:None)
				),
				'eep': FirstMatchDecider(
					LocatedBehavoir("_OOP", 
									lambda x,y: y.start_to_exit_mode(x),
									lambda x,y: y.finish_exiting_mode(x)),
					LocatedBehavoir("_OPEN",
									lambda x,y: y.start_to_enter_mode(x, 1),
									lambda x,y: y.finish_entering_mode(x, 1))
				),
				'y': FirstMatchDecider(
					Anticipation("_OUT", lambda x,y: y.exit_mode(x)),
					Behavoir("_DEFAULT", lambda x,y: None)
				)
			}).default(lambda x,y: pr(x)),
			initial_mode = 0,
			final_modes = {0, 1, 'eep'},
			enter = {
				1: lambda syntax, state: state.push_location(),
				'eep': lambda syntax, state: pr(syntax)
			},
			exit = {
				1: lambda syntax, state: pr(state.pop_location())
			},
			evolve = {
				'eep': lambda syntax, state: pr(syntax)
			},
			devolve = {
				'eep': lambda syntax, state: pr(syntax)
			}
		)
		
	def test_default(self):
		self.m.feed("hello")
		self.m.finish()
		self.assertEqual(self.out, "hello")
	def test_removes_parens(self):
		self.m.feed("hello( or not")
		self.assertEqual(self.out, "hello")
		self.m.finish()
	def test_handles_locations(self):
		self.m.feed("he( eats je)llo")
		self.m.finish()
		self.assertEqual(self.out, "he(0, 3)llo")
	def test_recursion(self):
		self.m.feed("he( eats (a lot of) je)llo")
		self.m.finish()
		self.assertEqual(self.out, "he(0, 10)(0, 3)llo")
	def test_reenter_and_evolve(self):
		self.m.feed("he!a(f!)llo")
		self.m.finish()
		self.assertEqual(self.out, "he!a((0, 5))llo")
	def test_preaction(self):
		self.m.feed("hello yadda then out goodbye")
		self.m.finish()
		self.assertEqual(self.out, "hello & goodbye")
	def test_preaction_leaves_location_alone(self):
		self.m.feed("yaddaout")
		self.assertEqual(self.m.mode(), 0)
		self.m.feed("(hello)")
		self.m.finish()
		self.assertEqual(self.out, '&(0, 9)')



from pasta_parser.machines.hook import HookMachine
from pasta_parser.machines import hook
class HookMachineTest(unittest.TestCase):
	def setUp(self):
		self.out = ""
		def pr(x): self.out += str(x)
		
		self.m = HookMachine(
			keywords = {
				Keyword('(', "_OPEN"),
				Keyword(')', "_CLOSE")
			},
			driver = ModalDecider({
				0: FirstMatchDecider(
					Behavoir("_OPEN", lambda syntax,state: state.enter_mode(syntax, 1))
				),
				1: FirstMatchDecider(
					Behavoir("_CLOSE", lambda syntax, state: state.exit_mode(syntax)),
					Behavoir("_OPEN", lambda syntax,state: state.enter_mode(syntax, 1))
				)
			}).default(lambda syntax, state: pr(syntax)),
			initial_mode = 0,
			final_modes = {0, 1},
			enter = { 1: lambda syntax, state: pr('->1:') },
			exit = { 1: lambda syntax, state: pr(')') },
			evolve = { 0: lambda x,y: pr('0'),
					   1: lambda x,y: pr('(') },
			devolve = { 0: lambda x,y: pr('0:') }
		)
	
	def test_hooks(self):
		self.m.feed("h(ell)o")
		self.m.finish()
		self.assertEqual(self.out, "h0->1:ell)0:o")
	def test_recursion(self):
		self.m.feed("h((e)ll)o")
		self.m.finish()
		self.assertEqual(self.out, "h0->1:(->1:e)ll)0:o")

from pasta_parser.machines.mode_path import ModePathMachine
class ModePathMachineTest(unittest.TestCase):
	def setUp(self):
		self.out = ""
		def pr(x): self.out += str(x)
		
		self.m = ModePathMachine(
			keywords = {
				Keyword('(', "_HELLO"),
				Keyword(')', "_GOODBYE"),
				Keyword('h', "_NADA")
			},
			driver = ModalDecider({
				0: FirstMatchDecider(
					Behavoir("_HELLO",
						lambda syntax, state:
							state.push_mode(1)
						),
					Behavoir("_GOODBYE",
						lambda syntax, state: progn(
							lambda: pr('bye')
					)),
					Behavoir("_DEFAULT",
						lambda syntax, state:
							pr(syntax)
						)
					),
				1: FirstMatchDecider(
					Behavoir("_GOODBYE",
							lambda syntax, state: progn(
								lambda: state.pop_mode()
							)),
					Behavoir("_HELLO",
							lambda syntax, state: progn(
								lambda: state.push_mode(1)
							)),
					Behavoir("_DEFAULT",
							lambda syntax, state: progn(
								lambda: pr(syntax)
							))
					)
			}),
			initial_mode = 0,
			final_modes = {0, 1}
		)
		
	def test_initialization(self):
		self.assertEqual(self.m.mode(), 0)
	def test_entrance_and_exit(self):
		self.m.feed("h(e")
		self.assertEqual(self.m.mode(), 1)
		self.assertEqual(self.m.peek(2), 0)
		self.assertTrue(self.m.peek(3) is None)
		self.m.feed("l)lo")
		self.assertEqual(self.m.mode(), 0)
		self.assertTrue(self.m.peek(2) is None)
		self.assertEqual(self.out, 'hello')
		self.m.feed(")")
		self.m.finish()
		self.assertEqual(self.m.mode(), 0)
		self.assertTrue(self.m.peek(2) is None)
		self.assertEqual(self.out, 'hellobye')
	def test_recursion(self):
		self.m.feed('(()')
		self.assertEqual(self.m.mode(), 1)
		self.assertEqual(len(self.m._path), 2)
		self.m.feed('(()')
		self.assertEqual(self.m.mode(), 1)
		self.assertEqual(len(self.m._path), 3)
		self.m.feed('))')
		self.assertEqual(self.m.mode(), 0)
		self.assertEqual(len(self.m._path), 1)
		self.m.finish()
		
	
from pasta_parser.machines.location import LocationMachine
class LocationMachineTest(unittest.TestCase):
	def setUp(self):
		self.out = ""
		self.pre = ''
		def pr(*x):
			for i in x: self.out += str(i) + ' '
			self.out += '\n'
		def bu(*x):
			for i in x: self.pre += str(i) + ' '
		self.m = LocationMachine(
			keywords = {
				Keyword('hi', "_HELLO"),
				Keyword('h', '_GOODBYE')
			},
			driver = FirstMatchDecider(
				LocatedBehavoir("_HELLO",
					lambda syntax, state: pr(state.location(), 'HI'),
					lambda syntax, state: state.push_location(),
				),
				LocatedBehavoir("_GOODBYE",
					lambda syntax, state: progn(
						lambda: pr(state.pop_location(), '"'+self.pre+'"'),
						lambda: pr('bye')
					),
					lambda x,y: pr(y.location())
				),
				LocatedBehavoir("_DEFAULT",
					lambda x,y: None,
					lambda x,y: bu(x)
				)
			)
		)
	
	def test_basic(self):
		self.m.feed('hi')
		self.m.finish()
		self.assertEqual(self.out, '(0, 0) HI \n')
	def test_location_stack(self):
		self.m.feed('hiiih')
		self.assertEqual(1, len(self.m._locations))
		self.m.finish()
		self.assertEqual(0, len(self.m._locations))
		self.assertEqual(self.out,
						 '(0, 0) HI \n(0, 2) "i i " \nbye \n(0, 5) \n')
		
from pasta_parser.machines.meaning import MeaningMachine
class MeaningMachineTest(unittest.TestCase):
	def setUp(self):
		self.o = ""
		def pr(x): self.o += x + ' '
	
		self.s = MeaningMachine(
			keywords = {
				Keyword('hi', "_HELLO"),
				Keyword('h', '_GOODBYE')
			},
			driver = FirstMatchDecider(
				Behavoir("_HELLO", lambda x, state: pr('HI')),
				Behavoir("_GOODBYE", lambda x, state: pr('bye')),
			).default(lambda x, state: pr(x))
		)
	
	def test_could_become(self):
		from pasta_parser.machines.meaning import _could_become
		self.assertTrue(_could_become('hello', 'he'))
		self.assertFalse(_could_become('hello', 'hello'))
		self.assertFalse(_could_become('hello', 'hello, world'))
		self.assertFalse(_could_become('hello', 'her'))
	def test_has_become(self):
		from pasta_parser.machines.meaning import _has_become
		self.assertFalse(_has_become('hello', 'he'))
		self.assertFalse(_has_become('hello', 'her'))
		self.assertTrue(_has_become('hello', 'hello'))
		self.assertTrue(_has_become('hello', 'hello, world'))
	def test_nothing(self):
		self.s.feed("")
		self.assertFalse(self.s._buffer)
		self.assertFalse(self.o)
	def test_something(self):
		self.s.feed("hiii")
		self.assertFalse(self.s._buffer)
		self.assertEqual(self.o, "HI i i ")
	def test_extra(self):
		self.s.feed("hiiih")
		self.assertEqual(self.s._buffer, 'h')
		self.assertEqual(self.o, "HI i i ")
	def test_finish(self):
		self.s.feed("hiiih")
		self.s.finish()
		self.assertFalse(self.s._buffer)
		self.assertEqual(self.o, "HI i i bye ")

class Keyword:
			def __init__(self, a, b):
				self.syntax = lambda: a
				self.semantics = lambda: b
