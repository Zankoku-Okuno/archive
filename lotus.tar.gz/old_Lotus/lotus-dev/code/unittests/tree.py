import unittest

from pasta_parser import parse_tree
class TestPrivates(unittest.TestCase):
	
	def test_structure(self):
		def closed():
			self.assertFalse(n._is_deep())
			self.assertTrue(n is n._descend())
		n = parse_tree._Node()
		closed()
		n._children.append("hello")
		closed()
		m = parse_tree._Node()
		n._children.append(m)
		self.assertTrue(n._is_deep())
		self.assertTrue(m is n._descend())
		m._open = False
		closed()
		n._children.append(parse_tree._Node())
		n._children.append("hello")
		closed()
	
	def test_frame(self):
		n = parse_tree._Node(test=1)
		self.assertEqual(1, n.frame('test'))
		self.assertEqual(1, n['test'])


from pasta_parser.parse_tree import *
class TestPublics(unittest.TestCase):
	def setUp(self):
		t = ParseTree()
		t.append('hi')
		t.deeper(eric=True)
		t.append(1)
		t.append(2)
		t.shallower()
		t.append('bye')
		self.t = t
	
	def test_toplevel(self):
		a = self.t
		self.assertEqual('hi', a._children[0].contents())
		self.assertEqual('bye', a._children[2].contents())
		self.assertTrue(isinstance(a._children[1], parse_tree._Node))
		self.assertEqual(3, len(a._children))
	def test_deeper(self):
		a = self.t._children[1]
		self.assertEqual(1, a._children[0].contents())
		self.assertEqual(2, a._children[1].contents())
		self.assertEqual(2, len(a._children))
	def test_frame(self):
		self.assertTrue(self.t._children[1].frame('eric'))
	def test_iterator(self):
		a = [lambda x: x.contents() == 'hi',
			 lambda x: isinstance(x, parse_tree._Node),
			 lambda x: x.contents() == 'bye']
		i = 0
		for item in self.t:
			self.assertTrue(a[i](item))
			i += 1
	#def test_len(self):
	#	self.assertEqual(4, len(self.t))
	def test_indexing(self):
		self.assertEqual('hi', self.t[0].contents())
		self.assertTrue(isinstance(self.t[1], parse_tree._Node))
		self.assertEqual(1, self.t[1][0].contents())
		self.assertEqual(2, self.t[1][1].contents())
		self.assertEqual('bye', self.t[2].contents())
	def test_overwriting(self):
		p = ParseTree()
		for char in self.t[2].contents():
			p.append(char)
		self.t[2] = p
		self.assertTrue(isinstance(self.t[2], parse_tree._Node))
		self.assertEqual(self.t[2][0].contents(), 'b')
		self.assertEqual(self.t[2][1].contents(), 'y')
		self.assertEqual(self.t[2][2].contents(), 'e')
	
