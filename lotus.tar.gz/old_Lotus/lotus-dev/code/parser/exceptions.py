from os.path import relpath

from functools import reduce

#
# Code for delaying exceptions
#

_delayed = []

def delayedRaise(ex):
	'''Holds an error which can (and should) be raised later on in the program.'''
	_delayed.append(ex)

def undelay():
	'''Raises any and all exceptions that have been stored away until now.
	If there are no exceptions in storage, then nothing happens.'''
	if len(_delayed) == 0:
		pass
	elif len(_delayed) == 1:
		raise _delayed[0]
	else:
		raise CompoundLotusError(_delayed)


#
# Support for new exceptions
#

class LotusParserError(Exception):
	pass

class CompoundLotusError(LotusParserError):
	def __init__(self, errs):
		self.errs = errs
		#print(self.errs)
	
	def __str__(self):
		return reduce(lambda x,y: '{0}\n{1}'.format(x,y), self.errs, '')

class TracedLotusError(LotusParserError):
	def __init__(self, obj):
		self.locations = [obj.now_location()]
	def append(self, obj):
		self.locations.append(obj.now_location)
	
	def __str__(self):
		return "TODO"

def load_context(location):
	'''Loads the text at the passed (file, line). A column is not required.
	'''
	f = open(location[0])
	for i in range(location[1] - 1): f.readline()
	linetext = f.readline()
	return linetext[:-1] if linetext and linetext[-1] == '\n' else linetext	

#
# New exception definitions
#

class ModuleStructureError(LotusParserError):
	pass

class SyntaxError(LotusParserError):
	def __init__(self, obj, msg):
		l = obj.location()
		ct = load_context(l)
		super().__init__("In '{0}' line {1}: {2}\ncol {3}\t{4}\n \\__>\t{5}^".format(
			relpath(l[0]), l[1], msg.capitalize(), l[2], ct,
			reduce(lambda x,y: x+y, [ '\t' if ct[x] == '\t' else ' ' for x in range(l[2]) ], '')
		))

class ConflictError(LotusParserError):
	def __init__(self, originator, obj1, obj2, msg):
		l1 = obj1.location()
		l2 = obj2.location()
		super().__init__("In '{2}' line {3}: {4}\n\tconflicts with: '{5}' line {6}.\n  >  {7}\n  >  {8}".format(
			None, None, relpath(l2[0]), l2[1], msg, relpath(l1[0]), l1[1], load_context(l1), load_context(l2)
		))


class EarlyEOL(LotusParserError):
	def __init__(self, extractor):
		l = extractor.location()
		ct = load_context(l)
		super().__init__("Unexpected end-of-line in '{0}' line {1} while in {2} Mode:\ncol {3}\t{4}\n \\__>\t{5}^".format(
			l[0], l[1], extractor.mode_name(), l[2], ct,
			reduce(lambda x,y: x+y, [ '\t' if ct[x] == '\t' else ' ' for x in range(l[2]) ], '')
		))

class EarlyEOF(LotusParserError):
	def __init__(self, extractor):
		l = extractor.location()
		ct = load_context(l)
		super().__init__("Unexpected end-of-file in '{0}' line {1} while in {2} Mode:\ncol {3}\t{4}\n \\__>\t{5}^".format(
			l[0], l[1], extractor.mode_name(), l[2], ct,
			reduce(lambda x,y: x+y, [ '\t' if ct[x] == '\t' else ' ' for x in range(l[2]) ], '')
		))

class RestrictedOperator(LotusParserError):
	def __init__(self, extractor):
		l = extractor.location()
		ct = load_context(l)
		super().__init__("Operator {0} cannot be used in '{1}' line {2} while in {3} Mode:\ncol {4}\t{5}\n \\__>\t{6}^".format(
			extractor.matchedLotus, l[0], l[1], extractor.mode_name(), l[2], ct,
			reduce(lambda x,y: x+y, [ '\t' if ct[x] == '\t' else ' ' for x in range(l[2]) ], '')
		))