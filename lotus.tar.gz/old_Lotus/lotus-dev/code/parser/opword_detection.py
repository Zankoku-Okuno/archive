import re

from .exceptions import *
from .seed_database import define_opword

use_opword = re.compile(r'\s'+define_opword+r'\s')

class OpwordScanner:
	def __init__(self):
		self.opwords = set()
	
	def feed(self, input, file, line):
		'''Returns true if this line is an opword statement, false otherwise.
		Also, if the line is an opword statement, it will:
			1) check the word for validity and soundness,
			2) add it to this scanner's memory,
			3) overwriting old memory if necessary.
		'''
		if not re.search(use_opword, input): return False
		attempt = Statement(input, file, line)
		if attempt.is_valid() and attempt.is_sound():
			self.inject(attempt)
		return True
	
	def inject(self, statement):
		'''Adds the statement to this scanner's memory, bypassing nigh all error-checking.
		The statement is still checked against ambiguity.
		If the statement is not transparent, then it overwrites the older statement.
		'''
		for existing in self.opwords:
			if not statement.is_unambiguous(existing):
				delayedRaise(ConflictError(self, existing, statement, "{0} already has a meaning".format(existing.operandA)))
				break
			if not statement.is_transparent(existing):
				self.opwords.remove(existing)
				self.opwords.add(statement)
				break
		else: self.opwords.add(statement)
	
	def merge(self, other):
		'''Attempts to merge another scanner into this one.
		Merging is successful if everything is transparent and unambiguous.
		If unsuccessful, delayed errors are raised, but the attempt continues.
		As long as things go smoothly, everything new in the other scanner becomes part of this scanner.
		'''
		for attempt in other.opwords:
			for existing in self.opwords:
				if not attempt.is_unambiguous(existing):
					delayedRaise(ConflictError(self, existing, attempt, "{0} already has a meaning".format(existing.operandA)))
					break
				if not attempt.is_transparent(existing):
					delayedRaise(ConflictError(self, existing, attempt, "{0} already has a symbol".format(existing.operandB)))
					break
			else: self.opwords.add(attempt)

class Statement:
	def __init__(self, input, file, line):
		assert input, "Don't feed empy inputs to Opword.Statement"
		self.text = input[:-1] if input[-1] == '\n' else input
		self.file, self.line, self.col = file, line, 0
		self.operandA, self.operandB = None, None

	def syntax(self): return self.operandA
	def semantics(self): return self.operandB
	
	
	def location(self):
		'''Returns a tuple (file, line, col) where this statement was found.
		col is zero unless there is an error on this line.'''
		return (self.file, self.line, self.col)
	
	def is_valid(self):
		'''Returns false if there are any syntax errors in this statement.
		Also, if there is an error, raised a delayed error and
		updates the location to the column where the error is.
		'''
		from .exceptions import SyntaxError
		#Not in the correct scope
		if re.match('\\s*\t', re.sub(' {3}', '\t', self.text)): #TODO remove the magic number
			self.col = 0
			delayedRaise(SyntaxError(self, "opword statement must be in module scope")) #TODO call it module?
			return False
		words = [ x for x in re.sub(r'\s+', ' ', self.text.strip()).split(' ') ]
		#'_OPWORD' appears more than once
		if words.count(define_opword) > 1:
			self.col = self.text.index(define_opword, text.index(define_opword)+1)
			delayedRaise(SyntaxError(self, "opword operator may only appear once in statement"))
			return False
		#Opword statement has more or less than one left argument
		if words[1] != define_opword:
			self.col = self.text.index(words[0])
			delayedRaise(SyntaxError(self, "exactly one argument required on left side of opword statement"))
			return False
		#Opword statement has more or less than one right argument
		if len(words) - words.index(define_opword) != 2:
			self.col = self.text.index(define_opword)+len(define_opword)+1
			delayedRaise(SyntaxError(self, "exactly one argument required on right side of opword statement"))
			return False
		self.operandA = words[0]
		self.operandB = words[2]
		return True
	
	def is_sound(self):
		'''Returns true only if the statement assigns an extant meaning.
		Also, if there is an error, raised a delayed error and
		updates the location to the column where the error is.
		'''
		from .seed_database import all_opwords
		if self.operandB not in all_opwords:
			self.col = self.text.index(define_opword)+len(define_opword)+1 #TODO this'll point wrong if there's extra whitespace, also, there are similar bits spread out around here
			delayedRaise(SyntaxError(self, "right-hand argument in opword statement must be a recognized opword"))
			return False
		else: return True
	
	def is_unambiguous(self, other):
		'''Given another opword statement, returns true if the operandA's are the same when they should not be.
			They may be the same if the operandB's are the same or both in an overloadable pair of the seed_database.
		If there is a problem, the column gets set, but something else must deal with it the rest of the way.
		'''
		from .seed_database import seed_keyword_pairs
		if self.operandA == other.operandA and self.operandB != other.operandB and reduce(
						lambda acc, pair: acc and (self.operandB and other.operandB) not in pair, seed_keyword_pairs):
			self.col = self.text.index(self.operandA)
			return False
		else: return True

	def is_transparent(self, other):
		'''Given another opword statement, returns false only if the operandB's are the same but the operandA's are different.
		If there is a problem, the column gets set, but something else must deal with it the rest of the way.
		'''
		if self.operandB == other.operandB and self.operandA != other.operandA:
			self.col = self.text.index(self.operandB, self.text.index(define_opword))
			return False
		else: return True
	
	def __eq__(self, other):
		return self.operandA and self.operandB and other.operandA and other.operandB and self.operandA == other.operandA and self.operandB == other.operandB

	def __hash__(self):
		return self.operandA.__hash__() + self.operandB.__hash__()

__all__ = ['OpwordScanner']