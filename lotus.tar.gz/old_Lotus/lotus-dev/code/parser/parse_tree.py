class Tree:
	def __init__(self, root=[]):
		self._data = root
		self._open = True
		
	#These methods provide functionality for initial building of the tree
	def is_open(self): return self._open
	def is_deep(self):
		return self._data and						\
			isinstance(self._data[-1], Tree) and	\
			self._data[-1].is_open()
	def descend(self):
		if self.is_deep(): return self._data[-1].descend()
		else: return self
	def append(self, item): self.descend()._data.append(item)
	def open(self): self.append(Tree())
	def close(self): self.descend()._open = False
	
	def __str__(self):
		return str(self._data) + ('d' if self.is_deep() else '') + ('o' if self._open else '')
	
	def __iter__(self):
		return next(self)
	def __next__(self):
		for datum in self._data:
			if isinstance(datum, Tree):
				for deeper_datum in datum: yield deeper_datum
			else: yield datum