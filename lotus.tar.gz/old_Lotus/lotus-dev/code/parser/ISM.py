from functools import reduce as fold
from .parse_tree import *

class InfiniteStateMachine:
	"""Really, it's only a small generalization on the standard finite state
	machine.
State may move into other states, also remembering where it came from so that it
can later exit states one-at-a-time. Furthermore, each state is actually a
"tower" of a certain height. Each time the path enters a state without
previously exiting therefrom, it enters on the next "floor" of the tower. In
this way, the path never crosses itself and if a floor of height n is occupied
by the path, so are all floors less than n.
  The goal is to have the path enter states to represent entering some syntactic
  structure, then push out completed syntactic structures as it exits states.
"""
#I need a different location strategy
# just keep all the location information as up-to-date as posible usign a stack
# file only changes when contextualized
# line only changes when certain sepcial items are found (though for now it's just newline)
# col changes +1 for each item read, but resets to 1 (currently 0) for each line completed
#I need a better output strategy, too
# put it all in here, maintaining the location stack

	def __init__(self, keywords=set(), driver=dict()):
	#structure for strings in various states of reading
		self.buffer = ""
		self.hunting = False
		self.found = ""
		self.lookahead = ""
		self.output = Tree()
	#structure for the various stacks 
		self.mode_stack = []
		self.next_floors = {k: 0 for k in driver.keys()}
		self.location_stack = []
	#structures for dealing with context
		self.file = None
		self.line = 0
		self.col = 0
	#structures for dealing with keywords
		self.syntaxes = {}
		self.detection = {}
	#structures for mediating behavoirs
		self.keywords = keywords
		self.driver = driver
		self.transitions = dict()
		self.enter_hooks = dict() #whenever a mode is just made to be on top of the stack
		self.exit_hooks = dict() #whenever a mode is just made to be not on top of the stack
		#TODO called during a transition
	
	#dealing with real startup and shutdown
	def set_up(self, mode=0, file=None, line=0, col=0):
		"""Sets up the machine to begin reading input."""
		self.contextualize(file, line, col)
		self.push_location()
		self.mode_stack.append(mode)
		self.next_floors[mode] += 1
		self._change_mode(None, mode)
		if self.mode() in self.enter_hooks: self.enter_hooks[self.mode()]()
	
	def tear_down(self):
		pass
	
	#arbitrary changes to context
	def contextualize(self, file=None, line=0, col=0):
		"""Changes the machine's context"""
		self.file = file
		self.line = line
		self.col = col
	
	# ------ The main waterfall ------ #
	
	
	def feed(self, input):
		"""Given an interable, goes through item-by-item, applying the appropriate transitions and actions along the way."""
		for item in input: self._smell(item)
	
	def _smell(self, item):
		"""Decides what to do about a given input item."""
		if self.hunting:
			self.lookahead += item
			self._hunt()
		elif item in self.detection:
			self.hunting = True
			self._smell(item)
		else:
			self._eat(item)
	
	def _eat(self, item):
		"""Consumes an input item based on ."""
		self.buffer += item
		self._digest(item)
		
	def _digest(self, item):
		"""Maintains context as each input item is consumed."""
		if item == '\n': #TODO make generalized
			self.line += 1
			self.col = 1
		else: self.col += 1
		
	def _hunt(self):
		"""Looks for keywords in the input."""
		potentials = { x for x in self.syntaxes
					   if matches_at_start(x, self.lookahead) }
		if potentials: #then we may have a keyword here
			candidates = { x for x in potentials
						   if matches_fully(x, self.lookahead) }
			if len(potentials) == len(candidates): #confirms we have found all candidates
				#given the syntaxes we've found, translate them all into semantics
				semantics = self._decode(candidates)
				#find the first stimulus-response in our driver that applies
				behavoir = [ behavoir for behavoir in self.driver[self.mode()]
									  if behavoir[0] in semantics ][0]
				#for that stimulus (semantics) find its largest syntax in our keywords: that's our self.found
				self.found = fold(lambda acc, i: i if acc < i else acc,
								{ keyword.syntax() for keyword in self.keywords
									if keyword.semantics() == behavoir[0] })
				#now, activate the callback and cleanup
				behavoir[1]()
				self._chew()
				self.hunting = False
				self._decay()
		else: #confirms the non-existence of an operator
			self.buffer += self.lookahead[0]
			self.lookahead = self.lookahead[1:]
			self._decay()
	
	def _chew(self):
		"""Having found a keyword, update the lookahead."""
		for item in self.found: self._digest(item)
		self.lookahead = self.lookahead[len(self.found):]
		self.found = ""
		
	def _decay(self):
		"""When there's lookahead left, ensure it's consumed correctly."""
		leftovers = self.lookahead
		self.lookahead = ""
		self.feed(leftovers)
	
	# ------ Maintenence of keyword detection and callbacks ------ #
	def _update_detectors(self):
		self.syntaxes = { keyword.syntax() for keyword in self.keywords
							if keyword.semantics() in
							{ behavoir[0] for behavoir in self.driver[self.mode()] }	#select the semantics of all the currently relevant behavoirs
						}
		self.detection = { syntax[0] for syntax in self.syntaxes }
		
	def _decode(self, syntaxes):
		return { keyword.semantics() for keyword in self.keywords
				 if keyword.syntax() in syntaxes }
	
	# ------ Maintentence of the mode stack ------ #
	
	def mode(self): return self.mode_stack[-1]
	
	def enter_mode(self, mode):
		fr = self.mode()
		self.mode_stack.append(mode)
		self.next_floors[mode] += 1
		self._change_mode(fr, self.mode())
	def exit_mode(self):
		fr = self.mode()
		self.next_floors[self.mode()] -= 1
		self.mode_stack = self.mode_stack[:-1]
		self._change_mode(fr, self.mode())
	def _change_mode(self, fr, to):
		if fr in self.exit_hooks: self.exit_hooks[fr]()
		if fr in self.transitions and to in self.transitions[fr]:
			self.transitions[fr][to]()
		self._chew()
		self._update_detectors()
		if to in self.enter_hooks: self.enter_hooks[to]()
	
	# ------ Maintenence of the location and output ------ #
	
	def push_location(self):
		self.location_stack.append((self.file, self.line, self.col))
	def pop_location(self):
		out = self.location_stack[-1]
		self.location_stack = [] if len(self.location_stack) == 1 else self.location_stack[:-1]
		return out
	
	def flush(self, constructor=None):
		if constructor and self.buffer:
				self.output.append(constructor(self.buffer, self.pop_location()))
		self.buffer = ""
	def open(self): self.output.open()
	def close(self): self.output.close()
	
	def vomit(self):
		pass #TODO








def matches_at_start(syntax, text):
	"""returns whether the text could be the start of syntax"""
	return text and								\
			matches_fully(syntax, text) or		\
			(	len(text) < len(syntax) and		\
				text == syntax[:len(text)]		\
			)
def matches_fully(syntax, text):
	"""returns whether the text begins with the syntax"""
	return len(syntax) <= len(text) and			\
			text[:len(syntax)] == syntax

class Keyword:
	def __init__(self, a, b):
		self.a = a
		self.b = b
	def syntax(self): return self.a
	def semantics(self): return self.b

if __name__ == '__main__':
	def pr(str): print(str)
	ISM = InfiniteStateMachine(
		{Keyword('a', "_A_")},#,Keyword('ah', "_B_")},
		{0: [
				("_B_", lambda: pr("hello")),
				("_A_", lambda: pr("hi"))
			]}
		)
	ISM.feed("hhahahahaaaa ")

