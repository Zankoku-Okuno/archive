
class Lexeme():
	'''	Provides an interface for accessing the properties of a single token.
	'''
	def __init__(self, content, location):
		'''	content should be a single string
			location is a triple (file, initial line, initial column)
		'''
		self.content = content
		self.file = location[0]
		self.line = location[1]
		self.col = location[2]
	def location(self):
		return (self.file, self.line, self.col)
	
	def __str__(self):
		return "{0}\n{1}\n".format(self.location(), self.content)




class Unknown(Lexeme):
	"""	For strings of lexemes that have not yet been tokenized"""
	pass
	
class Comment(Lexeme):
	'''	Included for completeness' sake.'''
	pass

class StringLiteral(Lexeme):
	"""	For lexemes that have been found to be string literals."""
	pass

class WovenUnknown(Lexeme):
	'''	For lexemes that have been woven into a string,
		but not yet tokenized.
	'''
	def __init__(self, content, location, depth):
		"""Depth is the number of strings deep into which this lexeme is woven"""
		self.depth = depth
		super().__init__(content, location)