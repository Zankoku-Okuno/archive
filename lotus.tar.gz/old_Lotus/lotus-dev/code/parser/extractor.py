from .lexemes import *
from .seed_database import *
from .exceptions import *
from .ISM import InfiniteStateMachine

mode_names = {
	0: "Standard",
	1: "Comment",
	2: "String",
	3: "Weaving"	
}

def progn(*lambdas):
	for lamb in lambdas:
		lamb()

flush_types = {
	0: Unknown,
	10: None,
	110: Comment
}

class Extractor(InfiniteStateMachine):
	

	def __init__(self, keywords):
		class Defaults:
			def __init__(self, syntax, semantics):
				self.syntax = lambda: syntax
				self.semantics = lambda: semantics
		keywords.add(Defaults('\n', '_NEWLINE'))
		
		super().__init__(keywords, self.__init_driver__())
		self.__init_hooks__()
	
	def __init_driver__(self):
		def ram(char):
			self.buffer += char
		return {
			0: [	(line_comment, lambda: progn(
						lambda: ram('\n'),
						lambda: self.enter_mode(10)) ),
					(begin_comment, lambda: self.enter_mode(110) )
				],
			10: [	('_NEWLINE', lambda: self.exit_mode() )
				],
			110:[	(begin_comment, lambda: self.enter_mode(110) ),
					(end_comment, lambda: self.exit_mode() )
				]
		}
	
	def __init_hooks__(self):
		self.enter_hooks = self.__init_enter__()
		self.exit_hooks = self.__init_exit__()
		self.transitions = self.__init_transitions__()
	
	def __init_enter__(self):
		return {
			0: lambda: self.push_location()
		}
	def __init_exit__(self):
		return {
			0: lambda: self.flush(Unknown),
			10: lambda: self.flush()
		}
	def __init_transitions__(self):
		return {
			0: {
				110: lambda: self.push_location()
			},
			110: {
				0: lambda: self.flush(Comment)
			}
		}



