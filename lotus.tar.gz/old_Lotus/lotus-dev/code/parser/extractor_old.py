from functools import reduce

from .lexemes import *
from .seed_database import *
from .exceptions import *


mode_names = {
	0: "Standard",
	1: "Comment",
	2: "String",
	3: "Weaving"	
}

class Extractor:
	#TODO make a generalized FSM engine (except that it's really an infinite state machine 'cause of the depths) and allow for custom match preferences
	def __init__(self, opwords):
		"""The opwords argument should contain all of the opwords that are defined for the input file.
		"""
		self.opwords = { x for x in opwords if x.operandB in (comment_opwords + string_opwords) }
		self.lexemes = []
		
		self.modeStack = []
		self.mode = 0
		self.hunting = False
		self.escaped = False
		self.weaveDepth = 0
		self.buffer = ""
		self.potential = ""
		self.matchedLotus = ""
		
		self.file = None
		self.line = -1
		self.col = 0
		self.col_stack = []
		
		self.__init_behavior()
		self.enterMode(0)
	
	#
	# Important Stuff
	#
	
	def contextualize(self, filename, lineno):
		'''The FSM needs to know where it is so it can report errors correctly: call this before feeding new input.'''
		if self.file != filename:
			if self.mode or self.hunting:
				raise EarlyEOF(self)
			else:
				self.naturalClose()
				self.file = filename
		if not self.mode // 100:
			self.line = lineno
		else: #multiline mode
			pass #don't update the line number
	
	def feed(self, input):
		'''	Top-level access for feeding the FSM.
			input shuld be a single line of text terminated by a newline,
			unless the line was taken from the end of a file'''
		#assert self.potential == "", "String phase FSM was fed new input while still handling lookahead." #I don't think this matters
		for char in input:
			print("{1}: {0}, {2}".format(self.mode, char, self.firstChars))
			if char != '\n': self.col += 1
			self.decisionMode(char)
			if char == '\n': self.col = 0
	
	#
	# Implementation Stuff
	#
	
	def decisionMode(self, char):
		if self.hunting: self.huntMode(char)
		elif self.mode == 30: #string weaving mode
			self.multilineMode(char)
		elif self.mode // 100: #multiline modes
			self.multilineMode(char)
		else: self.onelineMode(char)
		
	
	def artificialClose(self):
		'''When an operator is found, use this to close off the buffer into a lexeme.'''
		normalized = self.mode // 10 % 10
		if normalized == 0: #Unexplained
			if self.buffer:#We don't want empty unexplained stuff, that's just boring
				self.lexemes.append(Unknown(self.buffer, self.lex_location()))
				self.col_stack = self.col_stack[:-1]
		elif normalized == 1: #Comments
			self.col_stack = self.col_stack[:-1] #Just discard comments TODO: consider keeping them around: doc strings
		elif normalized == 2: #Strings
			self.lexemes.append(StringLiteral(self.buffer, self.lex_location()))
			self.col_stack = self.col_stack[:-1]
		elif normalized == 3: #String weaving
			self.lexemes.append(WovenUnknown(self.buffer, self.lex_location(), self.weaveDepth))
			self.col_stack = self.col_stack[:-1]
		else: assert False, "The string phase FSM made it to an illegal mode."
		
		self.buffer = ""
	
	def naturalClose(self):
		'''When a newline is found outside of multi-line input, use this to attempt to close the buffer into a lexeme.'''
		#TODO verify I have the semantics right, although I can't come up with a test for it, either
		#assert not self.mode // 100, "Tried to do a natural close in a muti-line mode." #again, I don't think I care
		if 20 <= self.mode < 30: #In a one-line string mode
			raise EarlyEOL(self)
		elif self.mode == 0 or self.mode == 30:
			self.artificialClose()
		else:
			self.exitMode()
			if not self.mode // 100: self.naturalClose()
	#NOTE: weird grammar: "This may well be the most difficult to ensure I have the semantics right"
	
	def onelineMode(self, char):
			'''Handles input characters under most circumstances; c.f. multilineMode and hunterMode'''
			if char == '\n':
				self.naturalClose()
			else:
				self.multilineMode(char)
	
	def multilineMode(self, char):
		'''Handles input characters when in a multi-line mode and not hunting for operators'''
		if self.escaped:
			self.buffer += char
			self.escaped = False
		elif char in self.firstChars:
			self.hunting = True
			self.huntMode(char)
		else:
			self.buffer += char
	
	def huntMode(self, char):
			'''Adds chars to help disambiguate, then shuffles the work to resolveMode'''
			assert self.hunting, "Entered huntMode without actually hunting."
			self.potential += char
			self.resolveMode()
	
	def resolveMode(self):
			'''Handles all lookahead tasks in case they are needed to disambiguate operators.
			Larger operators are preferred, when they can be found.'''
			eventualMatches = { x for x in self.attend[self.mode] if x.could_eventually_begin(self.potential) }
			if eventualMatches: #We may have an operator here
				completeMatches = { x for x in eventualMatches if x.currently_begins(self.potential) }
				if len(completeMatches) == len(eventualMatches): #The lookahead confirms we have found the largest possible operator here
					#A single lotus operator might have multiple seed meanings
					self.matchedLotus = reduce(lambda x, y: x if len(x.operandA) > len(y.operandA) else y, completeMatches).operandA
					sememes = { x.operandB for x in self.attend[self.mode] if x.operandA == self.matchedLotus }
					#Find the (one) behavior we should enact by delving through a priority queue
					[ behavior[1] for behavior in self.behave[self.mode] if behavior[0] in sememes ][0]()
					#if not self.escaped: self.lexemes.append(OpwordLexeme(self.matchedLotus, self.file, self.line)) #TODO consider if I want this
					self.cleanupMode(len(self.matchedLotus))
				else: #There might be a bigger operator than what we've found so far
					pass
			else: #The lookahead confirms the non-existence of any operator
				self.buffer += self.potential[0]
				self.cleanupMode(1)
	
	def cleanupMode(self, howMuchIsHandled):
		self.hunting = False
		nextInput = self.potential[howMuchIsHandled:]
		self.potential = ""
		if nextInput:
			self.col -= len(nextInput)
			self.feed(nextInput)
	
	def enterMode(self, mode):
		self.modeStack.append(mode)
		self.changeMode(mode)
		assert self.modeStack[-1] == self.mode, "Modes got out of synch."
		
	def exitMode(self):
		assert self.mode or not self.weaveDepth, "Even though we're in standard mode, we aren't fully unweaved."
		assert self.modeStack, "Tried to exit a mode, but there's no mode to exit to."
		assert self.mode, "Tried to exit from a standard mode, but that should be the root mode."
		self.modeStack = self.modeStack[:-1]
		self.changeMode(self.modeStack[-1])
		assert self.modeStack[-1] == self.mode, "Modes got out of synch."
	
	def changeMode(self, mode):
		self.artificialClose()
		self.col_stack.append(self.col - len(self.potential))
		self.mode = mode
		self.firstChars = { x.operandA[0] for x in self.attend[self.mode] }
	
	def escape(self):
		self.buffer += self.matchedLotus
		self.escaped = True
	
	def weave(self):
		self.weaveDepth += 1
		self.enterMode(30)
		
	def unweave(self):
		self.exitMode()
		self.weaveDepth -= 1
	
	def poorChoice(self, attempt):
		raise RestrictedOperator(self)
		
	def __init_behavior(self):
		self.behave = dict()
		
		def escapeable(cdr):
			return [ (string_escape, lambda: self.escape()) ] + cdr
		
		def weaveable(cdr):
			return [ (begin_string_weave, lambda: self.weave()) ] + cdr
		
		def unweaveable(cdr):
			return [ (end_string_weave, lambda: self.unweave()) ] + cdr
		
		def enterComments(cdr):
			return [
				(line_comment, lambda: self.enterMode(10)),
				(begin_comment, lambda: self.enterMode(110))
			] + cdr
		
		def exitComments(cdr):
			return [ (end_comment, lambda: self.exitMode()) ] + cdr
		
		def enterStrings(cdr):
			return [
				(begin_string1, lambda: self.enterMode(20)),
				(begin_string2, lambda: self.enterMode(21)),
				(begin_string3m, lambda: self.enterMode(120)),
				(begin_string4m, lambda: self.enterMode(121))
			] + cdr
		
		def exitString(opword, cdr):
			return [ (opword, lambda: self.exitMode()) ] + cdr
		
		def cantEnterString(opword, cdr):
			return [ (opword, lambda: self.poorChoice("enter string")) ] + cdr
		
		def cantExitStrings(cdr):
			return [
				(end_string1, lambda: self.poorChoice("exit string")),
				(end_string2, lambda: self.poorChoice("exit string")),
				(end_string3m, lambda: self.poorChoice("exit string")),
				(end_string4m, lambda: self.poorChoice("exit string"))
			] + cdr
		
		def cantExitComments(cdr):
			return [ (end_comment, lambda: self.poorChoice("exit comment")) ] + cdr
		
		#Standard mode
		self.behave[0] = enterComments(enterStrings(cantExitStrings(cantExitComments([]))))
		
		#Comment modes
		self.behave[10] = []
		self.behave[110] = enterComments(exitComments([]))
		
		#String modes
		self.behave[20] = escapeable(weaveable(exitString(end_string1, cantEnterString(begin_string1, []))))
		self.behave[21] = escapeable(weaveable(exitString(end_string2, cantEnterString(begin_string2, []))))
		self.behave[120] = escapeable(weaveable(exitString(end_string3m, cantEnterString(begin_string3m, []))))
		self.behave[121] = escapeable(weaveable(exitString(end_string4m, cantEnterString(begin_string4m, []))))
		
		#Weave mode
		self.behave[30] = unweaveable(enterComments(enterStrings(cantExitStrings(cantExitComments([])))))
		
		self.attend = dict()
		for mode in self.behave:
			self.attend[mode] = { x for x in self.opwords if x.operandB in { x[0] for x in self.behave[mode] } }
		
	
	
	
	#
	# Support Stuff
	#
	
		

	
	def mode_name(self):
		return mode_names[self.mode // 10 % 10]
	
	def location(self): #TODO add a location method that gets the location for starts of lexemes
		return (
			self.file,
			self.line + self.buffer.count('\n'),# + self.potential.count('\n'),
			self.col - (0 if self.hunting else len(self.potential))# - reduce(
				#lambda x,y: x+y, { len(z)+1 for z in (self.buffer).split('\n')[:-1] }, 0)
		)
	
	def lex_location(self):
		return (self.file, self.line, self.col_stack[-1])

	
	
	
	
	
	
	
	
	
	
	
	