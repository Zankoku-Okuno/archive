#!/usr/bin/env python
# -*- coding: utf-8 -*-





define_opword = "_OPWORD"


line_comment = "_LINE_COMMENT"
begin_comment = "_BEGIN_COMMENT"
end_comment = "_END_COMMENT"

begin_string1 = "_START_WEAK_STRING"
begin_string2 = "_START_STRONG_STRING"
begin_string3m = "_START_WEAK_MULTILINE_STRING"
begin_string4m = "_START_STRONG_MULTILINE_STRING"
end_string1 = "_END_WEAK_STRING"
end_string2 = "_END_STRONG_STRING"
end_string3m = "_END_WEAK_MULTILINE_STRING"
end_string4m = "_END_STRONG_MULTILINE_STRING"
string_escape = "_STRING_ESCAPE"
begin_string_weave = "_STRING_WEAVE"
end_string_weave = "_STRING_UNWEAVE"



comment_opwords = [ line_comment , begin_comment, end_comment ]
string_opwords = [
	begin_string1, begin_string2, begin_string3m, begin_string4m,
	end_string1, end_string2, end_string3m, end_string4m,
	string_escape, begin_string_weave, end_string_weave
]

all_opwords = comment_opwords + string_opwords

seed_keyword_pairs = [
	(begin_comment, end_comment),
	(begin_string1, end_string1),
	(begin_string2, end_string2),
	(begin_string3m, end_string3m),
	(begin_string4m, end_string4m),
	(begin_string_weave, end_string_weave)
]




__all__ = [
	'all_opwords',
	'comment_opwords',
	'string_opwords',
	
	'define_opword',
	'line_comment',
	'begin_comment',
	'end_comment',
	'begin_string1',
	'begin_string2',
	'begin_string3m',
	'begin_string4m',
	'end_string1',
	'end_string2',
	'end_string3m',
	'end_string4m',
	'string_escape',
	'begin_string_weave',
	'end_string_weave'
]
