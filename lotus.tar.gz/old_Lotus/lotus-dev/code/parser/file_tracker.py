from copy import copy
import fileinput
import os.path
import re

from .opword_detection import OpwordScanner
from .exceptions import *

_all_files = dict()
def get_lotus(filepath):
	'''Use this to both obtain existing lotus files and create new ones.
	This ensures that data is not needlessly re-calculated and duplicated.
	'''
	if filepath not in _all_files:
		_all_files[filepath] = LotusFile(filepath)
	return _all_files[filepath]

class LotusFile:
	'''This class deals with keeping track of all the (so-far) known information about each lotus file.
	Be sure to call methods in the correct order:
		1) map_watershed
		2) get_opwords
		3+) TODO
	'''
	def __init__(self, filepath):
		self.path = filepath
		self.dir, self.file = os.path.split(filepath)
		self.lines_already_scanned = set()
		
		self.module = None
		self.tributaries = None
		
		self.explicit_opwords = None
		self.implicit_opwords = None
		self.opwords = None
		
		self.lexemes = None
		
		self.flags = { 'extract': False }
	
	def map_watershed(self):
		'''Recursively map the watershed which leads into this file.
		The watershed delivers only notations to this file, and even then, only provided their consistency.
		'''
		self.module = self.find_module()
		self.tributaries = self.find_explicit_tributaries()
		#TODO ensure no circular dependencies
		if self.module: self.module.map_watershed()
		{ tributary.map_watershed() for tributary in self.tributaries }
		undelay()
	
	def get_opwords(self): #TODO support import tracking when creating exceptions
		'''Recursively get opwords from upstream.
		Errors out if two opwords from different streams conflict.
		Opwords from modules can get overwritten, however.
		Opwords defined in this file are also scanned, and override anything inherited.
		'''
		if not self.opwords:
			self.opwords = copy(self.get_implicit_opwords())
			[ self.opwords.inject(explicit) for explicit in self.get_explicit_opwords().opwords ]
		return copy(self.opwords)
	
	def extract_strings_and_comments(self):
		'''Extract all strings and comments from the input file.
		'''
		if not self.flags['extract']:
			from .extractor import Extractor
			extractor = Extractor(self.opwords.opwords)
			first_line = 1
			for line in self.lines_already_scanned:
				if line in self.lines_already_scanned: first_line += 1
				else: break
			extractor.set_up(file=self.path, line=first_line, col=1)
			with fileinput.input(files=self.path) as file:
				for line in file:
					if file.lineno() not in self.lines_already_scanned:
						#print(file.lineno(), line[:7])
						extractor.contextualize(file.filename(), file.lineno(), 1)
						extractor.feed(line)
				extractor.contextualize(None, None)
				extractor.feed('')
			self.lexemes = extractor.output
	
	#
	# Helpers
	#
	
	def find_module(self):
		search_path = os.path.split(self.dir)[0] if self.file == 'petal' or re.match(r'.*\.petal\Z', self.file) else self.dir
		modules = [ x for x in os.listdir(search_path) if x == 'petal' or re.match(r'.*\.petal\Z', x) ]
		if len(modules) == 0:
			return None
		elif len(modules) == 1:
			return  get_lotus(os.path.join(search_path, modules[0]))
		else:
			raise ModuleStructureError("Directory '{0}' has multiple module definitions:\n  >  {1}".format(search_path, modules))
	
	def find_explicit_tributaries(self):
		lines = []
		paths = []
		with fileinput.input(files=self.path) as file:
			searching = True #but not yet found
			for line in file:
				if re.match(r'\s*\Z', line):
					self.lines_already_scanned.add(file.lineno())
				elif searching:
					if re.match(r'pond\s', line):
						searching = False
						if re.match(r'\s*\S', line[4:]): #file on pond line
							lines.append(file.lineno())
							paths.append(line[4:])
						self.lines_already_scanned.add(file.lineno())
					else: break
				else: #not searching
					if re.sub(' {3}', '	', line)[0] == '\t':
						lines.append(file.lineno())
						paths.append(line)
						self.lines_already_scanned.add(file.lineno())
					else: break
		attempts = [ os.path.normpath(os.path.join(self.dir,
													re.sub(r'\A/', '',
														re.sub('//', '/../',
															re.sub(r'\.', '/',
																path.strip())))+'.spring')) for path in paths ]
		out = []
		for i in range(len(attempts)):
			if os.path.exists(attempts[i]):
				out.append(get_lotus(attempts[i]))
			else:
				delayedRaise(ModuleStructureError("Non-existent file '{0}' imported.\n     In '{1}' line {2}".format(
													attempts[i], self.file, lines[i])))
		return out
	
	def get_implicit_opwords(self):
		if not self.implicit_opwords:
			self.implicit_opwords = self.module.get_opwords() if self.module else OpwordScanner()
			explicit_implicit = OpwordScanner()
			[ explicit_implicit.merge(tributary.get_implicit_opwords()) for tributary in self.tributaries ]
			undelay()
			[ self.implicit_opwords.inject(opword) for opword in explicit_implicit.opwords ]
		return self.implicit_opwords
	
	def get_explicit_opwords(self):
		if not self.explicit_opwords:
			self.explicit_opwords = OpwordScanner()
			[ self.explicit_opwords.merge(tributary.get_explicit_opwords()) for tributary in self.tributaries ]
			undelay()
			#scan this file if necessary
			if self.file == 'petal' or re.match(r'.*\.(petal|spring)\Z', self.file):
				with fileinput.input(files=self.path) as file:
					for line in file:
						if line not in self.lines_already_scanned:
							if self.explicit_opwords.feed(line, file.filename(), file.lineno()):
								self.lines_already_scanned.add(file.lineno())
			undelay()
		return self.explicit_opwords
	

__all__ = ['get_lotus']
	