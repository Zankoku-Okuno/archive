from okulib import progn

from .hook import HookMachine
from .location import LocationMachine
class HookLocationMachine(HookMachine, LocationMachine):
	def __init__(self, keywords, driver, initial_mode, final_modes,
				 enter=dict(), evolve=dict(), devolve=dict(), exit=dict()):
		self.keywords = keywords
		self.driver = driver
		self.final_modes = final_modes
		
		self.enter_hooks = enter
		self.evolve_hooks = evolve
		self.devolve_hooks = devolve
		self.exit_hooks = exit
		
		self.reset(initial_mode)
	
	def reset(self, reinitial_mode, line=0, col=0):
		self._reset_meaning()
		self._reset_location(line, col)
		self._reset_hook(reinitial_mode)

	def start_to_enter_mode(self, syntax, mode):
		return progn(lambda: self._evolve_from(syntax), lambda: self.push_mode(mode) )
	def finish_entering_mode(self, syntax, mode):
		return self._enter_into(syntax)

	def start_to_exit_mode(self, syntax):
		return progn(lambda: self._exit_from(syntax), lambda: self.pop_mode())
	def finish_exiting_mode(self, syntax):
		return self._devolve_into(syntax)