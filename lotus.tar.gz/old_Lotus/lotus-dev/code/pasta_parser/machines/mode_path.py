from .meaning import MeaningMachine
class ModePathMachine(MeaningMachine):
	def __init__(self, keywords, driver, initial_mode, final_modes):
		self.keywords = keywords
		self.driver = driver
		self.reset(initial_mode)
		self.final_modes = final_modes
	
	def reset(self, reinitial_mode):
		self._reset_meaning()
		self._reset_mode(reinitial_mode)
	def _reset_mode(self, reinitial_mode):
		self._path = []
		self.push_mode(reinitial_mode)
	def _feed_eof(self):
		if self.mode() not in self.final_modes: raise UnexpectedEOF(self)
	
	def push_mode(self, mode):
		self._path.append(mode)
	def pop_mode(self):
		out = self.peek()
		self._path = self._path[:-1]
		return out
	def peek(self, depth=1):
		if len(self._path) < depth: return None
		else: return self._path[-depth]
	def mode(self): return self.peek()

class UnexpectedEOF(Exception):
	def __init__(self, state):
		self.state = state