from okulib import progn

from .mode_path import ModePathMachine, UnexpectedEOF
class HookMachine(ModePathMachine):
	def __init__(self, keywords, driver, initial_mode, final_modes,
				 enter=dict(), evolve=dict(), devolve=dict(), exit=dict()):
		self.enter_hooks = enter
		self.evolve_hooks = evolve
		self.devolve_hooks = devolve
		self.exit_hooks = exit
		super().__init__(keywords, driver, initial_mode, final_modes)
	
	def _reset_hook(self, reinitial_mode):
		self._reset_mode(reinitial_mode)
		self._enter_into(None)
	def _feed_eof(self):
		if self.mode() not in self.final_modes: raise UnexpectedEOF(self)
		self._exit_from(None)
	
	def _hook(self, hook_type, syntax):
		if self.mode() in hook_type:
			hook_type[self.mode()](syntax, self)
	
	def _enter_into(self, syntax): self._hook(self.enter_hooks, syntax)
	def _evolve_from(self, syntax): self._hook(self.evolve_hooks, syntax)
	def _devolve_into(self, syntax): self._hook(self.devolve_hooks, syntax)
	def _exit_from(self, syntax): self._hook(self.exit_hooks, syntax)
	

	def enter_mode(self, syntax, mode):
		return progn(
			lambda: self._evolve_from(syntax),
			lambda: self.push_mode(mode),
			lambda: self._enter_into(syntax) )
	def exit_mode(self, syntax):
		return progn(
			lambda: self._exit_from(syntax),
			lambda: self.pop_mode(),
			lambda: self._devolve_into(syntax) )