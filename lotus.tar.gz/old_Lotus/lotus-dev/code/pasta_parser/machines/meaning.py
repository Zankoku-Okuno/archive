def _could_become(syntax, input):
	"""returns whether the text, after having appropriate items added, could become the syntax
	
	if the input is longer than the syntax, then return false: _has_become is a better test"""
	return len(input) < len(syntax) and input == syntax[:len(input)]
def _has_become(syntax, input):
	"""returns whether the text begins with the syntax
	
	if input is longer than the syntax, it does not matter"""
	return len(syntax) <= len(input) and input[:len(syntax)] == syntax

class MeaningMachine:
	def __init__(self, keywords, driver):
		"""Keywords provides a set of symbol-sign/syntax-semantics pairs. Driver provides actions for each meaning based on the state of the machine."""
		self.keywords = keywords
		self.driver = driver
		self._reset_meaning()
	
	def feed(self, input):
		"""Parses the input as much as possible and awaits further input."""
		self._buffer = self._continue(self._buffer + input if self._buffer else input)
	def finish(self):
		"""Signals that no further input is coming, so parsing should go ahead even in the face of uncertainty."""
		self._buffer = self._finish(self._buffer)
		self._feed_eof()
	def reset(self): self._reset_meaning()
	def _reset_meaning(self):
		"""Causes the machine to revert to a clean (initial) state."""
		self._buffer = None
	
	def _continue(self, input):
		if not input: return None
		else:
			potentials = self._fetch( lambda x: 
								_could_become(x.syntax(), input) or
								_has_become(x.syntax(), input) )
			if not potentials: return self._step(self._continue, input)
			else:
				candidates = { x for x in potentials if _has_become(x.syntax(), input) }
				return input if len(potentials) != len(candidates) \
					else self._leap(self._continue, input, candidates)
				
	def _finish(self, input):
		if not input: return None
		candidates = self._fetch( lambda x: _has_become(x.syntax(), input) )
		if not candidates: return self._step(self._finish, input)
		else: return self._leap(self._finish, input, candidates)
	
	def _step(self, recurse, input):
		syntax = input[0]
		semantic, action = self._decode("_DEFAULT")
		return self._move(syntax, action, recurse, input)
	def _leap(self, recurse, input, candidates):
		from functools import reduce as fold
		semantic, action = self._decode({ x.semantics() for x in candidates })
		syntax = fold(lambda acc,i: i if len(acc) < len(i) else acc,
					  { x.syntax() for x in candidates if x.semantics() == semantic })
		if 'preact' in action.__dict__:
			action.preact(syntax, self)
			return recurse(input)
		else: return self._move(syntax, action, recurse, input)
	
	def _act(self, syntax, action):
		action.act(syntax, self)
	def _fetch(self, filter_function):
		return { x for x in self.keywords
				if self.driver.detects(self, x.semantics())
					and filter_function(x) }
	def _decode(self, semantics):
		return self.driver.decide(self, semantics)
	def _move(self, syntax, action, recurse, input):
		self._act(syntax, action)
		return recurse(self._cleanup(syntax, input))
	def _cleanup(self, syntax, input):
		return input[len(syntax):]
	def _feed_eof(self): pass