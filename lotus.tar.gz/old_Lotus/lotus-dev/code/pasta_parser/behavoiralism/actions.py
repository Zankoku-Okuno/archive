class Action:
	def __init__(self, function): self.act = function

class Preaction(Action):
	def __init__(self, function): self.preact = function

class LocatedAction(Action):
	def __init__(self, function, postaction):
		super().__init__(function)
		self.postact = postaction