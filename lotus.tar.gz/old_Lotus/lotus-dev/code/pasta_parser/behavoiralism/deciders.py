class FirstMatchDecider:
	def __init__(self, *prioritized_responses):
		self.responses = [ x for x in prioritized_responses ]
		self._detection_cache = { x.stimulus() for x in self.responses }
	
	def decide(self, state, stimuli):
		for behavoir in self.responses:
			if behavoir.stimulus() in stimuli:
				return behavoir.stimulus(), behavoir.response()
		else: raise Exception(stimuli) #TODO
	
	def detects(self, state, stimulus):
		return stimulus in self._detection_cache
	
	def default(self, default):
		if "_DEFAULT" not in { x.stimulus() for x in self.responses }:
			from .behavoirs import Behavoir
			self.responses.append(Behavoir("_DEFAULT", default))
		return self

class ModalDecider:
	def __init__(self, driver):
		self.responses = driver
	
	def decide(self, state, stimuli):
		if state.mode() in self.responses:
			return self.responses[state.mode()].decide(state, stimuli)
		else: raise Exception() #TODO
	
	def detects(self, state, stimulus):
		return state.mode() in self.responses and \
			self.responses[state.mode()].detects(state, stimulus)
	
	def default(self, default):
		for response in self.responses.values():
			response.default(default)
		return self