class _Leaf:
	def __init__(self, contents, **frame_data):
		self._frame = frame_data
		self._contents = contents
	def frame(self, key): return self._frame[key]
	def contents(self): return self._contents

class _Node:
	def __init__(self, **frame_data):
		self._frame = frame_data
		self._children = []
		self._open = True
	def frame(self, key): return self._frame[key]
	
	def _descend(self):
		if self._is_deep(): return self._children[-1]._descend()
		else: return self
	def _is_deep(self):
		return self._children and isinstance(self._children[-1], _Node) and \
			self._children[-1]._open
	
	def __iter__(self): return self._children.__iter__()
	
	#def __len__(self):
	#	from functools import reduce as fold
	#	return fold(lambda acc,i: acc + (len(i) if isinstance(i, _Node) else 1),
	#				self, 0)
	
	def __getitem__(self, index):
		return self.frame(index) if isinstance(index, str) else self._children[index]
	def __setitem__(self, index, value):
		if isinstance(index, str):
			self.frame[index] = value
		else: self._children[index] = value
		
class ParseTree(_Node):
	def __init__(self): super().__init__()
		
	def deeper(self, **frame_data):
		self._descend()._children.append(_Node(**frame_data))
	def append(self, item, **frame_data):
		self._descend()._children.append(_Leaf(item, **frame_data))
	def shallower(self):
		self._descend()._open = False
	