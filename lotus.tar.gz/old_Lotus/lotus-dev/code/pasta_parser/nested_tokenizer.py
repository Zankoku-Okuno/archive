from .machines.hook_location import HookLocationMachine
from .parse_tree import ParseTree

class NestedTokenizer(HookLocationMachine):
	def __init__(self, keywords, driver, initial_mode, final_modes,
				 enter=dict(), evolve=dict(), devolve=dict(), exit=dict()):
		super().__init__(keywords, driver, initial_mode, final_modes,
						 enter, evolve, devolve, exit)
		self._storage = ''
		self._output = ParseTree()
	
	def buffer(self, syntax):
		self._storage += syntax
		#NOTE if _buffer were the name of _storage, it would conflict with MeaningMachine._buffer, which is STUPID!
	def flush(self, **frame_data):
		self._output.append(self._storage, **frame_data)
		self._storage = ''
	def deeper(self, **frame_data):
		self._output.deeper(**frame_data)
	def shallower(self):
		self._output.shallower()