from rxengine import *


t = TransitionTable()
p = 1
q = -1

t.add(p, p, (1,2,3))
t.add(p, p, (1,2,5))

t.add(p, q, (1,2,5))

t.add(q, q, (1,2,3))

print(t)

m = Machine(t, {p}, {q})
print(m.trace([(1,2,5),(1,2,3)]))
