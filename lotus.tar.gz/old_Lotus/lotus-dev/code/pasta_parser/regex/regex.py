from rxconst import epsilon

class Bounds:
    def __init__(self, begin, end):
        self.begin = begin
        self.end = end
    def copy(self):
        return Bounds(self.start, self.end)
    def glomb(self, symbol):
        if symbol is not epsilon:
            self.end += 1
    def __eq__(self, other):
        return other.isinstance(Bounds) and (
            self.begin == other.begin and self.end == other.end )

class Groups:
    self._data = dict() #from group name to list of Bounds
    #DOC names are _flat_: b/r name scope is always global to the match
    def copy(self):
        return {key: self._data[key] for key in self._data}
    def glomb(symbol, group):
        if group not in self:
            raise KeyError(group)
        for bounds in self._data[group]:
            bounds.glomb(symbol)
    def __contains__(self, group):
        return group in self._data
    def __getitem__(self, group):
        """Call to retrieve an already matched group.
        
        Since groups may have match multiple matches associated, a list of all matches is returned.
        If there is no match for the group, then the empty list is returned.
        FIXME All groups will be returned, even if they are not done matching."""
        return self._data[group] if group in self else []
    def __setitem__(self, group, begin):
        """Call when a new group needs to be tracked.
        
        group = the name of the group to be tracked
        begin = the index where the group begins"""
        if group not in self:
            self._data[group] = []
        self._data[group].append(Bounds(begin, begin))
    def __eq__(self, other):
        if not other.isinstance(Groups):
            return False
        if len(self._data) != len(other._data):
            return False
        for key in self._data:
            if key not in other._data:
                return False
            if self._data[key] != other._data[key]:
                return False
        else:
            return True
    

class Agent:
    def __init__(self, state):
        self.state = state
        self.bounds = MatchBounds(0, 0)
        self.groups = Groups()
    def copy(self):
        out = Agent(self.state)
        out.bounds = self.bounds.copy()
        out.groups = self.groups.copy()

class BasicState:
    self.transitions = dict()
    
    def add_transition(self, symbol, state):
        if symbol not in self.transitions:
            self.transitions[symbol] = set()
        self.transitions[symbol].add(state)
    
    def on_enter(self, agent):
        return agent
    
    def update(agents, symbol):
        if symbol not in self.transitions:
            return set()
        new_states, new_agents = self.transitions[symbol], set()
        for agent in agents:
            for state in new_states:
                new_agents.add(state.on_enter(agent.copy()))
                