
#NO! wait a minute:
#why don't we just use Thompson's construction?
#we keep track of multiple paths as in an NFA
#then, could match is true if there are any live states
#has matched is true if any paths have reached a terminal state
#terminal staets persist but do not count as alive

#each path keeps track of the input it has matched and related data for backreferencing
#when a path exits from a particular kleene star subexpression, it kills all the paths that exited earlier?

#the one difficulty (which is obvious from definitions) is dealing with nested structures.
#but, no biggie, probably: actually, nesting has already been parsed out of the way
#oh, and backreferences



#split by alternation
#apply kleene star
#build/integrate subexpressions
#build literal transitions

class Machine:
	def __init__(self, transition_table, initial_states, final_states):
		self.table = transition_table
		self.initial_states = initial_states
		self.final_states = final_states
	
	def trace(self, iterable, start_from=None):
		agents = self.table.epsilon_close(self.get_initial_agents()) if start_from is None else start_from
		for item in iterable:
			agents = self.table.move_all(agents, item)
		return ({agent for agent in agents if agent.state in self.final_states},
				{agent for agent in agents if agent.state not in self.final_states})
	
	def get_initial_agents(self, start_index=0):
		return {Agent(state, start_index, start_index) for state in self.initial_states}

class _Epsilon:
	def __str__(self):
		return "None"
epsilon = _Epsilon()

class TransitionTable:
	def __init__(self):
		self.transitions = dict()
		self.backreferences = set() #of pairs (start states set, end states set)
	
	# === Table Structure Definition ===
	
	def add(self, from_state, to_state, on_input):
		if from_state not in self.transitions:
			self.transitions[from_state] = dict()
		if to_state not in self.transitions:
			self.transitions[to_state] = dict()
		if on_input not in self.transitions[from_state]:
			self.transitions[from_state][on_input] = set()
		self.transitions[from_state][on_input].add(to_state)
	
	def join(self, state1, state2):
		#we make sure that state1 connects out to all the states that state2
		#also connects out to
		for on_input in self.transitions[state2]:
			for to_state in self.transitions[state2][on_input]:
				self.add(state1, on_input, to_state)
		#now we replace any entrance into state2 with an entrance into state1
		for from_state in self.transitions:
			for on_input in self.transitions[from_state]:
				if state2 in self.transitions[from_state][on_input]:
					self.transitions[from_state][to_state].remove(state2)
					self.transitions[from_state][to_state].add(state1)
		#finally, since state2 is inaccessible, remove it
		self.transitions.pop(state2)
	
	# === Transition functions ===
	
	def move_all(self, agents, symbol):
		out = set()
		for agent in agents:
			out = out.union(self.transition(agent, symbol))
		return out
	
	def transition(self, agent, symbol):
		return self.epsilon_close(self.delta(agent, symbol))
	
	def delta(self, agent, symbol):
		if symbol not in self.transitions[agent.state]:
			return set()
		glomb = agent.epsilon_glomb if symbol is epsilon else agent.glomb
		out = set()
		for new_state in self.transitions[agent.state][symbol]:
			out.add(glomb(new_state))
		return out
	
	def epsilon_close(self, data_set):
		old_set = data_set
		data_set = self.epsilon_delta(data_set)
		while data_set != old_set:
			old_set = data_set
			data_set = self.epsilon_delta(data_set)
		return data_set
	def epsilon_delta(self, data_set):
		out = data_set
		for data in data_set:
			out = out.union(self.delta(data, epsilon))
		return out
	
	def __str__(self): #SPIFFY
		return '\n'.join({"* {0}: {1}".format(state,
					', '.join({"{0} -> {1}".format(symbol, self.transitions[state][symbol])
						for symbol in self.transitions[state]}))
					for state in self.transitions})


class Agent:
	"""Immutable object (by convention anyway) to help organize agents
	travelling throught a transition table. They hold both current state
	information as well as information on where in a string it is matched.
	
	An agent should be used with only one transition table and for only one
	input string."""
	def __init__(self, state, start=0, end=0):
		self.state = state
		self.start_index = start
		self.end_index = end
	
	def __str__(self):
		return ("<Agent: state {0}; {1}-{2}>".format(self.state, self.start_index, self.end_index))
	def __repr__(self):
		return str(self) #HAX

	def glomb(self, new_state=None):
		return Agent(
			self.state if new_state is None else new_state,
			self.start_index, self.end_index + 1
		)
	def epsilon_glomb(self, new_state=None):
		return Agent(
			self.state if new_state is None else new_state,
			self.start_index, self.end_index)
	
	def __eq__(self, other):
		return (self.state == other.state
				and self.start_index == other.start_index
				and self.end_index == other.end_index)
	def __hash__(self):
		return 3*self.state + 13*self.start_index + 7*self.end_index








class BackreferenceData: #MAYBE we don't actually need backreferences, just take advantage of metadata
	def __init__(self, initial_data=None):
		self.data = dict() if initial_data is None else initial_data
	
	def glomb(self, key, symbol):
		out = {k:self.data[k][:] for k in self.data}
		if key not in out:
			out[key] = []
		out[key].append(symbol)
		return BackreferenceData(out)
	
	def __eq__(self, other):
		if not isinstance(other, self.__class__):
			return False
		if self.data.keys() != other.data.keys():
			return False
		for key in self.data:
			if self.data[key] != other.data[key]:
				return False
		else:
			return True
	def __hash__(self):
		hash = 0
		for key in self.data:
			hash += 2*key.__hash__()
		return 5*len(self.data) + hash
	
	def __str__(self):
		return str(self.data)
	def __repr__(self):
		return repr(self.data)
