class _RXConst:
	pass

kleene_star = _RXConst()
expr = _RXConst()
end = _RXConst()
alt = _RXConst()

epsilon = _RXConst()