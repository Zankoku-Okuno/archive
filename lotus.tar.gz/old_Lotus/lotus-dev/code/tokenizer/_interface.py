from pasta_parser.behavoiralism.deciders import *
from pasta_parser.behavoiralism.behavoirs import *

def make_driver(dict):
	return ModalDecider(
		{ k: FirstMatchDecider(*dict[k]) for k in dict }
	)


def mode_changer(stimulus, mode):
	return LocatedBehavoir(stimulus,
				lambda syntax, state: state.start_to_enter_mode(syntax, mode),
				lambda syntax, state: state.finish_entering_mode(syntax, mode))
def mode_exiter(stimulus):
	return LocatedBehavoir(stimulus,
				lambda syntax, state: state.start_to_exit_mode(syntax),
				lambda syntax, state: state.finish_exiting_mode(syntax))

def change_mode(stimulus, mode):
	return Anticipation(stimulus,
						lambda syntax, state: state.enter_mode(syntax, mode))
def exit_mode(stimulus):
	return Anticipation(stimulus,
						lambda syntax, state: state.exit_mode(syntax))

def default_buffer():
	return Behavoir("_DEFAULT", lambda syntax, state: state.buffer(syntax))
def default_nothing():
	return Behavoir("_DEFAULT", lambda syntax, state: None)
	

def flush():
	return lambda syntax, state: state.flush()