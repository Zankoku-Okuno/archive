from pasta_parser.nested_tokenizer import NestedTokenizer
from ._interface import *

driver = make_driver({
	'whitespace': (
		mode_changer("_LINE_COMMENT", 'line'),
		default_nothing()
	),
	'line': (
		exit_mode("_NEWLINE"),
		default_nothing()
	)
})

evolve = { 0: flush() }
exit = { 0: flush() }


#TODO get this working along with phonemes
#def phoneme_examiner(syntax, state):
#	if state.phoneme_depth is 0:
#		state.phoneme_depth += 1
#		state.phoneme = resolve_phoneme(syntax)
#	elif state.phoneme_depth is 1:
#		if state.phoneme.can_have_suffix(resolve_phoneme(syntax)):
#			state.phoneme_depth += 1
#			state.phoneme = resolve_phoneme(syntax)
#	if state.phoneme == resolve_phoneme(syntax):
#		state.buffer(syntax)
#	else:
#		state.flush(start=state.pop_location(), end=state.location(), type='token')
#		state.phoneme_depth = 0
#		state.phoneme = None
	
	