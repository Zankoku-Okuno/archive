import fileinput
from parser.exceptions import *
import os
from functools import reduce

if __name__ == '__main__':
	testfile = 'testModule/testSubmodule/test.lotus'
	try:
		cwd = os.getcwd()
		sendin = os.path.join(cwd, testfile)
		# getting the file tracker up and running
		from parser.file_tracker import *
		lotus = get_lotus(sendin)
		print("\nCompiling: '{0}' in".format(lotus.file), lotus.dir)
		# mapping the watershed
		lotus.map_watershed()
		def module_trace(visit):
			return module_trace(visit.module)+', '+visit.file if visit.module else visit.file
		print('\nIn modules:', module_trace(lotus))
		print('Importing:', reduce(lambda x,y: x.file+', '+y.file, lotus.tributaries))
		#determining opwords
		print('\nOpwords:')
		{ print("\t{0}\t{1}".format(x.operandA, x.operandB)) for x in lotus.get_opwords().opwords }
		#extracting strings and comments
		lotus.extract_strings_and_comments()
		print('\nExtraction Phase:')
		for lexeme in lotus.lexemes:
					print("{0} {1}:\n{2}".format((lexeme.line, lexeme.col), type(lexeme).__name__, lexeme.content))
		#examining whitespace
			#TODO
			#in this phase, we examine the unknown code again
			#we identify and extract any keywords
			#we split whitespace-separated characters into possible tokens
			#we keep track of tab structure, using it to determine blocks and statements
	except CompoundLotusError as ce:
		print("Multiple Errors:\n{0}".format(ce))
	except LotusParserError as e:
		print('{0}: {1}'.format(type(e).__name__, e))























atomizeFiles = ['testModule/testSubmodule/test.lotus']

if False:
	
	from seed.file_tracker import *
	p = get_lotus(os.path.join(os.getcwd(), 'testModule/testSubmodule/test.lotus'))
	p.map_watershed()
	print(p.path)
	print('\t', p.module.path, [x.file for x in p.tributaries])
	print('\t', {x[len(os.getcwd()):] for x in all_files.keys()})
	p.get_opwords()
	print('{0} opwords:'.format(len(p.scanner.knownMatches)))
	for match in p.scanner.knownMatches:
		print("\tMatched at line {0} in file {1}:\n\t   {2}".format(match.line, match.file, match))
	
	
	
	exit(0)
	
	from seed.atomizer import Atomizer
	
	try:
		for atomizer in Atomizer(atomizeFiles).next_phase():
			print()
			print()
			
			if atomizer.phase == 1:
				print("Immediate Matches:")
				if atomizer.scanner.knownMatches:
					for match in atomizer.scanner.knownMatches:
						print("\tMatched at line {0} in file {1}:\n\t   {2}".format(match.line, match.file, match))
				else: print("None")
				print("Deferred Matches:")
				if atomizer.scanner.unknownMatches:
					for match in atomizer.scanner.unknownMatches:
						print("\tMatched at line {0} in file {1}:\n\t   {2}".format(match.line, match.file, match))
				else: print("None")
				print("Stale Matches:")
				if atomizer.scanner.staleMatches:
					for match in atomizer.scanner.staleMatches:
						print("\tMatched at line {0} in file {1}:\n\t   {2}".format(match.line, match.file, match))
				else: print("None")
			
			elif atomizer.phase == 2:
				for lexeme in atomizer.extractor.lexemes:
					print("{0} {1}	{2}".format(lexeme.lineno, lexeme.lexeme_type, lexeme.content))
			
			elif atomizer.phase == 3:
				pass
			
			elif atomizer.phase == 4:
				pass
			
			else: assert False, "The testing class called the phases wrong."
	
	except CompoundLotusError as ce:
		print("Multiple Errors:\n{0}".format(ce))
	except LotusParserError as e:
		print('{0}: {1}'.format(type(e).__name__, e))
		
	
	#try:
	#	atoms = Atomizer()
	#	
	#	with fileinput.input(files=atomizeFiles) as files:
	#		for line in files:
	#			atoms.scan_phase(line, files.filename(), files.lineno())
	#	print()
	#	print("Succesful Matches:")
	#	if atoms.matches:
	#		for match in atoms.matches:
	#			print("Matched at line {1} in file {2}:\n\t{0}".format(match.context, match.line, match.file))
	#	else: print("None")
	#	print()
	#	print("Unexpained Matches:")
	#	if atoms.unexplainedMatches:
	#		for match in atoms.unexplainedMatches:
	#			print("Matched at line {1} in file {2}:\n\t{0}".format(match.context, match.line, match.file))
	#	else: print("None")
	#	print()
	#	
	#	atoms.stringPhase__init__()
	#	
	#	print("After String Phase:")
	#	with fileinput.input(files=atomizeFiles) as files:
	#		for line in files:
	#			atoms.string_phase(line, files.filename(), files.lineno())
	#	atoms.string_phase("", None, None)
	#	
	#	for lexeme in atoms.FSM.lexemes:
	#		print("{0} {1}	{2}".format(lexeme.lineno, lexeme.lexeme_type, lexeme.content))
	#
	#except LotusParserError as e:
	#	print(type(e).__name__ + ': ' + e.args[0])
	
	
	
	
