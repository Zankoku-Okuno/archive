import unittest
from unittests.machines import *
from unittests.tree import *
from unittests.matcher import *
from unittests.tokenizer import *

unittest.main()