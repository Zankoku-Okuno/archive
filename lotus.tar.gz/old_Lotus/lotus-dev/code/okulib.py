def progn(*expressions):
	out = None
	for expression in expressions:
		out = expression()
	return out