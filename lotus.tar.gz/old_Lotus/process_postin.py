class PostNode:
	def __init__(self, process, left=None, right=None):
		self.data = process
		self.l = left
		self.r = right
		self.posted = False
		self.steering = False
	
	def post(self, process):
		"Marks the object as flagging. Once flagging, cannot unflag itself."""
		if process == self.data:
			self.posted = True
		else:
			if process < self.data:
				self.l.post(obj)
			elif process > self.data:
				self.r.post(obj)
			#So the steering propagates upwards
			self.steering = True
	
	def search(self):
		"""Searches through the tree depth-first for posted objects."""
		out = []
		if self.steering:
			#On the other hand, search propagates downwards
			self.steering = False
			if self.l is not None: out += self.l.search()
			if self.r is not None: out += self.r.search()
		if self.posted:
			out += [self.data]
			self.posted = False
		return out


# There is a one-to-one relationship between process and posted flag, so
# competing processes cannot conflict. The flag may only be written while the
# process is awake, after which the process imediately sleeps. The flag may only
# be unset by the monitor, which immediately schedules the flag (well, after
# some shuffling through its own, private memory space, but that's immediate
# enough for multitasking).

# After a search is made, all found processes are scheduled, and another search
# is not made while scheduling occurs. Thus, it is groups of proceses that are
# scheduled at a time, ensuring that low-priority processes do not starve. (If B
# is low priority, the higher-priority A & C cannot lock it out by making
# multiple requests, since B is scheduled once per scheduling of A&/C)

# About steering, we nees to think about when a post and search cross each
# other.
#  Let's say a search is in progress but then a post overtakes it down one of
# its branches. There will be steering flags above where the paths crossed, The
# search wil follow the new steering to find the new post. After all is said and
# done, we're left with some excess steering.
#  Let's say a post is in progress when a search overtakes it. The current post
# may have traced back to the serach's path or not. 1) If so, the case is as
# above. 2) If not, the the new post will not be found by the search, but the
# search will not modify any of the flags that the post has just set, nor will
# it reset any flags above it (including any flags the post might modify) 

#  About wake-ups: a secretary thread will have to keep track of incoming wake
# requests in a counter. The secretary is initially awake. While awake, if its
# counter increases, it increments the Janitor's counter by draining its own
# counter (making use of a temporary variable so data isn't corrupted). After
# dealing with the counters, it sleeps (though its counter may still increase
# while asleep).
#  When the Janitor wakes, it subtracts its leftover (stored in a "found"
# counter from its own incoming counter. It then searches, and each found
# increases its found counter. It then schedules the processes and wakes the
# first process in line (the key will pass down the line on its own), decrements
# the found counter by the incoming counter and resets incoming. Finally, it
# wakes its secretary and sleeps (though it may still recieve posts while
# sleeping).

# There's one final problem: we only need to keep track of the processes that
# actually access the resource (that will keep monitor overhead to a minimum).
# We should let the secretary accept registrations. The secretary will make
# appropriate changes to the tree structure due to new registrations before
# sending on requests from registered processes. Thing is, posting to the tree
# may need to be disabled as well (if we need to rebalance the tree). TODO: so
# we really do need a proper lock when a registration needs to be made. This
# does have to be solved anyway, just in case fo forking.

# Also, we should augment the whole thing with a general secretary that keeps
# track of processes that only have one accessor. As long as only one process is
# dealing with the object, the proces can keep the key, but as soon as a second
# process enters the mix, the general secretary should set up a new janitor for
# the resource and let the old process know it should pass the key on.

#Thing is, how do we ensure the linked list is okay: I've been thinking build it
#backwards, but that strategy doesn't allow updates to be made later, not to
#mention it can be inefficient (especially if a queue builds up in the main
#monitor). A better way would be to simply leave the lock with the last object
#that used it. The lock only moves when there is a request on it. The monitor is
#simply there to serialize requests.


