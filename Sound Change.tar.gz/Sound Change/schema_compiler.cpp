class schema_compiler
{
    public:
    //CONSTRUCTORS
        schema_compiler();
        
    //RUNTIME
        //void get_feature(unsigned feature);
        //void set_feature(unsigned feature, bool value);
        unsigned phone_size() const;
        unsigned decode(const string& feature);//this ought to be const, but map[point] is not const, and I can't figure out a way areound it
        vector<bool> set_feature(unsigned feature, bool val);
        
    //COMPILE-TIME
        void compile(istream& in);
        void finalize();

    //TESTING METHODS
        void TEST_print();
        
    //FIELDS
    private:
        bool finalized;
        
        unsigned last_muex;
        map<string, unsigned> feature_sorter;
        vector<unsigned> muex_ends;
        vector<string> link_memory;
        
        map<string, unsigned> muex_decoder;     //this turns user-readable muex names into ints that reference a position+1 in the muex_definer
        map<string, unsigned> feature_decoder;  //this turns user-readable feature names into ints that reference a position; for use later in the compiler
        vector<bool> supers;
        vector<bool> subs;
    
    //HELPERS
        uint dec(const string& feature);
};

schema_compiler::schema_compiler()
{
    last_muex = 0;
    finalized=false;
}



unsigned schema_compiler::phone_size() const
{
    return muex_ends[muex_ends.size()-1];
}

unsigned schema_compiler::decode(const string& feature)
{
    return dec(feature);
}

unsigned schema_compiler::set_feature(unsigned feature)
{
    //TODO
    //create a vector<bool> which is a copy of the original phone
    //find which muex the feature is in, then go through the vec setting everything to zero (prolly calling unset feature so that supers/subs also get set 0)
    //set the requested feature to 1, then check supers/subs
    return 0;
}

//TODO unset_feature






void schema_compiler::compile(istream& in)
{
    if(finalized) throw exception(/*Phone Schema is already finalized and cannot be modified!*/);
    string s;
    unsigned editing;
    while(true){
        getline(in, s, '\n');
        stringstream muex_line;     //certainly there's a way to let the stream know it's gotten more stuff?
        muex_line << s;
        if(in.eof()) break;
        
        getline(muex_line, s, '=');
        if(s=="LINK") {
            muex_line << endl;
            getline(muex_line, s);
            //cout << "found " << s << endl;
            link_memory.push_back(s); continue;
        }
        if(muex_decoder[s]==0) muex_decoder[s] = ++last_muex;       //let's ensure the muex can be decoded before going any further
        editing = muex_decoder[s];                                                          //and then decode it, since we're about to edit it
        
        while(true){                                        //so let's go sort out the given features
            getline(muex_line, s, ' ');
            if (muex_line.eof()) break;
            if(feature_sorter[s]!=0)                //don't allow a second definition on the same name!
                throw exception(/*"Compiler Error!\tFeature " + s + " already defined."*/);
            feature_sorter[s]=editing;          //and let's get the feature into sorting for later
        }
    }
}

void schema_compiler::finalize()
{
    if(finalized) throw exception(/*Phone Schema is already finalized and cannot be finalized again!*/);
    //we need to figure out where the endpoints of each muex is in the final phone description array
    unsigned num_muexes = muex_decoder.size();
    muex_ends = vector<unsigned>(num_muexes);
    for(map<string,unsigned>::iterator i = feature_sorter.begin(), e=feature_sorter.end(); i != e; ++i)
        ++muex_ends[(i->second)-1];
    for(unsigned i = 1; i !=num_muexes; ++i)
        muex_ends[i]+=muex_ends[i-1];
    //we need to build the feature decoder, which will map a string feature name to a position in the phone description vector
    vector<unsigned> indexes(num_muexes);
    unsigned second;
    for(map<string,unsigned>::iterator i = feature_sorter.begin(), e=feature_sorter.end(); i != e; ++i)
    {
        second = i->second;
        if (second==0) throw exception(/*A feature has been mapped to an invalid muex.*/);
        --second;
        feature_decoder[i->first] = ++indexes[second] + (second==0?0:muex_ends[second-1]);
    }
    //let's set-up the link memory
    uint phone_size = muex_ends[muex_ends.size()-1];
    for(uint i = 0; i < phone_size*phone_size; ++i){
        supers.push_back(false);
        subs.push_back(false);
    }
    //we need to figure out what features are super-features of what sub-features
    string s;
    uint decSup, decSub;
    for(vector<string>::iterator i = link_memory.begin(), e=link_memory.end(); i!=e; ++i)
    {
    
        stringstream link(*i);
        getline(link, s, ' ');
        
        if (link.eof()) throw exception(/*Syntax Error: Empty LINK!*/);
        cout<<"linking " << *i << "\n";
        decSup = dec(s);
        while(true){                                        //so let's go sort out the given features
            getline(link, s, ' ');
            if (link.eof()) break;
            decSub = dec(s);
            supers[phone_size*decSub+decSup] = true;
            subs[phone_size*decSup+decSub] = true;
        }
    }
    
    
    finalized = true;
    
    
    cout << endl << "SCHEMA TEST" <<endl;
    for(map<string,unsigned>::iterator i = muex_decoder.begin(), e=muex_decoder.end(); i != e; ++i)
        cout << ':' << i->first << " ends at " << muex_ends[(i->second)-1] << endl;
    
    cout<<"Features:";
    for(map<string,unsigned>::iterator i = feature_decoder.begin(), e=feature_decoder.end(); i != e; ++i)
        cout << ' ' << i->first << '(' << dec(i->first) <<')';
    cout << endl << "Supers:";
    for(uint i = 0; i < supers.size(); ++i){
        if (i%phone_size==0) cout<<"\n\t";
        cout << supers[i];
    }
    cout << endl << "Subs:";
    for(uint i = 0; i < subs.size(); ++i){
        if (i%phone_size==0) cout<<"\n\t";
        cout << subs[i];
    }
    cout << endl;
}

void schema_compiler::TEST_print()
{
    cout << "TESTING\n";
    for(map<string,unsigned>::iterator i = muex_decoder.begin(); i !=muex_decoder.end(); ++i)
        cout << (i->first) << " compiled to " << (i->second) << endl;
    cout << endl;
    for(map<string,unsigned>::iterator i = feature_sorter.begin(); i !=feature_sorter.end(); ++i)
        cout << (i->first) << " goes in " << (i->second) << endl;
}

unsigned schema_compiler::dec(const string& feature)
{
    uint outPlus = feature_decoder[feature];
    if(outPlus==0) throw exception(/*That feature is undefined!*/);
    return outPlus-1;
}