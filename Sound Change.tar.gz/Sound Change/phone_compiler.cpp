class phone_compiler
{
    public:
        phone_compiler(const schema_compiler& schema_comp);
        void compile(istream& in);
    private:
        unsigned phone_size, last_phone;
        schema_compiler schema;
        
        map<string, unsigned> phone_decoder;    //maps a string phone name to a position+1; use the return-1 multiplied by phone_size to get offset in the phone+features
        vector<bool> phone_features;    //the data for all the phones is in a massive flat container, you'll have to adjust your start position, then read off
        set<string> multigraph_starts;       //conatins all and only those strings which are the initial section of a multigraph
};


phone_compiler::phone_compiler(const schema_compiler& schema_comp)
{
    last_phone=0;
    schema = schema_comp;
    phone_size = schema.phone_size();
    for(uint i = 0; i < phone_size; ++i)
        phone_features.push_back(true);
}

void phone_compiler::compile(istream& in)
{
    string s;
    while(true)
    {
        getline(in, s, '\n');
        if (in.eof()) break;
        stringstream phone;
        phone << s;
        getline(phone, s, '=');
        if (phone_decoder[s]!=0) throw exception(/*Compiler error! You can't define the same phone twice.*/);
        //TODO add functionality for recognizing initial segments of multigraphs
        for(int e = s.size(); --e!= 0;)
            multigraph_starts.insert(s.substr(0,e));
        
        unsigned offset = (++last_phone)*phone_size;
        phone_decoder[s]=last_phone;
        for(unsigned i = 0; i!=phone_size; ++i) phone_features.push_back(false);
        while(true)
        {
            getline(phone, s, ' ');
            if (phone.eof()) break;
            //cout << "got feature " << s << offset+schema.decode(s) << '\t';
            phone_features[offset+schema.decode(s)] = true;
        }
    }   
    
    //TESING STUFF
    cout << endl << "PHONES TEST" << endl;
    cout<< "Phone size = " << phone_size << " bits"<<endl <<"Phone definitions: ";
    for(uint i = 0; i != phone_features.size(); ++i)
    {
        if (i!=0&&i%phone_size==0) cout << '|';
        cout << phone_features[i];
    }
    cout << endl << "Phones List:";
    for(map<string,uint>::const_iterator i = phone_decoder.begin(), e=phone_decoder.end(); i!=e; ++i)
        cout << ' ' << i->first << '(' << i->second << ')';
    cout << endl << "Initial sections of multigraphs:";
    for(set<string>::const_iterator i = multigraph_starts.begin(), e=multigraph_starts.end(); i!=e; ++i)
        cout << ' ' << *i;
    cout << endl;
    
}