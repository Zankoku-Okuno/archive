void preprocess(istream& in, ostream& out);
void preprocess1(istream& in, ostream& out);
void preprocess2(istream& in, ostream& out);

void preprocess(istream& in, ostream& out)
{
    stringstream s1, s2, s3;
    preprocess1(in, s1);
    preprocess2(s1, out);
}

void splitter(istream& in, ostream& schema, ostream& phones)
{
    string s;
    int state = 0; //1=schema, 2=phones
    while(true){
        getline(in, s, '\n');
        if (in.eof()) break;
        else if(s=="__SCHEMA") state = 1;
        else if(s=="__PHONES") state = 2;
        else if(state!=0){
            if (state==1) schema << s << '\n';
            if(state==2) phones << s << '\n';
        }
    }
}

void preprocess1(istream& in, ostream& out)
{
    string str;
    while(true)
    {
        getline(in, str);
        if(in.eof()) break;
        out << str << '\n';
    }
}

void preprocess2(istream& in, ostream& out)
{
    char check;
    int processing = -1; //-1=start, 0=determining processor, 1=processor determined , 10=schema, 20=rules
    string p, check2;
    int state = 0;  //0=standard, 1=whitespace, 2=newline, 3=equalsFound
    while(true)
    {
        if(processing==1)
        {
            //cout << "found processor " << p << endl;
            if (p=="__SCHEMA") processing = 10;
            if (p=="__PHONES") processing = 20;
            state = 2;
        }
        in.get(check);
 /*       check2 = "";
        check2 = check==' ' ? "space" : (check=='\t' ? "tab" : (check=='\n' ? "newl" : (check2.push_back(check),check2)));
        cout << "read\t" << check2 << "\t" << processing << '_' << state << endl;
 */    
        if (in.eof()) break;
        if (check=='\r') {}
        else if (processing==0) {
            if(check=='\n') processing=1;
            if (check!=' '&&check!='\t') {
                out<<check;
                if(check!='\n') p.push_back(check);
            }
        }
        else if (check=='_') {processing = 0; p = '_'; out << ((state==2||state==-1)?"_":"\n_");}
        else if (processing==10)        //SCHEMA PROCESSING
        {
            if (state==2) {
                if (check=='=') state=3;
                if (check!=' '&&check!='\t'&&check!='\n') {out << check;}
            }
            else if (state==3){
                if (check!=' '&&check!='\t'&&check!='\n') {out << check; state=0;}
            }
            else if(check==' '||check=='\t'){
                if (state==0) out << ' ';
                state = 1;
            }
            else if(check=='\n')
            {
                if (state==0) out << ' ';
                if (state!=2) out << '\n';
                state = 2;
            }
            else {
                out << check;
                state = 0;
            }
        }
        else if (processing ==20)       //PHONES PROCESSING
        {
            if (state==2) {
                if (check=='=') state=3;
                if (check!=' '&&check!='\t'&&check!='\n') {out << check;}
            }
            else if (state==3){
                if (check!=' '&&check!='\t'&&check!='\n') {out << check; state=0;}
            }
            else if(check==' '||check=='\t'){
                if (state==0) out << ' ';
                state = 1;
            }
            else if(check=='\n')
            {
                if (state==0) out << ' ';
                if (state!=2) out << '\n';
                state = 2;
            }
            else {
                out << check;
                state = 0;
            }
        }
        
        //FOR MORE PROCESSORS
        
    }
    if (state!=2) out << '\n';
}