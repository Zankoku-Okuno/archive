
using namespace std;

typedef unsigned uint;


#include<iostream>
#include<sstream>
#include<string>
#include<map>
#include<set>
#include<vector>
#include<exception>
#include"preprocessor.cpp"
#include"schema_compiler.cpp"
#include"phone_compiler.cpp"

///THESE ARE FOR TESTING PURPOSES
#include<fstream>
///END TESTING PURPOSE INCLUDES

int main(void)
{
    cout << "Running...\n############\n";
    fstream file("testProg.txt");
    stringstream processed;
    preprocess(file, processed);
    /*string print;
    while(true)
    {
        getline(processed, print);
        if (processed.eof()) break;
        cout << print << endl;
    }*/
    
    file.close();
    
    stringstream schema, phones;
    splitter(processed, schema, phones);
    
    schema_compiler comp;
    comp.compile(schema);
    comp.finalize();
    phone_compiler comp2(comp);
    comp2.compile(phones);
    
    cout << "\n############\nFinished!\n";
    return 0;/*
    
    stringstream s1, s1a;
    stringstream s2, s2a;
    s1 << "__SCHEMA" << endl << "POA=bilabial\tlabiodental"<< endl << "VOICING=voiced unvoiced creaky " << endl << "POA=dental alveolar postalveolar " << endl;
    s1a<< "__PHONES" << endl <<"f=unvoiced labiodental "<<endl <<"v=voiced labiodental "<<endl<<"dh=alveolar creaky "<< endl;
    
    
    phone_schema_compiler comp;
    preprocess(s1, s2);
    cout << "PREPROCESS FINISHED!" <<endl;
    comp.compile(s2);
    //comp.TEST_print();
    comp.finalize();
    cout << "\nfound labiodental at " << comp.decode("labiodental") << endl;
    cout << "found voiced at " << comp.decode("voiced") << endl;
    cout << "found unvoiced at " << comp.decode("unvoiced") << endl;
    cout << "found creaky at " << comp.decode("creaky") << endl;
    cout << "found alveolar at " << comp.decode("alveolar") << endl;
    
    //return 0;
    
    preprocess(s1a, s2a);
    cout << "PREPROCESS FINISHED!" <<endl;
    phone_compiler comp2(comp);
    comp2.compile(s2a);
    
    return 0;*/
}