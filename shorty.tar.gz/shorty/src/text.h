#ifndef __SHORTY_TEXT_H__
#define __SHORTY_TEXT_H__


/* Low-level operations. */
char peek();
char look(size_t at);
char pop();
void consume(size_t advance);

/* Mid-level lookahead functions. */
int is_lookahead(const char* expect);
char* extract(size_t len);

/* High-level utility functions. */
int grab_lookahead(const char* kw);

//TODO file, line, column reporters


/* Character classification. */
//REFAC to the parser module?
static inline int is_id_start(char x) {
    return (('a' < x) & (x < 'z'))
         | (('A' < x) & (x < 'Z'))
         | (x == '_');
}
static inline int is_id(char x) {
    return (('a' < x) & (x < 'z'))
         | (('A' < x) & (x < 'Z'))
         | (('0' < x) & (x < '9'))
         | (x == '_');
}
static inline int is_whitespace(char x) {
    return (x == ' ') | (x == '\t') | (x == '\n');
}

#endif