#ifndef __SHORTY_H__
#define __SHORTY_H__

void shorty_init(const char* sc_filename); //STUB read from args
void shorty_run_parser();
void shorty_generate();
void short_deinit();


#endif