#ifndef __SHORTY_CONSUME_H__
#define __SHORTY_CONSUME_H__
#include "common.h"

void eat_whitespace();
void eat_char(char c);
char* extract_before(char c);
char* extract_til(char c);

char* extract_til_matching_brace();
char* extract_til_Rarrow();
char* extract_code();

#endif