#ifndef __SHORTY_MODE_H__
#define __SHORTY_MODE_H__


typedef void (*Mode)();

void init_mode();

void push_mode(Mode next);
void pop_mode();

/* Perform one parsing step. */
void step_mode();

#endif