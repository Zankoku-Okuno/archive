#ifndef __SHORTY_MACHINE_H__
#define __SHORTY_MACHINE_H__
#include "mode.h"



/* State behavoir functions. */
void ready();

/* Parsers */
void parse_module();
void parse_import();
void parse_var();
void parse_fun();
void parse_typedef();
void parse_struct();

//ready state (can pick up new keywords)
//interior state (reading some id-compat thing, so no kws get picked up)
//comment states
//this may be all I need until I have more complex parsing

//I can add nice things here, like machines to extract brace-delimited whatevs
//also, things to test&consume keywords all at once, consume whitespace



#endif