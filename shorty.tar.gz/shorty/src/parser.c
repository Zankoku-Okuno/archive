#ifndef __SHORTY_MACHINE_C__
#define __SHORTY_MACHINE_C__
#include "common.h"
#include "mode.h"
#include "consume.h"

void shorty_run_parser() {
	init_mode(ready);
    while(peek()) step_mode();
}


void ready() {
    assert(peek());

    if (grab_lookahead("module")) parse_module();
    else if (grab_lookahead("import")) parse_import();
    //TODO flag
    //TODO val
    else if (grab_lookahead("var")) parse_var();
    else if (grab_lookahead("fun")) parse_fun();
    else if (grab_lookahead("typedef")) parse_typedef();
    //TODO enum
    else if (grab_lookahead("struct")) parse_struct();
    //TODO union
    //TODO variant
    //TODO class
    else if (grab_lookahead("extern")) {
        eat_whitespace();
        set_linkage(1);
        //TODO change mode to only accept definitions
    }
    else if (grab_lookahead("intern")) {
        eat_whitespace();
        set_linkage(0);
        //TODO change mode to only accept definitions
    }
    //TODO what to do with apparent preprocessor commands?
    //TODO comments (might contain documentation)
    //TODO a passthrough syntax to write straight C code (but where does it get slot in?)
    //TODO module initializer
    //TODO unittests
    else
        pop(); //STUB
}


/* Module parsing. */
void parse_module() {
    eat_whitespace();
    set_module_name(extract_til(';'));
}
void parse_import() {
    eat_whitespace();
    add_import(extract_til(';'));
}

/* Object definition parsing. */
void parse_var() {
    eat_whitespace();
    exitwhen {
        for(size_t i = 0; look(i); ++i)
            if (look(i) == ';') goto nodef;
            else if (look(i) == '=') goto def;
        fprintf(stderr, "Syntax Error: expected ';' or '='\n");
        abort();
    whenexit(nodef)
        add_var(extract_til(';'), NULL);
    whenexit(def)
        char* declaration = extract_til('=');
        if (peek() == '{') {
            unreachable; // STUB
        }
        else add_var(declaration, extract_til(';'));
    } done;
}
void parse_fun() {
    eat_whitespace();
    char* name = extract_til('=');
    char* params =
        /*if*/(peek() == '>') ? (
            pop(),
            eat_whitespace(),
            "void"
        )
        /*else*/: extract_til_Rarrow();
    char* retType = extract_before('{');//TODO extract_before_fun(); //goes before {, in{, out{ or body{
    if(1){//if (peek() == '{') {
        char* codeblock = extract_code();
        add_func(name, params, retType, codeblock);
    }
    else {
        unreachable;
        //if (grab_lookahead("in")) ...
        //if (grab_lookahead("out")) ...
        //if (grab_lookahead("body")) ...
        //else error
        //TODO pre/postconditions
    }
}

/* Type definition parsing. */
void parse_typedef() {
    eat_whitespace();
    char* name = extract_til('=');
    exitwhen {
        for(size_t i = 0; look(i); ++i)
            if (look(i) == ';') goto basic;
            else if (look(i) == '=') goto function;
        fprintf(stderr, "Syntax Error: expected ';' or '='\n");
        abort();
    whenexit(basic)
        add_type(name, extract_til(';'), NULL);
    whenexit(function)
        char* params = extract_til_Rarrow();
        add_type(name, params, extract_til(';'));
    } done;
}

void parse_struct() {
    eat_whitespace();
    exitwhen {
        for(size_t i = 0; look(i); ++i)
            if (look(i) == ':') goto inherits;
            else if (look(i) == '{') goto basetype;
        fprintf(stderr, "Syntax Error: expected '{' or ':' in struct definition.\n");
        abort();
    whenexit(basetype)
        char* name = extract_til('{');
        char* definition = extract_til_matching_brace();
        add_struct(name, NULL, definition);
    whenexit(inherits)
        unreachable;
    } done;
}



#endif