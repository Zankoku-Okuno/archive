#ifndef __SHORTY_IO_C__
#define __SHORTY_IO_C__
#include "common.h"


FILE* h_file = NULL,
    * c_file = NULL;

void init_io() {
    deinit_io();
    h_file = fopen("test/delme.h", "w"); //STUB
    c_file = fopen("test/delme.c", "w"); //STUB
}
void deinit_io() {
    if (h_file) { fclose(h_file); h_file = NULL; }
    if (c_file) { fclose(c_file); c_file = NULL; }
}
/* Returns unique pointer to malloc'd string. */
char* filename2string(const char* filename) {
    FILE* infile = fopen(filename, "r");
    if (infile == NULL) {
        fprintf(stderr, "io.c:22 -- file not found: %s\n", filename);
        abort(); //TODO or were there permissions errors?
    }

    const size_t CHUNK_SIZE = 1024;
    // Initialize.
    char* acc = enforce(malloc(CHUNK_SIZE*sizeof(char)));
    size_t buffer_size = CHUNK_SIZE, writehead = 0;
    do {
        assert(buffer_size % CHUNK_SIZE == 0);
        assert(writehead % CHUNK_SIZE == 0);
        // Read chunk size and increment our string writehead until we reach the end of the file.
        size_t chunk_read_amt = fread(acc + writehead, sizeof(char), CHUNK_SIZE, infile);
        writehead += chunk_read_amt;
        if (chunk_read_amt < CHUNK_SIZE) break;
        // If our writehead is going to move beyond our allocated space, make more space.
        if (writehead == buffer_size) {
            buffer_size *= 2;
            acc = enforce(realloc(acc, buffer_size * sizeof(char)));
        }
    } while(1);
    // Calculate where our string ends and null-terminate it.
    acc[writehead+1] = '\0';
        
    fclose(infile);
    return acc;
}


void hchar(char in) { fprintf(h_file, "%c", in); }
void hputs(const char* in) { fprintf(h_file, "%s", in); }
void cchar(char in) { fprintf(c_file, "%c", in); }
void cputs(const char* in) { fprintf(c_file, "%s", in); }


#endif