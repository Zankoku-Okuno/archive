#ifndef __SHORTY_SYMBOL_H__
#define __SHORTY_SYMBOL_H__


void init_symbol(); //TODO may need to add include directories


void set_linkage(int flag);
void set_module_name(char* name);
void add_import(char* x);
void add_var(char* declaration, char* definition);
void add_func(char* name, char* params, char* retType, char* code);

void add_type(char* name, char* def, char* retType);
void add_struct(char* name, char* super_name, char* fields);



#endif
