#ifndef __SHORTY_COMMON_H__
#define __SHORTY_COMMON_H__
//TODO get rid of this!
#define _GNU_SOURCE

#include <assert.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "strutil.h"
#include "io.h"
#include "text.h"
//module imports
//generate
#include "symbol.h"
#include "parser.h"

static inline void* enforce(void* in) {
    if (in) return in;
    fprintf(stderr, "Out of memory.\n");
    abort();
}

#define exitwhen do
#define whenexit(l) break; l:;
#define done while(0)

#define unreachable do { fprintf(stderr, "%s:%d -- unreachable code\n", __FILE__, __LINE__); abort(); } while(0)

#endif