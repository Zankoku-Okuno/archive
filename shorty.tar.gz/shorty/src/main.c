

#include "shorty.h"







int main(int argc, char** argv) {
    shorty_init("test/delme.sc"); //STUB read from args
    shorty_run_parser();
    shorty_generate();
    // short_deinit();
    return 0;

    // init_text("delme.sc");
    // run_parser();
    // init_io(); //STUB read from args
    // generate();
    // deinit_io();
    // return 0;
}