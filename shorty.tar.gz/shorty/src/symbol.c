#ifndef __SHORTY_SYMBOL_C__
#define __SHORTY_SYMBOL_C__
#include "common.h"

#define ADD_THING(type, name, params, ...) \
    static type all_##name##s = NULL;\
    static size_t num_##name##s = 0, max_##name##s = 32;\
    void add_##name params {\
        if (all_##name##s == NULL)\
            all_##name##s = enforce(malloc(max_##name##s*sizeof(char*)));\
        if (num_##name##s == max_##name##s)\
            all_##name##s = enforce(realloc(all_##name##s, (max_##name##s *= 2)*sizeof(char*)));\
        __VA_ARGS__\
    }

static int linkage = 1;
void set_linkage(int flag) { linkage = flag ? 1 : 0; }

/* Store module name. */
static char* module_name = NULL;
void set_module_name(char* name) {
    //TODO validate name syntax
    if (module_name) abort(); //TODO report error
    module_name = name;
}

/* Store imports. */
ADD_THING(char**, import, (char* x), 
    //TODO validate name syntax
    //TODO check against double imports
    all_imports[num_imports++] = x;
)

/* Store typedefs. */
typedef struct {
    char* name;
    char* definition;
    char* returnType;
    int linkage;
} TypedefInfo;
ADD_THING(TypedefInfo*, type, (char* name, char* def, char* retType), 
    //TODO validate name syntax
    //TODO check against double definitions
    TypedefInfo x = {name, def, retType, linkage}; linkage = 1;
    all_types[num_types++] = x;
)

/* Store variables. */
typedef struct {
    char* declaration;
    char* definition;
    int linkage;
} VarInfo;

ADD_THING(VarInfo*, var, (char* declaration, char* definition),
    assert(declaration);
    //TODO check declaration syntax
    VarInfo x = {declaration, definition, linkage}; linkage = 1;
    all_vars[num_vars++] = x;
)

/* Store functions. */
typedef struct {
    char* name;
    char* params;
    char* returnType;
    char* codeblock;
    int linkage;
} FuncInfo;
ADD_THING(FuncInfo*, func, (char* name, char* params, char* retType, char* code),
    //TODO validate
    FuncInfo x = {name, params, retType, code, linkage}; linkage = 1;
    all_funcs[num_funcs++] = x;
)


/* Store structure definitions. */
typedef struct {
    char* name;
    char* super;
    char* fields;
    int linkage;
} StructInfo;

ADD_THING(StructInfo*, struct, (char* name, char* super_name, char* fields),
    //TODO check against double definitions
    //TODO check super name exists (at some point?)
    //TODO default initializers
    StructInfo x = { name, super_name, fields, linkage }; linkage = 1;
    all_structs[num_structs++] = x;
)

//TODO
// const char* declare_struct(const char* name);
// const char* define_struct_fields(const char* name);

void gen_header_includes() {
    for(size_t i = 0; i < num_imports; ++i) {
        hputs("#include ");
        if (all_imports[i][0] != '<') hchar('"');
        for(char* c = all_imports[i]; *c != '\0'; ++c)
            if (*c == '.') hchar('/');
            else if (*c == '>') continue;
            else hchar(*c);
        hputs(".h");
        if (all_imports[i][0] != '<') hputs("\"\n");
        else hputs(">\n");
    }
}
void gen_header_typedefs() {
    for(size_t i = 0; i < num_types; ++i) if (all_types[i].linkage) {
        if (all_types[i].returnType) {
            hputs("typedef "); hputs(all_types[i].returnType);
            hputs(" (*"); hputs(all_types[i].name); hputs(")(");
            hputs(all_types[i].definition); hputs(");\n");
        }
        else {
            hputs("typedef "); hputs(all_types[i].definition); hchar(' ');
            hputs(all_types[i].name); hputs(";\n");
        }
    }
}
void gen_header_forward_decls() {
    for(size_t i = 0; i < num_structs; ++i) {
        hputs("typedef struct "); hputs(all_structs[i].name); hchar(' ');
        hputs(all_structs[i].name); hputs(";\n");
    }
    //TODO
}
void gen_header_structs() {
    for(size_t i = 0; i < num_structs; ++i) if (all_structs[i].linkage) {
        hputs("struct "); hputs(all_structs[i].name); hputs(" {\n");
        if (all_structs[i].super) unreachable; //TODO
        hputs(all_structs[i].fields); hputs("\n};\n");
    }
}
void gen_header_vars() {
    for(size_t i = 0; i < num_vars; ++i) if (all_vars[i].linkage) {
        hputs("extern "); hputs(all_vars[i].declaration); hputs(";\n");
    }
}
void gen_header_functions() {
    for(size_t i = 0; i < num_funcs; ++i) if (all_funcs[i].linkage) {
        hputs(all_funcs[i].returnType); hchar(' '); hputs(all_funcs[i].name);
        hchar('('); hputs(all_funcs[i].params); hputs(");\n");
    }
}
void gen_header() {
    char* module_macro = strdup(module_name);
    for(char* c = module_macro; *c != '\0'; ++c)
        if (('a' <= *c) & (*c <= 'z'))
            *c -= 'a' - 'A';
        else if ((*c < 'A') | ('Z' < *c)) *c = '_';
    hputs("#ifndef __"); hputs(module_macro); hputs("_H__\n");
    hputs("#define __"); hputs(module_macro); hputs("_H__\n");
    hchar('\n');
    gen_header_includes();
    hchar('\n');
    gen_header_typedefs();
    gen_header_forward_decls();
    hchar('\n');
    gen_header_structs();
    hchar('\n');
    //TODO typedefs, struct/union defs
    hchar('\n');
    gen_header_vars();
    hchar('\n');
    gen_header_functions();
    hchar('\n');
    hputs("#endif");
}


void gen_transunit_typedefs() {
    for(size_t i = 0; i < num_types; ++i) if (!all_types[i].linkage) {
        if (all_types[i].returnType) {
            cputs("typedef "); cputs(all_types[i].returnType);
            cputs(" (*"); cputs(all_types[i].name); cputs(")(");
            cputs(all_types[i].definition); cputs(");\n");
        }
        else {
            cputs("typedef "); cputs(all_types[i].definition); cchar(' ');
            cputs(all_types[i].name); cputs(";\n");
        }
    }
}
void gen_transunit_structs() {
    for(size_t i = 0; i < num_structs; ++i) if (!all_structs[i].linkage) {
        cputs("struct "); cputs(all_structs[i].name); cputs(" {\n");
        if (all_structs[i].super) unreachable; //TODO
        cputs(all_structs[i].fields); cputs("\n};\n");
    }
}
void gen_transunit_vars() {
    for(size_t i = 0; i < num_vars; ++i) {
        if (!all_vars[i].linkage) cputs("static ");
        cputs(all_vars[i].declaration);
        if (all_vars[i].definition && all_vars[i].definition[0] != '{') {
            cputs(" = ");
            cputs(all_vars[i].definition);
        }
        //TODO emit initialization code
        cputs(";\n");
    }
}
void gen_transunit_functions() {
    for(size_t i = 0; i < num_funcs; ++i) {
        if (!all_funcs[i].linkage) cputs("static ");
        cputs(all_funcs[i].returnType); cchar(' '); cputs(all_funcs[i].name);
        cchar('('); cputs(all_funcs[i].params); cputs(") ");
        cputs(all_funcs[i].codeblock); cchar('\n');
    }
}
void gen_transunit() {
    cputs("#include \""); 
    for(char* c = module_name; *c != '\0'; ++c)
        if (*c == '.') cchar('/');
        else cchar(*c);
    cputs(".h\"\n\n");
    gen_transunit_typedefs();
    cchar('\n');
    gen_transunit_structs();
    cchar('\n');
    gen_transunit_vars();
    cchar('\n');
    gen_transunit_functions();
    hchar('\n');
}
void gen_scifile() {
    //STUB
}

void shorty_generate() {
    init_io();
    gen_header();
    gen_transunit();
    gen_scifile();
    deinit_io();
}


#endif