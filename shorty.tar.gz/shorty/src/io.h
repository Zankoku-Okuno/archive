#ifndef __SHORTY_IO_H__
#define __SHORTY_IO_H__


void init_io();
void deinit_io();


char* filename2string(const char* filename);


void hchar(char in);
void hputs(const char* in);
void cchar(char in);
void cputs(const char* in);
//TODO functions to read/write .sci files




#endif