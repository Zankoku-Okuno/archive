/** \file strutil.h

Provides commonly-used string handling and manipulation functions beyond that supported 
by the standard library.

    \author Okuno Zankoku
    \date 2013
    \copyright 3-clause BSD
*/
#ifndef __SHORTY_STRUTIL_H__
#define __SHORTY_STRUTIL_H__
#include <stddef.h>

/**
 * Supports efficiently building strings incrementally.
 */
typedef struct {
    /** \privatesection */
    char* out; //Memoryspace for storing the built string.
    //High-speed (fewer malloc calls) buffer and fill amount.
    //Used when appending characters one-at-a-time.
    char* buf;
    size_t buflen;
} StrBuffer;

/** Allocates and initializes a new \c StrBuffer from the heap.
    \memberof StrBuffer
    \return unique pointer to a \c StrBuffer, or \c NULL if allocation failed.
*/
StrBuffer* strbuf_new();

/** Initializes resources for an existing \c StrBuffer.
    \memberof StrBuffer
    \sideeffect clear the buffer
*/
void strbuf_init(StrBuffer* this);

/** Destroys resources for this, but does not destroy the buffer itself. 
    \memberof StrBuffer
    \sideeffect clear the buffer
*/
void strbuf_del(StrBuffer* this);

/** Destroys this and all its resources.
    \memberof StrBuffer
*/
void strbuf_free(StrBuffer* this);

/** Append a single character.
    \memberof StrBuffer
*/
void strbuf_char(StrBuffer* this, char in);

/** Append a copy of a string.
    \memberof StrBuffer
*/
void strbuf_str(StrBuffer* this, const char* in);

/** Get a reference to the string so far.
    \memberof StrBuffer
    \return Only a view is given.
            Any updates to the buffer will modify the view, and vice-versa.
            The view owns no resources, and should therefore not be free'd.
*/
const char* strbuf_view(StrBuffer* this);

/** Get a unique pointer to the string built so far.
    \memberof StrBuffer
    \sideeffect clear the buffer
*/
char* strbuf_get(StrBuffer* this);

/** Modify an string by appending a second string.
    \param[out] base
    \param[in] append
    \sideeffect the base string is extended so that its suffix is equal to \c append
*/
void strappend(char** base, const char* append);
//TODO get rid of the GNU reliance by implementing a strndup

#endif