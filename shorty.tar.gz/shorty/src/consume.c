#ifndef __SHORTY_CONSUME_C__
#define __SHORTY_CONSUME_C__
#include "common.h"

void eat_whitespace() {
    while (is_whitespace(peek())) pop();
}
void eat_char(char c) {
    eat_whitespace();
    if (peek() == c) pop();
    else { fprintf(stderr, "Syntax Error: expected '%c'\n", c); abort(); }
    eat_whitespace();
}

char* extract_before(char c) {
    //FIXME keep strings outta this
    size_t i;
    for (i = 0; look(i) != c; ++i);
    for (--i; is_whitespace(look(i)); --i);
    char* out = extract(++i);
    eat_whitespace();
    return i ? out : strdup("");
}
char* extract_til(char c) {
    //FIXME keep strings outta this
    size_t i;
    for (i = 0; look(i) != c; ++i);
    for (--i; is_whitespace(look(i)); --i);
    char* out = extract(++i);
    eat_char(c);
    return i ? out : strdup("");
}

static void extract_matching(char open, char close, StrBuffer* collector) {
    int depth = 1;
    while (depth) {
        if (peek() == '{') ++depth;
        else if (peek() == '}') --depth;
        else if (peek() == '\"') {} //TODO
        else if (peek() == '\'') {} //TODO
        else if (peek() == '/') {
            strbuf_char(collector, pop());
            if (peek() == '/') {} //TODO
            else if (peek() == '*') {} //TODO
        }
        if(depth > 0) strbuf_char(collector, pop());
    }
}
char* extract_til_matching_brace() {
    StrBuffer buf; strbuf_init(&buf);
    extract_matching('{', '}', &buf);
    pop(); eat_whitespace();
    char* out = strbuf_get(&buf);
    strbuf_del(&buf);
    return out;
}
char* extract_code() {
    eat_whitespace();
    if(peek() != '{') { fprintf(stderr, "Syntax Error: expected '{'\n"); abort(); }
    StrBuffer buf; strbuf_init(&buf); strbuf_char(&buf, pop());
    extract_matching('{', '}', &buf);
    strbuf_char(&buf, pop());
    eat_whitespace();
    char* out = strbuf_get(&buf);
    strbuf_del(&buf);
    return out;
}

char* extract_til_Rarrow() {
    char* out = extract_til('=');
    if (peek() == '>') pop();
    else { fprintf(stderr, "Syntax Error: expected '=>'\n"); abort(); }
    eat_whitespace();
    return out;
}

#endif