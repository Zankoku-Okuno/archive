#ifndef __SHORTY_MODE_C__
#define __SHORTY_MODE_C__
#include "common.h"

const size_t MODE_STEP = 10;

static Mode* mode_base = NULL;
static size_t top = 0;
static size_t extent = 0;

void init_mode(Mode start) {
	mode_base = enforce(malloc(MODE_STEP*sizeof(Mode)));
	extent = MODE_STEP;
	mode_base[0] = start;
}

void push_mode(Mode next) {
	if (++top == extent)
		mode_base = enforce(realloc(mode_base, (extent+MODE_STEP)*sizeof(Mode)));
	mode_base[top] = next;
}
void pop_mode() {
	assert(top > 0);
	--top;
}

void step_mode() {
	mode_base[top]();
}

#endif