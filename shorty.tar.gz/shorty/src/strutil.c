#ifndef __SHORTY_STRUTIL_C__
#define __SHORTY_STRUTIL_C__
//FIXME move enforce so we don't need common.h, just libzan/whatevs
#include "common.h"
#include "strutil.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

enum { BUF_SIZE = 32 };
StrBuffer* strbuf_new() {
    StrBuffer* out = enforce(malloc(sizeof(StrBuffer)));
    strbuf_init(out);
    return out;
}
void strbuf_init(StrBuffer* b) {
    b->out = NULL;
    b->buf = enforce(malloc(BUF_SIZE*sizeof(char)));
    b->buflen = 0;
}
void strbuf_del(StrBuffer* b) {
    if (b->buf) { free(b->buf); b->buf = NULL; }
    if (b->out) { free(b->out); b->out = NULL; }
}
void strbuf_free(StrBuffer* b) {
    strbuf_del(b);
    free(b);
}

void strbuf_flush(StrBuffer* b) {
    assert(b->buflen < BUF_SIZE);
    b->buf[b->buflen] = '\0';
    strappend(&b->out, b->buf);
    b->buflen = 0;
}
void strbuf_char(StrBuffer* b, char in) {
    assert(b->buflen < BUF_SIZE-1);
    b->buf[b->buflen++] = in;
    if (b->buflen == BUF_SIZE-1) strbuf_flush(b);
}
void strbuf_str(StrBuffer* b, const char* in) {
    if (b->buflen > 0) strbuf_flush(b);
    assert(b->buflen == 0);
    strappend(&b->out, in);
}
const char* strbuf_view(StrBuffer* b) {
    strbuf_flush(b);
    return b->out;
}
char* strbuf_get(StrBuffer* buf) {
    strbuf_flush(buf);
    char* out = buf->out;
    buf->out = NULL;
    return out;
}



void strappend(char** s, const char* a) { //OPTZ can't I use realloc here? just be more careful w/ memory?
    char* old = *s;
    if (old == NULL) {
        char* new = enforce(malloc((strlen(a)+1)*sizeof(char)));
        strcpy(new, a);
        *s = new;
    }
    else {
        size_t old_length    = strlen(old),
               append_length = strlen(a);
        char* new = enforce(malloc((old_length+append_length+1)*sizeof(char)));
        strncpy(new, old, old_length);
        strncpy(new+old_length, a, append_length);
        new[old_length+append_length] = '\0';
        *s = new;
        free(old);
    }
}

#endif