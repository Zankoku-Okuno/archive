#ifndef __SHORTY_TEXT_C__
#define __SHORTY_TEXT_C__
#define _GNU_SOURCE
#include "common.h"


/* ====== Shorty Input ====== */
struct {
    char* base;
    char* stop;
    size_t loc;
} sc = { NULL, NULL, 0 };

/* Tracking current location in source. */
size_t line   = 0,
       column = 0;


char peek() {
    char out = sc.base[sc.loc];
    assert(out != '\r' || sc.base[sc.loc-1] != '\n');
    return (out == '\r') ? '\n' : out;
}
char look(size_t at) {
    char out = (sc.base + sc.loc + at) < sc.stop ? sc.base[sc.loc+at] : '\0';
    if (out == '\r' && sc.loc > 0 && sc.base[sc.loc-1] == '\n') return look(at+1);
    return (out == '\r') ? '\n' : out;
}
char pop() {
    if (sc.base+sc.loc >= sc.stop) return '\0';
    char out = sc.base[sc.loc++];
    if (out == '\n') {
        ++line, column = 1;
        if (sc.base[sc.loc] == '\r') ++sc.loc;
    }
    else if (out == '\r') ++line, column = 1;
    else ++column;
    return (out == '\r') ? '\n' : out;
}
void consume(size_t advance) {
    if (sc.base+sc.loc < sc.stop) sc.loc += advance;
    else sc.loc = sc.stop - sc.base;
}


int is_lookahead(const char* expect) {
    size_t len = strlen(expect);
    for (size_t i = 0; i < len; ++i)
        if (look(i) != expect[i]) return 0;
    return 1;
}
char* extract(size_t len) {
    if (sc.base+sc.loc+len > sc.stop)
        len = (size_t)sc.stop - (size_t)(sc.base+sc.loc);
    char* out = strndup(sc.base+sc.loc, len);
    consume(len);
    return out;
}


int grab_lookahead(const char* kw) {
    if (!is_id_start(peek())) return 0;
    size_t len = strlen(kw);
    assert(len);
    if (is_lookahead(kw) & !is_id(look(len))) {
        consume(len);
        return 1;
    }
    else return 0;
}


/* ====== Initializer ====== */

void shorty_init(char* infile) { //REFAC so a different shorty_init delegates to a text_init?
    sc.base = filename2string(infile);
    sc.stop = sc.base + strlen(sc.base);
    sc.loc = 0;
}


#endif