Shorty
======

A simple way to write less verbose C.

It's actually not too hard to write object-oriented C. The problem is you'll be doing your own name-mangling, and there will be a lot of boiler-plate. Shorty is a preprocessor that produces C output from a simple (mostly pass-through) input file. For more bang per buck, Shorty produces .h files as well as .c files, so there's no need to pre-declare everything.

Yeah, it's essentially C-with-classes, but this time without the language bloat. I will admit, you will have to dig through the C output if you have compiler errors, since shorty does not attempt to parse C. OTOH, if you input good-looking shorty, you should get good-looking C. It might also be possible more long-term to impose a code formatter between C generation and output.

Features
--------

Automatic generation of header files from source. No more redundant, mechanical forward declarations!

Structures are statically-typed, non-polymorphic, but they do get single-inheritance, if you're willing to upcast.

Classes are statically-typed, multiple-dispatch, multiple-inheritance beasts. It's not your normal C-code, but damn if it isn't useful from time-to-time.

Unified module system, including renaming of imported functions.

Literate programming in LaTeX, and possibly HTML.

It'd be nice to support true algebraic data types, but if it ends up being too library-driven, I may not go with it. I can at least support a simple variant syntax, and that may be enough (for C <.<)

Ideas
-----
Ability to pass by "reference". The number one downside of -> is that it's an awkward sequence of keystrokes, and I'd like to cut down on that. Under the hood, references are pointers, but dots on shorty references turn into C arrows.

Tuples: anon structs that just compose

Properties for classes. Possibly "myobj@myfield" === "sc__D7myfeild(myobj.mro)(myobj)". For assignment, maybe use "myobj@&myfield" to return address, then you can set it. OTOH, that would also break encapsulation, so... well, I'm working on it. It may be possible to just use the python underscore convention.

I'm working on a way to expand function overloading to a larger domain. I have a way to make it work with classes, and I may be able to extend that method to structures that define some standardized RTTI.

I want to support lambdas and closures (because fuck yeah!)

Special unittest and debug blocks. Programming by contract.

Fix array syntax and add multi-dimensional arrays.

Scheme-esque interpreter to handle macros.

Cool syntax like foreach, for...then...else, loop...until/while, auto-breaking cases (unless fallthrough), and anything else I can think of. Perhaps even <- and = vs. = and ==.

UTF-8
