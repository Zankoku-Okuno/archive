module Language.L3.Grammar where

import Data.Ratio
import Data.Maybe
import Data.List
import Control.Applicative


type Nat = Int
type Natural = Integer
type Name = String
type Region = Maybe Name

data Value = SVal Integer -- ^ signed integers
           | UVal Natural -- ^ unsigned integers
           | FVal Rational -- ^ floating point numbers

data Type = NatTy Nat
          | IntTy Nat
          | FloTy Nat
          | BitsTy Nat
          | AddrTy Region

data Loc = Imm Value
         | Reg Name
         | Var Name
         | Stack Loc
         | Mem Region Loc
         | Indirect { indirectReg :: Loc
                    , indirectMult :: Nat
                    , indirectOffset :: Int
                    }
         | AddrOf Loc


data Decl = VarDecl Name Type
          | ParamDecl Nat Name Type
          | FreeParams -- ^ size of var params on stack may be available
           -- | Cache { cacheTo :: Name, cacheFrom :: Loc }

data Instr = Move { moveTo :: Loc, moveFrom :: Loc }
           | Compute { storeTo :: [Loc], instr :: Name, instrArgs :: [Loc] }
           | Goto Name
           | Call { callStore :: Maybe Loc
                  , callTo :: Loc
                  , callArgs :: [Loc]
                  , callConv :: Maybe Name -- ^ calling convention
                  }
           | Jump { jumpTo :: Loc
                  , jumpArgs :: [Loc]
                  , jumpConv :: Maybe Name -- ^ calling convention
                  }
           | Ret (Maybe Loc) (Maybe Name)
           | Cond { condition :: [Condition], condElse :: Block }
           | Scope Block

data Condition = Condition { condTest :: Name, condArgs :: [Loc], condDo :: Block }

data Block = Block (Maybe Name) [Decl] [Instr]


data Definition = Initialize { initAddr :: Name, initData :: [Value] }
                | Reserve { reserveAddr :: Name, reserveObjSize :: Nat, reserveNumObjs :: Nat }
                | Proc { procName :: Name, isInline :: Bool, isExported :: Bool, procBody :: Block }
                | Require FilePath

newtype TopLevel = TopLevel [Definition]



instance Show Value where
    show (SVal i) | i < 0 = show i
                  | otherwise = '+':show i
    show (UVal n) = show n
    show (FVal f) = show f

instance Show Type where
    show (NatTy size) = "Nat" ++ show size
    show (IntTy size) = "Int" ++ show size
    show (FloTy size) = "Float" ++ show size
    show (BitsTy size) = "Bits" ++ show size
    show (AddrTy Nothing) = "Addr"
    show (AddrTy (Just region)) = "Addr[" ++ region ++ "]"

instance Show Loc where
    show (Imm val) = show val
    show (Reg name) = '$':name
    show (Var name) = name
    show (Stack loc) = "@(" ++ show loc ++ ")"
    show (Mem Nothing loc) = "@[" ++ show loc ++ "]"
    show (Mem (Just name) loc) = "@[" ++ name ++ " : " ++ show loc ++ "]"
    show (Indirect loc mul off) = mult ++ core ++ offset
        where
        mult = if mul == 1 then "" else show mul ++ "*"
        core = "[" ++ show loc ++ "]"
        offset | off < 0 = show off
               | 0 < off = '+':show off
               | off == 0 = ""
    show (AddrOf loc) = '&':show loc

instance Show Decl where
    show (VarDecl name ty) = "var " ++ name ++ "(" ++ show ty ++ ");"
    show (ParamDecl n name ty) = "@" ++ show n ++ ": " ++ name ++ "(" ++ show ty ++ ");"
    show FreeParams = "@...;"

instance Show Instr where
    show (Move to from) = show to ++ " <= " ++ show from ++ ";"
    show (Compute to instr args) = concat
        [ intercalate ", " (show <$> to), if null to then "" else " <- "
        , instr, " "
        , intercalate " " (show <$> args)
        , ";" ]
    show (Goto to) = "goto " ++ to ++ ";"
    show (Call store_m to args conv_m) = concat
        [ maybe "_" show store_m, " <- "
        , "call", maybe "" (\x -> "(" ++ x ++ ")") conv_m, " "
        , show to, " ", intercalate " " (show <$> args)
        , ";" ]
    show (Jump to args conv_m) = concat
        [ "jump", maybe "" (\x -> "(" ++ x ++ ")") conv_m
        , " ", show to, " "
        , intercalate " " (show <$> args)
        , ";" ]
        where
        showConv = maybe "" (\x -> "(" ++ x ++ ")") conv_m
    show (Ret val_m conv_m) = concat
        [ "ret", maybe "" (\x -> "(" ++ x ++ ")") conv_m
        , maybe "" (\x -> " " ++ show x) val_m
        , ";"]
    show (Cond arms elseArm) = intercalate "\n    " (show <$> arms) ++ "\n    else " ++ show elseArm
    show (Scope block) = show block

instance Show Condition where
    show (Condition test args block) = concat
        [ "if ", test, " ", intercalate " " (show <$> args), ";\n    "
        , "then ", show block]

instance Show Block where
    show (Block label_m decls instrs) = concat
        [ showLabel, "{"
        , concat $ ("\n    "++) <$> (show <$> decls) ++ (show <$> instrs)
        , "\n    }" ]
        where
        showLabel = case label_m of
            Nothing -> ""
            Just label -> label ++ ": "

instance Show Definition where
    show (Initialize name vals) = undefined --STUB
    show (Reserve name objSize numObjs) = concat
        [ "alloc ", name, " {", show objSize, " * ", show numObjs, "};" ]
    show (Proc name inl exp body) = concat
        [ if exp then "export\n" else ""
        , if inl then "inline\n" else ""
        , "proc ", name, ": "
        , show body
        ]
    show (Require filepath) = "require " ++ show filepath

instance Show TopLevel where
    show (TopLevel xs) = intercalate "\n" (show <$> xs)