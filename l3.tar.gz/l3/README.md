L3
==

L<sup>3</sup> is a Low-Level Language. It is designed for systems programming but is *not* an assembler. L<sup>3</sup> allows full access to the registers and stack, it has concepts luch as variables, scope, `if` and function calls, and also performs simple optimizations (such as propagation and folding). The compiler is designed to be easily re-targetable to new platforms and architectures. L<sup>3</sup> is especially meant for use as an intermediate language and for implementing runtime systems.

Why not a high-level language? High-level languages don't let the programmer manipulate the stack or registers. Many require a large runtime system, which is usually unacceptable when you are writing your own runtime.

Why not assembly? Assembly is not standardized, not cross-platform, and not cross-architecture. Failure to optimize manually results in poorly-performing programs, even though in many cases optimization by the assembler would be acceptable.

Why not C? C has nearly no runtime, and it allows some stack and register manipulation. However, register manipulation is limited, and the ability to manipulate the stack is dependent on inline assembly, which is not standardized. In many ways, it is the worst of both worlds.

Why not LLVM? Although LLVM is an excellent optimizer, it does not have full control over the stack: it is committed to C-like stack frames. Although a custom calling convention can hack around the problem, a first-class stack is the only way to ensure full generality.